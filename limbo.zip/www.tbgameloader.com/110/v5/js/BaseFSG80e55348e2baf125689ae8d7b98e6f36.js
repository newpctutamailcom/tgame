(function(n) {
    var l = n.Laya;
    var r = l.AppContext,
        u = l.ArrayUtils,
        x = l.BaseMain,
        U = l.BaseScene;
    var t = l.BaseView,
        e = l.Box,
        h = l.Browser,
        H = l.Button,
        G = l.CheckBox,
        F = l.ChipSettingView;
    var d = l.CommonUtils,
        P = l.CustomErrorMaster,
        a = l.Dispatcher,
        V = l.DolAnimation;
    var W = l.DolButton,
        K = l.DolPool,
        i = l.DynamicMessage,
        Y = l.ErrorShower;
    var s = l.Event,
        o = l.FairSimpleGameDto,
        z = l.FairSimpleMyBetDto;
    var c = l.GameContext,
        Q = l.GameEnum,
        m = l.GlobalConfig,
        X = l.GlobalEnum;
    var j = l.GlobalEvent,
        J = l.GlobalSoundEnum,
        _ = l.Handler,
        b = l.HitArea;
    var Z = l.HttpManager,
        g = l.Image,
        q = l.ImageNumber,
        $ = l.Label,
        tt = l.List;
    var et = l.MsgMaster,
        it = l.Node,
        st = l.Panel,
        nt = l.PaytableView,
        S = l.Radio;
    var p = l.Rectangle,
        f = l.SceneManager,
        C = l.SoundManager,
        I = l.SoundUtils;
    var ht = l.Sprite,
        E = l.StringUtils,
        N = l.TcpLogicManager,
        at = l.TcpManager;
    var lt = l.TextInput,
        B = l.TweenLite;
    n.BaseFSG = {};
    BaseFSG.Base = {};
    class w {
        constructor() {
            this.numArr = [500, 200, 100, 50, 10, 2, 1];
            this.pathArr = [r.Instance.ModuleName + "/common/common/ui/img_b_09.png", r.Instance.ModuleName + "/common/common/ui/img_b_08.png", r.Instance.ModuleName + "/common/common/ui/img_b_07.png", r.Instance.ModuleName + "/common/common/ui/img_b_06.png", r.Instance.ModuleName + "/common/common/ui/img_b3_1.png", r.Instance.ModuleName + "/common/common/ui/img_b2_1.png", r.Instance.ModuleName + "/common/common/ui/img_b1_1.png"];
            this.popResultHasTwoConfirmButton = false;
            this.init()
        }
        init() {}
        getResultSkinPath(t = 1) {
            var e = this.pathArr[this.pathArr.length - 1];
            for (var i = 0; i < this.numArr.length; i++) {
                if (t >= this.numArr[i]) {
                    return this.pathArr[i]
                }
            }
            return e
        }
    }
    BaseFSG.Base.BaseGameUtils = l.BaseGameUtils = w;
    class ot extends x {
        constructor() {
            super()
        }
        InitApp() {
            super.InitApp();
            N.Instance.InitTcpLogic();
            r.Instance.GameKind = 2
        }
    }
    BaseFSG.Base.BaseFSGMain = l.BaseFSGMain = ot;
    class rt extends U {
        constructor() {
            super();
            this.viewPool = new K;
            this.init();
            if (this.GameUtilsClass) {
                r.GameUtils = new this.GameUtilsClass
            }
        }
        baseInit(t) {
            super.baseInit(t);
            this.setUIPathByName("GameScene")
        }
        init() {
            super.init()
        }
        createUI() {
            super.createUI()
        }
        init() {
            this.GameUtilsClass = w
        }
        registeEvent() {
            super.registeEvent();
            a.on("MFG_STATUS_CHANGE", this, this.onStatusChanged, 3);
            a.on("NC_USERINFO_CLICK", this, this.showUserInfo, 3);
            a.on("NC_USERINFO_CHANGEHEAD", this, this.showHeadList, 3);
            a.on("NC_SHOW_GAMELIMIS", this, this.showGameLimits, 3);
            a.on("NC_SHOW_CHECKROUN_SEED", this, this.showCheckSeed, 3);
            a.on("NC_SHOW_DETAILED_RULES", this, this.showDetailedRules, 3);
            a.on("NC_SHOW_GREEN_RULES", this, this.showGreenDetailed, 3);
            a.on("NC_SHOW_LOADING", this, this.showLoading, 3);
            a.on("NC_SHOW_SHA", this, this.showShaView, 3);
            a.on("NC_FSG_START", this, this.doFSGStart, 3);
            a.on("NC_FSG_OVER", this, this.doFSGOver, 3);
            a.on("NC_FSG_NEXT", this, this.doFSGNext, 3);
            a.on("NC_FSG_OPE_CALLBACK", this, this.doOpeCallback, 3);
            a.on("TCP_GET_READY_FINISH", this, this.onGetReady, 3);
            a.on("NC_SHOW_POP", this, this.showPop, 3);
            a.on("NC_SHOW_ANIMATION", this, this.showAnimation, 3);
            a.on("NC_HIDE_ANIMATION", this, this.hideAnimation, 3)
        }
        onGetReady() {}
        doFSGNext() {}
        doFSGStart(t, e) {}
        doFSGOver(t, e) {}
        doOpeCallback(t, e) {}
        onEnter() {
            super.onEnter();
            I.Instance.playMusicInGame("bg_music");
            this["viewHeader"] && (this["viewHeader"].zOrder = 6);
            this["viewBet"] && (this["viewBet"].zOrder = 1);
            this["viewSha"] && (this["viewSha"].zOrder = 7);
            this["viewLoading"] && (this["viewLoading"].zOrder = 4);
            this["viewResult"] && (this["viewResult"].zOrder = 3);
            this["viewBetInfo"] && (this["viewBetInfo"].zOrder = 2);
            this["viewAnimation"] && (this["viewAnimation"].zOrder = 8);
            this.showLoading(false);
            l.timer.frameOnce(1, this, this.showShaView, [false]);
            this.onResize();
            l.stage.on(s.RESIZE, this, this.onResize);
            this["viewAnimation"] && (this["viewAnimation"].visible = false)
        }
        onResize() {
            this["imgBG"] && (this["imgBG"].width = l.stage.realDesignWidth);
            this["imgBG"] && (this["imgBG"].height = l.stage.realDesignHeight);
            if (this.isHor) {} else {
                this["viewHeader"] && (this["viewHeader"].y = (1900 - l.stage.realDesignHeight) / 2)
            }
        }
        onExit() {
            super.onExit()
        }
        onStatusChanged() {}
        showUserInfo(t = true) {
            if (t) {
                var e = new r.Instance.UserInfoClass;
                this.addChild(e);
                e.zOrder = 100
            } else {
                this.userInfo.removeSelf()
            }
        }
        showHeadList() {
            var t = new R;
            this.addChild(t);
            t.zOrder = 100;
            t.y = 30
        }
        showGameLimits(t = true) {
            var e = new M;
            this.addChild(e);
            e.zOrder = 100
        }
        showPop(t) {
            var e = new t;
            this.addChild(e);
            e.zOrder = 100
        }
        showCheckSeed(t = true) {
            var e = new r.Instance.CheckRoundSeedClass;
            this.addChild(e);
            e.zOrder = 100
        }
        showDetailedRules() {
            var t = new L;
            this.addChild(t);
            t.zOrder = 100
        }
        showGreenDetailed() {
            var t = new k;
            this.addChild(t);
            t.zOrder = 100
        }
        showLoading(t) {
            this["viewLoading"] && (this["viewLoading"].visible = t)
        }
        showShaView(t) {
            this["viewSha"] && (this["viewSha"].visible = t)
        }
        showAnimation() {
            this.showAni(true)
        }
        hideAnimation() {
            this.showAni(false)
        }
        showAni(t) {
            this["viewHeader"] && (this["viewHeader"].visible = !t);
            this["viewBet"] && (this["viewBet"].visible = !t);
            this["viewSha"] && (this["viewSha"].visible = !t);
            this["viewResult"] && (this["viewResult"].visible = !t);
            this["viewBetInfo"] && (this["viewBetInfo"].visible = !t);
            this["viewAnimation"] && (this["viewAnimation"].visible = t)
        }
    }
    BaseFSG.Base.BaseGameScene = l.BaseGameScene = rt;
    BaseFSG.Base.View = {};
    class ut extends e {
        constructor() {
            super();
            this.view = new v;
            this.addChild(this.view);
            this.size(this.view.width, this.view.height)
        }
    }
    BaseFSG.Base.View.BetViewCellItem2 = l.BetViewCellItem2 = ut;
    class dt extends e {
        constructor() {
            super();
            this.view = new r.Instance.ResultCellClass;
            this.addChild(this.view);
            this.size(this.view.width, this.view.height)
        }
    }
    BaseFSG.Base.View.ResultViewCellItem = l.ResultViewCellItem = dt;
    BaseFSG.Base.UI = {};
    class ct extends S {
        constructor(t = null, e = "") {
            super(t, e);
            this.NORMAL_SCALE = 1;
            this.SELECTED_SCALE = 1;
            this.imgShine = new g(r.Instance.ModuleName + "/game/img_chip.png")
        }
        onEnable() {
            super.onEnable();
            this.imgShine.anchorX = .5;
            this.imgShine.anchorY = .5;
            this.imgShine.x = this.width / 2;
            this.imgShine.y = this.height / 2;
            this.addChild(this.imgShine);
            this.imgShine.visible = this.selected;
            this.refreshScale()
        }
        onMouse(t) {
            super.onMouse(t);
            if (t.type === s.MOUSE_OVER) {
                this.scale(this.SELECTED_SCALE, this.SELECTED_SCALE, true)
            } else if (t.type == s.MOUSE_OUT) {
                this.refreshScale()
            }
        }
        refreshScale() {
            var t = this.selected ? this.SELECTED_SCALE : this.NORMAL_SCALE;
            this.scale(t, t, true)
        }
        get selected() {
            return super.selected
        }
        set selected(t) {
            super.selected = t;
            this.imgShine.visible = this.selected;
            this.refreshScale()
        }
    }
    BaseFSG.Base.UI.BetRadio = l.BetRadio = ct;
    class mt extends S {
        constructor(t = null, e = "") {
            super(t, e);
            this.NORMAL_POSY = 0;
            this.SELECTED_POSY = 0
        }
        onEnable() {
            super.onEnable();
            this.refreshPosY()
        }
        onMouse(t) {
            super.onMouse(t);
            if (t.type === s.MOUSE_OVER) {} else if (t.type == s.MOUSE_OUT) {
                this.refreshPosY()
            }
        }
        refreshPosY() {
            var t = this.selected ? this.SELECTED_POSY : this.NORMAL_POSY;
            this.pos(this.x, t, true)
        }
        get selected() {
            return super.selected
        }
        set selected(t) {
            super.selected = t;
            this.refreshPosY()
        }
    }
    BaseFSG.Base.UI.MoveBetRadio = l.MoveBetRadio = mt;
    class y extends t {
        constructor() {
            super();
            this._selected = false;
            this.btnSkin1 = r.Instance.ModuleName + "/%s/common/ui/img_frame01_01.png";
            this.btnSkin2 = r.Instance.ModuleName + "/%s/common/ui/img_frame01_02.png";
            this.imgSkin1 = r.Instance.ModuleName + "/%s/common/ui/btn_choose_01.png";
            this.imgSkin2 = r.Instance.ModuleName + "/%s/common/ui/btn_choose_02.png"
        }
        baseInit(t) {
            super.baseInit(t);
            this._uiPath = "GameUI/Common/View/AutoNumberCell"
        }
        createUI() {
            super.createUI()
        }
        registeEvent() {
            super.registeEvent();
            this.registeAllButton()
        }
        onButtonClick(t) {
            switch (t) {
                case "btn":
                    console.log(this._data);
                    a.dispatch("NC_FSG_CELL_SELECTED", [this]);
                    break
            }
        }
        onEnable() {
            super.onEnable();
            this.fresh()
        }
        onLoad() {
            super.onLoad()
        }
        setDto(t, e = false) {
            this._data = t;
            this._selected = e;
            if (this.ViewCreated) {
                this.fresh()
            }
        }
        changeSelected(t = false) {
            var e = d.getPCOrMobilePath(this);
            this._selected = t;
            if (this._selected) {
                this.btn && (this.btn.disabled = true);
                this.img && (this.img.skin = E.format(this.imgSkin2, e))
            } else {
                this.btn && (this.btn.disabled = false);
                this.img && (this.img.skin = E.format(this.imgSkin1, e))
            }
        }
        fresh() {
            if (this._data) {
                if (this._data.lang != null && this._data.lang == "hi") {
                    this.lbl && (this.lbl.visible = false);
                    this.imgLang && (this.imgLang.visible = true)
                } else {
                    this.lbl && (this.lbl.text = this._data.num)
                }
                this.changeSelected(this._selected)
            }
        }
        get Data() {
            return this._data
        }
        set Data(t) {
            super.Data = t
        }
    }
    BaseFSG.Base.View.AutoNumberCell = l.AutoNumberCell = y;
    class _t extends t {
        constructor(t = null, e = 1, i = null) {
            super();
            this.NUM_ARRAY = [10, 100, 500, 1e3, 5e3, 1e4];
            this.CELL_WIDTH = 418;
            this.CELL_HEIGHT = 64;
            this.CELL_COLUMN = 2;
            this._callback = null;
            this._downNum = 0;
            this._upNum = 0;
            this._singleNum = 0;
            this.autoBS = 1.1;
            this._bx = 1;
            this._leftCount = 3;
            this._data = null;
            this.curCell = null;
            this._num = "";
            this._fix_count = 2;
            this._numCount = 9;
            this.POPUP_NONE = -1;
            this.POPUP_DOWN = 1;
            this.POPUP_SINGLE = 2;
            this.POPUP_UP = 3;
            this._autoData = new Object;
            this.popStatus = this.POPUP_NONE;
            this._callback = t;
            this._bx = e;
            this._data = i
        }
        baseInit(t) {
            super.baseInit(t);
            this.setUIPathByName("AutoPlaySelected")
        }
        createUI() {
            super.createUI()
        }
        onEnable() {
            super.onEnable();
            this.initHitArea();
            this.pList && (this.pList.vScrollBar.visible = false);
            this.reset();
            l.timer.frameOnce(1, this, this.init)
        }
        initHitArea() {}
        checkCanStart() {
            if (this._leftCount <= 0) {
                return false
            }
            if (this.chkDownStop.selected && this._downNum <= 0) {
                return false
            }
            if (this.chkUpStop && (this.chkUpStop.selected && this._upNum <= 0)) {
                return false
            }
            if (this.chkSigleStop.selected && this._singleNum <= 0) {
                return false
            }
            return true
        }
        registeEvent() {
            super.registeEvent();
            this.registeAllButton();
            a.on("NC_FSG_CELL_SELECTED", this, this.onCellSelected)
        }
        onCellSelected(t) {
            if (t != null && t.Data != null) {
                var e = t.Data;
                if (e.key == "auto") {
                    this._leftCount = e.num;
                    this.btnStart && (this.btnStart.disabled = !this.checkCanStart());
                    if (this.curCell != null) {
                        this.curCell.changeSelected()
                    }
                    this.curCell = t;
                    this.curCell.changeSelected(true)
                }
            }
        }
        initList() {
            var h = this;
            if (this.isHor) {
                this.CELL_HEIGHT = 64;
                this.CELL_WIDTH = 418
            } else {
                this.CELL_HEIGHT = 104;
                this.CELL_WIDTH = 393
            }
            if (this.pList) {
                this.pList.destroyChildren();
                for (var t = 0; t < Math.ceil(this.NUM_ARRAY.length / 2); t++) {
                    for (var e = 0; e < this.CELL_COLUMN; e++) {
                        var i = t * this.CELL_COLUMN + e;
                        if (i < this.NUM_ARRAY.length) {
                            d.createView(y, _.create(this, function(t, e, i, s) {
                                h.pList.addChild(s);
                                s.x = 13 + e * h.CELL_WIDTH;
                                s.y = t * h.CELL_HEIGHT;
                                var n = new Object;
                                n.num = h.NUM_ARRAY[i];
                                n.key = "auto";
                                s.setDto(n);
                                if (n.num == h._leftCount) {
                                    h.curCell = s;
                                    h.curCell.changeSelected(true)
                                }
                            }, [t, e, i]))
                        }
                    }
                }
            }
        }
        onButtonClick(t) {
            I.Instance.playSound("button_click");
            switch (t) {
                case "chkDownStop":
                    this.onChkDownStop();
                    break;
                case "chkUpStop":
                    this.onChkUpStop();
                    break;
                case "chkSigleStop":
                    this.onChkSigleStop();
                    break;
                case "btnClose":
                    this.close();
                    break;
                case "btnStart":
                    this.onBtnStart();
                    break;
                case "btnNumDown":
                    this.onNumDownClick();
                    break;
                case "btnNumUp":
                    this.onNumUpClick();
                    break;
                case "btnNumSigle":
                    this.onNumSingleClick();
                    break;
                case "btnNum0":
                    this.addNum("0");
                    break;
                case "btnNum1":
                    this.addNum("1");
                    break;
                case "btnNum2":
                    this.addNum("2");
                    break;
                case "btnNum3":
                    this.addNum("3");
                    break;
                case "btnNum4":
                    this.addNum("4");
                    break;
                case "btnNum5":
                    this.addNum("5");
                    break;
                case "btnNum6":
                    this.addNum("6");
                    break;
                case "btnNum7":
                    this.addNum("7");
                    break;
                case "btnNum8":
                    this.addNum("8");
                    break;
                case "btnNum9":
                    this.addNum("9");
                    break;
                case "btnNumDot":
                    this.addNum(".");
                    break;
                case "btnDel":
                    this.delNum();
                    break;
                case "btnOK":
                case "btnHide":
                    this.closeAll();
                    break
            }
        }
        closeAll() {
            this.imgKeyboard && (this.imgKeyboard.visible = false);
            this.btnHide && (this.btnHide.visible = false);
            if (this.POPUP_DOWN == this.popStatus) {
                this._downNum = this._num;
                this.freshDownNum()
            } else if (this.POPUP_UP == this.popStatus) {
                this._upNum = this._num;
                this.freshUpNum()
            } else if (this.POPUP_SINGLE == this.popStatus) {
                this._singleNum = this._num;
                this.freshSingleNum()
            }
            this.popStatus = this.POPUP_NONE
        }
        reset() {
            var t = d.getPCOrMobilePath(this);
            this.chkDownStop.selected = false;
            this.chkUpStop && (this.chkUpStop.selected = false);
            this.chkSigleStop.selected = false;
            this.txtNumDown.color = "#6e6f71";
            this.txtNumUp && (this.txtNumUp.color = "#6e6f71");
            this.txtNumSigle.color = "#6e6f71";
            this.imgSigleSign.color = "#6e6f71";
            this.imgUpSign && (this.imgUpSign.color = "#6e6f71");
            this.imgDownSign.color = "#6e6f71";
            this.imgDown && (this.imgDown.skin = r.Instance.ModuleName + "/" + t + "/common/ui/img_frame02_01.png");
            this.imgSigle && (this.imgSigle.skin = r.Instance.ModuleName + "/" + t + "/common/ui/img_frame02_01.png");
            this.imgUp && (this.imgUp.skin = r.Instance.ModuleName + "/" + t + "/common/ui/img_frame02_01.png");
            this.txtNumDown.text = "0.00";
            this.txtNumUp && (this.txtNumUp.text = "0.00");
            this.txtNumSigle.text = "0.00";
            this.btnNumDown.mouseEnabled = false;
            this.btnNumUp && (this.btnNumUp.mouseEnabled = false);
            this.btnNumSigle.mouseEnabled = false;
            this.imgSigleSign.skin = this.imgDownSign.skin = r.Instance.ModuleName + "/" + t + "/common/ui/img_money_2.png";
            this.imgUpSign && (this.imgUpSign.skin = r.Instance.ModuleName + "/" + t + "/common/ui/img_money_2.png");
            this.btnDownMin.disabled = true;
            this.btnDownAdd.disabled = true;
            this.btnUpMin && (this.btnUpMin.disabled = true);
            this.btnUpAdd && (this.btnUpAdd.disabled = true);
            this.btnSigleMin.disabled = true;
            this.btnSigleAdd.disabled = true;
            this.imgDownSign.text = r.Instance.CurrencyStr;
            this.imgUpSign && (this.imgUpSign.text = r.Instance.CurrencyStr);
            this.imgSigleSign.text = r.Instance.CurrencyStr
        }
        init() {
            this.closeAll();
            this._autoData = d.getLocalStorageJson("COOKIEAUTOPLAY" + r.Instance.uid);
            if (this._autoData == null) {
                this._autoData = new Object
            }
            if (this._autoData.leftTime == null) {
                this._leftCount = this.NUM_ARRAY[0]
            } else {
                this._leftCount = this._autoData.leftTime
            }
            if (this._autoData.totalLose != null && this._autoData.totalLose > 0) {
                this.chkDownStop.selected = true;
                this.onChkDownStop();
                this._downNum = this._autoData.totalLose;
                this.freshDownNum()
            } else {
                this.chkDownStop.selected = false;
                this.onChkDownStop();
                this.freshDownNum()
            }
            if (this._autoData.totalWin != null && this._autoData.totalWin > 0) {
                this.chkUpStop && (this.chkUpStop.selected = true);
                this.onChkUpStop();
                this._upNum = this._autoData.totalWin;
                this.freshUpNum()
            } else {
                this.chkUpStop && (this.chkUpStop.selected = false);
                this.onChkUpStop();
                this.freshUpNum()
            }
            if (this._autoData.perWin != null && this._autoData.perWin > 0) {
                this.chkSigleStop.selected = true;
                this.onChkSigleStop();
                this._singleNum = this._autoData.perWin;
                this.freshSingleNum()
            } else {
                this.chkSigleStop.selected = false;
                this.onChkSigleStop();
                this.freshSingleNum()
            }
            this.initList();
            this.btnStart && (this.btnStart.disabled = !this.checkCanStart())
        }
        onNumDownClick() {
            this.imgKeyboard && (this.imgKeyboard.visible = true);
            if (this.isHor) {
                this.imgKeyboard && (this.imgKeyboard.y = 0)
            } else {
                this.imgKeyboard && (this.imgKeyboard.y = 525)
            }
            this.popStatus = this.POPUP_DOWN;
            this._num = "";
            this.freshNum()
        }
        onNumUpClick() {
            this.imgKeyboard && (this.imgKeyboard.visible = true);
            if (this.isHor) {
                this.imgKeyboard && (this.imgKeyboard.y = 180)
            } else {
                this.imgKeyboard && (this.imgKeyboard.y = 791)
            }
            this.popStatus = this.POPUP_UP;
            this._num = "";
            this.freshNum()
        }
        onNumSingleClick() {
            this.imgKeyboard && (this.imgKeyboard.visible = true);
            if (this.isHor) {
                this.imgKeyboard && (this.imgKeyboard.y = 90)
            } else {
                this.imgKeyboard && (this.imgKeyboard.y = 658)
            }
            this.popStatus = this.POPUP_SINGLE;
            this._num = "";
            this.freshNum()
        }
        onChkDownStop() {
            if (this.chkDownStop.selected) {
                this.imgDown && (this.imgDown.skin = r.Instance.ModuleName + "/" + d.getPCOrMobilePath(this) + "/common/ui/img_frame02_02.png");
                this.txtNumDown.color = "#ffffff";
                this.imgDownSign.color = "#ffffff";
                this.btnDownAdd && this.btnDownAdd.on(s.CLICK, this, this.onBtnDownAdd);
                this.btnDownMin && this.btnDownMin.on(s.CLICK, this, this.onBtnDownMin)
            } else {
                this.imgDown && (this.imgDown.skin = r.Instance.ModuleName + "/" + d.getPCOrMobilePath(this) + "/common/ui/img_frame02_01.png");
                this.txtNumDown.color = "#6e6f71";
                this.imgDownSign.color = "#6e6f71";
                this.btnDownAdd && this.btnDownAdd.off(s.CLICK, this, this.onBtnDownAdd);
                this.btnDownMin && this.btnDownMin.off(s.CLICK, this, this.onBtnDownMin)
            }
            this.btnDownMin.disabled = !this.chkDownStop.selected;
            this.btnDownAdd.disabled = !this.chkDownStop.selected;
            this.btnNumDown.mouseEnabled = this.chkDownStop.selected;
            this.btnStart && (this.btnStart.disabled = !this.checkCanStart());
            this.closeAll()
        }
        onChkUpStop() {
            if (this.chkUpStop) {
                if (this.chkUpStop.selected) {
                    this.imgUp && (this.imgUp.skin = r.Instance.ModuleName + "/" + d.getPCOrMobilePath(this) + "/common/ui/img_frame02_02.png");
                    this.txtNumUp.color = "#ffffff";
                    this.imgUpSign.color = "#ffffff";
                    this.btnUpAdd && this.btnUpAdd.on(s.CLICK, this, this.onBtnUpAdd);
                    this.btnUpMin && this.btnUpMin.on(s.CLICK, this, this.onBtnUpMin)
                } else {
                    this.imgUp && (this.imgUp.skin = r.Instance.ModuleName + "/" + d.getPCOrMobilePath(this) + "/common/ui/img_frame02_01.png");
                    this.txtNumUp.color = "#6e6f71";
                    this.imgUpSign.color = "#6e6f71";
                    this.btnUpAdd && this.btnUpAdd.off(s.CLICK, this, this.onBtnUpAdd);
                    this.btnUpMin && this.btnUpMin.off(s.CLICK, this, this.onBtnUpMin)
                }
                this.btnUpMin.disabled = !this.chkUpStop.selected;
                this.btnUpAdd.disabled = !this.chkUpStop.selected;
                this.btnNumUp.mouseEnabled = this.chkUpStop.selected;
                this.btnStart && (this.btnStart.disabled = !this.checkCanStart())
            }
            this.closeAll()
        }
        onChkSigleStop() {
            if (this.chkSigleStop.selected) {
                this.imgSigle && (this.imgSigle.skin = r.Instance.ModuleName + "/" + d.getPCOrMobilePath(this) + "/common/ui/img_frame02_02.png");
                this.txtNumSigle.color = "#ffffff";
                this.imgSigleSign.color = "#ffffff";
                this.btnSigleAdd && this.btnSigleAdd.on(s.CLICK, this, this.onBtnSigleAdd);
                this.btnSigleMin && this.btnSigleMin.on(s.CLICK, this, this.onBtnSigleMin)
            } else {
                this.imgSigle && (this.imgSigle.skin = r.Instance.ModuleName + "/" + d.getPCOrMobilePath(this) + "/common/ui/img_frame02_01.png");
                this.txtNumSigle.color = "#6e6f71";
                this.imgSigleSign.color = "#6e6f71";
                this.btnSigleAdd && this.btnSigleAdd.off(s.CLICK, this, this.onBtnSigleAdd);
                this.btnSigleMin && this.btnSigleMin.off(s.CLICK, this, this.onBtnSigleMin)
            }
            this.btnSigleMin.disabled = !this.chkSigleStop.selected;
            this.btnSigleAdd.disabled = !this.chkSigleStop.selected;
            this.txtNumSigle.editable = this.chkSigleStop.selected;
            this.btnNumSigle.mouseEnabled = this.chkSigleStop.selected;
            this.btnStart && (this.btnStart.disabled = !this.checkCanStart());
            this.closeAll()
        }
        onBtnReset() {
            this.reset();
            this.reStorJson()
        }
        getLeftTime() {
            return this._leftCount
        }
        onBtnStart() {
            if (this._callback != null) {
                this._autoData.leftTime = this.getLeftTime();
                this.reStorJson();
                this._callback.runWith(this._autoData)
            }
            d.setLocalStorageJson("COOKIEAUTOPLAY" + r.Instance.uid, this._autoData);
            this.close()
        }
        reStorJson() {
            if (this.chkDownStop.selected) {
                this._autoData.totalLose = this._downNum
            } else {
                this._autoData.totalLose = 0
            }
            if (this.chkUpStop && this.chkUpStop.selected) {
                this._autoData.totalWin = this._upNum
            } else {
                this._autoData.totalWin = 0
            }
            if (this.chkSigleStop.selected) {
                this._autoData.perWin = this._singleNum
            } else {
                this._autoData.perWin = 0
            }
        }
        onTabSelexted() {}
        freshDownNum() {
            this._downNum = Math.max(this._downNum, 0);
            this._downNum = Math.min(this._downNum, c.Instance.FairSimple.am * this.NUM_ARRAY[this.NUM_ARRAY.length - 1]);
            this.txtNumDown.text = this._downNum.toFixed(2);
            this.btnStart && (this.btnStart.disabled = !this.checkCanStart())
        }
        freshUpNum() {
            if (this.txtNumUp) {
                this._upNum = Math.max(this._upNum, 0);
                var t = Math.min(999999999, c.Instance.FairSimple.mwm * this.NUM_ARRAY[this.NUM_ARRAY.length - 1]);
                if (t == 0) {
                    t = 999999999
                }
                this._upNum = Math.min(this._upNum, t);
                this.txtNumUp.text = this._upNum.toFixed(2);
                this.btnStart && (this.btnStart.disabled = !this.checkCanStart())
            }
        }
        freshSingleNum() {
            this._singleNum = Math.max(this._singleNum, 0);
            if (c.Instance.FairSimple.mwm > 0) {
                this._singleNum = Math.min(this._singleNum, c.Instance.FairSimple.mwm)
            }
            this.txtNumSigle.text = this._singleNum.toFixed(2);
            this.btnStart && (this.btnStart.disabled = !this.checkCanStart())
        }
        onBtnDownAdd() {
            I.Instance.playSound("Button");
            this._downNum += 1;
            this.freshDownNum()
        }
        onBtnDownMin() {
            I.Instance.playSound("Button");
            this._downNum -= 1;
            this.freshDownNum()
        }
        onBtnUpAdd() {
            I.Instance.playSound("Button");
            this._upNum += 1;
            this.freshUpNum()
        }
        onBtnUpMin() {
            I.Instance.playSound("Button");
            this._upNum -= 1;
            this.freshUpNum()
        }
        onBtnSigleAdd() {
            I.Instance.playSound("Button");
            this._singleNum += 1;
            this.freshSingleNum()
        }
        onBtnSigleMin() {
            I.Instance.playSound("Button");
            this._singleNum -= 1;
            this.freshSingleNum()
        }
        hasDot() {
            if (this._num) {
                var t = "" + this._num;
                var e = t.indexOf(".");
                if (e > 0) {
                    return t.length - e - 1
                }
            }
            return -1
        }
        getNumCount() {
            var t = this._num.split(".");
            if (t.length == 1) {
                return t[0].length
            }
            return 0
        }
        delNum() {
            if (this._num.length > 0) {
                this._num = this._num.substring(0, this._num.length - 1)
            }
            this.freshNum()
        }
        freshNum() {
            if (this.popStatus == this.POPUP_DOWN) {
                this.txtNumDown && (this.txtNumDown.text = this._num)
            } else if (this.popStatus == this.POPUP_UP) {
                this.txtNumUp && (this.txtNumUp.text = this._num)
            } else if (this.popStatus == this.POPUP_SINGLE) {
                this.txtNumSigle && (this.txtNumSigle.text = this._num)
            }
        }
        addNum(t) {
            var e = true;
            if (this._num != "0" && this._num != "") {
                e = false
            }
            var i = -1;
            if (e == false) {
                i = this.hasDot()
            }
            var s = 1;
            if (t != ".") {
                if (e) {
                    if (t == 0) {
                        return
                    } else {
                        this._num = t
                    }
                } else {
                    if (i >= this._fix_count) {
                        return
                    }
                    if (this.getNumCount() >= this._numCount) {
                        return
                    }
                    this._num = this._num + "" + t
                }
            } else {
                if (i >= 0) {
                    return
                } else {
                    if (this._num == "") {
                        this._num = "0"
                    }
                    this._num = this._num + "."
                }
            }
            this.freshNum()
        }
    }
    BaseFSG.Base.View.AutoPlaySelected = l.AutoPlaySelected = _t;
    class v extends t {
        constructor() {
            super();
            this.bg1 = r.Instance.ModuleName + "/common/common/ui/img_frame_03.png";
            this.bg2 = r.Instance.ModuleName + "/common/common/ui/img_frame_04.png"
        }
        baseInit(t) {
            super.baseInit(t);
            this.setUIPathByName("BetViewCell2")
        }
        createUI() {
            super.createUI()
        }
        registeEvent() {
            super.registeEvent();
            this.btnCheckFair && this.btnCheckFair.on(s.CLICK, this, this.onShield)
        }
        onEnable() {
            super.onEnable();
            this.fresh()
        }
        onLoad() {
            super.onLoad()
        }
        setDto(t, e) {
            this._data = t;
            this._index = e;
            if (this.ViewCreated) {
                this.fresh()
            }
        }
        fresh() {
            if (this._data) {
                var t = d.formartUTCtoLocalTimeByDayMonthYear(this._data.time, ".", true, false, true, 4);
                this.lbDate && (this.lbDate.text = t);
                if (this.isHor) {
                    this.lbBM && (this.lbBM.text = d.getCurrencyStrBySignal(d.getMoneyTextByNumber(this._data.bet)))
                } else {
                    this.lbBM && (this.lbBM.text = d.getMoneyTextByNumber(this._data.bet))
                }
                if (this._data.win != null && this._data.win != "" && this._data.win > 0) {
                    if (this.isHor) {
                        this.lbRM && (this.lbRM.text = "+" + d.getCurrencyStrBySignal(d.getMoneyTextByNumber(this._data.win + this._data.bet)))
                    } else {
                        this.lbRM && (this.lbRM.text = d.getMoneyTextByNumber(this._data.win + this._data.bet))
                    }
                    this.lbRM && (this.lbRM.color = "#00ff00")
                } else {
                    if (this._data.win + this._data.bet == 0) {
                        if (this.isHor) {
                            this.lbRM && (this.lbRM.text = d.getCurrencyStrBySignal("0.00"))
                        } else {
                            this.lbRM && (this.lbRM.text = "0.00")
                        }
                    } else {
                        if (this.isHor) {
                            this.lbRM && (this.lbRM.text = "+" + d.getCurrencyStrBySignal(d.getMoneyTextByNumber(this._data.win + this._data.bet)))
                        } else {
                            this.lbRM && (this.lbRM.text = d.getMoneyTextByNumber(this._data.win + this._data.bet))
                        }
                    }
                    this.lbRM && (this.lbRM.color = "#ffffff")
                }
                if (this._data.bet != null && this._data.bet != 0) {
                    if (this._data.win != null && this._data.win != "" && this._data.win > 0) {
                        this.lsGS && (this.lsGS.text = ((this._data.win + this._data.bet) / this._data.bet).toFixed(2) + "x");
                        this.lsGS && (this.lsGS.color = "#00ff00")
                    } else {
                        if (this._data.win + this._data.bet == 0) {
                            this.lsGS && (this.lsGS.text = "0.00x")
                        } else {
                            this.lsGS && (this.lsGS.text = ((this._data.win + this._data.bet) / this._data.bet).toFixed(2) + "x")
                        }
                        this.lsGS && (this.lsGS.color = "#ffffff")
                    }
                }
                if (this._index % 2 == 0) {
                    this.imgBG && (this.imgBG.skin = r.Instance.ModuleName + "/" + d.getPCOrMobilePath(this) + "/common/ui/img_frame_03.png")
                } else {
                    this.imgBG && (this.imgBG.skin = r.Instance.ModuleName + "/" + d.getPCOrMobilePath(this) + "/common/ui/img_frame_05.png")
                }
            }
        }
        onShield() {
            I.Instance.playSound("button_click");
            var t = c.Instance;
            if (!t.CheckRoundSeedData) {
                t.CheckRoundSeedData = new o
            }
            var e = JSON.parse(this._data.bs);
            t.CheckRoundSeedData.brd = this._data.bid;
            t.CheckRoundSeedData.gs = this._data.gr;
            t.CheckRoundSeedData.ss = this._data.ss;
            t.CheckRoundSeedData.ss256 = this._data.ss2;
            t.CheckRoundSeedData.rs256 = this._data.gr2;
            t.CheckRoundSeedData.gr = this._data.gr;
            t.CheckRoundSeedData.tm = this._data.time;
            t.CheckRoundSeedData.bm = this._data.bet;
            this._data.bs && (t.CheckRoundSeedData.bs = this._data.bs);
            t.CheckRoundSeedData.win = this._data.win + this._data.bet;
            if (e.mine_count != null) {
                t.CheckRoundSeedData.mc = e.mine_count
            }
            if (e.sp_array != null) {
                t.CheckRoundSeedData.sa = e.sp_array
            }
            if (e.line_count != null) {
                t.CheckRoundSeedData.lc = e.line_count
            }
            if (e.row_count != null) {
                t.CheckRoundSeedData.rc = e.row_count
            }
            if (e.field != null) {
                t.CheckRoundSeedData.field = e.field
            }
            if (e.action != null) {
                t.CheckRoundSeedData.action = e.action
            }
            if (e.bet_data != null) {
                t.CheckRoundSeedData.bet_data = e.bet_data
            }
            if (e.last_ope != null) {
                t.CheckRoundSeedData.last_ope = e.last_ope
            }
            if (e.plist != null) {
                t.CheckRoundSeedData.plist = e.plist
            }
            if (e.blist != null) {
                t.CheckRoundSeedData.blist = e.blist
            }
            if (e.ptype != null) {
                t.CheckRoundSeedData.ptype = e.ptype
            }
            if (e.btype != null) {
                t.CheckRoundSeedData.btype = e.btype
            }
            a.dispatch("NC_SHOW_CHECKROUN_SEED")
        }
    }
    BaseFSG.Base.View.BetViewCell2 = l.BetViewCell2 = v;
    class bt extends t {
        constructor() {
            super()
        }
        createUI() {
            this.loadSceneByName("CashoutView")
        }
        registeEvent() {
            super.registeEvent();
            a.on("MFG_CASHOUT", this, this.onCashout, 1);
            a.on("MFG_CASHOUT_FRESH", this, this.onCashoutFresh, 1)
        }
        onCashout(t = null) {
            if (this.cashout1.isActive) {
                this.cashout2.data = t
            } else {
                this.cashout1.data = t
            }
        }
        onCashoutFresh() {
            if (this.cashout2.isActive) {
                this.cashout2.visible = false;
                this.cashout1.justData = this.cashout2.data
            }
        }
        onEnable() {
            super.onEnable();
            this.initView()
        }
        initView() {}
    }
    BaseFSG.Base.View.CashoutView = l.CashoutView = bt;
    class gt extends t {
        constructor() {
            super();
            this._isActive = false;
            this._defaulty = 0;
            this._data = null
        }
        createUI() {
            this.loadSceneByName("CashoutViewCell")
        }
        registeEvent() {
            super.registeEvent();
            this.registeAllButton()
        }
        onButtonClick(t) {
            I.Instance.playSound("Button");
            switch (t) {
                case "btnClose":
                    this._isActive = false;
                    this.close();
                    break
            }
        }
        onEnable() {
            super.onEnable();
            this.initView()
        }
        initView() {
            this._defaulty = this.y;
            this.visible = false;
            var t = r.Instance.lang;
            if (t == "zh-cn" || t == "zh-tw") {} else if (t == "vi") {
                this.imgBg.width = 800;
                this.imgFront.width = 380;
                this.imgFront.x = 500;
                this.imgDuixian.x = 190;
                this.lbWin.x = 190;
                this.btnClose.x = this.imgBg.width - 70
            } else {}
        }
        close() {
            this._isActive = false;
            B.clearTarget(this);
            B.to(this, {
                y: -65,
                alpha: 0
            }, 500, null, _.create(this, function() {
                this.visible = false;
                a.dispatch("MFG_CASHOUT_FRESH")
            }))
        }
        set justData(t) {
            this._data = t;
            if (this._data) {
                this.lbMul && (this.lbMul.text = this.data.mul + "x");
                this.lbWin && (this.lbWin.text = d.getCurrencyStrBySignal(this.data.rm));
                this.visible = true;
                this._isActive = true;
                this.alpha = 1;
                this.y = this._defaulty;
                l.timer.once(3e3, this, this.close)
            }
        }
        get justData() {
            return super.justData
        }
        get isActive() {
            return this._isActive
        }
        set isActive(t) {
            super.isActive = t
        }
        get data() {
            return this._data
        }
        set data(t) {
            this._data = t;
            if (this._data) {
                I.Instance.playSound("Win");
                this.lbMul && (this.lbMul.text = this.data.mul + "x");
                this.lbWin && (this.lbWin.text = d.getCurrencyStrBySignal(this.data.rm));
                this.visible = true;
                this._isActive = true;
                this.alpha = 1;
                this.y = this._defaulty;
                l.timer.once(3e3, this, this.close)
            }
        }
    }
    BaseFSG.Base.View.CashoutViewCell = l.CashoutViewCell = gt;
    class St extends t {
        constructor() {
            super();
            this.BOX_COLUMN = 5;
            this.BOX_ROW = 5;
            this._tab = 1
        }
        baseInit(t) {
            super.baseInit(t);
            this.setUIPathByName("CheckRoundSeedView")
        }
        createUI() {
            super.createUI()
        }
        onEnable() {
            super.onEnable();
            this.init()
        }
        registeEvent() {
            var t = this;
            super.registeEvent();
            this.btnClose && this.btnClose.on(s.CLICK, this, this.destroy);
            this.btnFair && this.btnFair.on(s.CLICK, this, this.onBtnFair);
            this.btnCopy && this.btnCopy.on(s.CLICK, this, this.onBtnCopy);
            this.btnCopy2 && this.btnCopy2.on(s.CLICK, this, this.onBtnCopyBrd);
            this.btnTab1 && this.btnTab1.on(s.CLICK, this, function() {
                t.changeTab()
            });
            this.btnTab2 && this.btnTab2.on(s.CLICK, this, function() {
                t.changeTab(2)
            })
        }
        init() {
            var t = 450;
            var e = c.Instance;
            this.labRoundNumber.text = e.CheckRoundSeedData.brd;
            if (this.isHor) {
                t = 350
            }
            d.setTextOverflowByEllipsis(this.labRoundNumber, t);
            var i = 400;
            this.labSeed1.text = e.CheckRoundSeedData.ss;
            if (this.isHor) {
                i = 800
            } else {
                i = 550
            }
            d.setTextOverflowByEllipsis(this.labSeed1, i);
            this.labSeed2.text = e.CheckRoundSeedData.ss256;
            if (this.isHor) {
                i = 800
            } else {
                i = 650
            }
            d.setTextOverflowByEllipsis(this.labSeed2, i);
            this.labSeed3.text = e.CheckRoundSeedData.ss + e.CheckRoundSeedData.gs;
            d.setTextOverflowByEllipsis(this.labSeed3, i);
            this.labSeed4.text = e.CheckRoundSeedData.rs256;
            d.setTextOverflowByEllipsis(this.labSeed4, i);
            var s = d.formartUTCtoLocalTimeByDayMonthYear(e.CheckRoundSeedData.tm, "/", true, true, true);
            this.labTimeStr.text = s;
            this.lblBetMoney && (this.lblBetMoney.text = d.getCurrencyStrBySignal(d.getMoneyTextByNumber(e.CheckRoundSeedData.bm)));
            this.lblCash && (this.lblCash.text = d.getCurrencyStrBySignal(d.getMoneyTextByNumber(e.CheckRoundSeedData.win)));
            this.labResult.text = e.CheckRoundSeedData.gs;
            if (this.isHor) {
                i = 500
            } else {
                i = 600
            }
            d.setTextOverflowByEllipsis(this.labResult, i);
            if (e.CheckRoundSeedData.win > e.CheckRoundSeedData.bm) {
                this.lblCash && (this.lblCash.color = "#7aff00")
            } else {
                this.lblCash && (this.lblCash.color = "#ffffff")
            }
            this.lblSize && (this.lblSize.text = e.CheckRoundSeedData.mc);
            this.initBox();
            this.changeTab()
        }
        initBox() {
            var t = c.Instance;
            var e = 0;
            this.pIcon.destroyChildren();
            this.pNum.destroyChildren();
            for (var i = 0; i < this.BOX_ROW; i++) {
                for (var s = 0; s < this.BOX_COLUMN; s++) {
                    var n = t.CheckRoundSeedData.gs.substring(e, e + 1);
                    var h = false;
                    if (t.CheckRoundSeedData.sa != null && t.CheckRoundSeedData.sa.length > 0 && u.indexOf(e, t.CheckRoundSeedData.sa) >= 0) {
                        h = true
                    }
                    var a = new g;
                    a.anchorX = .5;
                    a.anchorY = .5;
                    var l = new $;
                    l.fontSize = 32;
                    l.color = "#ffffff";
                    l.text = n;
                    this.pNum.addChild(l);
                    l.anchorX = .5;
                    l.anchorY = .5;
                    l.x = s * 60 + 10;
                    l.y = i * 105 + 46.5;
                    var o = "img_gameResults0" + (parseInt(n) + 1) + "_0";
                    if (h) {
                        o += "1.png"
                    } else {
                        o += "2.png"
                    }
                    a.skin = r.Instance.ModuleName + "/" + d.getPCOrMobilePath(this) + "/common/ui/" + o;
                    this.pIcon.addChild(a);
                    a.x = s * 105 + 46.5;
                    a.y = i * 105 + 46.5;
                    e++
                }
            }
        }
        onBtnFair() {
            a.dispatch("NC_SHOW_GREEN_RULES")
        }
        changeTab(t = 1) {
            this._tab = t;
            if (this._tab == 1) {
                this.btnTab1 && (this.btnTab1.disabled = true);
                this.btnTab2 && (this.btnTab2.disabled = false);
                this.tab1 && (this.tab1.visible = true);
                this.tab2 && (this.tab2.visible = false);
                this.img1 && (this.img1.alpha = 1);
                this.img2 && (this.img2.alpha = .3)
            } else {
                this.btnTab1 && (this.btnTab1.disabled = false);
                this.btnTab2 && (this.btnTab2.disabled = true);
                this.tab1 && (this.tab1.visible = false);
                this.tab2 && (this.tab2.visible = true);
                this.img1 && (this.img1.alpha = .3);
                this.img2 && (this.img2.alpha = 1)
            }
        }
        onBtnCopy() {
            var t = c.Instance;
            var e = new String;
            e += d.getMsgForNowLang("clip_rbd") + ":" + t.CheckRoundSeedData.brd + "\r\n";
            e += d.getMsgForNowLang("clip_seed") + ":" + t.CheckRoundSeedData.ss + "\r\n";
            e += d.getMsgForNowLang("clip_seed_sec") + ":" + t.CheckRoundSeedData.ss256 + "\r\n";
            e += d.getMsgForNowLang("clip_result") + ":" + t.CheckRoundSeedData.gr + "\r\n";
            e += d.getMsgForNowLang("clip_seed_result") + ":" + t.CheckRoundSeedData.ss + t.CheckRoundSeedData.gr + "\r\n";
            e += d.getMsgForNowLang("clip_result_sec") + ":" + t.CheckRoundSeedData.rs256 + "\r\n";
            console.log(e);
            d.setClipboard(e);
            i.Instance.showText(d.getMsgForNowLang("clip_ok"))
        }
        onBtnCopyBrd() {
            var t = c.Instance;
            var e = new String;
            e += d.getMsgForNowLang("clip_rbd") + ":" + t.CheckRoundSeedData.brd + "\r\n";
            d.setClipboard(e);
            i.Instance.showText(d.getMsgForNowLang("clip_ok"))
        }
    }
    BaseFSG.Base.View.CheckRoundSeed = l.CheckRoundSeed = St;
    class L extends t {
        constructor() {
            super()
        }
        baseInit() {
            super.baseInit();
            this.setUIPathByName("DetailedRulesView")
        }
        createUI() {
            super.createUI()
        }
        registeEvent() {
            super.registeEvent();
            this.btnClose && this.btnClose.on(s.CLICK, this, this.destroy);
            this.btnDeepKnow && this.btnDeepKnow.on(s.CLICK, this, this.onBtnDeepKnow)
        }
        init() {}
        onEnable() {
            super.onEnable();
            var t = "./unjzp/help/" + r.Instance.AppID + "/help_" + r.Instance.lang + ".html";
            this.iframe = l.Browser.document.createElement("iframe");
            this.iframe.style.position = "absolute";
            this.iframe.style.zIndex = 100;
            this.iframe.src = t;
            this.iframe.style.border = "medium none";
            l.Browser.document.body.appendChild(this.iframe);
            l.stage.on(s.RESIZE, this, this.onResize);
            this.onResize();
            this.zOrder = 100
        }
        onResize() {
            var t = null;
            var e = 1900;
            var i = 1600;
            var s = 900;
            var n = 900;
            var h = e - l.stage.realDesignWidth;
            var a = s - l.stage.realDesignHeight;
            if (this.isHor) {
                t = new p(this.si.x, this.si.y, this.si.width, this.si.height)
            } else {
                t = new p(this.si.x, this.si.y, this.si.width, this.si.height);
                e = 900;
                i = 900;
                s = 1900;
                n = 1600
            }
            d.autoIframe(this.iframe, t, this.isHor)
        }
        onBtnDeepKnow() {
            a.dispatch("NC_SHOW_GREEN_RULES")
        }
        onDestroy() {
            super.onDestroy();
            if (this.iframe) {
                l.Browser.document.body.removeChild(this.iframe);
                this.iframe = null
            }
        }
    }
    BaseFSG.Base.View.DetailedRules = l.DetailedRules = L;
    class pt extends t {
        constructor() {
            super();
            this.MOVIE_INTERVAL = 100;
            this._canTouch = true;
            this._gameStatus = 0;
            this._index = -1;
            this._isAuto = false;
            this._movieType = 0
        }
        baseInit(t) {
            super.baseInit(t);
            this.setUIPathByName("GameCell")
        }
        createUI() {
            super.createUI()
        }
        onLoad() {
            super.onLoad()
        }
        onEnable() {
            super.onEnable();
            this.fresh()
        }
        registeEvent() {
            super.registeEvent();
            this.btn && this.btn.on(s.CLICK, this, this.onbtn);
            a.on("NC_FSG_START", this, this.onGameStart);
            a.on("NC_FSG_OVER", this, this.onGameOver);
            a.on("NC_FSG_NEXT", this, this.onNext, 1);
            a.on("NC_FSG_FRESH_CELL", this, this.onFresh);
            a.on("NC_FSG_OPEN_START", this, this.onOpenStart);
            a.on("NC_FSG_OPEN_OVER", this, this.onOpenOver)
        }
        onOpenStart(t) {
            if (this._index == t) {
                this.setImage(3)
            }
        }
        onOpenOver(t, e, i = 0) {
            if (c.Instance.isAuto) {
                if (this._index == t) {
                    if (u.indexOf(this._index, c.Instance.autoArray) >= 0 && this._gameStatus == 5) {
                        I.Instance.playSound("mines_select");
                        u.removebyvalue(c.Instance.autoArray, this._index);
                        this.setImage(2)
                    } else if (u.indexOf(this._index, c.Instance.autoArray) < 0 && this._gameStatus == 2 && !c.Instance.checkSelectMax()) {
                        I.Instance.playSound("mines_select");
                        c.Instance.autoArray.push(this._index);
                        this.setImage(5)
                    }
                    a.dispatch("NC_FSG_AUTO_SELECTED_CHANGE")
                }
            } else {
                if (this._index == t) {
                    if (e == true) {
                        if (i == 0) {
                            this.setImage(7)
                        } else {
                            this.setImage(6)
                        }
                    } else {
                        I.Instance.playSound("soft_win");
                        this.setImage(6)
                    }
                }
            }
        }
        onGameStart() {
            if (c.Instance.FairSimple == null) {
                return
            }
            if (c.Instance.FairSimple.is_over) {} else {
                if (c.Instance.FairSimple.brd != null && c.Instance.FairSimple.brd != "" && c.Instance.FairSimple.sp_array != null && c.Instance.FairSimple.sp_array.length > 0) {
                    if (u.indexOf(this._index, c.Instance.FairSimple.sp_array) >= 0) {
                        this.setImage(6)
                    } else {
                        this.setImage(2)
                    }
                } else {
                    this.setImage(2)
                }
            }
        }
        onGameOver() {
            if (c.Instance.FairSimple == null || c.Instance.FairSimple.gs == null || c.Instance.FairSimple.gs == "") {
                return
            }
            var t = c.Instance.FairSimple.gs;
            var e = t.substring(this._index, this._index + 1);
            this._movieType = 1;
            if (e == "1") {
                if (this._gameStatus == 2) {
                    this.fresh(8)
                } else if (c.Instance.isAuto) {
                    if (this._gameStatus == 5) {
                        this.fresh(7)
                    }
                }
            } else {
                if (this._gameStatus == 2) {
                    this.fresh(4)
                } else if (c.Instance.isAuto) {
                    if (this._gameStatus == 5) {
                        this.fresh(6)
                    }
                }
            }
        }
        onNext() {
            if (c.Instance.FairSimple == null || c.Instance.FairSimple.gs == null || c.Instance.FairSimple.gs == "") {
                return
            }
            if (c.Instance.isAuto) {
                this._movieType = 2;
                if (u.indexOf(this._index, c.Instance.autoArray) >= 0) {
                    this.fresh(5)
                } else {
                    this.fresh(2)
                }
            } else {
                this.setImage(1)
            }
        }
        onFresh() {
            if (c.Instance.isAuto) {
                this.setImage(2)
            } else {
                this.setImage(1)
            }
        }
        setDto(t = -1, e, i = 0, s = false) {
            this._gameStatus = e;
            this._movieType = i;
            this._index = t;
            this._isAuto = s;
            if (this.ViewCreated) {
                this.fresh()
            }
        }
        fresh(t = -1) {
            var e = this;
            if (t >= 0) {
                this._gameStatus = t
            }
            if (this._movieType == 0) {
                this.setImage()
            } else if (this._movieType == 1) {
                B.to(this.img, {
                    scaleX: 0
                }, this.MOVIE_INTERVAL, null, _.create(this, function() {
                    e.setImage();
                    B.to(e.img, {
                        scaleX: 1
                    }, e.MOVIE_INTERVAL, null, _.create(this, function() {}), 0, false)
                }), 0, false)
            } else if (this._movieType == 2) {
                B.to(this.img, {
                    scaleY: 0
                }, this.MOVIE_INTERVAL, null, _.create(this, function() {
                    e.setImage();
                    B.to(e.img, {
                        scaleY: 1
                    }, e.MOVIE_INTERVAL, null, _.create(this, function() {}), 0, false)
                }), 0, false)
            }
        }
        setImage(t = -1) {
            if (t > 0) {
                this._gameStatus = t
            }
            if (this._gameStatus > 0) {
                this.img.skin = r.Instance.ModuleName + "/" + d.getPCOrMobilePath(this) + "/common/ui/img_game0" + this._gameStatus + ".png"
            }
            if (t > 0) {
                if (t == 2 || t == 5) {
                    this._canTouch = true
                } else {
                    this._canTouch = false
                }
            }
            if (c.Instance.isAuto) {
                if (7 == this._gameStatus || 6 == this._gameStatus) {
                    this.imgAuto && (this.imgAuto.visible = true)
                } else {
                    this.imgAuto && (this.imgAuto.visible = false)
                }
            } else {
                this.imgAuto && (this.imgAuto.visible = false)
            }
        }
        onbtn() {
            var e = this;
            if (at.Instance.isBetting) {
                return
            }
            if (this._canTouch) {
                if (c.Instance.isAuto) {
                    a.dispatch("NC_FSG_OPEN_OVER", [this._index])
                } else {
                    if (!c.Instance.checkSelectMax()) {
                        var t = new Object;
                        t.brd = c.Instance.FairSimple.brd;
                        t.ope = 1;
                        t.index = this._index;
                        N.Instance.doSendFairSimpleOpeByData(t, _.create(this, function(t) {
                            a.dispatch("NC_FSG_OPEN_START");
                            a.dispatch("NC_FSG_OPEN_OVER", [e._index, t.is_over, t.rm])
                        }))
                    }
                }
            }
        }
    }
    BaseFSG.Base.View.GameCell = l.GameCell = pt;
    class M extends t {
        constructor() {
            super()
        }
        baseInit(t) {
            super.baseInit(t);
            this.setUIPathByName("GameLimitsView")
        }
        registeEvent() {
            super.registeEvent();
            a.on("NC_FSG_CONFIG_CHANGE", this, this.onConfigChange)
        }
        onConfigChange() {
            this.init()
        }
        createUI() {
            super.createUI()
        }
        onEnable() {
            super.onEnable();
            this.init()
        }
        registeEvent() {
            super.registeEvent();
            this.btnClose && this.btnClose.on(s.CLICK, this, this.destroy)
        }
        init() {
            this.labMin.text = d.getCurrencyStrBySignal(" " + c.Instance.FairSimple.im + " ");
            this.labMax.text = d.getCurrencyStrBySignal(" " + c.Instance.FairSimple.am + " ");
            var t = c.Instance.FairSimple.mwm;
            if (t == 0) {
                t = "-"
            } else {
                t = d.getCurrencyStrBySignal(" " + t + " ")
            }
            this.labSigle.text = t
        }
    }
    BaseFSG.Base.View.GameLimits = l.GameLimits = M;
    class D extends t {
        constructor() {
            super()
        }
        baseInit() {
            super.baseInit();
            this.setUIPathByName("GameRulesView")
        }
        createUI() {
            super.createUI()
        }
        registeEvent() {
            super.registeEvent();
            this.registeAllButton()
        }
        onCloseClick() {
            this.destroy();
            if (this.iframe) {
                l.Browser.document.body.removeChild(this.iframe);
                this.iframe = null
            }
        }
        init() {}
        onLoad() {
            super.onLoad();
            this.zOrder = 100
        }
        onEnable() {
            super.onEnable();
            var t = "./unjzp/help/" + r.Instance.AppID + "/rules_" + r.Instance.lang + ".html";
            this.iframe = l.Browser.document.createElement("iframe");
            this.iframe.style.position = "absolute";
            this.iframe.style.zIndex = 100;
            this.iframe.src = t;
            this.iframe.style.border = "medium none";
            l.Browser.document.body.appendChild(this.iframe);
            l.stage.on(s.RESIZE, this, this.onResize);
            this.onResize();
            this.zOrder = 100
        }
        onResize() {
            var t = null;
            var e = 1900;
            var i = 1600;
            var s = 900;
            var n = 900;
            if (this.isHor) {
                t = new p(30, 100, 1840, 750)
            } else {
                t = new p(30, 100, 840, 1750);
                e = 900;
                i = 900;
                s = 1900;
                n = 1600
            }
            var h = e - l.stage.realDesignWidth;
            var a = s - l.stage.realDesignHeight;
            if (this.isHor) {
                this.imgBG && (this.imgBG.width = l.stage.realDesignWidth);
                this.imgLine && (this.imgLine.width = l.stage.realDesignWidth);
                this.imgTitle && (this.imgTitle.x = 30 + h / 2);
                this.btnClose && (this.btnClose.x = 1820 - h / 2)
            } else {
                this.imgBG && (this.imgBG.height = l.stage.realDesignHeight);
                this.imgLine && (this.imgLine.y = 72 + a / 2);
                this.imgTitle && (this.imgTitle.y = 36 + a / 2);
                this.btnClose && (this.btnClose.y = 36 + a / 2)
            }
            d.autoIframe(this.iframe, t, this.isHor)
        }
        onButtonClick(t) {
            super.onButtonClick(t);
            if (t == "btnClose") {
                this.onCloseClick()
            }
        }
        onDestroy() {
            super.onDestroy();
            if (this.iframe) {
                l.Browser.document.body.removeChild(this.iframe);
                this.iframe = null
            }
        }
    }
    BaseFSG.Base.View.GameRulesView = l.GameRulesView = D;
    class k extends t {
        constructor() {
            super()
        }
        baseInit() {
            super.baseInit();
            this.setUIPathByName("GreenDetailed")
        }
        createUI() {
            super.createUI()
        }
        registeEvent() {
            super.registeEvent();
            this.registeAllButton()
        }
        onCloseClick() {
            this.destroy();
            if (this.iframe) {
                l.Browser.document.body.removeChild(this.iframe);
                this.iframe = null
            }
        }
        init() {}
        onLoad() {
            super.onLoad();
            this.zOrder = 100
        }
        onEnable() {
            super.onEnable();
            var t = "./unjzp/help/" + r.Instance.AppID + "/provably_" + r.Instance.lang + ".html";
            this.iframe = l.Browser.document.createElement("iframe");
            this.iframe.style.position = "absolute";
            this.iframe.style.zIndex = 100;
            this.iframe.style["background-color"] = "#000000";
            this.iframe.allowTransparency = "false";
            this.iframe.src = t;
            this.iframe.style.border = "medium none";
            l.Browser.document.body.appendChild(this.iframe);
            l.stage.on(s.RESIZE, this, this.onResize);
            this.onResize();
            this.zOrder = 100
        }
        onResize() {
            var t = null;
            var e = 1900;
            var i = 1600;
            var s = 900;
            var n = 900;
            if (this.isHor) {
                t = new p(30, 100, 1840, 750)
            } else {
                t = new p(30, 100, 840, 1750);
                e = 900;
                i = 900;
                s = 1900;
                n = 1600
            }
            var h = e - l.stage.realDesignWidth;
            var a = s - l.stage.realDesignHeight;
            if (this.isHor) {
                this.imgBG && (this.imgBG.width = l.stage.realDesignWidth);
                this.imgLine && (this.imgLine.width = l.stage.realDesignWidth);
                this.imgTitle && (this.imgTitle.x = 30 + h / 2);
                this.btnClose && (this.btnClose.x = 1820 - h / 2)
            } else {
                this.imgBG && (this.imgBG.height = l.stage.realDesignHeight);
                this.imgLine && (this.imgLine.y = 72 + a / 2);
                this.imgTitle && (this.imgTitle.y = 36 + a / 2);
                this.btnClose && (this.btnClose.y = 36 + a / 2)
            }
            d.autoIframe(this.iframe, t, this.isHor)
        }
        onButtonClick(t) {
            super.onButtonClick(t);
            if (t == "btnClose") {
                this.onCloseClick()
            }
        }
        onDestroy() {
            super.onDestroy();
            if (this.iframe) {
                l.Browser.document.body.removeChild(this.iframe);
                this.iframe = null
            }
        }
    }
    BaseFSG.Base.View.GreenDetailed = l.GreenDetailed = k;
    class A extends t {
        constructor() {
            super()
        }
        createUI() {
            this.loadSceneByName("HeadCellView")
        }
    }
    BaseFSG.Base.View.HeadCell = l.HeadCell = A;
    class ft extends t {
        constructor() {
            super();
            this.imgWinSkinConfig = ["img_num_01.png", "img_num_02.png"];
            this.JY_TIME = 100;
            this._is_movie = false
        }
        baseInit(t) {
            super.baseInit(t);
            this.setUIPathByName("HeaderView")
        }
        createUI() {
            super.createUI()
        }
        registeEvent() {
            super.registeEvent();
            this.btnSetting && this.btnSetting.on(s.CLICK, this, this.onBtnSetting);
            this.btnHelp && this.btnHelp.on(s.CLICK, this, this.onBtnHelp);
            a.on("GLOABLE_USER_BALANCE_CHANGE", this, this.onBalanceChanged, 1);
            a.on("NC_FSG_START", this, this.onGameStart);
            a.on("NC_FSG_OVER", this, this.onGameOver);
            a.on("NC_FSG_NEXT", this, this.onNext);
            a.on("TCP_GET_READY_FINISH", this, this.onGetReady);
            a.on("NC_AUTOMODE_CHANGE", this, this.onAutoModeChange)
        }
        onAutoModeChange(t) {
            if (t) {
                this.btnSetting && (this.btnSetting.disabled = true);
                this.btnHelp && (this.btnHelp.disabled = true)
            } else {
                this.btnSetting && (this.btnSetting.disabled = false);
                this.btnHelp && (this.btnHelp.disabled = false)
            }
        }
        onGetReady() {
            this.initView();
            c.Instance.isAutoGaming = false;
            this.onAutoModeChange()
        }
        onGameStart(t, e) {}
        onGameOver(t) {
            if (!t) t = c.Instance.FairSimple;
            if (t != null && t.rm != null && t.rm > 0) {
                if (this._is_movie) {
                    this.hideWin();
                    l.timer.clear(this, this.hideWin);
                    l.timer.once(this.JY_TIME + 1, this, this.makeMovie, [t])
                } else {
                    this.makeMovie(t)
                }
            } else {
                l.timer.clear(this, this.hideWin);
                this.hideWin()
            }
        }
        makeMovie(t) {
            var e = this;
            if (!t) t = c.Instance.FairSimple;
            this.lblWin && (this.lblWin.text = "+" + d.getCurrencyStrBySignal(d.getMoneyTextByNumber(t.rm)));
            this.imgWin && (this.imgWin.skin = r.Instance.ModuleName + "/" + d.getPCOrMobilePath() + "/common/ui/" + this.imgWinSkinConfig[t.rm > t.bm ? 0 : 1]);
            this.imgWin && (this.imgWin.visible = true);
            this.imgWin && (this.imgWin.alpha = 0);
            this._is_movie = true;
            B.clearTarget(this.imgWin);
            B.to(this.imgWin, {
                alpha: 1
            }, this.JY_TIME, null, _.create(this, function() {
                l.timer.clear(this, e.hideWin);
                l.timer.once(r.Instance.hide_win_interval, this, e.hideWin)
            }))
        }
        hideWin() {
            var t = this;
            this._is_movie = false;
            this.imgWin && (this.imgWin.visible = false);
            B.clearTarget(this.imgWin);
            B.to(this.imgWin, {
                alpha: 0
            }, this.JY_TIME, null, _.create(this, function() {
                t.imgWin && (t.imgWin.visible = false)
            }))
        }
        onNext() {}
        onEnable() {
            super.onEnable();
            this.onResize();
            l.stage.on(s.RESIZE, this, this.onResize);
            this.initView()
        }
        onResize() {
            if (this.isHor) {
                var t = 1900 - l.stage._realDesignWidth;
                var e = 900 - l.stage.realDesignHeight;
                this.imgBG && (this.imgBG.width = l.stage._realDesignWidth - 20);
                this.btnHelp && (this.btnHelp.x = r.Instance.help_pos_x);
                this.imgBalance && (this.imgBalance.x = 1613 - t);
                this.btnSetting && (this.btnSetting.x = 1768 - t);
                this.imgLogo && (this.imgLogo.x = r.Instance.logo_pos_x + t / 2);
                this.imgWin && (this.imgWin.x = 1609 - t)
            } else {
                var t = 900 - l.stage._realDesignWidth;
                var e = 1900 - l.stage.realDesignHeight;
                this.imgBG && (this.imgBG.y = l.stage.realDesignHeight - 23)
            }
        }
        initView() {
            this.imgWin && (this.imgWin.visible = false);
            if (this.btnSetting) {
                var t = new b;
                t.hit.drawRect(-this.btnSetting.width / 2, -this.btnSetting.height / 2, this.btnSetting.width * 2, this.btnSetting.height * 2, "#000000");
                this.btnSetting.hitArea = t
            }
            if (this.btnHelp && !this.isHor) {
                var t = new b;
                t.hit.drawRect(-this.btnHelp.width / 2, -this.btnHelp.height / 2, this.btnHelp.width * 2, this.btnHelp.height * 2, "#000000");
                this.btnHelp.hitArea = t
            }
            this.onBalanceChanged()
        }
        onBalanceChanged() {
            this.lbBalance && (this.lbBalance.text = d.getCurrencyStrBySignal(d.trimMoney(r.Instance.balance)))
        }
        onBtnSetting() {
            a.dispatch("NC_USERINFO_CLICK")
        }
        onBtnHelp() {
            a.dispatch("NC_SHOW_DETAILED_RULES")
        }
    }
    BaseFSG.Base.View.HeaderView = l.HeaderView = ft;
    class R extends t {
        constructor() {
            super()
        }
        baseInit(t) {
            super.baseInit(t);
            this.setUIPathByName("HeadListView")
        }
        registeEvent() {
            super.registeEvent();
            this.btnClose && this.btnClose.on(s.CLICK, this, this.destroy)
        }
        show() {
            super.show();
            this.headListPanel.vScrollBar.visible = false;
            this.createHeadImageList()
        }
        createHeadImageList() {
            for (var t = 1; t < 73; t++) {
                var e = new A;
                e.imgHeadFront.skin = r.Instance.ModuleName + "/" + d.getPCOrMobilePath(this) + "/common/photo/av_" + t + ".png";
                e.anchorX = .5;
                e.anchorY = .5;
                this.headListPanel.addChild(e);
                e.x = 80 + (t - 1) % 5 * 160;
                e.y = 80 + Math.floor((t - 1) / 5) * 160;
                e.btnHeadCell.on(s.CLICK, this, this.onHeadCellClick, [t]);
                if (t == r.Instance.pid) {
                    e.imgHeadBg.skin = r.Instance.ModuleName + "/" + d.getPCOrMobilePath(this) + "/common/ui/img_headBg1_02.png"
                } else {
                    e.imgHeadBg.skin = r.Instance.ModuleName + "/" + d.getPCOrMobilePath(this) + "/common/ui/img_headBg1.png"
                }
            }
        }
        onHeadCellClick(t) {
            N.Instance.doChangeUserImageHead(t);
            this.destroy()
        }
    }
    BaseFSG.Base.View.HeadList = l.HeadList = R;
    class Ct extends t {
        constructor() {
            super();
            this.curCell = null;
            this.CELL_WIDTH = 418;
            this.CELL_HEIGHT = 64;
            this.CELL_COLUMN = 2
        }
        baseInit(t) {
            super.baseInit(t);
            this._uiPath = "GameUI/Common/View/LangSettingView"
        }
        initList(h) {
            var a = this;
            if (this.isHor) {
                this.CELL_HEIGHT = 64;
                this.CELL_WIDTH = 317
            } else {
                this.CELL_HEIGHT = 104;
                this.CELL_WIDTH = 740;
                this.CELL_COLUMN = 1
            }
            if (this.pList) {
                this.pList.destroyChildren();
                for (var t = 0; t < Math.ceil(h.length / this.CELL_COLUMN); t++) {
                    for (var e = 0; e < this.CELL_COLUMN; e++) {
                        var i = t * this.CELL_COLUMN + e;
                        if (i < h.length) {
                            d.createView(y, _.create(this, function(t, e, i, s) {
                                a.pList.addChild(s);
                                s.width = a.CELL_WIDTH;
                                s.x = e * (a.CELL_WIDTH + 13);
                                s.y = t * a.CELL_HEIGHT;
                                var n = new Object;
                                n.lang = h[i];
                                n.num = m.LANGUAGE_CONFIG[h[i]];
                                n.key = "lang";
                                s.setDto(n);
                                if (n.lang == a._nowLang) {
                                    a.curCell = s;
                                    a.curCell.changeSelected(true)
                                }
                            }, [t, e, i]))
                        }
                    }
                }
            }
        }
        checkOK() {
            this.btnOK && (this.btnOK.disabled = this._lastLang == this._nowLang)
        }
        onEnable() {
            super.onEnable();
            this.pList && (this.pList.vScrollBar.visible = false);
            this.initData()
        }
        initData() {
            this._lastLang = r.Instance.lang;
            this.NowLang = this._lastLang;
            var t = h.langList;
            if (t != null && t.length > 1) {
                this.initList(t)
            } else {
                this.destroy()
            }
        }
        registeEvent() {
            super.registeEvent();
            this.registeAllButton();
            a.on("NC_FSG_CELL_SELECTED", this, this.onCellSelected)
        }
        onCellSelected(t) {
            if (t != null && t.Data != null) {
                var e = t.Data;
                if (e.key == "lang") {
                    this.NowLang = e.lang;
                    if (this.curCell != null) {
                        this.curCell.changeSelected()
                    }
                    this.curCell = t;
                    this.curCell.changeSelected(true)
                }
            }
        }
        onButtonClick(t) {
            super.onButtonClick(t);
            switch (t) {
                case "btnOK":
                    this.onBtnSure();
                    break;
                case "btnClose":
                    this.destroy();
                    break
            }
        }
        onBtnSure() {
            if (this._nowLang != this._lastLang) {
                d.setLang(this._nowLang)
            }
        }
        set NowLang(t) {
            this._nowLang = t;
            this.checkOK()
        }
        get NowLang() {
            return super.NowLang
        }
    }
    BaseFSG.Base.View.LangSettingView = l.LangSettingView = Ct;
    class It extends t {
        constructor() {
            super()
        }
        baseInit(t) {
            super.baseInit(t);
            this.setUIPathByName("MyBetView")
        }
        init() {
            super.init()
        }
        createUI() {
            super.createUI()
        }
        registeEvent() {
            super.registeEvent()
        }
        onEnable() {
            super.onEnable();
            this.initView()
        }
        initView() {
            this.myBet1.setBX(1);
            this.myBet2.setBX(2);
            var t = c.Instance;
            var e = t.getMyBetCount();
            a.dispatch("MFG_BET_BX_CHANGE", [e]);
            var i = t.getMyBetData(1);
            var s = t.getMyBetData(2);
            this.myBet1.setDto(i);
            this.myBet2.setDto(s)
        }
    }
    BaseFSG.Base.View.MyBetView = l.MyBetView = It;
    class Et extends t {
        constructor() {
            super();
            this.lastQuickMoney = 0;
            this.isAuto = false;
            this._betMoney = 1;
            this.min = 1;
            this.max = 200;
            this._autoMode = false;
            this._num = "";
            this._fix_count = 2;
            this._numCount = 4;
            this._numMulCount = 5;
            this.POPUP_BET_NONE = -1;
            this.POPUP_BET_KEYBOARD = 1;
            this.POPUP_BET_LIST = 2;
            this.needFresh = true;
            this.offX = 0;
            this.offY = 0;
            this.MOVIE_INTERVAL = 300;
            this.FLASH_TIME = 300;
            this.FLASH_START_X = -410;
            this.FLASH_END_X = 590;
            this.H_DIS = 10;
            this.RIGHT_DIS = 0;
            this.CODE_STRING = "brd";
            this.QUICK_BET_MONEY_ARRAY = [.1, .5, 1, 2, 5, 8, 10, 20, 50, 100, 200, 500, 1e3, 5e3, 1e4, 5e4, 1e5, 5e5, 1e6];
            this.QUICK_BET_COLUMN = 2;
            this.QUICK_BET_CELL_WIDTH = 242;
            this.QUICK_BET_CELL_HEIGHT = 65;
            this.QUICK_H_GAP = 20;
            this.QUICK_V_GAP = 15;
            this.lastFreshTime = 0;
            this.AUTO_DELAY = 1e3;
            this.popStatus = this.POPUP_BET_NONE
        }
        baseInit() {
            super.baseInit();
            this.setUIPathByName("MyBetViewCell")
        }
        initConfig() {}
        onEnable() {
            super.onEnable();
            this.onResize();
            l.stage.on(s.RESIZE, this, this.onResize);
            this.initConfig();
            this.initView();
            this.fresh()
        }
        onResize() {
            if (this.isHor) {
                this.offX = 1900 - l.stage._realDesignWidth;
                this.offY = 900 - l.stage.realDesignHeight;
                this.imgRight && (this.imgRight.x = 1903 - this.offX / 2);
                this.imgLeft && (this.imgLeft.x = -3 + this.offX / 2);
                this.imgBottom && (this.imgBottom.width = l.stage._realDesignWidth - 30)
            } else {
                this.offX = 900 - l.stage._realDesignWidth;
                this.offY = 1900 - l.stage.realDesignHeight;
                this.spBottom && (this.spBottom.y = 0 - this.offY / 2);
                this.spBottom2 && (this.spBottom2.y = 0 - this.offY / 2);
                this.spBottom3 && (this.spBottom3.y = 0 - this.offY / 2);
                this.btnSha && (this.btnSha.y = 150 + this.offY / 2)
            }
        }
        createUI() {
            super.createUI()
        }
        registeEvent(t = true) {
            super.registeEvent();
            this.registeAllButton();
            a.on("NC_FSG_START", this, this.onGameStart);
            a.on("NC_FSG_OVER", this, this.onGameOver);
            if (t) {
                a.on("NC_FSG_NEXT", this, this.onNext, 2)
            }
            a.on("NC_FSG_OPE_OVER", this, this.onOpeOver);
            a.on("TCP_GET_READY_FINISH", this, this.onGetReady);
            a.on("NC_FSG_CELL_SELECTED", this, this.onCellSelected);
            a.on("NC_FSG_DT_CHANGE", this, this.onDTChange);
            a.on("NC_FSG_CONFIG_CHANGE", this, this.onConfigChange)
        }
        onGameStart(t, e) {}
        onGameOver() {}
        onNext() {}
        onCellSelected(t) {
            if (t != null && t.Data != null) {
                var e = t.Data;
                if (e.key == "bet") {
                    this.betMoney = e.num;
                    this.freshBetMoney()
                }
            }
            this.closeAll()
        }
        onOpeOver(t = true) {}
        onGetReady() {}
        onDTChange() {}
        onConfigChange() {
            this.freshLimit();
            this.initBetMoneyList()
        }
        freshLimit() {
            this.min = c.Instance.FairSimple.im;
            this.max = c.Instance.FairSimple.am;
            this._numCount = c.Instance.FairSimple.am.toString().length;
            this.freshBetMoney()
        }
        initBetMoneyList() {
            var h = this;
            if (this.pQuickBetMoney) {
                this.pQuickBetMoney.destroyChildren();
                var t = [];
                for (var e = 0; e < this.QUICK_BET_MONEY_ARRAY.length; e++) {
                    if (this.QUICK_BET_MONEY_ARRAY[e] >= c.Instance.FairSimple.im && this.QUICK_BET_MONEY_ARRAY[e] <= c.Instance.FairSimple.am) {
                        t.push(this.QUICK_BET_MONEY_ARRAY[e])
                    }
                }
                if (this.isHor) {
                    this.QUICK_BET_CELL_WIDTH = 222;
                    this.QUICK_BET_CELL_HEIGHT = 50
                } else {
                    this.QUICK_BET_CELL_WIDTH = 300;
                    this.QUICK_BET_CELL_HEIGHT = 60
                }
                for (var e = 0; e < Math.ceil(t.length / this.QUICK_BET_COLUMN); e++) {
                    for (var i = 0; i < this.QUICK_BET_COLUMN; i++) {
                        var s = e * this.QUICK_BET_COLUMN + i;
                        if (s < t.length) {
                            var n = t[s];
                            var a = d.createView(O, _.create(this, function(t, e, i, s) {
                                s.width = h.QUICK_BET_CELL_WIDTH;
                                s.height = h.QUICK_BET_CELL_HEIGHT;
                                var n = new Object;
                                n.num = i;
                                n.key = "bet";
                                s.setDto(n);
                                h.pQuickBetMoney.addChild(s);
                                s.x = (h.QUICK_BET_CELL_WIDTH + h.QUICK_H_GAP) * e;
                                s.y = (h.QUICK_BET_CELL_HEIGHT + h.QUICK_V_GAP) * t
                            }, [e, i, n]))
                        }
                    }
                }
            }
        }
        closeAll() {
            this.imgBetSelect && (this.imgBetSelect.visible = false);
            this.imgQuickBetMoney && (this.imgQuickBetMoney.visible = false);
            this.imgBetMoneyKeyboard && (this.imgBetMoneyKeyboard.visible = false);
            this.btnClose && (this.btnClose.visible = false);
            if (this.POPUP_BET_KEYBOARD == this.popStatus) {
                this.betMoney = this._num;
                this.freshBetMoney()
            }
            this.popStatus = this.POPUP_BET_NONE
        }
        freshCode(t) {
            var e = this;
            if (t && c.Instance.FairSimple != null && c.Instance.FairSimple[this.CODE_STRING] != null) {
                this.lbCode && (this.lbCode.text = c.Instance.FairSimple[this.CODE_STRING]);
                this.bSha && (this.bSha.x = this.imgSha.width + this.H_DIS);
                var i = this.btnSha.width - this.imgSha.displayWidth - this.H_DIS - this.RIGHT_DIS;
                this.p && (this.p.width = i);
                var s = d.setTextOverflowByEllipsis(this.lbCode, i);
                if (this.ani) {
                    d.makeLabelWordOneByOne(this.lbCode, s, 10, 2)
                } else {
                    this.lbCode.text = s
                }
                this.ani && (this.ani.x = this.FLASH_START_X);
                this.ani && this.ani.play();
                this.ani && (this.ani.visible = true);
                this.ani && B.clearTarget(this.ani);
                this.ani && B.to(this.ani, {
                    x: this.FLASH_END_X
                }, this.FLASH_TIME, null, _.create(this, function() {
                    e.ani && e.ani.stop();
                    e.ani && (e.ani.visible = false)
                }))
            } else {
                this.lbCode && (this.lbCode.text = "")
            }
        }
        startAutoGame() {
            this._data.leftTime--
        }
        changeAutoStatus() {
            if (c.Instance.isAuto) {
                this.btnBet && (this.btnBet.disabled = true);
                this.btnAuto && (this.btnAuto.disabled = false)
            } else {
                this.btnBet && (this.btnBet.disabled = false);
                this.btnAuto && (this.btnAuto.disabled = true)
            }
        }
        changeMoney(t = true) {
            if (t) {
                for (var e = 0; e < this.QUICK_BET_MONEY_ARRAY.length; e++) {
                    var i = this.QUICK_BET_MONEY_ARRAY[e];
                    if (i > this.betMoney) {
                        this.betMoney = i;
                        break
                    }
                }
            } else {
                for (var e = this.QUICK_BET_MONEY_ARRAY.length - 1; e >= 0; e--) {
                    var i = this.QUICK_BET_MONEY_ARRAY[e];
                    if (i < this.betMoney) {
                        this.betMoney = i;
                        break
                    }
                }
            }
            this.freshBetMoney()
        }
        freshBetMoney() {
            this.betMoney = Math.max(this.min, this.betMoney);
            this.betMoney = Math.min(this.max, this.betMoney);
            this.lblBet && (this.lblBet.text = d.getCurrencyStrBySignal(this.betMoney.toFixed(2)));
            this.onOpeOver()
        }
        stopAutoMode() {
            if (c.Instance.isAuto) {
                this._data.leftTime = 0;
                this._autoMode = false;
                c.Instance.isAutoGaming = this._autoMode;
                a.dispatch("NC_AUTOMODE_CHANGE", [this._autoMode])
            }
        }
        checkAutoModeWithWin() {
            if (this._data.totalLose && this._data.totalLose > 0) {
                if (c.Instance.balance_change_list[0] <= -this._data.totalLose) {
                    return true
                }
            }
            if (this._data.totalWin && this._data.totalWin > 0) {
                if (c.Instance.balance_change_list[0] >= this._data.totalWin) {
                    return true
                }
            }
            if (this._data.perWin && this._data.perWin > 0) {
                if (c.Instance.single_win_list[0] >= this._data.perWin) {
                    return true
                }
            }
            return false
        }
        checkAutoMode() {
            if (this._data.leftTime < 0) {
                this.stopAutoMode()
            } else {
                if (this.checkAutoModeWithWin()) {
                    this.stopAutoMode()
                } else {
                    l.timer.once(this.AUTO_DELAY, this, this.doAutoPlay)
                }
            }
        }
        doAutoPlay() {}
        freshLeftCount() {
            this.startAutoGame();
            this.checkAutoMode();
            this.lbLeft && (this.lbLeft.text = this._data.leftTime)
        }
        initView() {
            if (c.Instance.FairSimple != null && c.Instance.FairSimple.bmc != null && c.Instance.FairSimple.bmc.length > 0) {
                this.QUICK_BET_MONEY_ARRAY = c.Instance.FairSimple.bmc
            }
            this.closeAll();
            this.ani && this.ani.stop();
            this.btnAutoBetDis && (this.btnAutoBetDis.mouseEnabled = false);
            this.ani && (this.ani.visible = false);
            this.btnStop && (this.btnStop.visible = false);
            this.pQuickBetMoney && (this.pQuickBetMoney.vScrollBar.visible = false);
            if (this._fix_count <= 0) {
                this["btnNumDot"] && (this["btnNumDot"].disabled = true)
            }
            this.betMoney = parseFloat(d.getLocalStorageItem("COOKIE_BETMONEY", "1"));
            this.freshLimit();
            this.freshBetMoney();
            this.freshCode(true)
        }
        hideAllButton(t = true) {
            this.btnBet && (this.btnBet.visible = false);
            this.spMask && (this.spMask.visible = false);
            this.spAllMask && (this.spAllMask.visible = false);
            this.imgAuto && (this.imgAuto.visible = false);
            if (t) {
                this.imgBet && (this.imgBet.visible = false)
            }
            this.btnDec && (this.btnDec.disabled = false);
            this.btnAdd && (this.btnAdd.disabled = false);
            this.btnBetCoin && (this.btnBetCoin.disabled = false);
            this.btnAuto && (this.btnAuto.disabled = false)
        }
        freshNum() {
            this.lblBet && (this.lblBet.text = this._num)
        }
        fresh() {
            if (this._data == null) {
                this._data = d.getLocalStorageJson("COOKIEBETDATA");
                if (this._data == null) {
                    this._data = new z
                }
            }
            this.changeAutoStatus();
            this.freshData();
            this.initBetMoneyList();
            this.onOpeOver()
        }
        freshData() {
            if (c.Instance.FairSimple.bm != null && c.Instance.FairSimple.bm > 0) {
                this.betMoney = c.Instance.FairSimple.bm
            }
            this.freshBetMoney()
        }
        loadLastData(t = false) {
            var e = this;
            console.log(this.needFresh);
            if (c.Instance.FairSimple.brd != null && c.Instance.FairSimple.brd != "") {
                if (t && this.needFresh) {
                    l.timer.frameOnce(1, this, function() {
                        a.dispatch("NC_FSG_START");
                        e.needFresh = false
                    })
                }
                return true
            }
            if (t && this.needFresh) {
                this.needFresh = false
            }
            return false
        }
        changeAutoMode(t = false) {
            this.closeAll();
            this._autoMode = t;
            c.Instance.isAutoGaming = this._autoMode;
            a.dispatch("NC_AUTOMODE_CHANGE", [this._autoMode]);
            l.timer.clear(this, this.doAutoPlay)
        }
        hasDot() {
            if (this._num) {
                var t = "" + this._num;
                var e = t.indexOf(".");
                if (e > 0) {
                    return t.length - e - 1
                }
            }
            return -1
        }
        getNumCount() {
            var t = this._num.split(".");
            if (t.length == 1) {
                return t[0].length
            }
            return 0
        }
        delNum() {
            if (this._num.length > 0) {
                this._num = this._num.substring(0, this._num.length - 1)
            }
            this.freshNum()
        }
        addNum(t) {
            var e = true;
            if (this._num != "0" && this._num != "") {
                e = false
            }
            var i = -1;
            if (e == false) {
                i = this.hasDot()
            }
            var s = 1;
            if (t != ".") {
                if (e) {
                    if (t == 0) {
                        return
                    } else {
                        this._num = t
                    }
                } else {
                    if (i >= this._fix_count) {
                        return
                    }
                    if (this.getNumCount() >= this._numCount) {
                        return
                    }
                    this._num = this._num + "" + t
                }
            } else {
                if (i >= 0) {
                    return
                } else {
                    if (this._num == "") {
                        this._num = "0"
                    }
                    this._num = this._num + "."
                }
            }
            this.freshNum()
        }
        freshRefreshTime() {
            var t = (new Date).getTime();
            var e = 5e3 - t + this.lastFreshTime;
            this.lblTime && (this.lblTime.text = Math.ceil(e / 1e3));
            if (t - this.lastFreshTime > 5e3) {
                this.lblTime && (this.lblTime.text = "");
                l.timer.clear(this, this.freshRefreshTime);
                this.lastFreshTime = 0;
                this.btnFresh && (this.btnFresh.disabled = false)
            }
        }
        playButtonSound(t) {
            if (t == "btnBet") {
                I.Instance.playSound("big_button")
            } else if (t == "btnAutoBet") {
                I.Instance.playSound("chip")
            } else {
                I.Instance.playSound("button_click")
            }
        }
        doBet() {}
        doFresh() {
            N.Instance.doGetFairSimpleInitGame(true);
            this.btnFresh && (this.btnFresh.disabled = true);
            this.lastFreshTime = (new Date).getTime();
            l.timer.loop(100, this, this.freshRefreshTime);
            this.freshRefreshTime()
        }
        onButtonClick(t) {
            this.playButtonSound(t);
            switch (t) {
                case "btnFresh":
                    this.doFresh();
                    break;
                case "btnDec":
                    this.changeMoney(false);
                    break;
                case "btnAdd":
                    this.changeMoney();
                    break;
                case "btnBet":
                    this.closeAll();
                    this.doBet();
                    break;
                case "btnStop":
                    this.changeAutoMode(false);
                    break;
                case "btnBetCoin":
                    if (this.imgQuickBetMoney) {
                        this.imgQuickBetMoney.visible = !this.imgQuickBetMoney.visible;
                        this.btnClose && (this.btnClose.visible = this.imgQuickBetMoney.visible);
                        if (this.imgQuickBetMoney.visible) {
                            this.popStatus = this.POPUP_BET_LIST;
                            a.dispatch("NC_FSG_BET_MONEY_CELL_CHECK", [this.betMoney, "bet"])
                        }
                    }
                    break;
                case "btnKeyBoard":
                    if (this.imgBetMoneyKeyboard) {
                        this.imgBetMoneyKeyboard.visible = !this.imgBetMoneyKeyboard.visible;
                        this.btnClose && (this.btnClose.visible = this.imgBetMoneyKeyboard.visible);
                        if (this.imgBetMoneyKeyboard.visible) {
                            this.imgBetSelect && (this.imgBetSelect.visible = true);
                            this.popStatus = this.POPUP_BET_KEYBOARD;
                            this._num = "";
                            this.freshNum()
                        }
                    }
                    break;
                case "btnNum0":
                    this.addNum("0");
                    break;
                case "btnNum1":
                    this.addNum("1");
                    break;
                case "btnNum2":
                    this.addNum("2");
                    break;
                case "btnNum3":
                    this.addNum("3");
                    break;
                case "btnNum4":
                    this.addNum("4");
                    break;
                case "btnNum5":
                    this.addNum("5");
                    break;
                case "btnNum6":
                    this.addNum("6");
                    break;
                case "btnNum7":
                    this.addNum("7");
                    break;
                case "btnNum8":
                    this.addNum("8");
                    break;
                case "btnNum9":
                    this.addNum("9");
                    break;
                case "btnNumDot":
                    this.addNum(".");
                    break;
                case "btnDel":
                    this.delNum();
                    break;
                case "btnOK":
                    this.closeAll();
                case "btnClose":
                    this.closeAll();
                    break;
                case "btnSha":
                    break;
                case "btnCopy":
                    this.onBtnCopy();
                    break
            }
        }
        onBtnCopy() {
            var t = c.Instance;
            var e = new String;
            e += d.getMsgForNowLang("clip_seed_sec") + ":" + (t.FairSimple.ss256 ? t.FairSimple.ss256 : "") + "\r\n";
            e += d.getMsgForNowLang("clip_result_sec") + ":" + (t.FairSimple.rs256 ? t.FairSimple.rs256 : "") + "\r\n";
            d.setClipboard(e);
            i.Instance.showText(d.getMsgForNowLang("clip_ok"))
        }
        get betMoney() {
            return this._betMoney
        }
        set betMoney(t) {
            this._betMoney = t
        }
    }
    BaseFSG.Base.View.MyBetViewCell = l.MyBetViewCell = Et;
    class T extends t {
        constructor() {
            super();
            this._page = 1;
            this._total_page = 1;
            this._is_send = false;
            this._dataSource = []
        }
        onEnable() {
            super.onEnable()
        }
        baseInit(t) {
            super.baseInit(t);
            this.setUIPathByName("MyHistoryView")
        }
        createUI() {
            super.createUI()
        }
        registeEvent() {
            super.registeEvent();
            this.registeAllButton();
            this.on(j.EVENT_ON_VIEW_CREATE_END, this, this.onViewCreateEnd)
        }
        onViewCreateEnd() {
            this.initListConfig();
            this.init()
        }
        onButtonClick(t) {
            I.Instance.playSound("button_click");
            switch (t) {
                case "btnClose":
                    this.close();
                    break;
                case "btnPre":
                    this.onBtnPre();
                    break;
                case "btnNext":
                    this.onBtnNext();
                    break
            }
        }
        init() {
            this._is_send = false;
            this._page = 1;
            this._total_page = 1;
            this.freshList()
        }
        onBtnPre() {
            if (this._is_send) {
                return
            }
            this._page--;
            this.freshPage();
            this.freshList()
        }
        onBtnNext() {
            if (this._is_send) {
                return
            }
            this._page++;
            this.freshPage();
            this.freshList()
        }
        freshPage() {
            this._page = Math.max(1, this._page);
            this._page = Math.min(this._total_page, this._page);
            if (this._page <= 1) {
                this.btnPre && (this.btnPre.disabled = true);
                this.imgPre && (this.imgPre.alpha = .3)
            } else {
                this.btnPre && (this.btnPre.disabled = false);
                this.imgPre && (this.imgPre.alpha = 1)
            }
            if (this._page >= this._total_page) {
                this.btnNext && (this.btnNext.disabled = true);
                this.imgNext && (this.imgNext.alpha = .3)
            } else {
                this.btnNext && (this.btnNext.disabled = false);
                this.imgNext && (this.imgNext.alpha = 1)
            }
            this.pageNum && (this.pageNum.text = this._page);
            this.pageTotal && (this.pageTotal.text = this._total_page)
        }
        onLoad() {
            super.onLoad()
        }
        initListConfig() {}
        updateItem(t, e) {
            t.view.setDto(t.dataSource)
        }
        freshList() {
            if (this._is_send || r.Instance.http_replay_address == null || r.Instance.http_replay_address == "") {
                return
            }
            var t = 10;
            if (this.isHor) {
                t = 6
            }
            var e = r.Instance.http_replay_address.replace("/api/", "/SimpleFairGameHistory/");
            var i = e + "?pid=" + r.Instance.UrlPid + "&game_id=" + r.Instance.AppID + "&uid=" + r.Instance.uid + "&page=" + this._page + "&limit=" + t + "&is_demo=false";
            d.IsDebugMode && console.log("replay url:" + i);
            this._is_send = true;
            Z.Instance.tryHttp(i, 3e3, 3, this, this.onReplayHttpCompleteHandler, this.onReplayHttpErrorHandler)
        }
        onReplayHttpCompleteHandler(t) {
            this._is_send = false;
            m.IS_DEBUG_MODE && console.info("onReplayHttpCompleteHandler", t);
            if (t.error > 0) {
                Y.showError(t);
                return
            }
            this._dataSource = [];
            this._dataSource = t.list;
            this._page = t.page;
            this._total_page = t.total_page;
            this.freshPage();
            this.renderList()
        }
        renderList() {
            var i = this;
            this.myBetList.destroyChildren();
            if (this._dataSource == null || this._dataSource.length == 0) {
                return
            }
            for (var t = 0; t < this._dataSource.length; t++) {
                var e = d.createView(v, _.create(this, function(t, e) {
                    e.setDto(i._dataSource[t], t);
                    e.x = 0;
                    e.y = t * 78;
                    this.myBetList.addChild(e)
                }, [t]))
            }
        }
        onReplayHttpErrorHandler(t) {
            this._is_send = false;
            m.IS_DEBUG_MODE && console.info("onReplayHttpErrorHandler", t);
            var e = new Object;
            e.error = 100002;
            d.showMessage(d.GetErrorText(e), 100002)
        }
    }
    BaseFSG.Base.View.MyHistory = l.MyHistory = T;
    class O extends t {
        constructor() {
            super();
            this._selected = false;
            this._stype = 1
        }
        baseInit(t) {
            super.baseInit(t);
            this.setUIPathByName("NumberCell")
        }
        createUI() {
            super.createUI()
        }
        registeEvent() {
            super.registeEvent();
            this.registeAllButton();
            a.on("NC_FSG_BET_MONEY_CELL_CHECK", this, this.onCellCheck)
        }
        onCellCheck(t, e) {
            if (this._data != null) {
                if (this._data.key == e) {
                    if (this._data.num == t) {
                        this.changeSelected(true)
                    } else {
                        this.changeSelected()
                    }
                }
            } else {
                this.changeSelected()
            }
        }
        onButtonClick(t) {
            switch (t) {
                case "btn":
                    a.dispatch("NC_FSG_CELL_SELECTED", [this]);
                    break
            }
        }
        onEnable() {
            super.onEnable();
            this.fresh()
        }
        onLoad() {
            super.onLoad()
        }
        setDto(t, e = false, i = 1) {
            this._data = t;
            this._selected = e;
            if (this.ViewCreated) {
                this.lbl && (this.lbl.fontSize = Math.max(20, Math.floor(this.height / 2)));
                this.fresh()
            }
        }
        changeSelected(t = false) {
            this._selected = t;
            if (this._stype == 1) {
                this.btn && (this.btn.disabled = this._selected);
                this.btn && (this.btn.mouseEnabled = true)
            } else {
                this.btn2 && (this.btn2.disabled = this._selected);
                this.btn2 && (this.btn2.mouseEnabled = true)
            }
        }
        fresh() {
            if (this._data) {
                this.lbl && (this.lbl.text = this._data.num);
                if (this._stype == 1) {
                    this.btn && (this.btn.visible = true);
                    this.btn2 && (this.btn2.visible = false)
                } else {
                    this.btn2 && (this.btn2.visible = true);
                    this.btn && (this.btn.visible = false)
                }
                this.changeSelected(this._selected)
            }
        }
        get Data() {
            return this._data
        }
        set Data(t) {
            super.Data = t
        }
    }
    BaseFSG.Base.View.NumberCell = l.NumberCell = O;
    class Nt extends t {
        constructor(t = null, e = 3) {
            super();
            this._num = "0";
            this._fix_count = "2";
            this._callback = null;
            this._numCount = 3;
            this._callback = t;
            this._numCount = e
        }
        createUI() {
            this.loadSceneByName("NumberInputView")
        }
        registeEvent() {
            super.registeEvent();
            this.registeAllButton()
        }
        onButtonClick(t) {
            switch (t) {
                case "btn0":
                    this.addNum("0");
                    break;
                case "btn1":
                    this.addNum("1");
                    break;
                case "btn2":
                    this.addNum("2");
                    break;
                case "btn3":
                    this.addNum("3");
                    break;
                case "btn4":
                    this.addNum("4");
                    break;
                case "btn5":
                    this.addNum("5");
                    break;
                case "btn6":
                    this.addNum("6");
                    break;
                case "btn7":
                    this.addNum("7");
                    break;
                case "btn8":
                    this.addNum("8");
                    break;
                case "btn9":
                    this.addNum("9");
                    break;
                case "btnDot":
                    this.addNum(".");
                    break;
                case "btnClear":
                    this.clear();
                    break;
                case "btnOK":
                    if (this._callback != null) {
                        this._callback.runWith(this._num)
                    }
                    this.close();
                    break;
                case "btnClose":
                    this.close();
                    break
            }
        }
        clear() {
            this._num = "0";
            this.freshNum()
        }
        addNum(t) {
            var e = true;
            if (this._num != "0") {
                e = false
            }
            var i = -1;
            if (e == false) {
                i = this.hasDot()
            }
            var s = 1;
            if (t != ".") {
                if (e) {
                    if (t == 0) {
                        return
                    } else {
                        this._num = t
                    }
                } else {
                    if (i >= this._fix_count) {
                        return
                    }
                    if (this.getNumCount() >= this._numCount) {
                        return
                    }
                    this._num = this._num + "" + t
                }
            } else {
                if (i >= 0) {
                    return
                } else {
                    this._num = this._num + "."
                }
            }
            this.freshNum()
        }
        onEnable() {
            super.onEnable();
            this.initView()
        }
        initView() {
            this.freshNum()
        }
        freshNum() {
            this.lbNum && (this.lbNum.text = this._num)
        }
        hasDot() {
            if (this._num) {
                var t = "" + this._num;
                var e = t.indexOf(".");
                if (e > 0) {
                    return t.length - e - 1
                }
            }
            return -1
        }
        getNumCount() {
            var t = this._num.split(".");
            if (t.length == 1) {
                return t[0].length
            }
            return 0
        }
    }
    BaseFSG.Base.View.NumberInputView = l.NumberInputView = Nt;
    class Bt extends t {
        constructor() {
            super();
            this.COLUMN_PER_ROW = 10;
            this.CELL_HEIGHT = 42;
            this.CELL_WIDTH = 128;
            this.CELL_GAP = 5;
            this.BASE_HGITH = 56;
            this.show_item_count = 10;
            this.show_item_count2 = 60;
            this.cell_scale = 1;
            this._mode = false;
            this.MOVIE_TIME = 250;
            this._is_movie = false;
            this._tw = null;
            this._result_history = [];
            this._result_wait_list = [];
            this._cell_list = [];
            this._cell_list2 = []
        }
        baseInit() {
            super.baseInit();
            this.setUIPathByName("ResultView")
        }
        createUI() {
            super.createUI()
        }
        onEnable() {
            super.onEnable();
            this.onResize();
            l.stage.on(s.RESIZE, this, this.onResize);
            this.initView()
        }
        onResize() {
            this.freshList2();
            if (!this.isHor) {
                var t = 900 - l.stage._realDesignWidth;
                var e = 1900 - l.stage.realDesignHeight;
                this.pBG && (this.pBG.y = 229 + e / 2);
                this.btnHistory && (this.btnHistory.y = 261 + e / 2)
            }
        }
        makeListData() {}
        madeDataByHor() {
            if (this.isHor) {
                this.COLUMN_PER_ROW = 10;
                this.CELL_WIDTH = 90;
                this.CELL_HEIGHT = 30;
                this.BASE_HGITH = 61;
                this.CELL_GAP = 5
            } else {
                this.COLUMN_PER_ROW = 6;
                this.CELL_WIDTH = 128;
                this.CELL_HEIGHT = 42;
                this.BASE_HGITH = 75;
                this.CELL_GAP = 12
            }
        }
        makeListData2() {
            this.madeDataByHor();
            this.dataSource2 = this._result_history.concat().reverse();
            if (this.dataSource2 != null && this.dataSource2.length > 0) {
                var t = Math.ceil(this.dataSource2.length / this.COLUMN_PER_ROW);
                var e = this.BASE_HGITH + t * this.CELL_HEIGHT + (t - 1) * this.CELL_GAP;
                this.pMore && (this.pMore.height = e);
                this.imgMore && (this.imgMore.height = e)
            }
        }
        updateItem(t, e) {
            t.view.setDto(t.dataSource)
        }
        freshList() {
            this.makeListData();
            this.renderList()
        }
        freshList2() {
            this.makeListData2();
            this.renderList2()
        }
        renderList() {
            var e = this;
            if (this._result_wait_list == null || this._result_wait_list.length == 0) {
                return
            }
            if (this._is_movie) {
                return
            }
            this._is_movie = true;
            var i = this._result_wait_list.shift();
            for (var t = 0; t < this._cell_list.length; t++) {
                var s = this._cell_list[t];
                B.to(s, {
                    x: s.x + (this.CELL_WIDTH + this.CELL_GAP)
                }, this.MOVIE_TIME, null, _.create(this, function(t) {
                    if (t.x > 1330) {
                        t.destroy();
                        u.deleteItemFromArray(e._cell_list, t)
                    }
                }, [s]))
            }
            d.createView(r.Instance.ResultCellClass, _.create(this, function(t) {
                t.alpha = 0;
                t.anchorX = 1;
                t.anchorY = .5;
                t.scaleX = 2;
                t.scaleY = 2;
                t.width = e.CELL_WIDTH;
                t.x = e.CELL_WIDTH;
                t.y = e.CELL_HEIGHT / 2;
                t.setDto(i);
                this.historyList.addChild(t);
                e._tw = B.to(t, {
                    scaleX: 1,
                    scaleY: 1,
                    alpha: 1
                }, e.MOVIE_TIME, null, _.create(this, function() {
                    e._is_movie = false;
                    e._tw = null;
                    e.renderList()
                }));
                e._cell_list.push(t)
            }))
        }
        renderList2() {
            var i = this;
            if (this.dataSource2 == null || this.dataSource2.length == 0) {
                return
            }
            for (var t = 0; t < this.dataSource2.length; t++) {
                var e = null;
                if (t < this._cell_list2.length) {
                    e = this._cell_list2[t];
                    e.setDto(this.dataSource2[t])
                } else {
                    d.createView(r.Instance.ResultCellClass, _.create(this, function(t, e) {
                        e.setDto(i.dataSource2[t]);
                        e.width = i.CELL_WIDTH;
                        e.x = t % i.COLUMN_PER_ROW * (i.CELL_WIDTH + i.CELL_GAP);
                        e.y = Math.floor(t / i.COLUMN_PER_ROW) * (i.CELL_HEIGHT + i.CELL_GAP);
                        this.historyList2.addChild(e);
                        i._cell_list2.push(e)
                    }, [t]))
                }
            }
        }
        onLoad() {
            super.onLoad()
        }
        registeEvent() {
            super.registeEvent();
            a.on("NC_FSG_OVER", this, this.onGameOver);
            a.on("NC_SHOW_RESULT_VIEW", this, this.showOrHide);
            a.on("NC_AUTOMODE_CHANGE", this, this.onAutoModeChange);
            this.registeAllButton()
        }
        onAutoModeChange(t) {
            if (t) {
                this.btnHistory && (this.btnHistory.disabled = true)
            } else {
                this.btnHistory && (this.btnHistory.disabled = false)
            }
        }
        showOrHide(t) {
            this.visible = t
        }
        onGameOver(t) {
            if (this._result_history == null) {
                this._result_history = []
            }
            this._result_history.push(t);
            if (this._result_history.length > this.show_item_count2) {
                this._result_history.splice(0, this._result_history.length - this.show_item_count2)
            }
            if (this._result_wait_list == null) {
                this._result_wait_list = []
            }
            this._result_wait_list.push(t);
            this.freshList();
            this.freshList2()
        }
        onButtonClick(t) {
            I.Instance.playSound("button_click");
            switch (t) {
                case "btnClose":
                    if (this._mode) {
                        this.changeMode()
                    }
                    break;
                case "btnHistory":
                    this.changeMode(!this._mode);
                    break
            }
        }
        changeMode(t = false) {
            this._mode = t;
            this.pMore && (this.pMore.visible = this._mode);
            this.btnHistory && (this.btnHistory.selected = this._mode);
            this.btnClose && (this.btnClose.visible = this._mode)
        }
        initView() {
            this.madeDataByHor();
            this.changeMode();
            this.freshList();
            this.freshList2()
        }
        onCloseApp() {}
    }
    BaseFSG.Base.View.ResultView = l.ResultView = Bt;
    class wt extends t {
        constructor() {
            super()
        }
        baseInit(t) {
            super.baseInit(t);
            this.setUIPathByName("ResultViewCell")
        }
        createUI() {
            super.createUI()
        }
        onLoad() {
            super.onLoad()
        }
        onEnable() {
            super.onEnable();
            this.fresh()
        }
        registeEvent() {
            super.registeEvent();
            this.btnResultVew && this.btnResultVew.on(s.CLICK, this, this.onBtnResultVew)
        }
        setDto(t) {
            this._data = t;
            if (this.ViewCreated) {
                this.fresh()
            }
        }
        fresh() {
            if (this._data) {
                if (this._data.rm != "" && this._data.rm > 0) {
                    this.lbBS && (this.lbBS.color = "#2fb114")
                } else {
                    this.lbBS && (this.lbBS.color = "#ffffff")
                }
                var t = this._data.gs + "";
                if (t.length <= 4) {
                    t = "0" + t
                }
                this.lbBS && (this.lbBS.text = t)
            }
        }
        onBtnResultVew() {}
        onDestroy() {
            super.onDestroy();
            this._data = null
        }
    }
    BaseFSG.Base.View.ResultViewCell = l.ResultViewCell = wt;
    class yt extends t {
        constructor() {
            super()
        }
        baseInit(t) {
            super.baseInit(t);
            this._uiPath = "GameUI/Common/View/ScreenSettingView"
        }
        onEnable() {
            super.onEnable();
            this.initData()
        }
        initData() {
            this._lastType = h.onPC;
            this.NowType = this._lastType
        }
        registeEvent() {
            super.registeEvent();
            this.registeAllButton()
        }
        onButtonClick(t) {
            super.onButtonClick(t);
            switch (t) {
                case "btnSure":
                    this.onBtnSure();
                    break;
                case "btnClose":
                    this.destroy();
                    break;
                case "btnH":
                    this.NowType = true;
                    d.setMobileScreenType(this._nowType ? 2 : 1);
                    break;
                case "btnV":
                    this.NowType = false;
                    d.setMobileScreenType(this._nowType ? 2 : 1);
                    break
            }
        }
        onBtnSure() {}
        set NowType(t) {
            this._nowType = t;
            this.btnH.disabled = this._nowType;
            this.btnV.disabled = !this._nowType
        }
        get NowType() {
            return super.NowType
        }
    }
    BaseFSG.Base.View.ScreenSettingView = l.ScreenSettingView = yt;
    class vt extends t {
        constructor() {
            super();
            this._copying = false
        }
        baseInit(t) {
            super.baseInit(t);
            this.setUIPathByName("ShaView")
        }
        init() {
            super.init()
        }
        createUI() {
            super.createUI()
        }
        registeEvent() {
            super.registeEvent();
            a.on("NC_FSG_START", this, this.onStart, 1);
            a.on("NC_FSG_OVER", this, this.onOver, 1);
            a.on("NC_FSG_NEXT", this, this.onNext, 1);
            a.on("TCP_GET_READY_FINISH", this, this.onGetReady, 1);
            this.registeAllButton()
        }
        onButtonClick(t) {
            I.Instance.playSound("button_click");
            switch (t) {
                case "btnCopy":
                    this.onBtnCopy();
                    break;
                case "btnCheck":
                    this.onBtnCheck();
                    break;
                case "btnClose":
                case "btnClose2":
                    a.dispatch("NC_SHOW_SHA", [false]);
                    break
            }
        }
        onEnable() {
            super.onEnable();
            this.initView();
            this.onResize();
            l.stage.on(s.RESIZE, this, this.onResize)
        }
        onResize() {
            if (this.isHor) {} else {
                var t = 900 - l.stage._realDesignWidth;
                var e = 1900 - l.stage.realDesignHeight;
                this.box && (this.box.y = 188 + e / 2)
            }
        }
        initView() {
            if (this.btnCopy) {
                var t = new b;
                t.hit.drawRect(0, -this.btnCopy.height / 2, this.btnCopy.width, this.btnCopy.height * 2, "#000000");
                this.btnCopy.hitArea = t
            }
            if (this.btnCheck) {
                var t = new b;
                t.hit.drawRect(0, -this.btnCheck.height / 2, this.btnCheck.width, this.btnCheck.height * 2, "#000000");
                this.btnCheck.hitArea = t
            }
            if (c.Instance.FairSimple.brd != null && c.Instance.FairSimple.brd != "") {
                this.onStart()
            } else {
                this.onNext()
            }
        }
        onStart() {
            this.lbCode.text = c.Instance.FairSimple.brd;
            this.lbResultSecret.text = c.Instance.FairSimple.rs256;
            this.lbSeed.text = "";
            this.lbSeedSecret.text = c.Instance.FairSimple.ss256;
            this.lbResult.text = "";
            this.btnCheck && (this.btnCheck.disabled = true);
            this.btnCopy && (this.btnCopy.disabled = false);
            this.onCalculate()
        }
        onOver() {
            this.lbCode.text = c.Instance.FairSimple.brd;
            this.lbResultSecret.text = c.Instance.FairSimple.rs256;
            this.lbSeed.text = c.Instance.FairSimple.ss;
            this.lbSeedSecret.text = c.Instance.FairSimple.ss256;
            this.lbResult.text = c.Instance.FairSimple.gs;
            this.btnCheck && (this.btnCheck.disabled = false);
            this.btnCopy && (this.btnCopy.disabled = false);
            this.onCalculate()
        }
        onCalculate() {
            if (this.isHor) {} else {
                if (this.lbCode.text != "") {
                    d.setTextOverflowByEllipsis(this.lbCode, 500)
                }
                if (this.lbSeed.text != "") {
                    d.setTextOverflowByEllipsis(this.lbSeed, 500)
                }
                if (this.lbResultSecret.text != "") {
                    d.setTextOverflowByEllipsis(this.lbResultSecret, 500)
                }
                if (this.lbSeedSecret.text != "") {
                    d.setTextOverflowByEllipsis(this.lbSeedSecret, 500)
                }
                if (this.lbResult.text != "") {
                    d.setTextOverflowByEllipsis(this.lbResult, 500)
                }
            }
        }
        onNext() {
            this.lbCode.text = "";
            this.lbResultSecret.text = "";
            this.lbSeed.text = "";
            this.lbSeedSecret.text = "";
            this.lbResult.text = "";
            this.btnCheck && (this.btnCheck.disabled = true);
            this.btnCopy && (this.btnCopy.disabled = true)
        }
        onGetReady() {
            this.initView()
        }
        onBtnCopy() {
            var t = c.Instance;
            var e = new String;
            e += d.getMsgForNowLang("clip_rbd") + ":" + (t.FairSimple.brd ? t.FairSimple.brd : "") + "\r\n";
            e += d.getMsgForNowLang("clip_seed") + ":" + (t.FairSimple.ss ? t.FairSimple.ss : "") + "\r\n";
            e += d.getMsgForNowLang("clip_result_sec") + ":" + (t.FairSimple.rs256 ? t.FairSimple.rs256 : "") + "\r\n";
            e += d.getMsgForNowLang("clip_seed_sec") + ":" + (t.FairSimple.ss256 ? t.FairSimple.ss256 : "") + "\r\n";
            e += d.getMsgForNowLang("clip_result") + ":" + (t.FairSimple.gs ? t.FairSimple.gs : "") + "\r\n";
            d.setClipboard(e);
            i.Instance.showText(d.getMsgForNowLang("clip_ok"))
        }
        onBtnCheck() {
            var t = c.Instance;
            if (!t.CheckRoundSeedData) {
                t.CheckRoundSeedData = new o
            }
            if (t.FairSimple.brd == null || t.FairSimple.brd == "") {
                return
            }
            t.CheckRoundSeedData.brd = t.FairSimple.brd;
            t.CheckRoundSeedData.gs = t.FairSimple.gs;
            t.CheckRoundSeedData.ss = t.FairSimple.ss;
            t.CheckRoundSeedData.ss256 = t.FairSimple.ss256;
            t.CheckRoundSeedData.rs256 = t.FairSimple.rs256;
            t.CheckRoundSeedData.gr = t.FairSimple.gs;
            t.CheckRoundSeedData.tm = d.getUTCTime();
            t.CheckRoundSeedData.bm = t.FairSimple.bm;
            if (t.FairSimple.rm != null && t.FairSimple.rm > 0) {
                t.CheckRoundSeedData.win = t.FairSimple.rm
            } else {
                t.CheckRoundSeedData.win = 0
            }
            t.CheckRoundSeedData.mc = t.mineCount;
            t.CheckRoundSeedData.sa = t.FairSimple.sp_array;
            a.dispatch("NC_SHOW_CHECKROUN_SEED")
        }
    }
    BaseFSG.Base.View.ShaView = l.ShaView = vt;
    class Lt extends t {
        constructor() {
            super();
            this.BASE_POS_Y_H = 316;
            this.BASE_HEIGHT_H = 335;
            this.BASE_POS_Y_V = 412;
            this.BASE_HEIGHT_V = 430;
            this.BUTTON_HEIGHT_H = 58;
            this.BUTTON_HEIGHT_V = 85;
            this.sp_height = 0
        }
        baseInit() {
            super.baseInit();
            this._uiPath = "GameUI/Common/View/UserInfoView"
        }
        createUI() {
            super.createUI()
        }
        onEnable() {
            super.onEnable();
            this.onResize();
            l.stage.on(s.RESIZE, this, this.onResize);
            this.init()
        }
        onResize() {
            if (this.isHor) {
                var t = 1900 - l.stage._realDesignWidth;
                var e = 900 - l.stage.realDesignHeight;
                this.imgK && (this.imgK.x = 1851 - t / 2)
            } else {
                var t = 900 - l.stage._realDesignWidth;
                var e = 1900 - l.stage.realDesignHeight;
                this.imgK && (this.imgK.y = 1150 - this.sp_height - e / 2)
            }
        }
        registeEvent() {
            super.registeEvent();
            this.registeAllButton();
            this.chkSound && this.chkSound.on(s.CLICK, this, this.onChkSound)
        }
        onButtonClick(t) {
            switch (t) {
                case "btnBettingRecord":
                    this.onBtnBettingRecord();
                    break;
                case "btnRule":
                    this.onBtnRule();
                    break;
                case "btnGameLimit":
                    this.onBtnGameLimit();
                    break;
                case "btnChip":
                    this.onBtnChip();
                    break;
                case "btnScreen":
                    this.onBtnScreen();
                    break;
                case "btnLang":
                    this.onBtnLang();
                    break;
                case "btnFull":
                    if (n.isNotFullScreen()) {
                        n.requestFullScreen()
                    } else {
                        n.exitFullScreen()
                    }
                    this.close();
                    break
            }
        }
        init() {
            this.chkSound.selected = !C.soundMuted;
            this.labUserName.text = r.Instance.user_name;
            this.btnScreen && (this.btnScreen.visible = !this.isHor || h.onRealMobile);
            this.btnLang && (this.btnLang.visible = h.langList.length > 1);
            this.btnFull && (this.btnFull.visible = n.canFullScreen());
            this.btnChip && (this.btnChip.visible = c.Instance.has_chips_setting);
            var t = 0;
            this.sp_height = 0;
            var e = this.BUTTON_HEIGHT_V;
            var i = this.BASE_POS_Y_V;
            var s = this.BASE_HEIGHT_V;
            if (this.isHor) {
                e = this.BUTTON_HEIGHT_H;
                i = this.BASE_POS_Y_H;
                s = this.BASE_HEIGHT_H
            }
            if (this.btnChip && this.btnChip.visible) {
                t++;
                this.btnChip && (this.btnChip.y = i + this.sp_height);
                this.sp_height += e
            }
            if (this.btnScreen && this.btnScreen.visible) {
                t++;
                this.btnScreen && (this.btnScreen.y = i + this.sp_height);
                this.sp_height += e
            }
            if (this.btnLang && this.btnLang.visible) {
                t++;
                this.btnLang && (this.btnLang.y = i + this.sp_height);
                this.sp_height += e
            }
            if (this.btnFull && this.btnFull.visible) {
                t++;
                this.btnFull && (this.btnFull.y = i + this.sp_height);
                this.sp_height += e
            }
            this.imgK && (this.imgK.height = s + this.sp_height)
        }
        onBtnChageHead() {
            a.dispatch("NC_USERINFO_CHANGEHEAD");
            this.destroy()
        }
        onBtnBettingRecord() {
            var t = new T;
            t.zOrder = 100;
            f.Instance.NowScene.addChild(t);
            this.destroy()
        }
        onBtnRule() {
            var t = new D;
            t.zOrder = 100;
            f.Instance.NowScene.addChild(t);
            this.destroy()
        }
        onBtnGameLimit() {
            a.dispatch("NC_SHOW_GAMELIMIS");
            this.destroy()
        }
        onBtnChip() {
            a.dispatch("NC_SHOW_POP", [BaseChips.Base.View.ChipSettingView]);
            this.destroy()
        }
        onBtnScreen() {
            a.dispatch("NC_SHOW_POP", [BaseFSG.Base.View.ScreenSettingView]);
            this.destroy()
        }
        onBtnLang() {
            a.dispatch("NC_SHOW_POP", [BaseFSG.Base.View.LangSettingView]);
            this.destroy()
        }
        onChkSound() {
            C.soundMuted = !this.chkSound.selected;
            C.musicMuted = !this.chkSound.selected;
            var t = "1";
            if (C.soundMuted) {
                t = "0"
            }
            d.setLocalStorageItem("COOKIESOUND", t);
            d.setLocalStorageItem("COOKIEMUSIC", t)
        }
    }
    BaseFSG.Base.View.UserInfo = l.UserInfo = Lt;
    return l
})(window);