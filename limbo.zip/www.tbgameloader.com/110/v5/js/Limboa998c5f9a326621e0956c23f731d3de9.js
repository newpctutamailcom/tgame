(function(e) {
    var i = e.Laya;
    var s = i.AppConfig,
        o = i.AppContext,
        t = i.ArrayUtils,
        a = i.AutoPlay;
    var n = i.AutoPlaySelected,
        m = i.BaseGameScene,
        l = i.BaseMain,
        h = i.BaseScene;
    var u = i.BaseView,
        r = i.Box,
        b = i.Browser,
        c = i.Button,
        d = i.CMDEvent,
        _ = i.CheckRoundSeed;
    var L = i.CommonUtils,
        p = i.Dispatcher,
        N = i.DolAnimation,
        D = i.DolButton;
    var x = i.DolSkeleton,
        E = i.DynamicMessage,
        g = i.Event,
        O = i.FairSimpleMyBetDto;
    var f = i.GameContext,
        P = i.GameEnum,
        F = i.GlobalButtonEnum,
        T = i.GlobalConfig;
    var H = i.GlobalEnum,
        K = i.GlobalEvent,
        Y = i.GlobalSoundEnum,
        z = i.HBox;
    var W = i.HSlider,
        w = i.Handler,
        J = i.Image,
        Q = i.ImageNumber,
        X = i.Label;
    var Z = i.MsgMaster,
        C = i.MyBetViewCell,
        q = i.NumberCell,
        $ = i.NumberInputView;
    var ee = i.Panel,
        I = i.ResultView,
        S = i.ResultViewCell,
        V = i.SceneManager;
    var G = i.SoundUtils,
        ie = i.Sprite,
        se = i.StringUtils,
        M = i.TcpLogicManager;
    var te = i.TweenLite;
    e.Limbo = {};
    Limbo.Config = {};
    Limbo.Config.Res = {};
    class U {
        constructor() {}
    }
    Limbo.Config.Res.GameResConfig = i.GameResConfig = U;
    U.RES_3D = [];
    U.RES_3D_LMAT = [];
    U.RES_FNT = [];
    i.static(U, ["RES_2D", function() {
        return this.RES_2D = ["Limbo/common/common/ani/loading.atlas", "Limbo/common/common/ani/roundid.atlas", "res/atlas/Common/common/common/autoPlay.atlas", "res/atlas/Common/common/common/comp.atlas", "res/atlas/Common/common/common/dialog.atlas", "res/atlas/Common/common/common/ui.atlas", "res/atlas/Common/common/common/userinfo.atlas", "res/atlas/Common/common/common/verification.atlas", "res/atlas/Common/common/en/ui.atlas", "res/atlas/Common/common/hi/ui.atlas", "res/atlas/Common/common/id/ui.atlas", "res/atlas/Common/common/ms/ui.atlas", "res/atlas/Common/common/pr/ui.atlas", "res/atlas/Common/common/th/ui.atlas", "res/atlas/Common/common/vi/ui.atlas", "res/atlas/Common/common/zh-cn/ui.atlas", "res/atlas/Common/m/common/ui.atlas", "res/atlas/Common/m/en/ui.atlas", "res/atlas/Common/m/hi/ui.atlas", "res/atlas/Common/m/id/ui.atlas", "res/atlas/Common/m/ms/ui.atlas", "res/atlas/Common/m/pr/ui.atlas", "res/atlas/Common/m/th/ui.atlas", "res/atlas/Common/m/vi/ui.atlas", "res/atlas/Common/pc/common/ui.atlas", "res/atlas/Common/pc/en/ui.atlas", "res/atlas/Common/pc/hi/ui.atlas", "res/atlas/Common/pc/id/ui.atlas", "res/atlas/Common/pc/ms/ui.atlas", "res/atlas/Common/pc/pr/ui.atlas", "res/atlas/Common/pc/th/ui.atlas", "res/atlas/Common/pc/vi/ui.atlas", "res/atlas/Limbo/common/common/ui.atlas", "res/atlas/Limbo/m/common/ui.atlas", "res/atlas/Limbo/m/en/ui.atlas", "res/atlas/Limbo/m/hi/ui.atlas", "res/atlas/Limbo/m/id/ui.atlas", "res/atlas/Limbo/m/ms/ui.atlas", "res/atlas/Limbo/m/pr/ui.atlas", "res/atlas/Limbo/m/th/ui.atlas", "res/atlas/Limbo/m/vi/ui.atlas", "res/atlas/Limbo/m/zh-cn/ui.atlas", "res/atlas/Limbo/pc/common/ui.atlas", "res/atlas/Limbo/pc/en/ui.atlas", "res/atlas/Limbo/pc/hi/ui.atlas", "res/atlas/Limbo/pc/id/ui.atlas", "res/atlas/Limbo/pc/ms/ui.atlas", "res/atlas/Limbo/pc/pr/ui.atlas", "res/atlas/Limbo/pc/th/ui.atlas", "res/atlas/Limbo/pc/vi/ui.atlas", "res/atlas/Limbo/pc/zh-cn/ui.atlas", "Limbo/m/common/spine/huojian.png", "Limbo/m/common/spine/huojian.sk", "Limbo/m/common/spine/shu_xingkong.png", "Limbo/m/common/spine/shu_xingkong.sk", "Limbo/pc/common/spine/heng_xingkong.png", "Limbo/pc/common/spine/heng_xingkong.sk", "Limbo/pc/common/spine/huojian.png", "Limbo/pc/common/spine/huojian.sk"]
    }, "RES_SOUND", function() {
        return this.RES_SOUND = ["Assets/Limbo/Sound/big_button.mp3", "Assets/Limbo/Sound/button_click.mp3", "Assets/Limbo/Sound/chip.mp3", "Assets/Limbo/Sound/limbo_fly.mp3", "Assets/Limbo/Sound/limbo_win.mp3", "Assets/Limbo/Sound/soft_win.mp3", "Assets/Limbo/Sound/sound_lose.mp3"]
    }, "RES_UI", function() {
        return this.RES_UI = ["GameUI/Common/Dialog/MessageBox.json", "GameUI/Common/Dialog/MessageYesNoBox.json", "GameUI/Common/Dialog/ReconnectMessageBox.json", "GameUI/Common/Scenes/GameLoading.json", "GameUI/Common/View/AutoNumberCell_h.json", "GameUI/Common/View/AutoNumberCell_v.json", "GameUI/Common/View/BonusAnnouncementView.json", "GameUI/Common/View/BonusAnnouncementView_h.json", "GameUI/Common/View/BonusAnnouncementView_v.json", "GameUI/Common/View/DynamicMsgView.json", "GameUI/Common/View/GameLoadingBarNew.json", "GameUI/Common/View/LangSettingView_h.json", "GameUI/Common/View/LangSettingView_v.json", "GameUI/Common/View/LoadingView_h.json", "GameUI/Common/View/LoadingView_v.json", "GameUI/Common/View/ScreenSettingView_h.json", "GameUI/Common/View/ScreenSettingView_v.json", "GameUI/Common/View/UserInfoView_h.json", "GameUI/Common/View/UserInfoView_v.json", "GameUI/Limbo/Scenes/GameLoading_h.json", "GameUI/Limbo/Scenes/GameLoading_v.json", "GameUI/Limbo/Scenes/GameScene_h.json", "GameUI/Limbo/Scenes/GameScene_v.json", "GameUI/Limbo/View/AutoNumberCell_h.json", "GameUI/Limbo/View/AutoNumberCell_v.json", "GameUI/Limbo/View/AutoPlaySelected_h.json", "GameUI/Limbo/View/AutoPlaySelected_v.json", "GameUI/Limbo/View/BetViewCell2_h.json", "GameUI/Limbo/View/BetViewCell2_v.json", "GameUI/Limbo/View/CheckRoundSeedView_h.json", "GameUI/Limbo/View/CheckRoundSeedView_v.json", "GameUI/Limbo/View/DetailedRulesView_h.json", "GameUI/Limbo/View/DetailedRulesView_v.json", "GameUI/Limbo/View/GameLimitsView_h.json", "GameUI/Limbo/View/GameLimitsView_v.json", "GameUI/Limbo/View/GameLoadingBarNew.json", "GameUI/Limbo/View/GameRulesView_h.json", "GameUI/Limbo/View/GameRulesView_v.json", "GameUI/Limbo/View/GreenDetailed_h.json", "GameUI/Limbo/View/GreenDetailed_v.json", "GameUI/Limbo/View/HeaderView_h.json", "GameUI/Limbo/View/HeaderView_v.json", "GameUI/Limbo/View/LangSettingView_h.json", "GameUI/Limbo/View/LangSettingView_v.json", "GameUI/Limbo/View/LoadingView_h.json", "GameUI/Limbo/View/LoadingView_v.json", "GameUI/Limbo/View/MyBetViewCell_h.json", "GameUI/Limbo/View/MyBetViewCell_v.json", "GameUI/Limbo/View/MyHistoryView_h.json", "GameUI/Limbo/View/MyHistoryView_v.json", "GameUI/Limbo/View/NumberCell_h.json", "GameUI/Limbo/View/NumberCell_v.json", "GameUI/Limbo/View/ResultViewCell_h.json", "GameUI/Limbo/View/ResultViewCell_v.json", "GameUI/Limbo/View/ResultView_h.json", "GameUI/Limbo/View/ResultView_v.json", "GameUI/Limbo/View/ScreenSettingView_h.json", "GameUI/Limbo/View/ScreenSettingView_v.json", "GameUI/Limbo/View/UserInfoView_h.json", "GameUI/Limbo/View/UserInfoView_v.json"]
    }, "RES_SK", function() {
        return this.RES_SK = ["Limbo/m/common/spine/huojian.sk", "Limbo/m/common/spine/shu_xingkong.sk", "Limbo/pc/common/spine/heng_xingkong.sk", "Limbo/pc/common/spine/huojian.sk"]
    }, "RES_ALL", function() {
        return this.RES_ALL = ["Assets/Limbo/Sound/big_button.mp3", "Assets/Limbo/Sound/button_click.mp3", "Assets/Limbo/Sound/chip.mp3", "Assets/Limbo/Sound/limbo_fly.mp3", "Assets/Limbo/Sound/limbo_win.mp3", "Assets/Limbo/Sound/soft_win.mp3", "Assets/Limbo/Sound/sound_lose.mp3", "res/atlas/Limbo/common/common/ui.atlas", "res/atlas/Limbo/common/common/ui.png", "res/atlas/Limbo/m/common/ui.atlas", "res/atlas/Limbo/m/common/ui.png", "res/atlas/Limbo/m/en/ui.atlas", "res/atlas/Limbo/m/en/ui.png", "res/atlas/Limbo/m/hi/ui.atlas", "res/atlas/Limbo/m/hi/ui.png", "res/atlas/Limbo/m/id/ui.atlas", "res/atlas/Limbo/m/id/ui.png", "res/atlas/Limbo/m/ms/ui.atlas", "res/atlas/Limbo/m/ms/ui.png", "res/atlas/Limbo/m/pr/ui.atlas", "res/atlas/Limbo/m/pr/ui.png", "res/atlas/Limbo/m/th/ui.atlas", "res/atlas/Limbo/m/th/ui.png", "res/atlas/Limbo/m/vi/ui.atlas", "res/atlas/Limbo/m/vi/ui.png", "res/atlas/Limbo/m/zh-cn/ui.atlas", "res/atlas/Limbo/m/zh-cn/ui.png", "res/atlas/Limbo/pc/common/ui.atlas", "res/atlas/Limbo/pc/common/ui.png", "res/atlas/Limbo/pc/en/ui.atlas", "res/atlas/Limbo/pc/en/ui.png", "res/atlas/Limbo/pc/hi/ui.atlas", "res/atlas/Limbo/pc/hi/ui.png", "res/atlas/Limbo/pc/id/ui.atlas", "res/atlas/Limbo/pc/id/ui.png", "res/atlas/Limbo/pc/ms/ui.atlas", "res/atlas/Limbo/pc/ms/ui.png", "res/atlas/Limbo/pc/pr/ui.atlas", "res/atlas/Limbo/pc/pr/ui.png", "res/atlas/Limbo/pc/th/ui.atlas", "res/atlas/Limbo/pc/th/ui.png", "res/atlas/Limbo/pc/vi/ui.atlas", "res/atlas/Limbo/pc/vi/ui.png", "res/atlas/Limbo/pc/zh-cn/ui.atlas", "res/atlas/Limbo/pc/zh-cn/ui.png", "Limbo/common/common/ani/loading.atlas", "Limbo/common/common/ani/loading.png", "Limbo/common/common/ani/roundid.atlas", "Limbo/common/common/ani/roundid.png", "Limbo/m/common/spine/huojian.png", "Limbo/m/common/spine/huojian.sk", "Limbo/m/common/spine/shu_xingkong.png", "Limbo/m/common/spine/shu_xingkong.sk", "Limbo/pc/common/spine/heng_xingkong.png", "Limbo/pc/common/spine/heng_xingkong.sk", "Limbo/pc/common/spine/huojian.png", "Limbo/pc/common/spine/huojian.sk", "GameUI/Limbo/Scenes/GameLoading_h.json", "GameUI/Limbo/Scenes/GameLoading_v.json", "GameUI/Limbo/Scenes/GameScene_h.json", "GameUI/Limbo/Scenes/GameScene_v.json", "GameUI/Limbo/View/AutoNumberCell_h.json", "GameUI/Limbo/View/AutoNumberCell_v.json", "GameUI/Limbo/View/AutoPlaySelected_h.json", "GameUI/Limbo/View/AutoPlaySelected_v.json", "GameUI/Limbo/View/BetViewCell2_h.json", "GameUI/Limbo/View/BetViewCell2_v.json", "GameUI/Limbo/View/CheckRoundSeedView_h.json", "GameUI/Limbo/View/CheckRoundSeedView_v.json", "GameUI/Limbo/View/DetailedRulesView_h.json", "GameUI/Limbo/View/DetailedRulesView_v.json", "GameUI/Limbo/View/GameLimitsView_h.json", "GameUI/Limbo/View/GameLimitsView_v.json", "GameUI/Limbo/View/GameLoadingBarNew.json", "GameUI/Limbo/View/GameRulesView_h.json", "GameUI/Limbo/View/GameRulesView_v.json", "GameUI/Limbo/View/GreenDetailed_h.json", "GameUI/Limbo/View/GreenDetailed_v.json", "GameUI/Limbo/View/HeaderView_h.json", "GameUI/Limbo/View/HeaderView_v.json", "GameUI/Limbo/View/LangSettingView_h.json", "GameUI/Limbo/View/LangSettingView_v.json", "GameUI/Limbo/View/LoadingView_h.json", "GameUI/Limbo/View/LoadingView_v.json", "GameUI/Limbo/View/MyBetViewCell_h.json", "GameUI/Limbo/View/MyBetViewCell_v.json", "GameUI/Limbo/View/MyHistoryView_h.json", "GameUI/Limbo/View/MyHistoryView_v.json", "GameUI/Limbo/View/NumberCell_h.json", "GameUI/Limbo/View/NumberCell_v.json", "GameUI/Limbo/View/ResultViewCell_h.json", "GameUI/Limbo/View/ResultViewCell_v.json", "GameUI/Limbo/View/ResultView_h.json", "GameUI/Limbo/View/ResultView_v.json", "GameUI/Limbo/View/ScreenSettingView_h.json", "GameUI/Limbo/View/ScreenSettingView_v.json", "GameUI/Limbo/View/UserInfoView_h.json", "GameUI/Limbo/View/UserInfoView_v.json"]
    }]);
    class v extends l {
        constructor() {
            super()
        }
        initConfig() {
            super.initConfig();
            o.Instance.supportPlatform = 1;
            b.langList = ["en", "vi", "pr", "hi", "th", "ms", "id"]
        }
        InitApp() {
            super.InitApp();
            o.Instance.AppID = 110;
            o.Instance.AppVersion = "1.0.0";
            o.Instance.ModuleName = "Limbo";
            o.Instance.GameResConfig = U;
            o.Instance.GameScene = A;
            o.Instance.GameKind = 2;
            o.Instance.CheckRoundSeedClass = j;
            o.Instance.ResultCellClass = y;
            o.Instance.fontArr = ["Microsoft YaHei", "fzcsjt", "stkaiti"];
            o.Instance.skNeedChangeSkin = ["tiaosan.sk"];
            this.setMoblieScreenTypeByLocalStorage(1)
        }
    }
    Limbo.Main = i.Main = v;
    Limbo.Scene = {};
    class A extends m {
        constructor() {
            super()
        }
        doFSGStart(e, i) {
            if (e != null) {
                L.setLocalStorageItem("COOKIE_BETMONEY", e.bet_money);
                L.setLocalStorageItem("COOKIE_MUL", e.mul)
            }
        }
        onResize() {
            super.onResize();
            this["imgMask"] && (this["imgMask"].height = i.stage.realDesignHeight);
            if (this.isHor) {
                this["imgMask"] && (this["imgMask"].width = Math.max(1769, i.stage.realDesignWidth));
                this["skBG"] && (this["skBG"].x = i.stage.realDesignWidth / 2)
            } else {
                this["skBG"] && (this["skBG"].y = 815 - (1900 - i.stage.realDesignHeight))
            }
        }
    }
    Limbo.Scene.GameScene = i.GameScene = A;
    Limbo.View = {};
    class R extends n {
        constructor(e = null, i = 1, s = null) {
            super(e, i, s);
            this.NUM_ARRAY = [10, 100, 500, 1e3, 5e3, 1e4]
        }
    }
    Limbo.View.LimboAutoPlaySelected = i.LimboAutoPlaySelected = R;
    class j extends _ {
        constructor() {
            super()
        }
        onEnable() {
            super.onEnable();
            this.onResize();
            this.p1 && (this.p1.hScrollBar.visible = false);
            i.stage.on(g.RESIZE, this, this.onResize)
        }
        onResize() {}
        init() {
            var e = 450;
            var i = f.Instance;
            this.labRoundNumber.text = i.CheckRoundSeedData.brd;
            if (this.isHor) {
                e = 350
            }
            L.setTextOverflowByEllipsis(this.labRoundNumber, e);
            this.labSeed1.text = i.CheckRoundSeedData.ss;
            if (this.isHor) {
                e = 800
            } else {
                e = 550
            }
            L.setTextOverflowByEllipsis(this.labSeed1, e);
            this.labSeed2.text = i.CheckRoundSeedData.ss256;
            if (this.isHor) {
                e = 800
            } else {
                e = 650
            }
            L.setTextOverflowByEllipsis(this.labSeed2, e);
            this.labResult.text = i.CheckRoundSeedData.gs;
            this.labSeed3.text = i.CheckRoundSeedData.ss + i.CheckRoundSeedData.gs;
            L.setTextOverflowByEllipsis(this.labSeed3, e);
            this.labSeed4.text = i.CheckRoundSeedData.rs256;
            L.setTextOverflowByEllipsis(this.labSeed4, e);
            var s = L.formartUTCtoLocalTimeByDayMonthYear(i.CheckRoundSeedData.tm, "/", true, true, true);
            this.labTimeStr.text = s;
            this.lblBetMoney && (this.lblBetMoney.text = L.getCurrencyStrBySignal(i.CheckRoundSeedData.bm));
            this.lblResult && (this.lblResult.text = i.CheckRoundSeedData.gs);
            var t = "";
            if (i.CheckRoundSeedData.bs != null) {
                var a = JSON.parse(i.CheckRoundSeedData.bs);
                t = a.mul
            }
            this.lblTarget && (this.lblTarget.text = t.toFixed(2) + "x");
            this.lblCash && (this.lblCash.text = L.getCurrencyStrBySignal(L.getMoneyTextByNumber(i.CheckRoundSeedData.win)));
            if (i.CheckRoundSeedData.win > 0) {
                if (this.isHor) {
                    this.lblMul && (this.lblMul.text = " (" + (i.CheckRoundSeedData.win / i.CheckRoundSeedData.bm).toFixed(2) + " x)")
                } else {
                    this.lblMul && (this.lblMul.text = (i.CheckRoundSeedData.win / i.CheckRoundSeedData.bm).toFixed(2) + "x")
                }
                this.lblCash && (this.lblCash.color = "#7aff00");
                this.imgResult && (this.imgResult.skin = o.Instance.ModuleName + "/" + L.getPCOrMobilePath(this) + "/common/ui/img_number01_k.png")
            } else {
                if (this.isHor) {
                    this.lblMul && (this.lblMul.text = "")
                } else {
                    this.lblMul && (this.lblMul.text = "0.00x")
                }
                this.lblCash && (this.lblCash.color = "#ffffff");
                this.imgResult && (this.imgResult.skin = o.Instance.ModuleName + "/" + L.getPCOrMobilePath(this) + "/common/ui/img_number01_l.png")
            }
        }
    }
    Limbo.View.LimboCheckRoundSeed = i.LimboCheckRoundSeed = j;
    class k extends C {
        constructor() {
            super();
            this.Limbo_MIN_CHANCE = 10;
            this.Limbo_MAX_CHANCE = 8818;
            this.MUL_MIN = 1.01;
            this.MUL_MAX = 99999.99;
            this.FLASH_TIME = 500;
            this.status = 0;
            this.chance = 8818;
            this._mul = "";
            this.mul = 2;
            this._mul_fix_count = 2;
            this.POPUP_BET_NONE = -1;
            this.POPUP_BET_KEYBOARD = 1;
            this.POPUP_BET_LIST = 2;
            this.POPUP_MUL_KEYBOARD = 3;
            this.noNeedFresh = false;
            this.MOVIE_TIME = 500;
            this.lastSlideTime = 0;
            this.init = true
        }
        initConfig() {
            super.initConfig();
            this.CODE_STRING = "rs256";
            this.AUTO_DELAY = 100
        }
        onResize() {
            super.onResize();
            if (this.isHor) {
                this.pBox && (this.pBox.width = 1580)
            } else {
                this.pBox && (this.pBox.width = 880);
                this.imgBetMoneyKeyboard && (this.imgBetMoneyKeyboard.y = 1113 - this.offY / 2);
                this.imgMulKeyboard && (this.imgMulKeyboard.y = 985 - this.offY / 2);
                this.imgQuickBetMoney && (this.imgQuickBetMoney.y = 794 - this.offY / 2);
                this.spBottom3 && (this.spBottom3.y = 1480 - this.offY / 2);
                this.btnCopy && (this.btnCopy.y = 150 + this.offY / 2);
                this.btnFresh && (this.btnFresh.y = 150 + this.offY / 2);
                this.imgFresh && (this.imgFresh.y = 150 + this.offY / 2);
                this.sk && (this.sk.y = 600 - this.offY / 2)
            }
        }
        freshData() {
            super.freshData();
            if (f.Instance.FairSimple.brd != null && f.Instance.FairSimple.brd != "") {
                i.timer.frameOnce(1, this, function() {
                    p.dispatch("NC_FSG_START")
                })
            } else {
                this.changeBetStatus()
            }
        }
        registeEvent() {
            super.registeEvent();
            this.lbResult && this.lbResult.on(g.COMPLETE, this, this.onResultJumpComplete)
        }
        onDTChange() {
            super.onDTChange()
        }
        onGetReady() {
            super.onGetReady();
            this.freshCode(true);
            this.changeAutoMode(false)
        }
        onResultJumpComplete() {
            if (f.Instance.FairSimple.rm == null) {
                this.lbResult && (this.lbResult.skin = o.Instance.ModuleName + "/" + L.getPCOrMobilePath(this) + "/common/ui/img_number01_0")
            } else if (f.Instance.FairSimple.rm != null && f.Instance.FairSimple.rm > 0) {
                this.lbResult && (this.lbResult.skin = o.Instance.ModuleName + "/" + L.getPCOrMobilePath(this) + "/common/ui/img_number02_0")
            } else {
                this.lbResult && (this.lbResult.skin = o.Instance.ModuleName + "/" + L.getPCOrMobilePath(this) + "/common/ui/img_number03_0")
            }
            if (f.Instance.FairSimple != null && f.Instance.FairSimple.gs != null) {
                this.lbResult && (this.lbResult.text = f.Instance.FairSimple.gs + "x")
            }
            if (f.Instance.FairSimple.rm != null && f.Instance.FairSimple.rm > 0) {}
            this.init = false
        }
        drawBar() {
            var e = -1;
            if (this.init) {
                e = 1
            }
            var i = 1;
            if (f.Instance.FairSimple != null && f.Instance.FairSimple.gs != null && f.Instance.FairSimple.gs != "") {
                e = parseFloat(f.Instance.FairSimple.gs)
            }
            if (e == -1) {
                return
            }
            this.lbResult && (this.lbResult.skin = o.Instance.ModuleName + "/" + L.getPCOrMobilePath(this) + "/common/ui/img_number01_0");
            this.lbResult && L.labelJumpTo(this.lbResult, i, e, .01, 500, 30, false, null, null, false, "%sx")
        }
        onGameStart(e, i) {
            super.onGameStart(e, i);
            this.spAllMask && (this.spAllMask.visible = true);
            this.btnBet && (this.btnBet.disabled = true);
            this.btnDec && (this.btnDec.disabled = true);
            this.btnAdd && (this.btnAdd.disabled = true);
            this.btnDec2 && (this.btnDec2.disabled = true);
            this.btnAdd2 && (this.btnAdd2.disabled = true);
            this.btnBetCoin && (this.btnBetCoin.disabled = true);
            this.btnCopy && (this.btnCopy.disabled = true);
            this.btnFresh && (this.btnFresh.visible = false);
            this.btnAuto && (this.btnAuto.disabled = true);
            this.playFei()
        }
        onGameOver() {
            super.onGameOver();
            this.freshCode(true);
            this.drawBar()
        }
        onNext() {
            super.onNext();
            if (f.Instance.FairSimple.rm != null && f.Instance.FairSimple.rm > 0) {
                G.Instance.playSound("limbo_win")
            } else {
                G.Instance.playSound("sound_lose")
            }
            if (f.Instance.isAuto) {
                this.freshLeftCount()
            } else {
                this.changeAutoMode(false)
            }
            this.clear()
        }
        onOpeOver(e = true) {}
        clear() {
            this.onOpeOver()
        }
        changeMul(e = true) {
            if (e) {
                this.mul = Math.floor(this.mul + 1)
            } else {
                this.mul = Math.floor(this.mul - 1)
            }
            this._mul = "";
            this.freshMul()
        }
        onButtonClick(e) {
            var i = this;
            super.onButtonClick(e);
            switch (e) {
                case "btnAdd2":
                    this.changeMul();
                    break;
                case "btnDec2":
                    this.changeMul(false);
                    break;
                case "btnAuto":
                    ;
                    var s = new R(w.create(this, function(e) {
                        f.Instance.single_win_list[0] = 0;
                        f.Instance.balance_change_list[0] = 0;
                        i._data.leftTime = e.leftTime;
                        i._data.totalWin = e.totalWin;
                        i._data.totalLose = e.totalLose;
                        i._data.perWin = e.perWin;
                        i._data.auto = e.auto;
                        i._data.bet_pos = e.bet_pos;
                        if (i._data.leftTime && i._data.leftTime > 0) {
                            i.changeAutoMode(true)
                        }
                    }), 1, {
                        chance: this.chance
                    });
                    s.zOrder = 100;
                    V.Instance.NowScene.addChild(s);
                    break;
                case "btnMulKeyBoard":
                    if (this.imgMulKeyboard) {
                        this.imgMulKeyboard.visible = !this.imgMulKeyboard.visible;
                        this.btnClose && (this.btnClose.visible = this.imgMulKeyboard.visible);
                        if (this.imgMulKeyboard.visible) {
                            this.imgMulSelect && (this.imgMulSelect.visible = true);
                            this.popStatus = this.POPUP_MUL_KEYBOARD;
                            this.freshMul(false, true)
                        }
                    }
                    break;
                case "btnNum00":
                    this.addNum("0", false);
                    break;
                case "btnNum01":
                    this.addNum("1", false);
                    break;
                case "btnNum02":
                    this.addNum("2", false);
                    break;
                case "btnNum03":
                    this.addNum("3", false);
                    break;
                case "btnNum04":
                    this.addNum("4", false);
                    break;
                case "btnNum05":
                    this.addNum("5", false);
                    break;
                case "btnNum06":
                    this.addNum("6", false);
                    break;
                case "btnNum07":
                    this.addNum("7", false);
                    break;
                case "btnNum08":
                    this.addNum("8", false);
                    break;
                case "btnNum09":
                    this.addNum("9", false);
                    break;
                case "btnNum0Dot":
                    this.addNum(".", false);
                    break;
                case "btn0Del":
                    this.delNum(false);
                    break;
                case "btn0OK":
                    this.closeAll();
                    break;
                case "btnSha":
                    this.onBtnCopy();
                    break
            }
        }
        changeAutoMode(e = false) {
            super.changeAutoMode(e);
            f.Instance.isAuto = this._autoMode;
            if (this._autoMode) {
                this.spAllMask && (this.spAllMask.visible = true);
                this.btnStop && (this.btnStop.visible = true);
                this.btnBet && (this.btnBet.disabled = true);
                this.btnDec && (this.btnDec.disabled = true);
                this.btnAdd && (this.btnAdd.disabled = true);
                this.btnDec2 && (this.btnDec2.disabled = true);
                this.btnAdd2 && (this.btnAdd2.disabled = true);
                this.btnBetCoin && (this.btnBetCoin.disabled = true);
                this.btnFresh && (this.btnFresh.visible = false);
                this.btnCopy && (this.btnCopy.disabled = true);
                this.freshLeftCount()
            } else {
                this.spAllMask && (this.spAllMask.visible = false);
                this.btnStop && (this.btnStop.visible = false);
                this.btnBet && (this.btnBet.disabled = false);
                this.btnDec && (this.btnDec.disabled = false);
                this.btnAdd && (this.btnAdd.disabled = false);
                this.btnDec2 && (this.btnDec2.disabled = false);
                this.btnAdd2 && (this.btnAdd2.disabled = false);
                this.btnBetCoin && (this.btnBetCoin.disabled = false);
                this.btnFresh && (this.btnFresh.visible = true);
                this.btnCopy && (this.btnCopy.disabled = false);
                this.btnAuto && (this.btnAuto.disabled = false)
            }
        }
        closeAll() {
            this.imgMulKeyboard && (this.imgMulKeyboard.visible = false);
            if (this.POPUP_MUL_KEYBOARD == this.popStatus) {
                this.imgMulSelect && (this.imgMulSelect.visible = false);
                this.freshMul(true)
            }
            super.closeAll()
        }
        freshBetMoney() {
            super.freshBetMoney()
        }
        stopAutoMode() {
            super.stopAutoMode();
            if (f.Instance.isAuto) {
                this.changeAutoMode(false)
            }
        }
        doBet(e = true) {
            var i = this;
            this._data.bm = this.betMoney;
            L.setLocalStorageJson("COOKIEBETDATA", this._data);
            var s = new Object;
            s.bet_money = L.formatNumber(this.betMoney);
            s.mul = this.mul;
            M.Instance.doSendFairSimpleStartByData(s, w.create(this, function(e) {
                if (L.IsNoError(e)) {} else {
                    i.changeAutoMode(false)
                }
                return
            }), e)
        }
        doAutoPlay() {
            super.doAutoPlay();
            this.doBet(false)
        }
        hideAllButton(e = true) {
            this.spMask && (this.spMask.visible = false);
            this.spAllMask && (this.spAllMask.visible = false);
            this.imgAuto && (this.imgAuto.visible = false);
            this.btnDec && (this.btnDec.disabled = false);
            this.btnAdd && (this.btnAdd.disabled = false);
            this.btnBetCoin && (this.btnBetCoin.disabled = false);
            this.btnAuto && (this.btnAuto.disabled = false)
        }
        initView() {
            super.initView();
            if (f.Instance.FairSimple != null && f.Instance.FairSimple.bmc != null && f.Instance.FairSimple.bmc.length > 0) {
                this.QUICK_BET_MONEY_ARRAY = f.Instance.FairSimple.bmc
            }
            this.hideAllButton();
            if (this._fix_count <= 0) {
                this["btnNumDot"] && (this["btnNumDot"].disabled = true)
            }
            if (this._mul_fix_count <= 0) {
                this["btnNum0Dot"] && (this["btnNum0Dot"].disabled = true)
            }
            this.changeAutoMode(false);
            this.drawBar();
            this.mul = parseFloat(L.getLocalStorageItem("COOKIE_MUL", "2.00"));
            this.freshMul();
            this.imgMulSelect && (this.imgMulSelect.visible = false)
        }
        playFei() {
            var e = this;
            G.Instance.playSound("limbo_fly");
            this.sk && this.sk.play("fei", false, w.create(this, function() {
                i.timer.frameOnce(1, this, function() {
                    e.sk && e.sk.play("jin")
                })
            }))
        }
        freshMul(e = true, i = false) {
            if (this._mul != "") {
                this.mul = parseFloat(this._mul)
            }
            if (i) {
                this.mul = 0;
                this._mul = "";
                this.lblMul && (this.lblMul.text = this._mul);
                return
            }
            this.mul = Math.min(this.mul, this.MUL_MAX);
            this.mul = Math.max(this.mul, this.MUL_MIN);
            if (e) {
                this._mul = "" + this.mul;
                this.lblMul && (this.lblMul.text = this.mul.toFixed(2))
            } else {
                this.lblMul && (this.lblMul.text = this._mul)
            }
        }
        hasDot(e = true) {
            var i = "";
            if (e) {
                if (this._num) {
                    i = "" + this._num
                }
            } else {
                if (this._mul) {
                    i = "" + this._mul
                }
            }
            if (i != "") {
                var s = i.indexOf(".");
                if (s > 0) {
                    return i.length - s - 1
                }
            }
            return -1
        }
        getNumCount(e = true) {
            var i = [];
            if (e) {
                i = this._num.split(".")
            } else {
                i = this._mul.split(".")
            }
            if (i.length == 1) {
                return i[0].length
            }
            return 0
        }
        delNum(e = true) {
            if (e) {
                if (this._num.length > 0) {
                    this._num = this._num.substring(0, this._num.length - 1)
                }
                this.freshNum()
            } else {
                if (this._mul.length > 0) {
                    this._mul = this._mul.substring(0, this._mul.length - 1)
                }
                this.freshMul(false)
            }
        }
        addNum(e, i = true) {
            if (i) {
                var s = true;
                if (this._num != "0" && this._num != "") {
                    s = false
                }
                var t = -1;
                if (s == false) {
                    t = this.hasDot(i)
                }
                var a = 1;
                if (e != ".") {
                    if (s) {
                        if (e == 0) {
                            return
                        } else {
                            this._num = e
                        }
                    } else {
                        if (t >= this._fix_count) {
                            return
                        }
                        if (this.getNumCount(i) >= this._numCount) {
                            return
                        }
                        this._num = this._num + "" + e
                    }
                } else {
                    if (this._fix_count <= 0) {
                        return
                    }
                    if (t >= 0) {
                        return
                    } else {
                        if (this._num == "") {
                            this._num = "0"
                        }
                        this._num = this._num + "."
                    }
                }
                this.freshNum()
            } else {
                var s = true;
                if (this._mul != "0" && this._mul != "") {
                    s = false
                }
                var t = -1;
                if (s == false) {
                    t = this.hasDot(i)
                }
                var a = 1;
                if (e != ".") {
                    if (s) {
                        if (e == 0) {
                            return
                        } else {
                            this._mul = e
                        }
                    } else {
                        if (t >= this._mul_fix_count) {
                            return
                        }
                        if (this.getNumCount(i) >= this._numMulCount) {
                            return
                        }
                        this._mul = this._mul + "" + e
                    }
                } else {
                    if (this._mul_fix_count <= 0) {
                        return
                    }
                    if (t >= 0) {
                        return
                    } else {
                        if (this._mul == "") {
                            this._mul = "0"
                        }
                        this._mul = this._mul + "."
                    }
                }
                this.freshMul(false)
            }
        }
        changeBetStatus() {
            this.hideAllButton()
        }
    }
    Limbo.View.LimboMyBetViewCell = i.LimboMyBetViewCell = k;
    class B extends I {
        constructor() {
            super();
            this.show_item_count2 = 35
        }
        madeDataByHor() {
            if (this.isHor) {
                this.COLUMN_PER_ROW = 7;
                this.CELL_WIDTH = 135;
                this.CELL_HEIGHT = 30;
                this.BASE_HGITH = 61;
                this.CELL_GAP = 5
            } else {
                this.COLUMN_PER_ROW = 5;
                this.CELL_WIDTH = 155;
                this.CELL_HEIGHT = 42;
                this.BASE_HGITH = 75;
                this.CELL_GAP = 12
            }
        }
    }
    Limbo.View.LimboResultView = i.LimboResultView = B;
    class y extends S {
        constructor() {
            super()
        }
        fresh() {
            if (this._data) {
                if (this._data.rm != "" && this._data.rm > 0) {
                    this.imgBG && (this.imgBG.skin = o.Instance.ModuleName + "/common/common/ui/img_timeNum_green.png")
                } else {
                    this.imgBG && (this.imgBG.skin = o.Instance.ModuleName + "/common/common/ui/img_timeNum_red.png")
                }
                var e = this._data.gs + "x";
                this.lbBS && (this.lbBS.text = e)
            }
        }
    }
    Limbo.View.LimboResultViewCell = i.LimboResultViewCell = y;
    new v;
    return i
})(window);