var FileVerNames = [{
        "AppID": "100",
        "VersionFileName": "Json/MineVersion7410a65ecdf86f801935eaf3f486a907.json",
        "AtlasFileName": "Json/MineFileConfigc35cb1d66bf9bc5d1975ca97c3cbdc34.json"
    },
    {
        "AppID": "101",
        "VersionFileName": "Json/HiloVersion2d337792b4e135c7012a22b606975159.json",
        "AtlasFileName": "Json/HiloFileConfig5e1fba1fa7514164cf8041cb25019304.json"
    },
    {
        "AppID": "102",
        "VersionFileName": "Json/DiceVersion9d7983f85cd9a9ce02c807a7e75a233a.json",
        "AtlasFileName": "Json/DiceFileConfig76b71a54dadb1d91577e8b14aec38a4b.json"
    },
    {
        "AppID": "105",
        "VersionFileName": "Json/GoalVersiondf7e0eaaaa5b623296ea5de0eae5c058.json",
        "AtlasFileName": "Json/GoalFileConfigcb4701d044721c4993775b294de6a8e4.json"
    },
    {
        "AppID": "106",
        "VersionFileName": "Json/KenoVersion33e4484b06a89b0816e6df1ad7592790.json",
        "AtlasFileName": "Json/KenoFileConfig95d19f77efdba37d67a8643ddfc93f04.json"
    },
    {
        "AppID": "103",
        "VersionFileName": "Json/PlinkoVersion3b6ce85a436ab786ad3b3b188514599a.json",
        "AtlasFileName": "Json/PlinkoFileConfig68583a3cb0ecaeae73c8628b6b79b357.json"
    },
    {
        "AppID": "107",
        "VersionFileName": "Json/HotlineVersion5a0f27c2da739945c44786e6c286786b.json",
        "AtlasFileName": "Json/HotlineFileConfig5337944ccb8528233e40c757db787c52.json"
    },
    {
        "AppID": "109",
        "VersionFileName": "Json/CoinVersion5458081f2febde1f1cca738a022e611c.json",
        "AtlasFileName": "Json/CoinFileConfig0b0ffc7b01be77dcc262fc89eec6795a.json"
    },
    {
        "AppID": "110",
        "VersionFileName": "Json/LimboVersionbb985499d23be8c23e957500dafe1072.json",
        "AtlasFileName": "Json/LimboFileConfig1337c105cf728eb086c9f0b417dbf465.json"
    },
    {
        "AppID": "111",
        "VersionFileName": "Json/CryptosVersion2c37ff52b1d1b60d9d52e6e110c097ac.json",
        "AtlasFileName": "Json/CryptosFileConfig04b4c092ec1b5c1dc240e2d40f1eb008.json"
    },
    {
        "AppID": "112",
        "VersionFileName": "Json/TripleVersion22960a6c7c73d72ef33935c8ad75dd31.json",
        "AtlasFileName": "Json/TripleFileConfig2f752b6e19cef32fe56b168a06703c2a.json"
    },
    {
        "AppID": "104",
        "VersionFileName": "Json/RouletteVersion130f693594de3183bf680c8e726f0d53.json",
        "AtlasFileName": "Json/RouletteFileConfigec00b13ef6b0793deeb3458444bbc48b.json"
    },
    {
        "AppID": "114",
        "VersionFileName": "Json/HorseVersionec37e5afb29ecbcf1856d238beae5928.json",
        "AtlasFileName": "Json/HorseFileConfig71dbb8c7037b348a3ffc52a47809824d.json"
    },
    {
        "AppID": "113",
        "VersionFileName": "Json/PharaohVersion6014211ca80f3c13525011fd08ab4701.json",
        "AtlasFileName": "Json/PharaohFileConfig479159da8b9d4d650e45cbe0a0a55a6b.json"
    },
    {
        "AppID": "108",
        "VersionFileName": "Json/SpaceDiceVersioncbe7c79d50db34a2413353ebdba9f2e7.json",
        "AtlasFileName": "Json/SpaceDiceFileConfigfdeed02153bdcfb4919eafbd55625f0d.json"
    },
    {
        "AppID": "116",
        "VersionFileName": "Json/KingAndBeggarVersionb084b018a515f3f9c1608eb64aa8a95c.json",
        "AtlasFileName": "Json/KingAndBeggarFileConfig96c666b785d63a26e0400f77c1e44e36.json"
    },
    {
        "AppID": "117",
        "VersionFileName": "Json/RockPaperScissorsVersionf7dc59d5bc6c115fb5b736ed1f21afa0.json",
        "AtlasFileName": "Json/RockPaperScissorsFileConfig6cf879e73cab707dc5977be187fdc359.json"
    },
    {
        "AppID": "115",
        "VersionFileName": "Json/PattiVersion0bbc8518348ffe7bfb8f03ccc9c0ffa3.json",
        "AtlasFileName": "Json/PattiFileConfig8a1b909c368c1bbe8692c3f796846d40.json"
    }
];