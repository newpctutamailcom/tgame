//-----libs-begin-----
loadLib("libs/laya.core.js");
loadLib("libs/laya.ani.js");
loadLib("libs/laya.ui.js");
loadLib("libs/laya.html.js");
//-----libs-end-------

window.screenOrientation = "landscape";
var LibObject = {
    "Common": {
        "id": "Common",
        "name": "Common",
        "js_path": "js/Common07ea1b9efd1c57c1123bc80024385e14.js",
        "reference": []
    },
    "BaseChips": {
        "id": "BaseChips",
        "name": "BaseChips",
        "js_path": "js/BaseChips58ab032226d9d4eb5971df5210a8ee26.js",
        "reference": []
    },
    "BaseFSG": {
        "id": "BaseFSG",
        "name": "BaseFSG",
        "js_path": "js/BaseFSG80e55348e2baf125689ae8d7b98e6f36.js",
        "reference": ["BaseChips"]
    },
    "CommonSlots": {
        "id": "CommonSlots",
        "name": "CommonSlots",
        "js_path": "js/CommonSlotse879128436aea74effbe8575dda6ff07.js",
        "reference": []
    },
    "Tools3D": {
        "id": "Tools3D",
        "name": "Tools3D",
        "js_path": "js/Tools3Dd418a0ebc9b92a186fa90f355dbacc0d.js",
        "reference": []
    },
    "100": {
        "id": "100",
        "name": "Mine",
        "is_app": true,
        "js_path": "js/Mine7bf0710c55c2b9d988343e6f78b2b699.js",
        "reference": ["Common", "BaseFSG"]
    },
    "101": {
        "id": "101",
        "name": "Hilo",
        "is_app": true,
        "js_path": "js/Hilo8c0f9b941c3ccdfe70b02370001f618a.js",
        "reference": ["Common", "BaseFSG"]
    },
    "102": {
        "id": "102",
        "name": "Dice",
        "is_app": true,
        "js_path": "js/Dice46b79cd7ca113ad42c6ad9f73e5f2757.js",
        "reference": ["Common", "BaseFSG"]
    },
    "105": {
        "id": "105",
        "name": "Goal",
        "is_app": true,
        "js_path": "js/Goal2809e6895c0fe972a999904a9f5e44a6.js",
        "reference": ["Common", "BaseFSG"]
    },
    "106": {
        "id": "106",
        "name": "Keno",
        "is_app": true,
        "js_path": "js/Keno538de9532ecf0f7c9038f8260a2c2fb0.js",
        "reference": ["Common", "BaseFSG"]
    },
    "103": {
        "id": "103",
        "name": "Plinko",
        "is_app": true,
        "js_path": "js/Plinko7f8cf512f38f06a08962209ea488d0d2.js",
        "reference": ["Common", "BaseFSG"]
    },
    "107": {
        "id": "107",
        "name": "Hotline",
        "is_app": true,
        "js_path": "js/Hotlinea07031a0a5cd99db6495e77cb18032c1.js",
        "reference": ["Common", "BaseFSG"]
    },
    "109": {
        "id": "109",
        "name": "Coin",
        "is_app": true,
        "js_path": "js/Coin7ee8530684ab41ef24876cb26a02d22e.js",
        "reference": ["Common", "BaseFSG"]
    },
    "110": {
        "id": "110",
        "name": "Limbo",
        "is_app": true,
        "js_path": "js/Limboa998c5f9a326621e0956c23f731d3de9.js",
        "reference": ["Common", "BaseFSG"]
    },
    "111": {
        "id": "111",
        "name": "Cryptos",
        "is_app": true,
        "js_path": "js/Cryptos77e9589aa1498e9792d6f2a71b7bd898.js",
        "reference": ["Common", "BaseFSG"]
    },
    "112": {
        "id": "112",
        "name": "Triple",
        "is_app": true,
        "js_path": "js/Triplee8490717be299f523df25670479344a9.js",
        "reference": ["Common", "BaseFSG"]
    },
    "104": {
        "id": "104",
        "name": "Roulette",
        "is_app": true,
        "js_path": "js/Roulettefb51f422b0072c5b929359b1de881612.js",
        "reference": ["Common", "BaseFSG", "BaseChips"]
    },
    "114": {
        "id": "114",
        "name": "Horse",
        "is_app": true,
        "js_path": "js/Horse4f53aa63cdfdd6409e31ab3bf035b5cb.js",
        "reference": ["Common", "BaseFSG", "BaseChips"]
    },
    "113": {
        "id": "113",
        "name": "Pharaoh",
        "is_app": true,
        "js_path": "js/Pharaoh50a19270061e60c2e7cbe36d334e2b30.js",
        "reference": ["Common", "BaseFSG", "CommonSlots"]
    },
    "108": {
        "id": "108",
        "name": "SpaceDice",
        "is_app": true,
        "js_path": "js/SpaceDiced4529fef3189f2fd975d8465e16bbcf8.js",
        "reference": ["Common", "BaseFSG"]
    },
    "116": {
        "id": "116",
        "name": "KingAndBeggar",
        "is_app": true,
        "js_path": "js/KingAndBeggarfeb9ab0085591132327ed47247ed863a.js",
        "reference": ["Common", "BaseFSG"]
    },
    "117": {
        "id": "117",
        "name": "RockPaperScissors",
        "is_app": true,
        "js_path": "js/RockPaperScissorsc52eb5f659affcdc50c21682ce59ce20.js",
        "reference": ["Common", "BaseFSG"]
    },
    "115": {
        "id": "115",
        "name": "Patti",
        "is_app": true,
        "js_path": "js/Patti6b4bfdd32b63473c6dd088f89a32047d.js",
        "reference": ["Common", "BaseFSG"]
    },
};

function getQueryString(name) {
    var reg = new RegExp("(^|&)" + name + "=([^&]*)(&|$)");
    var r = window.location.search.substr(1).match(reg);
    if (r != null) return unescape(r[2]);
    return null;
}


function getLibDataByID(id) {
    if (LibObject[id] == null) {
        alert("cannot found module:" + id);
        return null;
    }
    return LibObject[id];
}

var loadedModel = [];

function modelHasLoaded(id) {
    return (loadedModel.indexOf(id) >= 0);
}

function loadJsByAppID(appID) {
    var isLoadFaild = false;
    var data = getLibDataByID(appID);
    if (data != null) {
        var array = data.reference;
        for (var i = 0; i < array.length; i++) {
            if (loadedModel.indexOf(array[i]) >= 0) {
                continue;
            }
            var dataItem = getLibDataByID(array[i]);
            if (dataItem == null) {
                isLoadFaild = true;
                break;
            }
            if (dataItem.js_path != null && dataItem.js_path != "") {
                loadLib(dataItem.js_path);
                loadedModel.push(dataItem.id);
            }
        }

        if (isLoadFaild) {
            alert("loadedModel game res failed!");
        } else {
            if (data.js_path != null && data.js_path != "") {
                loadLib(data.js_path);
                loadedModel.push(appID);
            }
        }
    }
}

var gamehall = getQueryString("gamehall");
var appID = getQueryString("appid");

if (gamehall == "true") {
    if (appID == null || appID == "") {
        loadJsByAppID(0);
    } else {
        loadJsByAppID(appID);
    }
} else {
    if (appID == null || appID == "") {
        alert("no appID param!");
    } else {
        loadJsByAppID(appID);
    }
}