(function(e) {
    var t = e.Laya;
    var o = t.AppContext,
        i = t.AutoNumberCell,
        s = t.AutoPlaySelected;
    var n = t.BaseGameScene,
        a = t.BaseMain,
        l = t.BaseScene,
        m = t.BaseView;
    var h = t.Box,
        r = t.Browser,
        u = t.Button,
        C = t.CheckRoundSeed,
        c = t.CommonUtils;
    var d = t.Dispatcher,
        b = t.DolSkeleton,
        p = t.Event,
        _ = t.GameContext;
    var w = t.GameEnum,
        g = t.GlobalEnum,
        k = t.GlobalEvent,
        E = t.GlobalSoundEnum;
    var N = t.HBox,
        O = t.HSlider,
        I = t.Handler,
        T = t.Image,
        x = t.ImageNumber;
    var P = t.Label,
        H = t.MsgMaster,
        S = t.MyBetViewCell,
        F = t.NumberCell;
    var W = t.NumberInputView,
        K = t.Panel,
        V = t.ResultView,
        G = t.ResultViewCell;
    var f = t.SceneManager,
        U = t.SoundUtils,
        Y = t.Sprite,
        j = t.TcpLogicManager;
    e.Coin = {};
    Coin.Config = {};
    Coin.Config.Res = {};
    class A {
        constructor() {}
    }
    Coin.Config.Res.GameResConfig = t.GameResConfig = A;
    A.RES_3D = [];
    A.RES_3D_LMAT = [];
    A.RES_FNT = [];
    t.static(A, ["RES_2D", function() {
        return this.RES_2D = ["Coin/common/common/ani/loading.atlas", "Coin/common/common/ani/roundid.atlas", "res/atlas/Coin/common/common/ui.atlas", "res/atlas/Coin/m/common/ui.atlas", "res/atlas/Coin/m/en/ui.atlas", "res/atlas/Coin/m/hi/ui.atlas", "res/atlas/Coin/m/id/ui.atlas", "res/atlas/Coin/m/ms/ui.atlas", "res/atlas/Coin/m/pr/ui.atlas", "res/atlas/Coin/m/th/ui.atlas", "res/atlas/Coin/m/vi/ui.atlas", "res/atlas/Coin/m/zh-cn/ui.atlas", "res/atlas/Coin/pc/common/ui.atlas", "res/atlas/Coin/pc/en/ui.atlas", "res/atlas/Coin/pc/hi/ui.atlas", "res/atlas/Coin/pc/id/ui.atlas", "res/atlas/Coin/pc/ms/ui.atlas", "res/atlas/Coin/pc/pr/ui.atlas", "res/atlas/Coin/pc/th/ui.atlas", "res/atlas/Coin/pc/vi/ui.atlas", "res/atlas/Coin/pc/zh-cn/ui.atlas", "res/atlas/Common/common/common/autoPlay.atlas", "res/atlas/Common/common/common/comp.atlas", "res/atlas/Common/common/common/dialog.atlas", "res/atlas/Common/common/common/ui.atlas", "res/atlas/Common/common/common/userinfo.atlas", "res/atlas/Common/common/common/verification.atlas", "res/atlas/Common/common/en/ui.atlas", "res/atlas/Common/common/hi/ui.atlas", "res/atlas/Common/common/id/ui.atlas", "res/atlas/Common/common/ms/ui.atlas", "res/atlas/Common/common/pr/ui.atlas", "res/atlas/Common/common/th/ui.atlas", "res/atlas/Common/common/vi/ui.atlas", "res/atlas/Common/common/zh-cn/ui.atlas", "res/atlas/Common/m/common/ui.atlas", "res/atlas/Common/m/en/ui.atlas", "res/atlas/Common/m/hi/ui.atlas", "res/atlas/Common/m/id/ui.atlas", "res/atlas/Common/m/ms/ui.atlas", "res/atlas/Common/m/pr/ui.atlas", "res/atlas/Common/m/th/ui.atlas", "res/atlas/Common/m/vi/ui.atlas", "res/atlas/Common/pc/common/ui.atlas", "res/atlas/Common/pc/en/ui.atlas", "res/atlas/Common/pc/hi/ui.atlas", "res/atlas/Common/pc/id/ui.atlas", "res/atlas/Common/pc/ms/ui.atlas", "res/atlas/Common/pc/pr/ui.atlas", "res/atlas/Common/pc/th/ui.atlas", "res/atlas/Common/pc/vi/ui.atlas", "Coin/common/common/spine/jinbi.png", "Coin/common/common/spine/jinbi.sk", "Coin/common/common/spine/quan.png", "Coin/common/common/spine/quan.sk"]
    }, "RES_SOUND", function() {
        return this.RES_SOUND = ["Assets/Coin/Sound/big_button.mp3", "Assets/Coin/Sound/button_click.mp3", "Assets/Coin/Sound/chip.mp3", "Assets/Coin/Sound/coinflip_coin.mp3", "Assets/Coin/Sound/limbo_win.mp3", "Assets/Coin/Sound/soft_win.mp3", "Assets/Coin/Sound/sound_lose.mp3"]
    }, "RES_UI", function() {
        return this.RES_UI = ["GameUI/Common/Dialog/MessageBox.json", "GameUI/Common/Dialog/MessageYesNoBox.json", "GameUI/Common/Dialog/ReconnectMessageBox.json", "GameUI/Common/Scenes/GameLoading.json", "GameUI/Common/View/AutoNumberCell_h.json", "GameUI/Common/View/AutoNumberCell_v.json", "GameUI/Common/View/BonusAnnouncementView.json", "GameUI/Common/View/BonusAnnouncementView_h.json", "GameUI/Common/View/BonusAnnouncementView_v.json", "GameUI/Common/View/DynamicMsgView.json", "GameUI/Common/View/GameLoadingBarNew.json", "GameUI/Common/View/LangSettingView_h.json", "GameUI/Common/View/LangSettingView_v.json", "GameUI/Common/View/LoadingView_h.json", "GameUI/Common/View/LoadingView_v.json", "GameUI/Common/View/ScreenSettingView_h.json", "GameUI/Common/View/ScreenSettingView_v.json", "GameUI/Common/View/UserInfoView_h.json", "GameUI/Common/View/UserInfoView_v.json", "GameUI/Coin/Scenes/GameLoading_h.json", "GameUI/Coin/Scenes/GameLoading_v.json", "GameUI/Coin/Scenes/GameScene_h.json", "GameUI/Coin/Scenes/GameScene_v.json", "GameUI/Coin/View/AutoNumberCell_h.json", "GameUI/Coin/View/AutoNumberCell_v.json", "GameUI/Coin/View/AutoPlaySelected_h.json", "GameUI/Coin/View/AutoPlaySelected_v.json", "GameUI/Coin/View/BetViewCell2_h.json", "GameUI/Coin/View/BetViewCell2_v.json", "GameUI/Coin/View/CheckRoundSeedView_h.json", "GameUI/Coin/View/CheckRoundSeedView_v.json", "GameUI/Coin/View/DetailedRulesView_h.json", "GameUI/Coin/View/DetailedRulesView_v.json", "GameUI/Coin/View/GameLimitsView_h.json", "GameUI/Coin/View/GameLimitsView_v.json", "GameUI/Coin/View/GameLoadingBarNew.json", "GameUI/Coin/View/GameRulesView_h.json", "GameUI/Coin/View/GameRulesView_v.json", "GameUI/Coin/View/GreenDetailed_h.json", "GameUI/Coin/View/GreenDetailed_v.json", "GameUI/Coin/View/HeaderView_h.json", "GameUI/Coin/View/HeaderView_v.json", "GameUI/Coin/View/LangSettingView_h.json", "GameUI/Coin/View/LangSettingView_v.json", "GameUI/Coin/View/LoadingView_h.json", "GameUI/Coin/View/LoadingView_v.json", "GameUI/Coin/View/MyBetViewCell_h.json", "GameUI/Coin/View/MyBetViewCell_v.json", "GameUI/Coin/View/MyHistoryView_h.json", "GameUI/Coin/View/MyHistoryView_v.json", "GameUI/Coin/View/NumberCell_h.json", "GameUI/Coin/View/NumberCell_v.json", "GameUI/Coin/View/ResultViewCell.json", "GameUI/Coin/View/ResultViewCell_h.json", "GameUI/Coin/View/ResultViewCell_v.json", "GameUI/Coin/View/ResultView_h.json", "GameUI/Coin/View/ResultView_v.json", "GameUI/Coin/View/ScreenSettingView_h.json", "GameUI/Coin/View/ScreenSettingView_v.json", "GameUI/Coin/View/UserInfoView_h.json", "GameUI/Coin/View/UserInfoView_v.json"]
    }, "RES_SK", function() {
        return this.RES_SK = ["Coin/common/common/spine/jinbi.sk", "Coin/common/common/spine/quan.sk"]
    }, "RES_ALL", function() {
        return this.RES_ALL = ["Assets/Coin/Sound/big_button.mp3", "Assets/Coin/Sound/button_click.mp3", "Assets/Coin/Sound/chip.mp3", "Assets/Coin/Sound/coinflip_coin.mp3", "Assets/Coin/Sound/limbo_win.mp3", "Assets/Coin/Sound/soft_win.mp3", "Assets/Coin/Sound/sound_lose.mp3", "res/atlas/Coin/common/common/ui.atlas", "res/atlas/Coin/common/common/ui.png", "res/atlas/Coin/m/common/ui.atlas", "res/atlas/Coin/m/common/ui.png", "res/atlas/Coin/m/en/ui.atlas", "res/atlas/Coin/m/en/ui.png", "res/atlas/Coin/m/hi/ui.atlas", "res/atlas/Coin/m/hi/ui.png", "res/atlas/Coin/m/id/ui.atlas", "res/atlas/Coin/m/id/ui.png", "res/atlas/Coin/m/ms/ui.atlas", "res/atlas/Coin/m/ms/ui.png", "res/atlas/Coin/m/pr/ui.atlas", "res/atlas/Coin/m/pr/ui.png", "res/atlas/Coin/m/th/ui.atlas", "res/atlas/Coin/m/th/ui.png", "res/atlas/Coin/m/vi/ui.atlas", "res/atlas/Coin/m/vi/ui.png", "res/atlas/Coin/m/zh-cn/ui.atlas", "res/atlas/Coin/m/zh-cn/ui.png", "res/atlas/Coin/pc/common/ui.atlas", "res/atlas/Coin/pc/common/ui.png", "res/atlas/Coin/pc/en/ui.atlas", "res/atlas/Coin/pc/en/ui.png", "res/atlas/Coin/pc/hi/ui.atlas", "res/atlas/Coin/pc/hi/ui.png", "res/atlas/Coin/pc/id/ui.atlas", "res/atlas/Coin/pc/id/ui.png", "res/atlas/Coin/pc/ms/ui.atlas", "res/atlas/Coin/pc/ms/ui.png", "res/atlas/Coin/pc/pr/ui.atlas", "res/atlas/Coin/pc/pr/ui.png", "res/atlas/Coin/pc/th/ui.atlas", "res/atlas/Coin/pc/th/ui.png", "res/atlas/Coin/pc/vi/ui.atlas", "res/atlas/Coin/pc/vi/ui.png", "res/atlas/Coin/pc/zh-cn/ui.atlas", "res/atlas/Coin/pc/zh-cn/ui.png", "Coin/common/common/ani/loading.atlas", "Coin/common/common/ani/loading.png", "Coin/common/common/ani/roundid.atlas", "Coin/common/common/ani/roundid.png", "Coin/common/common/spine/jinbi.png", "Coin/common/common/spine/jinbi.sk", "Coin/common/common/spine/quan.png", "Coin/common/common/spine/quan.sk", "GameUI/Coin/Scenes/GameLoading_h.json", "GameUI/Coin/Scenes/GameLoading_v.json", "GameUI/Coin/Scenes/GameScene_h.json", "GameUI/Coin/Scenes/GameScene_v.json", "GameUI/Coin/View/AutoNumberCell_h.json", "GameUI/Coin/View/AutoNumberCell_v.json", "GameUI/Coin/View/AutoPlaySelected_h.json", "GameUI/Coin/View/AutoPlaySelected_v.json", "GameUI/Coin/View/BetViewCell2_h.json", "GameUI/Coin/View/BetViewCell2_v.json", "GameUI/Coin/View/CheckRoundSeedView_h.json", "GameUI/Coin/View/CheckRoundSeedView_v.json", "GameUI/Coin/View/DetailedRulesView_h.json", "GameUI/Coin/View/DetailedRulesView_v.json", "GameUI/Coin/View/GameLimitsView_h.json", "GameUI/Coin/View/GameLimitsView_v.json", "GameUI/Coin/View/GameLoadingBarNew.json", "GameUI/Coin/View/GameRulesView_h.json", "GameUI/Coin/View/GameRulesView_v.json", "GameUI/Coin/View/GreenDetailed_h.json", "GameUI/Coin/View/GreenDetailed_v.json", "GameUI/Coin/View/HeaderView_h.json", "GameUI/Coin/View/HeaderView_v.json", "GameUI/Coin/View/LangSettingView_h.json", "GameUI/Coin/View/LangSettingView_v.json", "GameUI/Coin/View/LoadingView_h.json", "GameUI/Coin/View/LoadingView_v.json", "GameUI/Coin/View/MyBetViewCell_h.json", "GameUI/Coin/View/MyBetViewCell_v.json", "GameUI/Coin/View/MyHistoryView_h.json", "GameUI/Coin/View/MyHistoryView_v.json", "GameUI/Coin/View/NumberCell_h.json", "GameUI/Coin/View/NumberCell_v.json", "GameUI/Coin/View/ResultViewCell.json", "GameUI/Coin/View/ResultViewCell_h.json", "GameUI/Coin/View/ResultViewCell_v.json", "GameUI/Coin/View/ResultView_h.json", "GameUI/Coin/View/ResultView_v.json", "GameUI/Coin/View/ScreenSettingView_h.json", "GameUI/Coin/View/ScreenSettingView_v.json", "GameUI/Coin/View/UserInfoView_h.json", "GameUI/Coin/View/UserInfoView_v.json"]
    }]);
    class R extends a {
        constructor() {
            super()
        }
        initConfig() {
            super.initConfig();
            o.Instance.supportPlatform = 1;
            r.langList = ["en", "vi", "pr", "hi", "th", "ms", "id"]
        }
        InitApp() {
            super.InitApp();
            o.Instance.AppID = 109;
            o.Instance.AppVersion = "1.0.0";
            o.Instance.ModuleName = "Coin";
            o.Instance.GameResConfig = A;
            o.Instance.GameScene = y;
            o.Instance.GameKind = 2;
            o.Instance.CheckRoundSeedClass = B;
            o.Instance.ResultCellClass = L;
            o.Instance.fontArr = ["Microsoft YaHei", "fzcsjt", "stkaiti"];
            o.Instance.skNeedChangeSkin = ["tiaosan.sk"];
            o.Instance.fsg_next_interval = 300;
            this.setMoblieScreenTypeByLocalStorage(1)
        }
    }
    Coin.Main = t.Main = R;
    Coin.Scene = {};
    class y extends n {
        constructor() {
            super()
        }
        doFSGStart(e, i) {
            if (e != null) {
                c.setLocalStorageItem("COOKIE_BETMONEY", e.bet_money);
                c.setLocalStorageItem("COOKIE_CHANCE", e.chance)
            }
        }
    }
    Coin.Scene.GameScene = t.GameScene = y;
    Coin.View = {};
    class v extends s {
        constructor(e = null, i = 1, s = null) {
            super(e, i, s);
            this._bet_pos = 1
        }
        init() {
            super.init();
            this.btnB.changeSelected(true);
            this.btnA.changeSelected();
            this.btnB.setDto({
                num: c.getMsgForNowLang("HEAD"),
                key: "pos",
                bet_pos: 1
            }, true);
            this.btnA.setDto({
                num: c.getMsgForNowLang("TAIL"),
                key: "pos",
                bet_pos: 2
            }, false);
            this.curPosCell = this.btnB
        }
        onCellSelected(e) {
            super.onCellSelected(e);
            if (e != null && e.Data != null) {
                var i = e.Data;
                if (i.key == "pos") {
                    this._bet_pos = i.bet_pos;
                    if (this.curPosCell != null) {
                        this.curPosCell.changeSelected()
                    }
                    this.curPosCell = e;
                    this.curPosCell.changeSelected(true)
                }
            }
        }
        onBtnStart() {
            if (this._callback != null) {
                this._autoData.bet_pos = this._bet_pos;
                this._autoData.leftTime = this.getLeftTime();
                this.reStorJson();
                this._callback.runWith(this._autoData)
            }
            c.setLocalStorageJson("COOKIEAUTOPLAY" + o.Instance.uid, this._autoData);
            this.close()
        }
        onNumDownClick() {
            this.imgKeyboard && (this.imgKeyboard.visible = true);
            if (this.isHor) {
                this.imgKeyboard && (this.imgKeyboard.y = 100)
            } else {
                this.imgKeyboard && (this.imgKeyboard.y = 360)
            }
            this.popStatus = this.POPUP_DOWN;
            this._num = "";
            this.freshNum()
        }
        onNumSingleClick() {
            this.imgKeyboard && (this.imgKeyboard.visible = true);
            if (this.isHor) {
                this.imgKeyboard && (this.imgKeyboard.y = 190)
            } else {
                this.imgKeyboard && (this.imgKeyboard.y = 495)
            }
            this.popStatus = this.POPUP_SINGLE;
            this._num = "";
            this.freshNum()
        }
    }
    Coin.View.CoinAutoPlaySelected = t.CoinAutoPlaySelected = v;
    class B extends C {
        constructor() {
            super()
        }
        onEnable() {
            super.onEnable();
            this.onResize();
            this.p1 && (this.p1.hScrollBar.visible = false);
            t.stage.on(p.RESIZE, this, this.onResize)
        }
        onResize() {}
        init() {
            this.lblRule && (this.lblRule.text = "1:" + c.getMsgForNowLang("HEAD") + " 2:" + c.getMsgForNowLang("TAIL"));
            var e = 450;
            var i = _.Instance;
            this.labRoundNumber.text = i.CheckRoundSeedData.brd;
            if (this.isHor) {
                e = 350
            }
            c.setTextOverflowByEllipsis(this.labRoundNumber, e);
            this.labSeed1.text = i.CheckRoundSeedData.ss;
            if (this.isHor) {
                e = 800
            } else {
                e = 550
            }
            c.setTextOverflowByEllipsis(this.labSeed1, e);
            this.labSeed2.text = i.CheckRoundSeedData.ss256;
            if (this.isHor) {
                e = 800
            } else {
                e = 650
            }
            c.setTextOverflowByEllipsis(this.labSeed2, e);
            this.labResult.text = i.CheckRoundSeedData.gs;
            this.labSeed3.text = i.CheckRoundSeedData.ss + i.CheckRoundSeedData.gs;
            c.setTextOverflowByEllipsis(this.labSeed3, e);
            this.labSeed4.text = i.CheckRoundSeedData.rs256;
            c.setTextOverflowByEllipsis(this.labSeed4, e);
            var s = c.formartUTCtoLocalTimeByDayMonthYear(i.CheckRoundSeedData.tm, "/", true, true, true);
            this.labTimeStr.text = s;
            this.lblBetMoney && (this.lblBetMoney.text = c.getCurrencyStrBySignal(i.CheckRoundSeedData.bm));
            this.lblResult && (this.lblResult.text = i.CheckRoundSeedData.gs);
            var t = "";
            if (i.CheckRoundSeedData.bs != null) {
                var n = JSON.parse(i.CheckRoundSeedData.bs);
                if (n.bet_pos != null && n.bet_pos == 1) {
                    t = c.getMsgForNowLang("HEAD")
                } else {
                    t = c.getMsgForNowLang("TAIL")
                }
            }
            this.lblTarget && (this.lblTarget.text = t);
            this.lblCash && (this.lblCash.text = c.getCurrencyStrBySignal(c.getMoneyTextByNumber(i.CheckRoundSeedData.win)));
            if (i.CheckRoundSeedData.win > 0) {
                if (this.isHor) {
                    this.lblMul && (this.lblMul.text = " (" + (i.CheckRoundSeedData.win / i.CheckRoundSeedData.bm).toFixed(2) + " x)")
                } else {
                    this.lblMul && (this.lblMul.text = (i.CheckRoundSeedData.win / i.CheckRoundSeedData.bm).toFixed(2) + "x")
                }
                this.lblCash && (this.lblCash.color = "#7aff00");
                this.imgResult && (this.imgResult.skin = o.Instance.ModuleName + "/" + c.getPCOrMobilePath(this) + "/common/ui/img_number01_k.png")
            } else {
                if (this.isHor) {
                    this.lblMul && (this.lblMul.text = "")
                } else {
                    this.lblMul && (this.lblMul.text = "0.00x")
                }
                this.lblCash && (this.lblCash.color = "#ffffff");
                this.imgResult && (this.imgResult.skin = o.Instance.ModuleName + "/" + c.getPCOrMobilePath(this) + "/common/ui/img_number01_l.png")
            }
        }
    }
    Coin.View.CoinCheckRoundSeed = t.CoinCheckRoundSeed = B;
    class M extends S {
        constructor() {
            super();
            this.Coin_MIN_CHANCE = 10;
            this.Coin_MAX_CHANCE = 8818;
            this.PAYOUT_MIN = 1.1;
            this.PAYOUT_MAX = 970;
            this.FLASH_TIME = 500;
            this.status = 0;
            this.POPUP_BET_NONE = -1;
            this.POPUP_BET_KEYBOARD = 1;
            this.POPUP_BET_LIST = 2;
            this.noNeedFresh = false;
            this.H_PROGRESS_WIDTH = 1566;
            this.V_PROGRESS_WIDTH = 854;
            this.MIN_PROGRESS_WIDTH = 5;
            this.MOVIE_TIME = 500;
            this.lastSlideTime = 0;
            this.init = true;
            this.lastCoin = 1;
            this.curCoin = 1;
            this.progressWidth = this.H_PROGRESS_WIDTH
        }
        initConfig() {
            super.initConfig();
            this.CODE_STRING = "rs256";
            this.AUTO_DELAY = 300
        }
        onResize() {
            super.onResize();
            if (this.isHor) {
                this.pBox && (this.pBox.width = 1580)
            } else {
                this.pBox && (this.pBox.width = 880);
                this.imgBetMoneyKeyboard && (this.imgBetMoneyKeyboard.y = 1113 - this.offY / 2);
                this.imgQuickBetMoney && (this.imgQuickBetMoney.y = 794 - this.offY / 2);
                this.spBottom3 && (this.spBottom3.y = 1480 - this.offY / 2);
                this.btnCopy && (this.btnCopy.y = 150 + this.offY / 2);
                this.btnFresh && (this.btnFresh.y = 150 + this.offY / 2);
                this.imgFresh && (this.imgFresh.y = 150 + this.offY / 2)
            }
        }
        freshData() {
            super.freshData();
            if (_.Instance.FairSimple.brd != null && _.Instance.FairSimple.brd != "") {
                t.timer.frameOnce(1, this, function() {
                    d.dispatch("NC_FSG_START")
                })
            } else {
                this.changeBetStatus()
            }
        }
        onDTChange() {
            super.onDTChange();
            this.freshWin()
        }
        freshWin() {
            var e = 30;
            if (_.Instance.FairSimple != null && _.Instance.FairSimple.dt != null) {
                e = _.Instance.FairSimple.dt
            }
            this.lbWin1 && (this.lbWin1.text = c.getMoneyTextByNumber(this.betMoney * 2 * (1e3 - e) / 1e3, false, o.Instance.DEFAULT_ACCURACY, true));
            this.lbWin2 && (this.lbWin2.text = c.getMoneyTextByNumber(this.betMoney * 2 * (1e3 - e) / 1e3, false, o.Instance.DEFAULT_ACCURACY, true));
            c.autoLabelWidth(this.lbWin1, 130);
            c.autoLabelWidth(this.lbWin2, 130)
        }
        freshBetMoney() {
            super.freshBetMoney();
            this.freshWin()
        }
        onGetReady() {
            super.onGetReady();
            this.freshCode(true);
            this.changeAutoMode(false)
        }
        drawBar(e = false) {
            this.playCoin(e)
        }
        freshCoin() {
            this.sk && (this.sk.visible = false);
            this.imgCoin && (this.imgCoin.skin = o.Instance.ModuleName + "/" + c.getPCOrMobilePath() + "/common/ui/img_" + this.curCoin + ".png");
            this.imgCoin && (this.imgCoin.visible = true);
            if (_.Instance.FairSimple.rm != null && _.Instance.FairSimple.rm > 0) {
                U.Instance.playSound("limbo_win")
            } else {
                U.Instance.playSound("sound_lose")
            }
        }
        playCoin(e = false) {
            var i = this;
            var s = "";
            this.lastCoin = this.curCoin;
            if (this.lastCoin == 1) {
                s = "jin_"
            } else {
                s = "yin_"
            }
            if (_.Instance.FairSimple != null && _.Instance.FairSimple.gs != null && _.Instance.FairSimple.gs != "") {
                this.curCoin = parseFloat(_.Instance.FairSimple.gs)
            } else {
                this.curCoin = 1
            }
            if (this.curCoin == 1) {
                s += "jin"
            } else {
                s += "yin"
            }
            if (e) {
                if (s != "") {
                    this.imgCoin && (this.imgCoin.visible = false);
                    this.sk && (this.sk.visible = true);
                    U.Instance.playSound("coinflip_coin");
                    this.sk && this.sk.play(s, false, I.create(this, function() {
                        t.timer.frameOnce(1, this, function() {
                            i.freshCoin()
                        })
                    }))
                }
            } else {
                this.freshCoin()
            }
        }
        onGameStart(e, i) {
            super.onGameStart(e, i);
            this.spAllMask && (this.spAllMask.visible = true);
            this.btnBet && (this.btnBet.disabled = true);
            this.btnDec && (this.btnDec.disabled = true);
            this.btnAdd && (this.btnAdd.disabled = true);
            this.btnBetCoin && (this.btnBetCoin.disabled = true);
            this.btnCashout1 && (this.btnCashout1.disabled = true);
            this.btnCashout2 && (this.btnCashout2.disabled = true);
            this.btnAuto && (this.btnAuto.disabled = true)
        }
        onGameOver() {
            super.onGameOver();
            this.freshCode(true);
            this.drawBar(true)
        }
        onNext() {
            super.onNext();
            if (_.Instance.isAuto) {
                this.freshLeftCount()
            } else {
                this.changeAutoMode(false)
            }
            this.clear()
        }
        onOpeOver(e = true) {}
        onDestroy() {
            super.onDestroy()
        }
        clear() {
            this.onOpeOver()
        }
        onButtonClick(e) {
            var i = this;
            super.onButtonClick(e);
            switch (e) {
                case "btnAuto":
                    ;
                    var s = new v(I.create(this, function(e) {
                        _.Instance.single_win_list[0] = 0;
                        _.Instance.balance_change_list[0] = 0;
                        i._data.leftTime = e.leftTime;
                        i._data.totalWin = e.totalWin;
                        i._data.totalLose = e.totalLose;
                        i._data.perWin = e.perWin;
                        i._data.auto = e.auto;
                        i._data.bet_pos = e.bet_pos;
                        if (i._data.leftTime && i._data.leftTime > 0) {
                            i.changeAutoMode(true)
                        }
                    }), 1, {});
                    s.zOrder = 100;
                    f.Instance.NowScene.addChild(s);
                    break;
                case "btnCashout1":
                    this.doCashOut(1);
                    break;
                case "btnCashout2":
                    this.doCashOut(2);
                    break;
                case "btnSha":
                    this.onBtnCopy();
                    break
            }
        }
        changeAutoMode(e = false) {
            super.changeAutoMode(e);
            _.Instance.isAuto = this._autoMode;
            if (this._autoMode) {
                this.spAllMask && (this.spAllMask.visible = true);
                this.btnStop && (this.btnStop.visible = true);
                this.btnCashout1 && (this.btnCashout1.disabled = true);
                this.btnCashout2 && (this.btnCashout2.disabled = true);
                this.btnBet && (this.btnBet.disabled = true);
                this.btnDec && (this.btnDec.disabled = true);
                this.btnAdd && (this.btnAdd.disabled = true);
                this.btnBetCoin && (this.btnBetCoin.disabled = true);
                this.btnFresh && (this.btnFresh.visible = false);
                this.btnCopy && (this.btnCopy.disabled = true);
                this.freshLeftCount()
            } else {
                this.spAllMask && (this.spAllMask.visible = false);
                this.btnStop && (this.btnStop.visible = false);
                this.btnCashout1 && (this.btnCashout1.disabled = false);
                this.btnCashout2 && (this.btnCashout2.disabled = false);
                this.btnBet && (this.btnBet.disabled = false);
                this.btnDec && (this.btnDec.disabled = false);
                this.btnAdd && (this.btnAdd.disabled = false);
                this.btnBetCoin && (this.btnBetCoin.disabled = false);
                this.btnFresh && (this.btnFresh.visible = true);
                this.btnCopy && (this.btnCopy.disabled = false);
                this.btnAuto && (this.btnAuto.disabled = false)
            }
        }
        doCashOut(e, i = true) {
            var s = this;
            this.closeAll();
            var t = new Object;
            t.bet_pos = e;
            t.bet_money = c.formatNumber(this.betMoney);
            j.Instance.doSendFairSimpleStartByData(t, I.create(this, function(e) {
                if (c.IsNoError(e)) {} else {
                    s.changeAutoMode(false)
                }
                return
            }), i)
        }
        stopAutoMode() {
            super.stopAutoMode();
            if (_.Instance.isAuto) {
                this.changeAutoMode(false)
            }
        }
        doAutoPlay() {
            super.doAutoPlay();
            this.doCashOut(this._data.bet_pos, false)
        }
        initView() {
            super.initView();
            this.freshWin();
            if (_.Instance.FairSimple != null && _.Instance.FairSimple.bmc != null && _.Instance.FairSimple.bmc.length > 0) {
                this.QUICK_BET_MONEY_ARRAY = _.Instance.FairSimple.bmc
            }
            this.hideAllButton();
            if (this._fix_count <= 0) {
                this["btnNumDot"] && (this["btnNumDot"].disabled = true)
            }
            this.changeAutoMode(false)
        }
        changeBetStatus() {
            this.hideAllButton()
        }
    }
    Coin.View.CoinMyBetViewCell = t.CoinMyBetViewCell = M;
    class D extends V {
        constructor() {
            super();
            this.show_item_count2 = 45
        }
        madeDataByHor() {
            if (this.isHor) {
                this.COLUMN_PER_ROW = 15;
                this.CELL_WIDTH = 60;
                this.CELL_HEIGHT = 54;
                this.BASE_HGITH = 61;
                this.CELL_GAP = 5
            } else {
                this.COLUMN_PER_ROW = 9;
                this.CELL_WIDTH = 80;
                this.CELL_HEIGHT = 75;
                this.BASE_HGITH = 75;
                this.CELL_GAP = 12
            }
        }
    }
    Coin.View.CoinResultView = t.CoinResultView = D;
    class L extends G {
        constructor() {
            super()
        }
        fresh() {
            if (this._data) {
                if (this._data.rm != "" && this._data.rm > 0) {
                    this.imgBG && (this.imgBG.alpha = 1)
                } else {
                    this.imgBG && (this.imgBG.alpha = .3)
                }
                this.imgBG && (this.imgBG.skin = o.Instance.ModuleName + "/" + c.getPCOrMobilePath() + "/common/ui/img_i" + this._data.gs + ".png")
            }
        }
    }
    Coin.View.CoinResultViewCell = t.CoinResultViewCell = L;
    new R;
    return t
})(window);