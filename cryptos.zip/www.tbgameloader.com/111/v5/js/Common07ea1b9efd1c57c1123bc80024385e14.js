(function(k) {
    var b = k.Laya;
    var U = b.Animation,
        x = b.AtlasInfoManager,
        B = b.BitmapFont,
        H = b.Box;
    var C = b.Browser,
        F = b.Button,
        Y = b.Byte,
        j = b.CallLater,
        W = b.CheckBox;
    var z = b.CheckRoundSeed,
        V = b.ColorFilter,
        K = b.Dialog,
        o = b.Dispatcher;
    var q = b.DolZipHelp,
        J = b.Ease,
        M = b.Event,
        X = b.EventDispatcher,
        Z = b.HSlider;
    var Q = b.HTMLDivElement,
        v = b.Handler,
        $ = b.HttpRequest,
        ee = b.Image;
    var te = b.Label,
        ae = b.Laya3D,
        ie = b.Loader,
        ne = b.LoaderManager,
        se = b.LocalStorage;
    var re = b.Node,
        oe = b.Panel,
        c = b.Point,
        le = b.Pool,
        he = b.Radio,
        _e = b.RadioGroup;
    var ce = b.Rectangle,
        ue = b.ResourceVersion,
        me = b.ResultViewCell,
        de = b.Scene;
    var ge = b.Script,
        pe = b.ScrollBar,
        Ee = b.Skeleton,
        fe = b.Socket,
        Ae = b.SoundChannel;
    var m = b.SoundManager,
        p = b.Sprite,
        Ce = b.Stage,
        Te = b.Stat,
        Oe = b.Templet;
    var Se = b.Text,
        ye = b.TextArea,
        Ne = b.TextInput,
        Re = b.Texture,
        Ie = b.Timer;
    var be = b.Tween,
        Me = b.URL,
        ve = b.UserInfo,
        d = b.Utils,
        Le = b.Vector3,
        we = b.View;
    var Pe = b.WebGL;
    k.Common = {};
    Common.Base = {};
    class De {
        constructor() {
            this.has3D = false;
            b.zipHelper = new Tt;
            this.initConfig();
            C.checkLang();
            b.Config.isAntialias = true;
            if (k["Laya3D"] && (this.has3D || Pe.enable())) k["Laya3D"].init(u.width, u.height);
            else b.init(u.width, u.height, b["WebGL"]);
            b["Physics"] && b["Physics"].enable();
            b["DebugPanel"] && b["DebugPanel"].enable();
            b.stage.screenMode = u.screenMode;
            b.stage.alignV = u.alignV;
            b.stage.alignH = u.alignH;
            b.stage.frameRate = u.frameRate;
            Me.exportSceneToJson = u.exportSceneToJson;
            if (u.debug || d.getQueryString("debug") == "true") b.enableDebugPanel();
            if (u.physicsDebug && b["PhysicsDebugDraw"]) b["PhysicsDebugDraw"].enable();
            L.Instance.initClass();
            this.InitApp();
            O.getLang();
            C.checkSupportPlatform();
            this.initScreenMode();
            o.on("GLOABLE_APP_CONTEXT_INIT_FINISH", this, this.onAppContextInitFinishHandler);
            L.Instance.InitAppContext();
            if (L.Instance.IsLocalDebug || L.Instance.IsShowStat) Te.show();
            else if (u.stat) Te.show()
        }
        initConfig() {
            this.isFullScreen = true;
            C.langList = ["en"]
        }
        setMoblieScreenTypeByLocalStorage(e = 1) {
            C.moblieScreenType = O.getMobileScreenType(e);
            if (C.moblieScreenType == 2) {
                L.Instance.supportPlatform = 3
            }
        }
        initScreenMode() {
            if (!this.isFullScreen) {
                L.Instance.setScaleMode("showall")
            } else {
                L.Instance.setScaleMode("pchmv");
                if (C.moblieScreenType == 2 && C.onRealMobile) {
                    b.stage.screenMode = Ce.SCREEN_HORIZONTAL
                } else if (C.onPC) {
                    b.stage.screenMode = Ce.SCREEN_NONE
                } else {
                    b.stage.screenMode = Ce.SCREEN_VERTICAL
                }
            }
        }
        InitApp() {
            dt.Instance.InitTcpLogic()
        }
        onAppContextInitFinishHandler() {
            ue.enable(L.Instance.VersionFileName, v.create(this, this.onVersionLoaded), ue.FILENAME_VERSION)
        }
        onVersionLoaded() {
            x.enable(L.Instance.AtlasFileName, v.create(this, this.onConfigLoaded))
        }
        onConfigLoaded() {
            zt.Instance.StartScene(L.Instance.LoadingScene)
        }
    }
    Common.Base.BaseMain = b.BaseMain = De;
    class Ge {
        constructor() {
            this.MYSELF_INDEX = 0;
            this.CARD_WIDTH = 204;
            this.CARD_HEIGHT = 275;
            this.GameResultView = null;
            this.GameResultCellView = null;
            this.GamePlayerView = null;
            this.GameTimerView = null;
            this.ChatView = null;
            this.WordCell = null;
            this.EmojiCell = null;
            this.UI_PATH = "GAMENAME";
            this.PLAYER_READY_POSITION_ARR = [];
            this.PLAYER_GAME_POSITION_ARR = [];
            this.WORD_ARR = [];
            this.EMOJI_ARR = [];
            this.CARD_PATH = this.UI_PATH + "";
            this.GAMEUI_PATH = this.UI_PATH + "game/";
            this.GAME_SOUND_PATH = this.UI_PATH + "sound/XXX";
            this.COMMON_SOUND_PATH = this.UI_PATH + "sound/common";
            this.init();
            this.initChatList()
        }
        init() {}
        initChatList() {
            this.WORD_ARR = [];
            this.EMOJI_ARR = []
        }
        sortCard(e, t = true) {
            return e.sort()
        }
        getCardTag(e, t, a = 0, i = false) {
            return 0
        }
        getSeatByPlayerCount(e) {
            return []
        }
        getZorderBySeat(e) {
            return e
        }
        getObserverPositionArray(e, t = 1) {
            if (e <= 0) {
                return []
            }
            var a = [];
            for (var i = 0; i < e; ++i) {
                var n = (t + i - 1) % e;
                a.push(n)
            }
            return a
        }
    }
    Common.Base.BaseGameUtils = b.BaseGameUtils = Ge;
    Common.Config = {};
    class u {
        constructor() {}
    }
    Common.Config.AppConfig = b.AppConfig = u;
    u.width = 1900;
    u.height = 900;
    u.scaleMode = "showall";
    u.screenMode = "horizontal";
    u.alignV = "middle";
    u.alignH = "center";
    u.frameRate = "fast";
    u.sceneRoot = "";
    u.debug = false;
    u.stat = false;
    u.physicsDebug = false;
    u.exportSceneToJson = true;
    class ke {
        constructor() {}
    }
    Common.Config.CurrencyConfig = b.CurrencyConfig = ke;
    b.static(ke, ["CurrencyConfig", function() {
        return this.CurrencyConfig = {
            2: "$%s",
            1: "¥%s",
            307: "₹%s",
            308: "₫%sK"
        }
    }, "ReplaceCurrencyConfig", function() {
        return this.ReplaceCurrencyConfig = {
            2: "$",
            1: "¥",
            307: "₹",
            308: "₫",
            3081: "K"
        }
    }]);
    Common.Config.Event = {};
    class r {
        constructor() {}
    }
    Common.Config.Event.GlobalEvent = b.GlobalEvent = r;
    r.GLOABLE_EVENT_TCP_ON_CONNECT = "GLOABLE_EVENT_TCP_ON_CONNECT";
    r.GLOABLE_EVENT_TCP_ON_CLOSE = "GLOABLE_EVENT_TCP_ON_CLOSE";
    r.GLOABLE_EVENT_TCP_ON_ERROR = "GLOABLE_EVENT_TCP_ON_ERROR";
    r.GLOABLE_EVENT_APP_RESTART = "GLOABLE_EVENT_APP_RESTART";
    r.GLOABLE_EVENT_APP_EXIT = "GLOABLE_EVENT_APP_EXIT";
    r.GLOABLE_EVENT_REFRESH_PING = "GLOABLE_EVENT_REFRESH_PING";
    r.GLOABLE_EVENT_WANT_NEW_PING = "GLOABLE_EVENT_WANT_NEW_PING";
    r.GLOABLE_EVENT_APP_READY_TO_RUN = "GLOABLE_EVENT_APP_READY_TO_RUN";
    r.GLOABLE_EVENT_WANT_RESTART_TCP_LOGIC = "GLOABLE_EVENT_WANT_RESTART_TCP_LOGIC";
    r.GLOABLE_EVENT_WANT_INIT_TCP_LOGIC = "GLOABLE_EVENT_WANT_INIT_TCP_LOGIC";
    r.EVENT_TWEEN_FINISH = "TweenEnd";
    r.GLOABLE_ON_VIEW_CREATE_END = "onViewCreateEnd";
    r.GLOABLE_APP_CONTEXT_INIT_FINISH = "GLOABLE_APP_CONTEXT_INIT_FINISH";
    r.GLOABLE_GAME_RES_LOAD_FINISH = "GLOABLE_GAME_RES_LOAD_FINISH";
    r.GLOABLE_USER_BALANCE_CHANGE = "GLOABLE_USER_BALANCE_CHANGE";
    r.GLOABLE_DYNAMIC_MESSAGE = "GLOABLE_DYNAMIC_MESSAGE";
    r.GLOABLE_DELETE_TCP_BY_CMD = "GLOABLE_DELETE_TCP_BY_CMD";
    r.GLOABLE_DELETE_TCP_BY_CMD = "GLOABLE_DELETE_TCP_BY_CMD";
    r.GLOABLE_NEW_SCENE_COMPLETE = "GLOABLE_NEW_SCENE_COMPLETE";
    r.EVENT_VIEW_TIP_CLICK = "EVENT_VIEW_TIP_CLICK";
    r.GLOABLE_HALL_TCP = "GLOABLE_HALL_TCP";
    r.GLOABLE_CLOSE_APP = "GLOABLE_CLOSE_APP";
    r.GLOABLE_INTERFACE_ERROR = "GLOABLE_INTERFACE_ERROR";
    r.TCP_GROUP_OK = "TCP_GROUP_OK";
    r.TCP_GROUP_FINISH = "TCP_GROUP_FINISH";
    r.TCP_GET_INTO_ROOM_FINISH = "TCP_GET_INTO_ROOM_FINISH";
    r.TCP_GET_READY_FINISH = "TCP_GET_READY_FINISH";
    r.TCP_GET_PLAYER_IN_DESK_FINISH = "TCP_GET_PLAYER_IN_DESK_FINISH";
    r.TCP_PLAYER_GETINTO_ROOM = "TCP_PLAYER_GETINTO_ROOM";
    r.TCP_PLAYER_LEAVE_ROOM = "TCP_PLAYER_LEAVE_ROOM";
    r.TCP_PLAYER_ON_LINE = "TCP_PLAYER_ON_LINE";
    r.TCP_READY_CHANGE = "TCP_READY_CHANGE";
    r.TCP_AUTO_CHANGE = "TCP_AUTO_CHANGE";
    r.TCP_GAME_ROOM_OVER = "TCP_GAME_ROOM_OVER";
    r.TCP_GAME_ROOM_DISSOLVE = "TCP_GAME_ROOM_DISSOLVE";
    r.TCP_CREATE_ROOM_OK = "TCP_CREATE_ROOM_OK";
    r.TCP_GET_PLAYER_COUNT_IN_GAMEID = "TCP_GET_PLAYER_COUNT_IN_GAMEID";
    r.TCP_PLAYER_SEND_EXP = "TCP_PLAYER_SEND_EXP";
    r.TCP_PLAYER_SEND_WORD = "TCP_PLAYER_SEND_WORD";
    r.TCP_GET_MY_ROOM_LIST = "TCP_GET_MY_ROOM_LIST";
    r.TCP_GET_MY_GAME_STATUS = "TCP_GET_MY_GAME_STATUS";
    r.HALL_CHOOSE_GAME = "HALL_CHOOSE_GAME";
    r.HALL_CHOOSE_FRIEND = "HALL_CHOOSE_FRIEND";
    r.HALL_RETURN_GAME_VIEW = "HALL_RETURN_GAME_VIEW";
    r.HALL_CHOOSE_ROOM = "HALL_CHOOSE_ROOM";
    r.PLAYER_DO_ACTION = "PLAYER_DO_ACTION";
    r.NC_FRESH_PLAYERINFO = "NC_FRESH_PLAYERINFO";
    r.NC_CARD_CAL_INIT = "NC_CARD_CAL_INIT";
    r.NC_RESET = "NC_RESET";
    r.NC_GAME_START = "NC_GAME_START";
    r.NC_GAME_OVER = "NC_GAME_OVER";
    r.NC_READY_FOR_GAME = "NC_READY_FOR_GAME";
    r.NC_GAME_RESULT = "NC_GAME_RESULT";
    r.NC_FA_PAI = "NC_FA_PAI";
    r.NC_PLAYER_FA_PAI = "NC_PLAYER_FA_PAI";
    r.NC_FA_PAI_OVER = "NC_FA_PAI_OVER";
    r.NC_GET_PLAYER_IN_DESK = "NC_GET_PLAYER_IN_DESK";
    r.NC_OPE_TURN = "NC_OPE_TURN";
    r.NC_WAIT_OPE = "NC_WAIT_OPE";
    r.NC_OPERATION = "NC_OPERATION";
    r.NC_CLOSE_CONSOLE = "NC_CLOSE_CONSOLE";
    r.NC_GAME_RESULT_LAYER = "NC_GAME_RESULT_LAYER";
    r.NC_CHANGE_DESK = "NC_CHANGE_DESK";
    r.NC_PLAYER_READY = "NC_PLAYER_READY";
    r.NC_PLAYER_IN = "NC_PLAYER_IN";
    r.NC_PLAYER_OUT = "NC_PLAYER_OUT";
    r.NC_PLAYER_OUT_BY_PLAYERINDEX = "NC_PLAYER_OUT_BY_PLAYERINDEX";
    r.NC_MY_FA_PAI = "NC_MY_FA_PAI";
    r.NC_TIMER_POS = "NC_TIMER_POS";
    r.NC_WINLOSE_ANIM = "NC_WINLOSE_ANIM";
    r.NC_FLYCOIN_ANIM = "NC_FLYCOIN_ANIM";
    r.NC_SHOW_ANIM = "NC_SHOW_ANIM";
    r.NC_STOP_ANIM = "NC_STOP_ANIM";
    r.NC_SHOW_CHOOSE_CHA = "NC_SHOW_CHOOSE_CHA";
    r.NC_CHANGE_CHA_OK = "NC_CHANGE_CHA_OK";
    r.NC_GAME_REPORT_OK = "NC_GAME_REPORT_OK";
    r.NC_PLAYER_SHOW_SCORE = "NC_PLAYER_SHOW_SCORE";
    r.NC_START_ANIM_OVER = "NC_START_ANIM_OVER";
    r.NC_REPLAY_STEP = "NC_REPLAY_STEP";
    r.NC_REPLAY_INIT = "NC_REPLAY_INIT";
    r.NC_REPLAY_RESTART = "NC_REPLAY_RESTART";
    r.NC_BANKER_CHANGE = "NC_BANKER_CHANGE";
    r.NC_BANKER_CHANGE_OVER = "NC_BANKER_CHANGE_OVER";
    r.NC_BANKER_ANIM = "NC_BANKER_ANIM";
    r.NC_BANKER_ANIM_OVER = "NC_BANKER_ANIM_OVER";
    r.NC_REFRESH_CARD_COUNT = "NC_REFRESH_CARD_COUNT";
    r.NC_USER_BALANCE_CHANGE = "NC_USER_BALANCE_CHANGE";
    r.NC_GET_OUT_ROOM = "NC_GET_OUT_ROOM";
    r.NC_GET_OUT_ROOM_OK = "NC_GET_OUT_ROOM_OK";
    r.NC_SCENE_CHANGED = "NC_SCENE_CHANGED";
    r.NC_TCP_CHANGE_USER_PORTRAIT = "NC_TCP_CHANGE_USER_PORTRAIT";
    r.NC_TIMER_CHANGED = "NC_TIMER_CHANGED";
    r.MUL_BET_CHANGED = "MUL_BET_CHANGED";
    r.MUL_MY_BET_CHANGED = "MUL_MY_BET_CHANGED";
    r.MUL_STATUS_CHANGED = "MUL_STATUS_CHANGED";
    r.MUL_PLAYER_COUNT_CHANGED = "MUL_PLAYER_COUNT_CHANGED";
    r.MUL_BANKER_QUEUE_CHANGED = "MUL_BANKER_QUEUE_CHANGED";
    r.MUL_BANKER_OVER = "MUL_BANKER_OVER";
    r.MUL_BANKER_CHANGE = "MUL_BANKER_CHANGE";
    r.MUL_GAME_OVER = "MUL_GAME_OVER";
    r.MUL_START_KAIPAI = "MUL_START_KAIPAI";
    r.MUL_GAME_RESULT = "MUL_GAME_RESULT";
    r.MUL_GAME_RESULT_MOVIE_FINISH = "MUL_GAME_RESULT_MOVIE_FINISH";
    r.MUL_GAME_RESULT_CHIP_MOVIE_FINISH = "MUL_GAME_RESULT_CHIP_MOVIE_FINISH";
    r.MUL_GAME_PLAYER_RESULT = "MUL_GAME_PLAYER_RESULT";
    r.MUL_CANCEL_BET = "MUL_CANCEL_BET";
    r.MUL_OPEN_PAI = "MUL_OPEN_PAI";
    r.MUL_MEN_LIGHT = "MUL_MEN_LIGHT";
    r.MUL_OPE_ERROR = "MUL_OPE_ERROR";
    r.MUL_BET_POS_CHANGED = "MUL_BET_POS_CHANGED";
    r.MFG_MUL_CHANGE = "MFG_MUL_CHANGE";
    r.MFG_USER_BET = "MFG_USER_BET";
    r.MFG_USER_CANCLE_BET = "MFG_USER_CANCLE_BET";
    r.MFG_PLAYER_CASH_OUT = "MFG_PLAYER_CASH_OUT";
    r.MFG_STATUS_CHANGE = "MFG_STATUS_CHANGE";
    r.MFG_TOTAL_BET_CHANGE = "MFG_TOTAL_BET_CHANGE";
    r.MFG_BET_LIST_CHANGE = "MFG_BET_LIST_CHANGE";
    r.MFG_BET_BX_CHANGE = "MFG_BET_BX_CHANGE";
    r.MFG_RESULT_LIST_CHANGE = "MFG_RESULT_LIST_CHANGE";
    r.MFG_CASHOUT = "MFG_CASHOUT";
    r.MFG_CASHOUT_FRESH = "MFG_CASHOUT_FRESH";
    r.MFG_MY_BET_LIST_CHANGE = "MFG_MY_BET_LIST_CHANGE";
    r.MFG_CARTOON_CHANGE = "MFG_CARTOON_CHANGE";
    r.HALL_REFRESH_APP_LIST = "HALL_REFRESH_APP_LIST";
    r.NC_FEEDBACK_OK = "NC_FEEDBACK_OK";
    r.NC_GAME_COUNT_CHANGE = "NC_GAME_COUNT_CHANGE";
    r.NC_USERINFO_CLICK = "NC_USERINFO_CLICK";
    r.NC_USERINFO_CHANGEHEAD = "NC_USERINFO_CHANGEHEAD";
    r.NC_SHOW_GAMELIMIS = "NC_SHOW_GAMELIMIS";
    r.NC_SHOW_CHECKROUN_SEED = "NC_SHOW_CHECKROUN_SEED";
    r.NC_SHOW_DETAILED_RULES = "NC_SHOW_DETAILED_RULES";
    r.NC_SHOW_GREEN_RULES = "NC_SHOW_GREEN_RULES";
    r.NC_SHOW_POP = "NC_SHOW_POP";
    r.NC_SHOW_SHA = "NC_SHOW_SHA";
    r.NC_SHOW_LOADING = "NC_SHOW_LOADING";
    r.NC_GAMESTATUS_CHANGE = "NC_GAMESTATUS_CHANGE";
    r.NC_FSG_START = "NC_FSG_START";
    r.NC_FSG_OVER = "NC_FSG_OVER";
    r.NC_FSG_NEXT = "NC_FSG_NEXT";
    r.NC_FSG_OPE_CALLBACK = "NC_FSG_OPE_CALLBACK";
    r.NC_FSG_FRESH_CELL = "NC_FSG_FRESH_CELL";
    r.NC_FSG_ADD_TO_ARRAY = "NC_FSG_ADD_TO_ARRAY";
    r.NC_FSG_OPE_OVER = "NC_FSG_OPE_OVER";
    r.NC_FSG_OPEN_START = "NC_FSG_OPEN_START";
    r.NC_FSG_OPEN_OVER = "NC_FSG_OPEN_OVER";
    r.NC_FSG_AUTO_SELECTED_CHANGE = "NC_FSG_AUTO_SELECTED_CHANGE";
    r.NC_FSG_CELL_SELECTED = "NC_FSG_CELL_SELECTED";
    r.NC_FSG_BET_MONEY_CELL_CHECK = "NC_FSG_BET_MONEY_CELL_CHECK";
    r.NC_FSG_DT_CHANGE = "NC_FSG_DT_CHANGE";
    r.NC_FSG_CONFIG_CHANGE = "NC_FSG_CONFIG_CHANGE";
    r.NC_AUTOMODE_CHANGE = "NC_AUTOMODE_CHANGE";
    r.NC_SHOW_WIN_MONEY = "NC_SHOW_WIN_MONEY";
    r.NC_PLINKO_SHOW_NOW_MONEY = "NC_PLINKO_SHOW_NOW_MONEY";
    r.NC_SHOW_RESULT_VIEW = "NC_SHOW_RESULT_VIEW";
    r.NC_FSG_KENO_BALL_SELECTED = "NC_FSG_KENO_BALL_SELECTED";
    r.NC_FSG_KENO_BALL_CAN_SELECT = "NC_FSG_KENO_BALL_CAN_SELECT";
    r.NC_FSG_KENO_BALL_MOUSE_ENABLE = "NC_FSG_KENO_BALL_MOUSE_ENABLE";
    r.NC_FSG_CHIP_SELECTED = "NC_FSG_CHIP_SELECTED";
    r.NC_CHIPS_CHANGE = "NC_CHIPS_CHANGE";
    r.NC_BET_OPE_CHANGE = "NC_BET_OPE_CHANGE";
    r.NC_RESULT_MOVIE_COMPLETE = "NC_RESULT_MOVIE_COMPLETE";
    r.NC_NUMBER_KEYBOARD_CHANGE = "NC_NUMBER_KEYBOARD_CHANGE";
    r.NC_NUMBER_KEYBOARD_CLOSE = "NC_NUMBER_KEYBOARD_CLOSE";
    r.NC_SHOW_ANIMATION = "NC_SHOW_ANIMATION";
    r.NC_HIDE_ANIMATION = "NC_HIDE_ANIMATION";
    r.NC_CHANGE_TAB = "NC_CHANGE_TAB";
    r.NC_NEXT_ROUND = "NC_NEXT_ROUND";
    r.NC_ANIMATION_SET = "NC_ANIMATION_SET";
    r.GLOABLE_USER_BALANCE_TOPUP = "GLOABLE_USER_BALANCE_TOPUP";
    r.NC_REBET = "NC_REBET";
    r.NC_REBET_OK = "NC_REBET_OK";
    r.HTTP_SPIN_OK = "HTTP_SPIN_OK";
    r.NC_WANT_SPIN = "NC_WANT_SPIN";
    r.NC_START_SPIN = "NC_START_SPIN";
    r.NC_START_BONUS_SPIN = "NC_START_BONUS_SPIN";
    r.NC_STOP_SPIN = "NC_STOP_SPIN";
    r.NC_REEL_STOPED = "NC_REEL_STOPED";
    r.NC_REEL_STATUS_CHANGED = "NC_REEL_STATUS_CHANGED";
    r.NC_CELL_STOPED = "NC_CELL_STOPED";
    r.NC_CELL_FAN_FINISH = "NC_CELL_FAN_FINISH";
    r.NC_CELL_FAN_CHANGED = "NC_CELL_FAN_CHANGED";
    r.NC_ALL_REEL_STOPED = "NC_ALL_REEL_STOPED";
    r.NC_LINE_CHANGE = "NC_LINE_CHANGE";
    r.NC_BET_CHANGE = "NC_BET_CHANGE";
    r.NC_BET_MULT_CHANGE = "NC_BET_MULT_CHANGE";
    r.NC_SPIN_QUICK_CHANGE = "NC_SPIN_QUICK_CHANGE";
    r.NC_CELL_CLICKED = "NC_CELL_CLICKED";
    r.NC_ONE_GAME_OVER = "NC_ONE_GAME_OVER";
    r.NC_CLOSE_TOOLTIP = "NC_CLOSE_TOOLTIP";
    r.NC_FSG_FOOTBAR_NORMAL = "NC_FSG_FOOTBAR_NORMAL";
    r.NC_FSG_FOOTBAR_DISABLE = "NC_FSG_FOOTBAR_DISABLE";
    r.NC_UPDATE_MONEY = "NC_UPDATE_MONEY";
    r.NC_FSG_NEXT_GAME = "NC_FSG_NEXT_GAME";
    r.NC_FSG_SLOT_GAMEOVER = "NC_FSG_SLOT_GAMEOVER";
    r.NC_SHOW_BONUS = "NC_SHOW_BONUS";
    r.NC_LONGIN_OK = "NC_LONGIN_OK";
    class e {
        constructor() {}
    }
    Common.Config.GameEnum = b.GameEnum = e;
    e.COOKIE_BET_COUNT = "COOKIEBETCOUNT";
    e.COOKIE_BET_DATA = "COOKIEBETDATA";
    e.COOKIE_CARTOON = "COOKIECARTOON";
    e.COOKIE_MUSIC = "COOKIEMUSIC";
    e.COOKIE_SOUND = "COOKIESOUND";
    e.COOKIE_AUTO_PLAY = "COOKIEAUTOPLAY";
    e.COOKIE_BETMONEY = "COOKIE_BETMONEY";
    e.COOKIE_MINECOUNT = "COOKIE_MINECOUNT";
    e.COOKIE_FIELD = "COOKIE_FIELD";
    e.COOKIE_CHANCE = "COOKIE_CHANCE";
    e.COOKIE_MUL = "COOKIE_MUL";
    e.COOKIE_BRM = "COOKIE_BRM";
    e.COOKIE_BRM = "COOKIE_BRM";
    e.COOKIE_START_POS = "COOKIE_START_POS";
    e.COOKIE_LAST_BET = "COOKIE_LAST_BET";
    e.COOKIE_LAST_CHIP = "COOKIE_LAST_CHIP";
    e.OPE_TYPE_OPEN = 1;
    e.OPE_TYPE_CASHOUT = 2;
    e.MOVIE_NONE = 0;
    e.MOVIE_HORIZONTAL = 1;
    e.MOVIE_VERTICAL = 2;
    e.GAMESTATUS_NONE = 1;
    e.GAMESTATUS_NORMAL = 2;
    e.GAMESTATUS_WAIT = 3;
    e.GAMESTATUS_NO_SELECT_NO = 4;
    e.GAMESTATUS_AUTO_SELECTED = 5;
    e.GAMESTATUS_SELECT_NO = 6;
    e.GAMESTATUS_SELECT_BINGO = 7;
    e.GAMESTATUS_NO_SELECT_BINGO = 8;
    e.GAMESTATUS_GOAL_NONE = 1;
    e.GAMESTATUS_GOAL_CAN_SELECT = 2;
    e.GAMESTATUS_GOAL_GAMEOVER = 3;
    e.GAMESTATUS_GOAL_ICON_NONE = 0;
    e.GAMESTATUS_GOAL_ICON_FLAG = 1;
    e.GAMESTATUS_GOAL_ICON_SELECT = 2;
    e.GAMESTATUS_GOAL_ICON_BOMB = 3;
    e.GAMESTATUS_GOAL_ICON_EXPORT = 4;
    e.SingleSelect = 1;
    e.PairSelect = 2;
    e.PartSelect = 3;
    e.SpecialSelect = 4;
    e.Small = 1;
    e.Even = 2;
    e.Black = 3;
    e.Red = 4;
    e.Odd = 5;
    e.Big = 6;
    e.PATTI_GAMESTATE_SELECT = 1;
    e.PATTI_GAMESTATE_BLIND = 2;
    e.PATTI_GAMESTATE_SEEN = 3;
    e.PATTI_GAMESTATE_PACK = 4;
    e.PATTI_OPE_CHOOSE = 1;
    e.PATTI_OPE_SEEN = 2;
    e.PATTI_OPE_PACK = 3;
    e.PATTI_OPE_SHOW = 4;
    e.PATTI_OPE_SHOW2 = 5;
    e.PATTI_OPE_SHOW3 = 6;
    class Ue {
        constructor() {}
    }
    Common.Config.GameNameConfig = b.GameNameConfig = Ue;
    b.static(Ue, ["GameNames", function() {
        return this.GameNames = {}
    }]);
    class t {
        constructor() {}
    }
    Common.Config.GlobalButtonEnum = b.GlobalButtonEnum = t;
    t.RETURN = "btnReturn";
    t.CLOSE = "btnClose";
    t.CHOOSE_GAME = "btnChooseGame";
    t.CHOOSE_ROOM = "btnChooseRoom";
    t.FRIENDROOM = "btnFriendRoom";
    t.SETTING = "btnSetting";
    t.CHANGE_CHA = "btnChangeCha";
    t.SHARE = "btnShare";
    t.FULLSCREEN = "btnFullScreen";
    t.NUMBER = "btnNum";
    t.LBL_NUMBER = "lblNum";
    t.DELETE = "btnDel";
    t.CLEAR = "btnClear";
    t.CREATE_ROOM = "btnCreateRoom";
    t.JOIN_ROOM = "btnJoinRoom";
    t.CREATE_ROOM_NO_ENTER = "btnCreateRoomNoEnter";
    t.CREATE_ROOM_GAME = "btnCreateRoomGame";
    t.REPLAY = "btnReplay";
    t.REPLAY_MENU = "btnReplayMenu";
    t.REPORT = "btnReport";
    t.CHANGEDESK = "btnChangeDesk";
    t.EXIT = "btnExit";
    t.CONTINUE = "btnContinue";
    t.BACKROOM = "btnBackRoom";
    t.COPY_REPLAYNO = "btnCopyReplayNo";
    t.COPY = "btnCopy";
    t.SEND = "btnSend";
    t.RECHARGE = "btnRecharge";
    t.MUSIC = "btnMusic";
    t.EFFECT = "btnEffect";
    t.BACK = "btnBack";
    t.UNTRUSTEESHIP = "btnUntrusteeship";
    t.TRUSTEESHIP = "btnTrusteeship";
    t.READY = "btnReady";
    t.QUIT = "btnQuit";
    t.BACKHALL = "btnBackHall";
    t.BACKGAMEHALL = "btnBackGameHall";
    t.QUITGROUP = "btnQuitGroup";
    t.DELROOM = "btnDelRoom";
    t.EARLYSTART = "btnEarlyStart";
    t.SITDOWN = "btnSit";
    t.SITDOWN1 = "btnSit1";
    t.SITDOWN2 = "btnSit2";
    t.SITDOWN3 = "btnSit3";
    t.SITDOWN4 = "btnSit4";
    t.CHAT = "btnChat";
    t.GAME_INFO = "btnGameInfo";
    t.HELP = "btnHelp";
    t.CANCELBET = "btnCancelBet";
    t.EXIT_REPLAY = "btnExitReplay";
    t.PAUSE = "btnPause";
    t.PLAY = "btnPlay";
    t.BE_BANKER = "btnBeBanker";
    t.CANCEL_BANKER = "btnCancelBanker";
    t.BANKER_QUEUE = "btnBankerQueue";
    t.CONFIRM = "btnConfirm";
    t.CONFIRM1 = "btnConfirm1";
    t.CANCEL = "btnCancel";
    t.NOTICE = "btnNotice";
    t.MONEY_MINUS = "btnMoneyMinus";
    t.MONEY_ADD = "btnMoneyAdd";
    t.BUTTON1 = "btn1";
    t.BUTTON2 = "btn2";
    t.BUTTON3 = "btn3";
    t.BUTTON4 = "btn4";
    t.BUTTON5 = "btn5";
    t.SELECT = "btnSelect";
    t.HISTORY = "btnHistory";
    t.BET = "btnBet";
    class g {
        constructor() {}
    }
    Common.Config.GlobalConfig = b.GlobalConfig = g;
    g.IS_SHOW_STAGE_BACKGROUND_COLOR = false;
    g.IS_TCP_PROTOCAL_ENCRYPTION_ENABLE = true;
    g.IS_DEBUG_MODE = false;
    g.TCP_PING_LOOP_TIME_SPAN = 1e4;
    g.TCP_CALL_TIMEOUT_TIME_SPAN = 1e4;
    g.TCP_CALL_SHOW_LOADING_TIME_SPAN = 1e3;
    g.TCP_DATA_EVENT_PRE_SIGNAL = "TCP_CMD_EVENT_";
    g.DEBUG_HTTP_WEB_URL = "wss://tsqp.testbasepartner.cn/";
    g.DEBUG_DEMO_HTTP_WEB_URL = "wss://tsqp.testbasepartner.cn/";
    g.DEBUG_REPLAY_HTTP_WEB_URL = "http://api.testlayaslot.com/api/replay";
    g.DEBUG_BET_HISTORY_HTTP_WEB_URL = "http://192.168.1.249:4444/GameHistory/replay";
    g.GREEN_DETAILED_HTTP_WEB_URL = "https://www.miniwebtool.com/sha256-hash-generator/";
    g.RES_3D_DOWNLOAD_SHOW_MULTIPLE = 5;
    g.RES_3D_LMAT_DOWNLOAD_SHOW_MULTIPLE = 2;
    g.FRESHGAME_CD = 5e3;
    g.NOT_ENOUGH_CD = 2e3;
    b.static(g, ["TCP_BIT_ENDIAN_MODE", function() {
        return this.TCP_BIT_ENDIAN_MODE = Y.BIG_ENDIAN
    }, "CHIP_LIST", function() {
        return this.CHIP_LIST = [.1, .5, 1, 5, 10, 50, 100, 500, 1e3, 5e3, 8e3, 1e4, 5e4, 1e5]
    }, "LANGUAGE_CONFIG", function() {
        return this.LANGUAGE_CONFIG = {
            en: "English",
            vi: "Tiếng Việt",
            pr: "Português",
            th: "ไทย",
            hi: "हिंदी",
            ms: "Melayu",
            id: "Bahasa Indonesia"
        }
    }]);
    class l {
        constructor() {}
    }
    Common.Config.GlobalEnum = b.GlobalEnum = l;
    l.GAME_KIND_GOLD = 0;
    l.GAME_KIND_MUL = 1;
    l.GAME_KIND_PRO_MUL = 2;
    l.GAME_FAIR_SINGLE_GAME = 3;
    l.GAME_LANGUAGE_CNS = "zh-cn";
    l.GAME_LANGUAGE_CNT = "zh-tw";
    l.GAME_LANGUAGE_ENG = "en";
    l.GAME_LANGUAGE_KO = "ko";
    l.GAME_LANGUAGE_ES = "es";
    l.GAME_LANGUAGE_VI = "vi";
    l.GAME_LANGUAGE_TH = "th";
    l.GAME_LANGUAGE_JA = "ja";
    l.GAME_LANGUAGE_HI = "hi";
    l.GAME_LANGUAGE_PR = "pr";
    l.GAME_LANGUAGE_MS = "ms";
    l.GAME_LANGUAGE_ID = "id";
    l.GAME_LANGUAGE_TL = "tl";
    l.GAME_LANGUAGE_MY = "my";
    l.MUL_GAME_STATUS_WAIT_BANKER = 0;
    l.MUL_GAME_STATUS_WAIT_GAME_START = 1;
    l.MUL_GAME_STATUS_BETTING = 2;
    l.MUL_GAME_STATUS_ACCOUNT = 3;
    l.MUL_GAME_STATUS_ANIMATION = 4;
    l.MUL_POS_RESULT_TYPE_TIE = 0;
    l.MUL_POS_RESULT_TYPE_WIN = 1;
    l.MUL_POS_RESULT_TYPE_LOSS = 2;
    l.MUL_BANKER_STATUS_NORMAL = 0;
    l.MUL_BANKER_STATUS_SUCCESS = 1;
    l.MUL_BANKER_STATUS_FAIL = 2;
    l.MUL_ACCOUNT_STATUS_NONE = 0;
    l.MUL_ACCOUNT_STATUS_DOING = 1;
    l.MUL_ACCOUNT_STATUS_FINISH = 2;
    l.MUL_BANKER_CHANGE_SHANG = 0;
    l.MUL_BANKER_CHANGE_XIA = 1;
    l.SCENE_TYPE_NONE = 0;
    l.SCENE_TYPE_HALL = 1;
    l.SCENE_TYPE_GAME = 2;
    l.SCENE_TYPE_LOADING = 3;
    l.ROOM_TYPE_RANDOM = 1;
    l.ROOM_TYPE_FRIEND = 2;
    l.ROOM_STATUS_READY = 1;
    l.ROOM_STATUS_RUNNING = 2;
    l.ROOM_STATUS_OVER = 3;
    l.GAME_STATUS_WAITING = 0;
    l.GAME_STATUS_PLAYING = 1;
    l.PLAYER_STATUS_WAITING = 0;
    l.PLAYER_STATUS_GAMING = 1;
    l.GAME_STATUS_NONE = 0;
    l.GAME_STATUS_GAME_OVER_IN_RESULT = 1;
    l.GAME_STATUS_FINDDING = 10;
    l.GAME_STATUS_CREATE_ROOM_TCP = 11;
    l.GAME_STATUS_GROUP_TCP = 12;
    l.GAME_STATUS_GROUPING = 13;
    l.GAME_STATUS_STOP_GROUP_TCP = 14;
    l.GAME_STATUS_HAS_ROOM = 15;
    l.GAME_STATUS_GROUP_FINISH = 16;
    l.GAME_STATUS_GETINTO_ROOM_TCP = 17;
    l.GAME_STATUS_GETINTO_ROOM_OK = 18;
    l.GAME_STATUS_GET_READY_TCP = 19;
    l.GAME_STATUS_GET_READY_OK = 20;
    l.GAME_STATUS_GETOUT_ROOM_TCP = 20;
    l.GAME_STATUS_GAMEING = 30;
    l.GAME_STATUS_OBSERVER = 31;
    l.GAME_STATUS_WANT_SIT_TCP = 32;
    l.GAME_STATUS_WANT_SIT_OK = 33;
    l.GAME_STATUS_NO_READY = 34;
    l.GAME_STATUS_READY_TCP = 35;
    l.GAME_STATUS_IS_READY = 36;
    l.GAME_STATUS_IN_GAME = 37;
    l.GAME_STATUS_GAMEOVERING = 38;
    l.GAME_STATUS_GAME_RESULT = 39;
    l.GAME_STATUS_GET_DESK_PLAYER_TCP = 41;
    l.GAME_STATUS_GET_DESK_PLAYER_OK = 42;
    l.HALL_VIEW_GAME = 1;
    l.HALL_VIEW_ROOM = 2;
    l.HALL_VIEW_FRIEND = 3;
    l.GAME_START = 1;
    l.GAME_OVER = 2;
    l.ZORDER_BG = 0;
    l.ZORDER_HALL_3D = 1;
    l.ZORDER_HALL_UI = 2;
    l.ZORDER_HALL_OPTION = 3;
    l.ZORDER_HALL_POPUP = 5;
    l.ZORDER_HALL_3D_CHOOSE = 6;
    l.ZORDER_GAME_3D = 1;
    l.ZORDER_GAME_TITLE = 2;
    l.ZORDER_GAME_PLAYER = 3;
    l.ZORDER_GAME_DESKCARD = 4;
    l.ZORDER_GAME_CHAT = 5;
    l.ZORDER_GAME_TIMER_BACK = 6;
    l.ZORDER_GAME_OPTION = 7;
    l.ZORDER_GAME_TIMER = 8;
    l.ZORDER_GAME_ANIM = 9;
    l.ZORDER_GAME_RESULT = 20;
    l.ZORDER_GAME_CHAT = 30;
    l.ZORDER_POPUP = 100;
    l.ZORDER_GAME_MUL_3D = 1;
    l.ZORDER_GAME_MUL_TITLE = 5;
    l.ZORDER_GAME_MUL_BET_INFO = 6;
    l.ZORDER_GAME_MUL_MY_BET = 7;
    l.ZORDER_GAME_MUL_HISTORY = 8;
    l.ZORDER_GAME_MUL_RESULT = 3;
    l.ZORDER_GAME_MUL_ANIM = 9;
    l.WANT_NONE = 0;
    l.WANT_PLAYING = 1;
    l.WANT_EXIT = 2;
    l.ALIGN_LEFT = 0;
    l.ALIGN_RIGHT = 1;
    l.ALIGN_MIDDLE = 2;
    l.ALIGN_TOP = 3;
    l.ALIGN_BOTTOM = 4;
    l.NC_LEVEL_SCENE = 3;
    l.NC_LEVEL_MODEL = 2;
    l.NC_LEVEL_VIEW = 1;
    l.PLAYER_SIT_IDLE = "sit1";
    l.PLAYER_SIT_HAPPY = "sit2";
    l.PLAYER_SIT_SAD = "sit3";
    l.PLAYER_SIT_WEARY = "sit4";
    l.PLAYER_SIT_THINKING = "sit5";
    l.MONEY_TYPE_NONE = 0;
    l.MONEY_TYPE_WAN = 1;
    l.MONEY_TYPE_QIAN = 2;
    l.MONEY_TYPE_BET = 3;
    l.MONEY_TYPE_MUL_K = 4;
    l.EMOJI_START = 100;
    l.PLAYER_ACTION_IDLE = 0;
    l.PLAYER_ACTION_HAPPY = 1;
    l.PLAYER_ACTION_UNHAPPY = 2;
    l.PLAYER_ACTION_WEARY = 3;
    l.PLAYER_ACTION_THINKING = 4;
    l.RESULT_ROOM_TYPE_REPLAY = 0;
    l.RESULT_ROOM_TYPE_RANDOM = 1;
    l.RESULT_ROOM_TYPE_ROOM_PLAYER = 2;
    l.RESULT_ROOM_TYPE_ROOM_OBSERVER = 3;
    l.BANKER_MODE_NONE = 1;
    l.BANKER_MODE_BANKER = 2;
    l.REPLAY_STEP_START = "REPLAY_STEP_START";
    l.REPLAY_STEP_ACTION = "REPLAY_STEP_ACTION";
    l.REPLAY_STEP_RESULT = "REPLAY_STEP_RESULT";
    l.REPLAY_MODE_NONE = 0;
    l.REPLAY_MODE_PLAYING = 1;
    l.REPLAY_MODE_PAUSE = 2;
    l.IMAGENUMBER_OFFSET_TYPE_RES = "none";
    l.IMAGENUMBER_OFFSET_TYPE_FIXED = "fixed";
    l.IMAGENUMBER_OFFSET_TYPE_RES_FIXED = "imgWithFixed";
    l.NUMBER_TYPE_INTEGER = 0;
    l.NUMBER_TYPE_FLOAT = 1;
    l.NUMBER_TYPE_MONEY = 2;
    l.GET_OUT_ROOM_TYPE_EXIT = 0;
    l.GET_OUT_ROOM_TYPE_CHANGE = 1;
    l.GET_OUT_ROOM_TYPE_REPLAY = 2;
    l.MUL_GIRL_ACTION_FA_PAI = 0;
    l.MUL_GIRL_ACTION_KAI_PAI = 1;
    l.MUL_GIRL_ACTION_SHOU_PAI = 2;
    l.MSG_TYPE_NONE = 0;
    l.MSG_TYPE_INFO = 1;
    l.MSG_TYPE_WARN = 2;
    l.MSG_TYPE_ERROR = 3;
    l.CIRCLE_TYPE_PERCENT = 1;
    l.CIRCLE_TYPE_ROTATION = 2;
    l.PLATFORM_BOTH = 1;
    l.PLATFORM_MOBLIE = 2;
    l.PLATFORM_PC = 3;
    l.MOBLIE_V = 1;
    l.MOBLIE_H = 2;
    l.HALL_TYPE_ALL = 0;
    l.HALL_TYPE_MUL = 1;
    l.HALL_TYPE_GOLD = 2;
    l.HALL_TYPE_MATCH = 3;
    l.HALL_TYPE_COLLECT = 4;
    l.LOADING_TYPE_NORMAL = 0;
    l.LOADING_TYPE_CHRISTMAS = 1;
    l.LOADING_TYPE_NEWYEAR = 2;
    l.MEN_STATUS_LOSE = 1;
    l.MEN_STATUS_WIN = 2;
    l.MEN_STATUS_FLOW = 3;
    l.LONGHU_HE = 0;
    l.LONGHU_LONG = 1;
    l.LONGHU_HU = 2;
    l.MUL_GAME_OPE_TYPE_BET = 0;
    l.MUL_GAME_OPE_TYPE_POS = 1;
    l.MUL_GAME_OPE_TYPE_CANCEL = 2;
    l.MUL_GAME_OPE_TYPE_EXP = 3;
    l.MUL_FAIR_GAME_STATUS_BETTING = 1;
    l.MUL_FAIR_GAME_STATUS_ANIMATION = 2;
    l.MUL_FAIR_GAME_STATUS_ACCOUNT = 3;
    l.MUL_FAIR_GAME_OPE_TYPE_BET = 0;
    l.MUL_FAIR_GAME_OPE_TYPE_CANCEL = 1;
    l.MUL_FAIR_GAME_OPE_TYPE_CASH_OUT = 2;
    l.ZORDER_MFG_BET = 1;
    l.ZORDER_MFG_MYBET = 4;
    l.ZORDER_MFG_RESULT = 3;
    l.ZORDER_MFG_HEADER = 5;
    l.ZORDER_MFG_SHA = 6;
    l.ZORDER_MFG_ANIMA = 2;
    l.ZORDER_MFG_CASHOUT = 9;
    l.ZORDER_MFG_POPUP = 100;
    l.ZORDER_FSG_BET = 1;
    l.ZORDER_FSG_HEADER = 6;
    l.ZORDER_FSG_SHA = 7;
    l.ZORDER_FSG_ANIMA = 4;
    l.ZORDER_FSG_HISTORY = 3;
    l.ZORDER_FSG_BETINFO = 2;
    l.ZORDER_FSG_ANIMALTION = 8;
    l.LOCALSTORE_CHIPS_CONFIG = "BetCofig";
    l.LOCALSTORE_ANI_CONFIF = "LOCALSTOREANICONFIF";
    l.LOCALSTORE_KING_CONFIG = "LOCALSTOREKINGCONFIF";
    l.MODE_TRANSFER_WALLET = 1;
    l.MODE_SINGLE_WALLET = 2;
    l.SYMBOL_TYPE_SMALL = 0;
    l.SYMBOL_TYPE_BIG = 1;
    l.SYMBOL_TYPE_WILD = 2;
    l.SYMBOL_TYPE_SCATTER = 3;
    l.SYMBOL_TYPE_BOUNCE = 4;
    l.GAME_STATUS_STOP = 0;
    l.GAME_STATUS_SPINNING = 1;
    l.GAME_MODE_MANUAL = 0;
    l.GAME_MODE_AUTO = 1;
    l.GAME_MODE_FREE = 2;
    l.GAME_MODE_BONUS = 3;
    l.GAME_MODE_GETBONUSINFREE = 4;
    l.GAME_MODE_RECONNECTBONUSINFREE = 5;
    l.REEL_STATUS_STOP = 0;
    l.REEL_STATUS_READY = 1;
    l.REEL_STATUS_STARTING = 2;
    l.REEL_STATUS_SPINNING = 3;
    l.REEL_STATUS_STOPING = 4;
    l.REEL_STATUS_REROLL = 5;
    l.REEL_STATUS_SPECIAL = 6;
    l.REEL_STATUS_NORMAL = 7;
    l.CELL_STATUS_NORMAL = 0;
    l.CELL_STATUS_INVALID = 1;
    l.CELL_STATUS_UNSHOW = 2;
    l.CELL_STATUS_DARK = 3;
    l.CELL_STATUS_ROTATION = 4;
    l.CELL_STATUS_REROLL = 5;
    l.CELL_ROTATE_ZZ = 0;
    l.CELL_ROTATE_FZ = 1;
    l.CELL_ROTATE_FF = 2;
    l.CELL_ROTATE_ZF = 3;
    l.CELL_ROTATE_FYQ = 4;
    l.CELL_ANI_ALL = 0;
    l.CELL_ANI_SCATTER = 1;
    l.CELL_ANI_NORMAL = 2;
    l.CELL_ROLL_MODE_UPDOWN = 0;
    l.CELL_ROLL_MODE_FANMIAN = 1;
    l.CELL_ROLL_MODE_SELFFLASH = 2;
    l.BIGWIN_TYPE_NONE = 0;
    l.BIGWIN_TYPE_BIG = 1;
    l.BIGWIN_TYPE_SUPER = 2;
    l.BIGWIN_TYPE_MEGA = 3;
    l.POPUP_TYPE1_FREE = "F";
    l.POPUP_TYPE1_BOUCES = "B";
    l.POPUP_TYPE2_NORMAL = 0;
    l.POPUP_TYPE2_TOTAL = 1;
    l.POPUP_TYPE2_RECONNECT = 2;
    l.POPUP_TYPE2_AGAIN = 3;
    l.POPUP_TYPE2_CHOOSE = 4;
    l.POPUP_TYPE3_ENTER = 0;
    l.POPUP_TYPE3_LOOP = 1;
    l.POPUP_TYPE3_EXIT = 2;
    l.FOOTBAR_NORMAL = 1;
    l.FOOTBAR_DISABLE = 2;
    l.FOOTBAR_PAYTABLE = 3;
    l.FOOTBAR_FREE = 4;
    l.FOOTBAR_M_AUTO = 5;
    l.FOOTBAR_BONUS = 6;
    class a {
        constructor() {}
    }
    Common.Config.GlobalSoundEnum = b.GlobalSoundEnum = a;
    a.PLAYER_SOUND_ONE = 1;
    a.PLAYER_SOUND_MULTI = 2;
    a.MUSIC_HALL = "music_hall";
    a.MUSIC_GAME = "music_game";
    a.SOUND_WINDOW_OPEN = "sound_open";
    a.SOUND_WINDOW_CLOSE = "sound_close";
    a.SOUND_GAME_START = "sound_gamestart";
    a.SOUND_ALARM = "sound_timer";
    a.SOUND_WIN = "sound_win";
    a.SOUND_LOSE = "sound_lose";
    a.SOUND_DRAW = "sound_draw";
    a.SOUND_COMPARE = "sound_compare";
    a.SOUND_FLYCOIN = "sound_flycoin";
    a.SOUND_REFRESH_SCORE = "sound_refresh_score";
    a.SOUND_FAPAI = "sound_fapai";
    a.SOUND_MSG = "msg%03d";
    a.SOUND_CUOPAI = "sound_cuopai";
    a.SOUND_COIN = "sound_coin";
    a.SOUND_QIPAI = "sound_qipai";
    a.SOUND_MSG_INFO = "sound_prompt";
    a.SOUND_MSG_WARN = "sound_warn_prompt";
    a.SOUND_MSG_ERROR = "sound_error_prompt";
    a.SOUND_BUTTON_CLICK = "button_click";
    a.SOUND_BET_CLICK = "big_button";
    a.SOUND_BOMB = "bomb_detect";
    a.SOUND_SOFT = "soft_win";
    a.SOUND_MINE = "mines_select";
    a.SOUND_AUTO = "chip";
    a.SOUND_WIN = "Win";
    a.SOUND_BUTTON_CLICK = "button_click";
    a.SOUND_BET_CLICK = "big_button";
    a.SOUND_DICE_BALL_MOVE = "dice_ball_move";
    a.SOUND_DICE_BALL_DRAG = "dice_ball_drag";
    a.SOUND_BALL_MOVE = "goal_ball_move";
    a.SOUND_KENO_SELECT_NUM = "keno_select_num";
    a.SOUND_KENO_HIT_NUM = "keno_hit_num";
    a.SOUND_KENO_RESULT = "keno_result";
    a.SOUND_KENO_DISABLED_NUM = "keno_disabled_num";
    a.SOUND_HHTLINE_SWITCH_HIGH_RISK = "hotline_switch_high_risk";
    a.SOUND_SPIN_HIGH_RISK_2_LINE = "hotline_spin_high_risk_2_line";
    a.SOUND_SPIN_HIGH_RISK = "hotline_spin_high_risk";
    a.SOUND_SPIN = "hotline_spin";
    a.SOUND_HILO_LOW_HIGH_BUTTON = "hilo_low_high_button";
    a.SOUND_HILO_CARD_CHANGE = "hilo_card_change";
    a.SOUND_HILO_DEAL_CARDS = "hilo_deal_cards";
    a.SOUND_LIMBO_FLY = "limbo_fly";
    a.SOUND_LIMBO_WIN = "limbo_win";
    a.SOUND_COINFLIP_COIN = "coinflip_coin";
    a.SOUND_LOSING = "losing";
    a.SOUND_ROULETTE_SPIN = "roulette_spin";
    a.SOUND_ROULETTE_SET_CHIP = "roulette_set_chip";
    a.SOUND_PHOTO = "photo";
    a.SOUND_MATCH = "match";
    a.SOUND_FLIP = "flip";
    a.SOUND_REELSTOP = "sound_reelstop";
    a.MUSIC_BONUS = "music_bonus";
    a.SOUND_WIN_BONUS = "sound_winbonus";
    a.SOUND_WIN_LINE = "sound_winline";
    a.SOUND_BONUS_START = "sound_bonusstart";
    a.SOUND_BONUS_REEL_START = "sound_bonusreelstart";
    a.SOUND_EXCEPT = "sound_except";
    a.SOUND_SPACEDICE_WIN = "spacedice_win";
    a.SOUND_SPACEDICE_LOSE = "spacedice_lose";
    a.SOUND_SPACEDICE_NUM = "spacedice_num";
    a.SOUND_SPACEDICE_SWIPE = "spacedice_swipe";
    a.SOUND_VS = "vs";
    a.SOUND_WIN_PATTI = "win_sound";
    a.SOUND_LOSE_PATTI = "lose";
    Common.Config.Msg = {};
    class i {
        constructor() {}
    }
    Common.Config.Msg.MsgMaster = b.MsgMaster = i;
    i.MSG_FEEDBACK_OK = "FEEDBACK_OK";
    i.CLIP_RBD = "clip_rbd";
    i.CLIP_SEED = "clip_seed";
    i.CLIP_RESULT = "clip_result";
    i.CLIP_SEED_SEC = "clip_seed_sec";
    i.CLIP_RESULT_SEC = "clip_result_sec";
    i.CLIP_OK = "clip_ok";
    i.CLIP_WEBSITE = "clip_website";
    i.CLIP_SEED_RESULT = "clip_seed_result";
    i.INTERVAL_TOO_SHORT = "interval_too_short";
    i.OVER = "OVER";
    i.UNDER = "UNDER";
    i.HEAD = "HEAD";
    i.TAIL = "TAIL";
    i.NUMBER = "NUMBER";
    i.SPLIT = "SPLIT";
    i.CORNER = "CORNER";
    i.COLOR = "COLOR";
    i.EVEN = "EVEN";
    i.ODD = "ODD";
    i.RED = "RED";
    i.BLACK = "BLACK";
    i.HOT = "HOT";
    i.PINS = "PINS";
    class n {
        constructor() {}
        static initMsg() {
            var e = null;
            e = new Object;
            e["zh-cn"] = "游戏编号";
            e["zh-tw"] = "游戏编号";
            e["en"] = "GAME ID";
            e["vi"] = "ID trò chơi";
            e["th"] = "เกมอัตโนมัติ";
            e["hi"] = "खेल आईडी";
            e["pr"] = "ID do jogo";
            e["ms"] = "Permainan automatik";
            e["id"] = "Game otomatis";
            n.MsgTextDic["clip_rbd"] = e;
            e = new Object;
            e["zh-cn"] = "种子明文";
            e["zh-tw"] = "種子明文";
            e["en"] = "Original Seed";
            e["vi"] = "Bản rõ hạt giống";
            e["hi"] = "मूल सीड";
            e["pr"] = "Semente Original";
            e["th"] = "Original Seed";
            e["ms"] = "Biji benih asal";
            e["id"] = "Biji benih asli";
            n.MsgTextDic["clip_seed"] = e;
            e = new Object;
            e["zh-cn"] = "结果";
            e["zh-tw"] = "結果";
            e["en"] = "Result";
            e["vi"] = "Kết quả";
            e["th"] = "ผลลัพธ์";
            e["hi"] = "खेल परिणाम";
            e["pr"] = "Resultado do jogo";
            e["ms"] = "Hasil permainan";
            e["id"] = "Hasil game";
            n.MsgTextDic["clip_result"] = e;
            e = new Object;
            e["zh-cn"] = "种子密文";
            e["zh-tw"] = "種子密文";
            e["en"] = "Encrypted Seed";
            e["vi"] = "Bản mã gốc";
            e["th"] = "Seed ที่เข้ารหัส";
            e["hi"] = "एन्क्रिप्टेड सीड";
            e["pr"] = "Semente criptografada";
            e["ms"] = "Biji benih enkripsi";
            e["id"] = "Biji benih enkripsi";
            n.MsgTextDic["clip_seed_sec"] = e;
            e = new Object;
            e["zh-cn"] = "结果密文";
            e["zh-tw"] = "結果密文";
            e["en"] = "Encrypted Result";
            e["vi"] = "Bản mã kết quả";
            e["th"] = "ผลลัพธ์ที่เข้ารหัส";
            e["hi"] = "एन्क्रिप्टेड परिणाम";
            e["pr"] = "Resultado criptografado";
            e["ms"] = "Hasil enkripsi";
            e["id"] = "Hasil enkripsi";
            n.MsgTextDic["clip_result_sec"] = e;
            e = new Object;
            e["zh-cn"] = "数据已复制，请粘贴到文本中进行查看";
            e["zh-tw"] = "數據已複製，請招貼到文本中進行查看";
            e["en"] = "The data has been copied, please paste it into text to view";
            e["vi"] = "Dữ liệu đã được sao chép, vui lòng dán vào văn bản để xem";
            e["th"] = "คัดลอกข้อมูลแล้ว โปรดวางลงในข้อความเพื่อดู";
            e["hi"] = "डेटा कॉपी कर लिया गया है, कृपया देखने के लिए टेक्स्ट में पेस्ट करें";
            e["pr"] = "Os dados foram copiados, cole no texto para visualizar";
            e["ms"] = "Data telah disalin, sila tampal ke dalam teks untuk dilihat";
            e["id"] = "Data telah disalin, silakan tempel ke teks untuk melihatnya";
            n.MsgTextDic["clip_ok"] = e;
            e = new Object;
            e["zh-cn"] = "网址已复制，请粘贴到浏览器中进行查看";
            e["zh-tw"] = "網址已複製，請招貼到瀏覽器中進行查看";
            e["en"] = "The website  has been copied, please paste it into browser to view";
            e["vi"] = "URL đã được sao chép, vui lòng dán vào trình duyệt để xem";
            e["th"] = "คัดลอก URL แล้ว โปรดวางลงในเบราว์เซอร์เพื่อดู";
            e["hi"] = "यूआरएल कॉपी कर लिया गया है, कृपया इसे देखने के लिए इसे ब्राउज़र में पेस्ट करें";
            e["pr"] = "O URL foi copiado, cole-o no navegador para visualizá-lo";
            e["ms"] = "URL telah disalin, sila tampalkannya ke dalam penyemak imbas untuk melihatnya";
            e["id"] = "URL telah disalin, silakan tempel ke browser untuk melihatnya";
            n.MsgTextDic["clip_website"] = e;
            e = new Object;
            e["zh-cn"] = "种子加结果";
            e["zh-tw"] = "種子加結果";
            e["en"] = "Original Seed plus game result";
            e["pr"] = "Resultado original do jogo Seed plus";
            e["vi"] = "Nguồn khởi đầu cộng với kết quả trò chơi";
            e["th"] = "ผลลัพธ์เกม Original Seed plus";
            e["ms"] = "Biji benih asal tambah hasil permainan";
            e["id"] = "Biji benih asli tambah hasil game";
            e["hi"] = "मूल सीड प्लस खेल परिणाम";
            n.MsgTextDic["clip_seed_result"] = e;
            e = new Object;
            e["zh-cn"] = "大于";
            e["zh-tw"] = "大于";
            e["en"] = "Over";
            e["pr"] = "Mais do que o";
            e["vi"] = "Trên";
            e["th"] = "มากกว่า";
            e["hi"] = "ऊपर";
            e["ms"] = "Lebih daripada";
            e["id"] = "Lebih banyak dari";
            n.MsgTextDic["OVER"] = e;
            e = new Object;
            e["zh-cn"] = "小于";
            e["zh-tw"] = "小于";
            e["en"] = "Under";
            e["pr"] = "Menor que";
            e["vi"] = "Dưới";
            e["th"] = "น้อยกว่า";
            e["hi"] = "नीचे";
            e["ms"] = "Kurang daripada";
            e["id"] = "Kurang dari";
            n.MsgTextDic["UNDER"] = e;
            e = new Object;
            e["zh-cn"] = "正面";
            e["zh-tw"] = "正面";
            e["en"] = "Head";
            e["vi"] = "Đầu";
            e["th"] = "ศีรษะ";
            e["hi"] = "सिर";
            e["pr"] = "Cabeça";
            e["ms"] = "Kepala";
            e["id"] = "Kepala";
            n.MsgTextDic["HEAD"] = e;
            e = new Object;
            e["zh-cn"] = "背面";
            e["zh-tw"] = "背面";
            e["en"] = "Tail";
            e["vi"] = "Cái đuôi";
            e["th"] = "หาง";
            e["hi"] = "पूंछ";
            e["pr"] = "Cauda";
            e["ms"] = "Ekor";
            e["id"] = "Ekor";
            n.MsgTextDic["TAIL"] = e;
            e = new Object;
            e["zh-cn"] = "号码";
            e["zh-tw"] = "号码";
            e["en"] = "Number";
            e["vi"] = "Số";
            e["th"] = "ตัวเลข";
            e["hi"] = "संख्या";
            e["pr"] = "Número";
            e["ms"] = "Nombor";
            e["id"] = "Nomor";
            n.MsgTextDic["NUMBER"] = e;
            e = new Object;
            e["zh-cn"] = "分注";
            e["zh-tw"] = "分注";
            e["en"] = "Split";
            e["vi"] = "Ghi chú";
            e["th"] = "บันทึก";
            e["hi"] = "टिप्पणी";
            e["pr"] = "Observação";
            e["ms"] = "Nota";
            e["id"] = "Catatan";
            n.MsgTextDic["SPLIT"] = e;
            e = new Object;
            e["zh-cn"] = "角注";
            e["zh-tw"] = "角注";
            e["en"] = "Corner";
            e["vi"] = "Ghi chú góc";
            e["th"] = "หมายเหตุมุม";
            e["hi"] = "कोने का नोट";
            e["pr"] = "Nota de canto";
            e["ms"] = "Nota sudut";
            e["id"] = "Catatan sudut";
            n.MsgTextDic["CORNER"] = e;
            e = new Object;
            e["zh-cn"] = "颜色";
            e["zh-tw"] = "颜色";
            e["en"] = "Color";
            e["vi"] = "Màu sắc";
            e["th"] = "สี";
            e["hi"] = "रंग";
            e["pr"] = "Cor";
            e["ms"] = "Warna";
            e["id"] = "Warna";
            n.MsgTextDic["COLOR"] = e;
            e = new Object;
            e["zh-cn"] = "双";
            e["zh-tw"] = "双";
            e["en"] = "Even";
            e["vi"] = "Số chẵn";
            e["th"] = "เลขคู่";
            e["hi"] = "सम संख्या";
            e["pr"] = "Números par";
            e["ms"] = "Nombor genap";
            e["id"] = "Angka genap";
            n.MsgTextDic["EVEN"] = e;
            e = new Object;
            e["zh-cn"] = "单";
            e["zh-tw"] = "单";
            e["en"] = "Odd";
            e["vi"] = "Số lẻ";
            e["th"] = "เลขคี่";
            e["hi"] = "विषम संख्य";
            e["pr"] = "Número ímpar";
            e["ms"] = "Nombor ganjil";
            e["id"] = "Angka ganjil";
            n.MsgTextDic["ODD"] = e;
            e = new Object;
            e["zh-cn"] = "红色";
            e["zh-tw"] = "红色";
            e["en"] = "Red";
            e["vi"] = "Màu đỏ";
            e["th"] = "สีแดง";
            e["hi"] = "लाल";
            e["pr"] = "Vermelho";
            e["ms"] = "Merah";
            e["id"] = "Merah";
            n.MsgTextDic["RED"] = e;
            e = new Object;
            e["zh-cn"] = "黑色";
            e["zh-tw"] = "黑色";
            e["en"] = "Black";
            e["vi"] = "Đen";
            e["th"] = "สีดำ";
            e["hi"] = "काला";
            e["pr"] = "Preto";
            e["ms"] = "Hitam";
            e["id"] = "Hitam";
            n.MsgTextDic["BLACK"] = e;
            e = new Object;
            e["zh-cn"] = "热";
            e["zh-tw"] = "热";
            e["en"] = "Hot";
            e["vi"] = "Nóng";
            e["th"] = "ร้อน";
            e["hi"] = "गरम";
            e["pr"] = "Calor";
            e["ms"] = "Panas";
            e["id"] = "Panas";
            n.MsgTextDic["HOT"] = e;
            e = new Object;
            e["zh-cn"] = "Pins";
            e["zh-tw"] = "Pins";
            e["en"] = "Pins";
            e["vi"] = "Ghim";
            e["th"] = "หมุด";
            e["hi"] = "पिंस";
            e["pr"] = "Pinos";
            e["ms"] = "Pin";
            e["id"] = "Pin";
            n.MsgTextDic["PINS"] = e
        }
    }
    Common.Config.Msg.MsgTextMaster = b.MsgTextMaster = n;
    b.static(n, ["MsgTextDic", function() {
        return this.MsgTextDic = new Object
    }]);
    Common.Config.Res = {};
    class xe {
        constructor() {}
    }
    Common.Config.Res.GameResConfig = b.GameResConfig = xe;
    xe.RES_3D = [];
    xe.RES_3D_LMAT = [];
    b.static(xe, ["RES_2D", function() {
        return this.RES_2D = ["res/atlas/Common/comp.atlas", "res/atlas/Common/loading.atlas"]
    }, "RES_UI", function() {
        return this.RES_UI = ["GameUI/Common/Dialog/MessageBox.json", "GameUI/Common/Dialog/MessageYesNoBox.json", "GameUI/Common/Scenes/GameLoading.json", "GameUI/Common/View/GameLoadingBar.json"]
    }]);
    Common.Config.Tcp = {};
    class s {
        constructor() {}
    }
    Common.Config.Tcp.CMDEvent = b.CMDEvent = s;
    s.CMD_PING = 1;
    s.CMD_LOGIN = 2;
    s.CMD_GET_SYSTEM_CONFIG = 3;
    s.CMD_GET_USER_BALANCE = 4;
    s.CMD_GET_MY_GAME_INFO = 5;
    s.CMD_GET_MY_CUSTOM_ROOM_INFO = 6;
    s.CMD_START_RANDOM_GAME_GROUP = 7;
    s.CMD_STOP_RANDOM_GAME_GROUP = 8;
    s.CMD_CREATE_GAME_ROOM = 9;
    s.CMD_GET_INTO_GAME_ROOM = 10;
    s.CMD_LEAVE_GAME_ROOM = 11;
    s.CMD_SEND_TRUSTEESHIP = 12;
    s.CMD_GAME_SEND_EXP = 13;
    s.CMD_GAME_SEND_CHAT_WORD = 14;
    s.CMD_WANT_TO_SIT_IN_DESK = 15;
    s.CMD_OWNER_DELETE_ROOM = 16;
    s.CMD_OWNER_KICK_PLAYER_OUT = 17;
    s.CMD_WANT_TO_START_GAME = 18;
    s.CMD_GET_READY_FOR_GAME = 19;
    s.CMD_SEND_GAME_OPERATION = 20;
    s.CMD_GET_PLAYER_COUNT_IN_GAME_ID = 21;
    s.CMD_GET_PLAYER_INFO_IN_DESK = 22;
    s.CMD_SEND_GAME_REPORT = 23;
    s.CMD_CHANGE_USER_PORTRAIT = 24;
    s.CMD_GET_ROOM_CONNECTION_INFO = 25;
    s.CMD_GET_MUL_GAME_SYSTEM_CONFIG = 26;
    s.CMD_GET_MUL_GAME_SERVER_INFO = 27;
    s.CMD_GET_INTO_MUL_GAME_ROOM = 28;
    s.CMD_LEAVE_MUL_GAME_ROOM = 29;
    s.CMD_WANT_TO_BE_BANKER = 30;
    s.CMD_WANT_TO_CANCLE_BANKER = 31;
    s.CMD_SEND_MUL_GAME_OPERATION = 32;
    s.CMD_GET_GAMEHALL_STATUS = 33;
    s.CMD_LOGIN_GAME_HALL = 34;
    s.CMD_GET_GAMEHALL_CONFIG = 35;
    s.CMD_COLLECT_GAME = 36;
    s.CMD_USER_SEND_ADVICE = 37;
    s.CMD_PUSH_GAME_SERVER_RESTART = 50;
    s.CMD_PUSH_USER_BALANCE = 51;
    s.CMD_PUSH_GAME_GROUP_FINISH = 52;
    s.CMD_PUSH_GAME_GROUP_CANCLE = 53;
    s.CMD_PUSH_CUSTOM_ROOM_CREATED = 54;
    s.CMD_PUSH_NEW_MARQUEE_MSG = 55;
    s.CMD_PUSH_PLAYER_GET_INTO_ROOM = 56;
    s.CMD_PUSH_PLAYER_LEAVE_ROOM = 57;
    s.CMD_PUSH_PLAYER_KICK_FROM_ROOM = 58;
    s.CMD_PUSH_GET_READY_FOR_GAME = 59;
    s.CMD_PUSH_KICK_OFF_USER = 60;
    s.CMD_PUSH_GAME_USER_ONLINE = 61;
    s.CMD_PUSH_GAME_DISSOLVE_OVER = 62;
    s.CMD_PUSH_GAME_ROOM_OVER = 63;
    s.CMD_PUSH_GAME_ROOM_STATUS = 64;
    s.CMD_PUSH_CREATE_ROOM_END = 65;
    s.CMD_PUSH_TRUSTEESHIP_STATUS = 66;
    s.CMD_PUSH_GAME_PLAYER_EXP = 67;
    s.CMD_PUSH_GAME_PLAYER_CHAT_WORD = 68;
    s.CMD_PUSH_SERVER_MAINTENANCE = 69;
    s.CMD_PUSH_MUL_GAME_RESULT = 70;
    s.CMD_PUSH_MUL_GAME_PLAYER_RESULT = 71;
    s.CMD_PUSH_BANKER_RESULT = 72;
    s.CMD_PUSH_GAME_STATUS_CHANGE = 73;
    s.CMD_PUSH_GAME_BET_DATA = 74;
    s.CMD_PUSH_PLAYER_COUNT_CHANGE = 75;
    s.CMD_PUSH_ADD_TO_BANKER_QUEUE = 76;
    s.CMD_PUSH_QUIT_BANKER_QUEUE = 77;
    s.CMD_PUSH_BONUS_ANNOUNCEMENT = 78;
    s.CMD_PUSH_GAME_EXP = 79;
    s.CMD_PUSH_CANCEL_BET = 80;
    s.CMD_GET_INTO_MFG_ROOM = 81;
    s.CMD_LEAVE_MFG_ROOM = 82;
    s.CMD_SEND_MFG_OPERATION = 83;
    s.CMD_PUSH_MFG_STATUS_CHANGE = 84;
    s.CMD_PUSH_MFG_MUL_CHANGE = 85;
    s.CMD_PUSH_MFG_USER_BET = 86;
    s.CMD_PUSH_MFG_USER_CANCLE_BET = 87;
    s.CMD_PUSH_MFG_PLAYER_CASH_OUT = 88;
    s.CMD_MFG_PLAYER_CHANGE_PID = 89;
    s.CMD_GET_MFG_RESULT_DETAIL = 90;
    s.CMD_DO_FAIR_SIMPLE_INIT_GAME = 91;
    s.CMD_DO_FAIR_SIMPLE_START_GAME = 92;
    s.CMD_DO_FAIR_SIMPLE_GAME_OPE = 93;
    s.CMD_PUSH_MJ_GAME_START = 101;
    s.CMD_PUSH_MJ_GAME_OPERATION = 102;
    s.CMD_PUSH_MJ_WAIT_OPERATION = 103;
    s.CMD_PUSH_MJ_QI_SHOU_HU = 104;
    s.CMD_PUSH_MJ_GEN_PAI = 105;
    s.CMD_PUSH_MJ_OPEN_LAIZI = 106;
    s.CMD_PUSH_MJ_SEA_BED_MODE = 107;
    s.CMD_PUSH_MJ_GAME_HU = 108;
    s.CMD_PUSH_MJ_START_GAME_TICK = 109;
    s.CMD_PUSH_MJ_SEE_BED_FEN_ZHANG = 110;
    s.CMD_PUSH_MJ_GAME_RESULT = 120;
    s.CMD_PUSH_NN_GAME_START = 201;
    s.CMD_PUSH_NN_FA_PAI = 202;
    s.CMD_PUSH_NN_BANKER_CHANGE = 203;
    s.CMD_PUSH_NN_WAIT_OPERATION = 204;
    s.CMD_PUSH_NN_GAME_OPERATION = 205;
    s.CMD_PUSH_NN_GAME_RESULT = 220;
    s.CMD_PUSH_TW_GAME_START = 301;
    s.CMD_PUSH_TW_FA_PAI = 302;
    s.CMD_PUSH_TW_BANKER_CHANGE = 303;
    s.CMD_PUSH_TW_WAIT_OPERATION = 304;
    s.CMD_PUSH_TW_GAME_OPERATION = 305;
    s.CMD_PUSH_TW_GAME_RESULT = 320;
    s.CMD_PUSH_ZJH_GAME_START = 401;
    s.CMD_PUSH_ZJH_WAIT_OPERATION = 402;
    s.CMD_PUSH_ZJH_GAME_OPERATION = 403;
    s.CMD_PUSH_ZJH_GAME_RESULT = 420;
    s.CMD_PUSH_SG_GAME_START = 501;
    s.CMD_PUSH_SG_FA_PAI = 502;
    s.CMD_PUSH_SG_BANKER_CHANGE = 503;
    s.CMD_PUSH_SG_WAIT_OPERATION = 504;
    s.CMD_PUSH_SG_GAME_OPERATION = 505;
    s.CMD_PUSH_SG_GAME_RESULT = 520;
    s.CMD_PUSH_BJ_GAME_START = 601;
    s.CMD_PUSH_BJ_FA_PAI = 602;
    s.CMD_PUSH_BJ_WAIT_OPERATION = 603;
    s.CMD_PUSH_BJ_GAME_OPERATION = 604;
    s.CMD_PUSH_BJ_GAME_RESULT = 620;
    class h {
        constructor() {}
    }
    Common.Config.Tcp.CustomErrorMaster = b.CustomErrorMaster = h;
    h.ERROR_TCP_TIME_OUT = 1e5;
    h.ERROR_REPLAY_PARAMETER_WRONG = 100001;
    h.ERROR_GET_REPLAY_DATA = 100002;
    h.ERROR_TOKEN_IS_EMPTY = 100003;
    h.ERROR_TCP_GATE_WAY_IS_EMPTY = 100004;
    h.ERROR_GET_TCP_GATE_WAY_ADDRESS = 100005;
    h.ERROR_GET_GATE_WAY_ADDRESS = 100006;
    h.ERROR_CONNECT_TCP_GATE_WAY = 100007;
    h.ERROR_TCP_GATE_WAY_CLOSED = 100008;
    h.ERROR_VERSION_FILE_WRONG = 100009;
    h.ERROR_APP_START_PARAMETER_WRONG = 100010;
    h.ERROR_FORCE_KICK_FROM_APP = 100011;
    h.ERROR_SERVER_MAINTENANCE = 100012;
    h.ERROR_NEW_VERSION_FOUND = 100013;
    h.ERROR_FOUND_OTHER_GAMING_APP = 100014;
    h.ERROR_REPLAY_APPID_MISSMATCH = 100015;
    h.ERROR_PID_IS_EMPTY = 100016;
    h.ERROR_MUL_CONFIG_ERROR = 100017;
    h.ERROR_KICK_ROOM_BY_NO_MONEY = 100100;
    h.ERROR_KICK_ROOM_BY_NO_ONLINE = 100101;
    h.ERROR_KICK_ROOM_BY_OWNER = 100102;
    h.ERROR_KICK_ROOM_BY_OTHER = 100103;
    class _ {
        constructor() {}
        static initError() {
            var e = null;
            e = new Object;
            e["zh-cn"] = "网络连接超时";
            e["zh-tw"] = "网络连接超时";
            e["en"] = "Network connection timed out";
            e["pr"] = "Conexão de rede expirou";
            e["vi"] = "Quá thời gian kết nối mạng";
            e["hi"] = "नेटवर्क कनेक्शन का समय समाप्त हो गया";
            e["es"] = "Se ha agotado el tiempo de conexión de red";
            e["th"] = "การเชื่อมต่อเครือข่ายหมดเวลา";
            e["tl"] = "Nag-time out ang koneksyon sa network";
            e["my"] = "ကွန်ရက်ချိတ်ဆက်မှု အချိန်ကုန်သွားသည်။";
            e["ms"] = "Had masa sambungan internet ";
            e["id"] = "Waktu koneksi jaringan habis";
            _.ErrorTextDic[1e5] = e;
            e = new Object;
            e["zh-cn"] = "游戏回放参数错误";
            e["zh-tw"] = "游戏回放参数错误";
            e["en"] = "Game playback parameter error";
            e["pr"] = "Erro de parâmetro de reprodução do jogo";
            e["vi"] = "Lỗi tham số phát lại trò chơi";
            e["hi"] = "नेटवर्क कनेक्शन समय समाप्त हो गया";
            e["es"] = "Error en el parámetro de reproducción del juego";
            e["th"] = "ข้อผิดพลาดของพารามิเตอร์การเล่นซ้ำเกม";
            e["tl"] = "Error sa parameter ng pag-playback ng laro";
            e["my"] = "ဂိမ်းပြန်ဖွင့်ခြင်း ကန့်သတ်ချက် အမှား";
            e["ms"] = "Parameter main semula salah";
            e["id"] = "Kesalahan parameter pemutaran game";
            _.ErrorTextDic[100001] = e;
            e = new Object;
            e["zh-cn"] = "游戏回放数据加载失败";
            e["zh-tw"] = "游戏回放数据加载失败";
            e["en"] = "Failed to load game playback data";
            e["pr"] = "Falha ao carregar os dados de reprodução do jogo";
            e["vi"] = "Không thể tải dữ liệu phát lại trò chơi";
            e["hi"] = "गेम प्लेबैक पैरामीटर त्रुटि";
            e["es"] = "Error al cargar los datos de reproducción del juego";
            e["th"] = "การโหลดข้อมูลการเล่นซ้ำเกมล้มเหลว";
            e["tl"] = "Nabigong i-load ang data ng pag-playback ng laro";
            e["my"] = "ဂိမ်းပြန်ဖွင့်ခြင်းဒေတာကို တင်ရန် မအောင်မြင်ပါ။";
            e["ms"] = "Kegagalan memuatkan data main semula permainan";
            e["id"] = "Pemuatan data replay game gagal";
            _.ErrorTextDic[100002] = e;
            e = new Object;
            e["zh-cn"] = "token不能为空";
            e["zh-tw"] = "token不能为空";
            e["en"] = "Token cannot be empty";
            e["pr"] = "O token não pode estar vazio";
            e["vi"] = "Token không thể để trống";
            e["hi"] = "गेम प्लेबैक डेटा लोड करने में विफल";
            e["es"] = "El token no puede estar vacío";
            e["th"] = "โทเค็นไม่สามารถเว้นว่างได้";
            e["tl"] = "Hindi maaaring walang laman ang token";
            e["my"] = "တိုကင်ကို ဗလာမဖြစ်နိုင်ပါ။";
            e["ms"] = "Token tidak boleh kosong";
            e["id"] = "token tidak boleh kosong";
            _.ErrorTextDic[100003] = e;
            e = new Object;
            e["zh-cn"] = "服务器连接地址错误";
            e["zh-tw"] = "服务器连接地址错误";
            e["en"] = "Server connection address error";
            e["pr"] = "Erro no endereço de conexão do servidor";
            e["vi"] = "Lỗi địa chỉ kết nối máy chủ";
            e["hi"] = "टोकन खाली नहीं हो सकता";
            e["es"] = "Error de dirección de conexión del servidor";
            e["th"] = "ข้อผิดพลาดที่อยู่การเชื่อมต่อเซิร์ฟเวอร์";
            e["tl"] = "Error sa address ng koneksyon sa server";
            e["my"] = "ဆာဗာချိတ်ဆက်မှုလိပ်စာ မှားနေပါသည်။";
            e["ms"] = "Alamat sambungan Server salah";
            e["id"] = "Kesalahan alamat koneksi server";
            _.ErrorTextDic[100004] = e;
            e = new Object;
            e["zh-cn"] = "服务器连接地址加载失败";
            e["zh-tw"] = "服务器连接地址加载失败";
            e["en"] = "Server connection URL failed to load";
            e["pr"] = "Falha ao carregar a URL de conexão do servidor";
            e["vi"] = "URL kết nối máy chủ không tải được";
            e["hi"] = "सर्वर कनेक्शन पता त्रुटि";
            e["es"] = "La URL de conexión del servidor no se pudo cargar";
            e["th"] = "ที่อยู่การเชื่อมต่อเซิร์ฟเวอร์ไม่สามารถโหลดได้";
            e["tl"] = "Nabigong mag-load ang URL ng koneksyon ng server";
            e["my"] = "ဆာဗာချိတ်ဆက်မှုလိပ်စာကို တင်၍မရပါ။";
            e["ms"] = "Kegagalan memuatkan URL sambungan Server";
            e["id"] = "Alamat koneksi server gagal dimuat";
            _.ErrorTextDic[100005] = e;
            e = new Object;
            e["zh-cn"] = "服务器连接地址加载失败";
            e["zh-tw"] = "服务器连接地址加载失败";
            e["en"] = "Server connection URL failed to load";
            e["pr"] = "Falha ao carregar a URL de conexão do servidor";
            e["vi"] = "URL kết nối máy chủ không tải được";
            e["hi"] = "सर्वर कनेक्शन URL लोड करने में विफल";
            e["es"] = "La URL de conexión del servidor no se pudo cargar";
            e["th"] = "ที่อยู่การเชื่อมต่อเซิร์ฟเวอร์ไม่สามารถโหลดได้";
            e["tl"] = "Nabigong mag-load ang URL ng koneksyon ng server";
            e["my"] = "ဆာဗာချိတ်ဆက်မှုလိပ်စာကို တင်၍မရပါ။";
            e["ms"] = "Kegagalan memuatkan URL sambungan Server";
            e["id"] = "Alamat koneksi server gagal dimuat";
            _.ErrorTextDic[100006] = e;
            e = new Object;
            e["zh-cn"] = "服务器连接失败";
            e["zh-tw"] = "服务器连接失败";
            e["en"] = "Server connection failed";
            e["pr"] = "Falha na conexão do servidor";
            e["vi"] = "Kết nối máy chủ không thành công";
            e["hi"] = "सर्वर कनेक्शन विफल";
            e["es"] = "Error de conexión del servidor.";
            e["th"] = "การเชื่อมต่อเซิร์ฟเวอร์ล้มเหลว";
            e["tl"] = "Nabigo ang koneksyon sa server";
            e["my"] = "ဆာဗာချိတ်ဆက်မှု မအောင်မြင်ပါ။";
            e["ms"] = "Kegagalan menyambung Server";
            e["id"] = "Koneksi server gagal";
            _.ErrorTextDic[100007] = e;
            e = new Object;
            e["zh-cn"] = "服务器连接已经断开";
            e["zh-tw"] = "服务器连接已经断开";
            e["en"] = "The server connection has been disconnected";
            e["pr"] = "A conexão com o servidor foi desligada";
            e["vi"] = "Đã ngắt kết nối máy chủ";
            e["hi"] = "सर्वर कनेक्शन डिस्कनेक्ट हो गया है";
            e["es"] = "Se ha desconectado la conexión del servidor";
            e["th"] = "การเชื่อมต่อเซิร์ฟเวอร์ถูกตัดการเชื่อมต่อ";
            e["tl"] = "Ang koneksyon sa server ay nadiskonekta";
            e["my"] = "ဆာဗာချိတ်ဆက်မှု ပြတ်တောက်သွားပါပြီ။";
            e["ms"] = "Sambungan server telah diputus";
            e["id"] = "Koneksi server telah terputus";
            _.ErrorTextDic[100008] = e;
            e = new Object;
            e["zh-cn"] = "游戏版本配置数据错误";
            e["zh-tw"] = "游戏版本配置数据错误";
            e["en"] = "Game version configuration data error";
            e["pr"] = "Erro nos dados de configuração da versão do jogo";
            e["vi"] = "Lỗi dữ liệu cấu hình phiên bản trò chơi";
            e["hi"] = "गेम संस्करण कॉन्फ़िगरेशन डेटा त्रुटि";
            e["es"] = "Error de datos de configuración de la versión del juego";
            e["th"] = "ข้อผิดพลาดข้อมูลการกำหนดค่าเวอร์ชันเกม";
            e["tl"] = "Error sa data ng configuration ng bersyon ng laro";
            e["my"] = "ဂိမ်းဗားရှင်းဖွဲ့စည်းပုံဒေတာအမှား";
            e["ms"] = "Data konfigurasi versi permainan salah";
            e["id"] = "Kesalahan data konfigurasi versi game";
            _.ErrorTextDic[100009] = e;
            e = new Object;
            e["zh-cn"] = "游戏启动参数配置错误";
            e["zh-tw"] = "游戏启动参数配置错误";
            e["en"] = "Game startup parameter configuration error";
            e["pr"] = "Erro na configuração dos parâmetros de inicialização do jogo";
            e["vi"] = "Lỗi cấu hình tham số khởi động trò chơi";
            e["hi"] = "गेम स्टार्टअप पैरामीटर कॉन्फ़िगरेशन त्रुटि";
            e["es"] = "Error de configuración de parámetro de inicio de juego";
            e["th"] = "ข้อผิดพลาดในการกำหนดค่าพารามิเตอร์การเริ่มต้นเกม";
            e["tl"] = "Error sa configuration ng parameter ng startup ng laro";
            e["my"] = "ဂိမ်းစတင်ခြင်းဆိုင်ရာ ကန့်သတ်ချက်များကို မှားယွင်းစွာ ပြင်ဆင်သတ်မှတ်ထားသည်။";
            e["ms"] = "Konfigurasi parameter startup permainan salah";
            e["id"] = "Kesalahan konfigurasi parameter startup game";
            _.ErrorTextDic[100010] = e;
            e = new Object;
            e["zh-cn"] = "您已经被强制踢出游戏";
            e["zh-tw"] = "您已经被强制踢出游戏";
            e["en"] = "You have been forcibly kicked out of the game";
            e["pr"] = "Você foi expulso do jogo por força";
            e["vi"] = "Bạn đã bị buộc phải rời khỏi trò chơi";
            e["hi"] = "आपको खेल से जबरन निकाल दिया गया है";
            e["es"] = "Ha sido expulsado por la fuerza del juego";
            e["th"] = "คุณถูกบังคับให้ออกจากเกม";
            e["tl"] = "Sapilitan kang pinaalis sa laro";
            e["my"] = "မင်းကို ဂိမ်းထဲက ထုတ်ခိုင်းလိုက်ပြီ။";
            e["ms"] = "Anda telah dikeluarkan dari permainan";
            e["id"] = "Anda telah dikeluarkan dari permainan";
            _.ErrorTextDic[100011] = e;
            e = new Object;
            e["zh-cn"] = "服务器已停服维护请您等待服务器维护结束后重新登录游戏";
            e["zh-tw"] = "服务器已停服维护请您等待服务器维护结束后重新登录游戏";
            e["en"] = "The server has been shut down for maintenance, please wait for the server maintenance to complete and log in to the game again";
            e["pr"] = "O servidor foi desligado para manutenção, por favor aguarde a manutenção do servidor para ser concluída e faça login no jogo novamente";
            e["vi"] = "Máy chủ tạm dừng để bảo trì, vui lòng đợi máy chủ bảo trì kết thúc và đăng nhập lại vào game";
            e["hi"] = "सर्वर रखरखाव के लिए बंद किया गया है, कृपया सर्वर रखरखाव पूरा होने का इंतजार करें और फिर से खेल में लॉग इन करें";
            e["es"] = "El servidor se ha cerrado por mantenimiento, por favor, espere a que el mantenimiento del servidor se complete e inicie sesión en el juego de nuevo";
            e["th"] = "เซิร์ฟเวอร์ถูกหยุดเพื่อการบำรุงรักษา โปรดรอจนกว่าการบำรุงรักษาเซิร์ฟเวอร์จะเสร็จสิ้นและเข้าสู่ระบบเกมอีกครั้ง";
            e["tl"] = "Ang server ay isinara para sa pagpapanatili, mangyaring maghintay para sa pagpapanatili ng server upang makumpleto at mag-log in muli sa laro";
            e["my"] = "ပြုပြင်ထိန်းသိမ်းမှုအတွက် ဆာဗာကို ရပ်တန့်ထားပြီး၊ ကျေးဇူးပြု၍ ဆာဗာပြုပြင်ထိန်းသိမ်းမှု ပြီးဆုံးရန် စောင့်ပြီး ဂိမ်းသို့ ထပ်မံဝင်ရောက်ပါ။";
            e["ms"] = "Server telah menghentikan pemeliharaan, tunggu sehingga pemeliharaan tamat untuk melog masuk permainan lagi";
            e["id"] = "Server telah dihentikan karena pemeliharaan. Harap tunggu hingga pemeliharaan server selesai dan login kembali ke dalam game.";
            _.ErrorTextDic[100012] = e;
            e = new Object;
            e["zh-cn"] = "发现新版本，请点击确定按钮开始游戏更新";
            e["zh-tw"] = "发现新版本，请点击确定按钮开始游戏更新";
            e["en"] = "A new version is found, please click the OK button to start the game update";
            e["pr"] = "Uma nova versão foi encontrada, por favor clique no botão OK para iniciar a atualização do jogo";
            e["vi"] = "Đã có phiên bản mới, vui lòng bấm vào nút OK để bắt đầu cập nhật trò chơi";
            e["hi"] = "नया संस्करण मिला है, कृपया OK बटन दबाकर गेम अपडेट शुरू करें";
            e["es"] = "Se encuentra una nueva versión, haga clic en el botón OK para iniciar la actualización del juego";
            e["th"] = "พบเวอร์ชันใหม่แล้ว โปรดคลิกปุ่มตกลงเพื่อเริ่มการอัปเดตเกม";
            e["tl"] = "May nakitang bagong bersyon, paki-click ang OK na buton para simulan ang pag-update ng laro";
            e["my"] = "ဗားရှင်းအသစ်ကို သင်တွေ့ရှိပါက၊ ဂိမ်းအပ်ဒိတ်စတင်ရန် OK ခလုတ်ကို နှိပ်ပါ။";
            e["ms"] = "Versi baru ditemui, klik butang pasti untuk memulakan kemas kini permainan";
            e["id"] = "Versi baru ditemukan, silakan klik tombol OK untuk memulai pembaruan game";
            _.ErrorTextDic[100013] = e;
            e = new Object;
            e["zh-cn"] = "您当前有其他未完成的游戏，请完成游戏后加入新的游戏";
            e["zh-tw"] = "您当前有其他未完成的游戏，请完成游戏后加入新的游戏";
            e["en"] = "You currently have other unfinished games, please complete the game and join a new game";
            e["pr"] = "Você atualmente tem outros jogos não finalizados, por favor complete o jogo e participe de um novo jogo";
            e["vi"] = "Bạn hiện đang có các trò chơi khác chưa hoàn thành, vui lòng hoàn thành trò chơi để tham gia trò chơi mới";
            e["hi"] = "आपके वर्तमान में अन्य अधूरे खेल हैं, कृपया खेल पूरा करें और नए खेल में शामिल हों";
            e["es"] = "Actualmente tiene otros juegos sin terminar, complete el juego y únase a un nuevo juego";
            e["th"] = "ขณะนี้คุณมีเกมอื่นๆ ที่ยังสร้างไม่เสร็จ กรุณาจบเกมและเข้าร่วมเกมใหม่";
            e["tl"] = "Kasalukuyan kang may iba pang hindi natapos na laro, mangyaring kumpletuhin ang laro at sumali sa isang bagong laro";
            e["my"] = "သင့်တွင် လက်ရှိတွင် အခြားမပြီးဆုံးသေးသောဂိမ်းများရှိသည်၊ ကျေးဇူးပြု၍ ဂိမ်းပြီးပါက ဂိမ်းအသစ်တစ်ခုထည့်ပါ။";
            e["ms"] = "Kini anda ada permainan lain yang belum selesai, sertai permainan baru selepas menyelesaikan permainan ini";
            e["id"] = "Saat ini Anda memiliki permainan lain yang belum selesai. Silakan selesaikan permainan tersebut dan bergabunglah dengan permainan baru.";
            _.ErrorTextDic[100014] = e;
            e = new Object;
            e["zh-cn"] = "您要回放的游戏数据和当前应用不符";
            e["zh-tw"] = "您要回放的游戏数据和当前应用不符";
            e["en"] = "The game data you want to replay does not match the current application";
            e["pr"] = "Os dados do jogo que você deseja reproduzir não correspondem ao aplicativo atual";
            e["vi"] = "Dữ liệu trò chơi bạn muốn phát lại không khớp với ứng dụng hiện tại";
            e["hi"] = "आप जिस गेम डेटा को पुनरावृत्ति करना चाहते हैं वह वर्तमान अनुप्रयोग से मेल नहीं खाता";
            e["es"] = "Los datos del juego que desea reproducir no coinciden con la aplicación actual";
            e["th"] = "ข้อมูลเกมที่คุณต้องการเล่นซ้ำไม่ตรงกับแอปพลิเคชันปัจจุบัน";
            e["tl"] = "Ang data ng laro na gusto mong i-replay ay hindi tumutugma sa kasalukuyang aplikasyon";
            e["my"] = "သင်ပြန်ဖွင့်လိုသော ဂိမ်းဒေတာသည် လက်ရှိအပလီကေးရှင်းနှင့် မကိုက်ညီပါ။";
            e["ms"] = "Data permainan yang mahu dimainkan semula tidak bercocok dengan aplikasi kini";
            e["id"] = "Data game yang ingin diputar ulang tidak sesuai dengan aplikasi saat ini";
            _.ErrorTextDic[100015] = e;
            e = new Object;
            e["zh-cn"] = "PID不能为空";
            e["zh-tw"] = "PID不能为空";
            e["en"] = "PID cannot be empty";
            e["pr"] = "O PID não pode estar vazio";
            e["vi"] = "PID không được để trống";
            e["hi"] = "PID खाली नहीं हो सकता";
            e["es"] = "El PID no puede estar vacío";
            e["th"] = "PID ต้องไม่เว้นว่าง";
            e["tl"] = "Hindi maaaring walang laman ang PID";
            e["my"] = "PID သည် ဗလာမဖြစ်နိုင်ပါ။";
            e["ms"] = "PID tidak boleh kosong";
            e["id"] = "PID tidak boleh kosong";
            _.ErrorTextDic[100016] = e;
            e = new Object;
            e["zh-cn"] = "配置不正确，请稍后再试！";
            e["zh-tw"] = "配置不正确，请稍后再试！";
            e["en"] = "Configuration is incorrect, please try again later!";
            e["pr"] = "A configuração está incorreta, por favor tente novamente mais tarde!";
            e["vi"] = "Cấu hình không chính xác, vui lòng thử lại sau!";
            e["hi"] = "कॉन्फ़िगरेशन गलत है, कृपया बाद में पुनः प्रयास करें!";
            e["es"] = "¡La configuración es incorrecta, por favor, intente de nuevo más tarde!";
            e["th"] = "การกำหนดค่าไม่ถูกต้อง โปรดลองอีกครั้งในภายหลัง";
            e["tl"] = "Mali ang configuration, pakisubukang muli sa ibang pagkakataon!";
            e["my"] = "ဖွဲ့စည်းမှုပုံစံသည် မှားယွင်းနေသည်၊ ကျေးဇူးပြု၍ နောက်မှ ထပ်ကြိုးစားပါ။";
            e["ms"] = "Konfigurasi salah, sila cuba sebentar lagi!";
            e["id"] = "Konfigurasinya salah, coba lagi nanti!";
            _.ErrorTextDic[100017] = e;
            e = new Object;
            e["zh-cn"] = "您的余额不足，无法继续游戏";
            e["zh-tw"] = "您的余额不足，无法继续游戏";
            e["en"] = "Your balance is insufficient and you cannot continue the game";
            e["pr"] = "Seu saldo é insuficiente e você não pode continuar o jogo";
            e["vi"] = "Số dư của bạn không đủ để tiếp tục trò chơi";
            e["hi"] = "आपका शेष राशि वर्तमान में खेल जारी रखने के लिए अपर्याप्त है";
            e["es"] = "Su saldo es insuficiente y no puede continuar el juego";
            e["th"] = "ยอดคงเหลือของคุณไม่เพียงพอที่จะเล่นเกมต่อ";
            e["tl"] = "Ang iyong balanse ay hindi sapat at hindi mo maaaring ipagpatuloy ang laro";
            e["my"] = "သင့်လက်ကျန်ငွေသည် ဂိမ်းကိုဆက်လက်လုပ်ဆောင်ရန် မလုံလောက်ပါ။";
            e["ms"] = "Baki anda tidak cukup, tidak boleh terus bermain";
            e["id"] = "Saldo Anda tidak cukup untuk melanjutkan permainan";
            _.ErrorTextDic[100100] = e;
            e = new Object;
            e["zh-cn"] = "由于您离线了，所以退出房间";
            e["zh-tw"] = "由于您离线了，所以退出房间";
            e["en"] = "Automatically exited the room because you were offline";
            e["pr"] = "Saiu automaticamente da sala porque estava offline";
            e["vi"] = "Thoát khỏi phòng vì bạn đang ngoại tuyến";
            e["hi"] = "आप ऑफलाइन थे इसलिए आपको स्वतः कमरे से निकाल दिया गया";
            e["es"] = "Salió automáticamente de la sala porque no estaba conectado";
            e["th"] = "ออกจากห้องเพราะคุณออฟไลน์";
            e["tl"] = "Awtomatikong lumabas sa kwarto dahil offline ka";
            e["my"] = "သင်သည် အော့ဖ်လိုင်းဖြစ်နေသောကြောင့် အခန်းမှထွက်ပါ။";
            e["ms"] = "Keluar dari bilik secara automatik kerana anda di luar talian";
            e["id"] = "Keluar dari ruangan karena Anda sedang offline";
            _.ErrorTextDic[100101] = e;
            e = new Object;
            e["zh-cn"] = "您已被房主踢出房间";
            e["zh-tw"] = "您已被房主踢出房间";
            e["en"] = "You have been kicked out of the room by the host";
            e["pr"] = "Você foi expulso da sala pelo anfitrião";
            e["vi"] = "Bạn đã bị chủ phòng đuổi ra khỏi phòng";
            e["hi"] = "आपको कमरे से मेजबान ने निकाल दिया है";
            e["es"] = "Ha sido expulsado de la habitación por el anfitrión";
            e["th"] = "คุณถูกโฮสต์ไล่ออกจากห้อง";
            e["tl"] = "Pinalayas ka ng host sa kwarto para sa paglalaro";
            e["my"] = "ပိုင်ရှင်က မင်းကို အခန်းထဲက ထုတ်ပစ်လိုက်တယ်။";
            e["ms"] = "Anda telah dikeluarkan dari bilik oleh hos";
            e["id"] = "Anda telah diusir dari ruangan oleh tuan rumah";
            _.ErrorTextDic[100102] = e;
            e = new Object;
            e["zh-cn"] = "您已离开房间";
            e["zh-tw"] = "您已离开房间";
            e["en"] = "You have left the room";
            e["pr"] = "Você deixou a sala";
            e["vi"] = "Bạn đã rời khỏi phòng";
            e["hi"] = "आप कमरे से चले गए हैं";
            e["es"] = "Ha salido de la sala";
            e["th"] = "คุณออกจากห้องแล้ว";
            e["tl"] = "Lumabas ka na ng kwarto para sa paglalaro";
            e["my"] = "မင်း အခန်းထဲက ထွက်သွားပြီ။";
            e["ms"] = "Anda telah meninggal di bilik";
            e["id"] = "Anda telah meninggalkan ruangan";
            _.ErrorTextDic[100103] = e
        }
    }
    Common.Config.Tcp.CustomErrorTextMaster = b.CustomErrorTextMaster = _;
    b.static(_, ["ErrorTextDic", function() {
        return this.ErrorTextDic = new Object
    }]);
    class E {
        constructor() {}
    }
    Common.Config.Tcp.ErrorMaster = b.ErrorMaster = E;
    E.ERROR_NOT_DEFINE = 1;
    E.ERROR_TCP_DECODE_FAIL = 2;
    E.ERROR_TCP_DECODE_MD5_FAIL = 3;
    E.ERROR_SERVER_ERROR = 4;
    E.ERROR_NO_AVAILABLE_WORKER = 5;
    E.ERROR_NOT_AVAILABLE_CMD = 6;
    E.ERROR_WRONG_CMD = 7;
    E.ERROR_CREATE_NEW_USER = 8;
    E.ERROR_USER_NOT_LOGIN = 9;
    E.ERROR_USER_IS_BANED = 10;
    E.ERROR_CREATE_ROOM_USER_IN_GAME = 11;
    E.ERROR_CREATE_ROOM_USER_IN_GROUPING = 12;
    E.ERROR_JOIN_ROOM_USER_IN_GROUPING = 13;
    E.ERROR_CREATE_ROOM_PLEASE_TRY_AGAIN_LATER = 14;
    E.ERROR_CREATE_ROOM_WRONG_OPTION = 15;
    E.ERROR_CREATE_AVAILABLE_ROOM_ID = 16;
    E.ERROR_CANNOT_KICK_PLAYER_IN_GAME = 17;
    E.ERROR_WRONG_CMD_PARAMETER = 18;
    E.ERROR_WRONG_APP_ID_CONFIG = 19;
    E.ERROR_IN_GAME_CANNOT_GROUP = 20;
    E.ERROR_WRONG_GAME_GROUP_CONFIG = 21;
    E.ERROR_CAN_NOT_MUTIL_LOGIN = 22;
    E.ERROR_HAVE_OTHER_APP_GAME_PLAYING = 23;
    E.ERROR_NO_AVAILABLE_GAME_ROOM_WORKER = 24;
    E.ERROR_WRONG_GAME_ROOM_INFO = 25;
    E.ERROR_GET_INTO_ROOM_PLEASE_TRY_AGAIN_LATER = 26;
    E.ERROR_QUIT_GAME_ROOM_FAIL = 27;
    E.ERROR_QUIT_GAME_ROOM_AFTER_GAME_START = 28;
    E.ERROR_DISSOLVE_GAME_ROOM_FAIL = 29;
    E.ERROR_DISSOLVE_GAME_ROOM_OWNER_ONLY = 30;
    E.ERROR_GET_READY_PLEASE_TRY_AGAIN_LATER = 31;
    E.ERROR_SEND_GAME_OPERATION_WRONG = 32;
    E.ERROR_NOT_ENOUGH_BALANCE = 33;
    E.ERROR_CURRENT_APP_STOP = 34;
    E.ERROR_CURRENT_GAME_TYPE_STOP = 35;
    E.ERROR_CURRENT_GAME_STOP = 36;
    E.ERROR_GAME_MONEY_CONFIG = 37;
    E.ERROR_MISSMATCH_APP_ID = 38;
    E.ERROR_GAME_ID_MANAGER_NOT_FOUND = 39;
    E.ERROR_GAME_DESK_IS_BUSY = 40;
    E.ERROR_GAME_DESK_IS_FULL = 41;
    E.ERROR_NOT_GAME_PLAYER_TURN = 42;
    E.ERROR_WEB_MANAGER_SIN_CODE = 43;
    E.ERROR_IP_NOT_ALLOW = 44;
    E.ERROR_USER_NOT_EXIST = 45;
    E.ERROR_SERVER_IN_MAINTENANCE = 46;
    E.ERROR_SERVER_RELOAD_WORKER = 47;
    E.ERROR_WRONG_CHAT_WORD_LENGTH = 48;
    E.ERROR_WRONG_GAME_MANAGER_CHECK_INFO = 49;
    E.ERROR_CREATE_TOO_MANY_ROOMS_TOTAL = 50;
    E.ERROR_CREATE_TOO_MANY_ROOMS_APP = 51;
    E.ERROR_GAME_REPLAY_NOT_FOUND = 52;
    E.ERROR_JOIN_IN_GAME_PLAYER_CAN_REPORT = 53;
    E.ERROR_CAN_NOT_MULTIPLE_REPORT = 54;
    E.ERROR_NOT_ENOUGH_BALANCE_SINGLE_GAME = 55;
    E.ERROR_GROUP_IS_FINISH_PLEASE_WAIT = 56;
    E.ERROR_AREADY_IN_ANOTHER_GROUP_QUEUE = 57;
    E.ERROR_WRONG_USER_GROUPKEY_CONFIG = 58;
    E.ERROR_GAME_IS_OVER = 59;
    E.ERROR_SERVER_IS_SUSPEND = 60;
    E.ERROR_GAME_IS_DOING_ACTION = 61;
    E.ERROR_GAME_IS_NOT_BEGIN = 62;
    E.ERROR_PLAYER_NOT_IN_TABLE = 63;
    E.ERROR_PLAYER_NO_OPE = 64;
    E.ERROR_GAME_ROOM_DISMISS = 65;
    E.ERROR_WRONG_BET_MONEY = 66;
    E.ERROR_TOP_BET_MONEY = 67;
    E.ERROR_NOT_ENOUGH_BET_BALANCE = 68;
    E.ERROR_NOW_IS_BANKER = 69;
    E.ERROR_BANKER_MONEY_TOO_SMALL = 70;
    E.ERROR_BANKER_MONEY_TOO_BIG = 71;
    E.ERROR_ALREADY_IN_BANKER_QUEUE = 72;
    E.ERROR_BANKER_QUEUE_IS_FULL = 73;
    E.ERROR_NOT_ENOUGH_FOR_BANKER = 74;
    E.ERROR_NOT_IN_BANKER_QUEUE = 75;
    E.ERROR_GAME_ROOM_IS_FULL = 76;
    E.ERROR_WRONG_MUL_GAME_CONFIG = 77;
    E.ERROR_WRONG_BET_MONEY_WHEN_BANKER = 78;
    E.ERROR_TOP_SPECIAL_BET_MONEY = 79;
    E.ERROR_MAX_USER_COLLECT_GAME_COUNT = 80;
    E.ERROR_WRONG_NOT_FOUND_GAME_RESULT = 81;
    E.ERROR_WRONG_MFG_GAME_STATUS = 82;
    E.ERROR_WRONG_MFG_BET_MONEY = 83;
    E.ERROR_WRONG_MFG_BET_NOT_FOUND = 84;
    E.ERROR_WRONG_MFG_DUPLICATE_BET = 85;
    E.ERROR_WRONG_FSG_NOT_IN_ROOM = 86;
    E.ERROR_WRONG_MFG_MAX_BET_COUNT = 87;
    E.ERROR_WRONG_ASW_CONFIG_WRONG = 88;
    E.ERROR_WRONG_ASW_DATA_CONFIG_WRONG = 89;
    E.ERROR_WRONG_ASW_ACCESS_FAIL = 90;
    E.ERROR_WRONG_ASW_ACCESS_BLOCKED = 91;
    class f {
        constructor() {}
        static initError() {
            var e = null;
            e = new Object;
            e["zh-cn"] = "发生未知错误,请联系客服人员";
            e["zh-tw"] = "发生未知错误,请联系客服人员";
            e["en"] = "An undefined error occurred, please contact the customer service staff";
            e["pr"] = "Um erro indefinido ocorreu, por favor contate o atendimento ao cliente.";
            e["vi"] = "Đã xảy ra lỗi không xác định,vui lòng liên hệ cskh";
            e["hi"] = "एक अनिर्धारित त्रुटि हुई है";
            e["es"] = "Se ha producido un error indefinido, póngase en contacto con el personal de atención al cliente";
            e["th"] = "เกิดข้อผิดพลาดที่ไม่ทราบสาเหตุ โปรดติดต่อฝ่ายบริการลูกค้า";
            e["tl"] = "May naganap na hindi natukoy na error, mangyaring makipag-ugnayan sa miyembro ng serbisyo sa customer";
            e["my"] = "အမည်မသိ အမှားအယွင်းတစ်ခု ဖြစ်ပေါ်ပါက ကျေးဇူးပြု၍ ဖောက်သည်ဝန်ဆောင်မှုဝန်ထမ်းများထံ ဆက်သွယ်ပါ။";
            e["ms"] = "Salah yang belum diketahui ditemukan";
            e["id"] = "Terjadi kesalahan yang tidak diketahui, silakan hubungi layanan pelanggan";
            f.ErrorTextDic[1] = e;
            e = new Object;
            e["zh-cn"] = "TCP数据解密失败";
            e["zh-tw"] = "TCP数据解密失败";
            e["en"] = "TCP data decryption failed";
            e["pr"] = "Falha na descriptografia de dados TCP";
            e["vi"] = "Giải mã dữ liệu TCP không thành công";
            e["hi"] = "TCP डेटा डिक्रिप्शन विफल रहा";
            e["es"] = "Descifrado de datos TCP fallido";
            e["th"] = "การถอดรหัสข้อมูล TCP ล้มเหลว";
            e["tl"] = "Nabigo ang pag-decryption ng data ng TCP";
            e["my"] = "TCP ဒေတာကို ကုဒ်ဝှက်ခြင်း မအောင်မြင်ပါ။";
            e["ms"] = "Kegagalan mendekripsi data TCP";
            e["id"] = "Dekripsi data TCP gagal";
            f.ErrorTextDic[2] = e;
            e = new Object;
            e["zh-cn"] = "TCP数据MD5验证失败";
            e["zh-tw"] = "TCP数据MD5验证失败";
            e["en"] = "TCP data MD5 verification failed";
            e["pr"] = "Falha na verificação MD5 dos dados TCP";
            e["vi"] = "Xác minh dữ liệu TCP MD5 không thành công";
            e["hi"] = "TCP डेटा MD5 सत्यापन विफल रहा";
            e["es"] = "La comprobación de datos TCP MD5 ha fallado";
            e["th"] = "การตรวจสอบ MD5 ข้อมูล TCP ล้มเหลว";
            e["tl"] = "Nabigo ang pag-verify ng MD5 ng data ng TCP";
            e["my"] = "TCP ဒေတာ MD5 အတည်ပြုခြင်း မအောင်မြင်ပါ။";
            e["ms"] = "Kegagalan mengesahkan MD5 data TCP";
            e["id"] = "Verifikasi MD5 data TCP gagal";
            f.ErrorTextDic[3] = e;
            e = new Object;
            e["zh-cn"] = "服务器处理错误";
            e["zh-tw"] = "服务器处理错误";
            e["en"] = "Server processing error";
            e["pr"] = "Erro de processamento do servidor";
            e["vi"] = "Lỗi xử lý máy chủ";
            e["hi"] = "सर्वर प्रोसेसिंग त्रुटि";
            e["es"] = "Error de procesamiento del servidor";
            e["th"] = "ข้อผิดพลาดในการประมวลผลเซิร์ฟเวอร์";
            e["tl"] = "Error sa pagproseso ng server";
            e["my"] = "ဆာဗာသည် အမှားများကို ကိုင်တွယ်သည်။";
            e["ms"] = "proses Server salah";
            e["id"] = "Kesalahan pemrosesan server";
            f.ErrorTextDic[4] = e;
            e = new Object;
            e["zh-cn"] = "没有找到正确的处理服务器";
            e["zh-tw"] = "没有找到正确的处理服务器";
            e["en"] = "The correct processing server was not found";
            e["pr"] = "O servidor correto de processamento não foi encontrado";
            e["vi"] = "Không tìm thấy máy chủ xử lý chính xác";
            e["hi"] = "सही प्रोसेसिंग सर्वर नहीं मिला";
            e["es"] = "El servidor de procesamiento correcto no se encontró";
            e["th"] = "ไม่พบเซิร์ฟเวอร์การประมวลผลที่ถูกต้อง";
            e["tl"] = "Hindi nahanap ang tamang server sa pagpoproseso";
            e["my"] = "မှန်ကန်သော လုပ်ဆောင်ခြင်းဆာဗာကို ရှာမတွေ့ပါ။";
            e["ms"] = "Server proses yang betul tidak ditemui";
            e["id"] = "Server pemrosesan yang benar tidak ditemukan";
            f.ErrorTextDic[5] = e;
            e = new Object;
            e["zh-cn"] = "服务器未找到对应的处理接口程序";
            e["zh-tw"] = "服务器未找到对应的处理接口程序";
            e["en"] = "The server did not find the corresponding processing interface program";
            e["pr"] = "O servidor não encontrou o programa de interface de processamento correspondente";
            e["vi"] = "Máy chủ không tìm thấy chương trình giao diện xử lý tương ứng";
            e["hi"] = "सर्वर ने संबंधित प्रोसेसिंग इंटरफेस प्रोग्राम नहीं पाया";
            e["es"] = "El servidor no ha encontrado el programa de interfaz de procesamiento correspondiente";
            e["th"] = "เซิร์ฟเวอร์ไม่พบโปรแกรมอินเทอร์เฟซการประมวลผลที่เกี่ยวข้อง";
            e["tl"] = "Hindi nakita ng server ang kaukulang processing interface program";
            e["my"] = "ဆာဗာသည် သက်ဆိုင်ရာ လုပ်ဆောင်ခြင်း အင်တာဖေ့စ်ပရိုဂရမ်ကို ရှာမတွေ့ပါ။";
            e["ms"] = "Server belum menemukan program antaramuka proses yang bercocok";
            e["id"] = "Server tidak menemukan program antarmuka pemrosesan yang sesuai";
            f.ErrorTextDic[6] = e;
            e = new Object;
            e["zh-cn"] = "接口ID不正确";
            e["zh-tw"] = "接口ID不正确";
            e["en"] = "The interface ID is incorrect";
            e["pr"] = "O ID da interface está incorreto";
            e["vi"] = "ID giao diện không chính xác";
            e["hi"] = "इंटरफेस ID गलत है";
            e["es"] = "El ID de la interfaz es incorrecto";
            e["th"] = "รหัสอินเทอร์เฟซไม่ถูกต้อง";
            e["tl"] = "Ang interface ID ay hindi tama";
            e["my"] = "အင်တာဖေ့စ် ID မမှန်ပါ။";
            e["ms"] = "ID antaramuka tidak betul";
            e["id"] = "ID Antarmuka salah";
            f.ErrorTextDic[7] = e;
            e = new Object;
            e["zh-cn"] = "玩家创建失败";
            e["zh-tw"] = "玩家创建失败";
            e["en"] = "Player creation failed";
            e["pr"] = "A criação do jogador falhou";
            e["vi"] = "Tạo người chơi không thành công";
            e["hi"] = "खिलाड़ी निर्माण विफल रहा";
            e["es"] = "Creación de reproductor fallida";
            e["th"] = "การสร้างผู้เล่นล้มเหลว";
            e["tl"] = "Nabigo ang paggawa ng player";
            e["my"] = "ကစားသမားဖန်တီးမှု မအောင်မြင်ပါ။";
            e["ms"] = "Kegagalan menciptakan pemain";
            e["id"] = "Pembuatan pemain gagal";
            f.ErrorTextDic[8] = e;
            e = new Object;
            e["zh-cn"] = "未登录的玩家无法调用该接口";
            e["zh-tw"] = "未登录的玩家无法调用该接口";
            e["en"] = "Players who are not logged in cannot call this interface";
            e["pr"] = "Jogadores que não estão logados não podem chamar esta interface";
            e["vi"] = "Người chơi chưa đăng nhập không thể vào giao diện này";
            e["hi"] = "लॉग इन नहीं किए गए खिलाड़ी इस इंटरफेस को कॉल नहीं कर सकते";
            e["es"] = "Los jugadores que no han iniciado sesión no pueden llamar a esta interfaz";
            e["th"] = "ผู้เล่นที่ไม่ได้เข้าสู่ระบบจะไม่สามารถเรียกใช้อินเทอร์เฟซนี้ได้";
            e["tl"] = "Ang mga manlalaro na hindi naka-log in ay hindi maaaring tumawag sa interface na ito";
            e["my"] = "လော့ဂ်အင်မဝင်သော ကစားသမားများသည် ဤအင်တာဖေ့စ်ကို ခေါ်ဆို၍မရပါ။";
            e["ms"] = "Pemain yang belum melog masuk tidak boleh memanggil antaramuka ini";
            e["id"] = "Pemain yang belum login tidak dapat memanggil antarmuka ini.";
            f.ErrorTextDic[9] = e;
            e = new Object;
            e["zh-cn"] = "玩家账号被禁止登录";
            e["zh-tw"] = "玩家账号被禁止登录";
            e["en"] = "Player account is banned from logging in";
            e["pr"] = "A conta do jogador está banida de fazer login";
            e["vi"] = "Tài khoản người chơi bị cấm đăng nhập";
            e["hi"] = "खिलाड़ी का खाता लॉग इन के लिए प्रतिबंधित है";
            e["es"] = "La cuenta del jugador está excluida del inicio de sesión";
            e["th"] = "บัญชีผู้เล่นถูกห้ามไม่ให้เข้าสู่ระบบ";
            e["tl"] = "Ang player account ay pinagbawalan sa pag-log in";
            e["my"] = "ကစားသမားအကောင့်များကို လော့ဂ်အင်ဝင်ခြင်းမှ တားမြစ်ထားသည်။";
            e["ms"] = "Nombor akaun pemain ini dilarang digunakan untuk logmasuk";
            e["id"] = "Akun pemain dilarang masuk";
            f.ErrorTextDic[10] = e;
            e = new Object;
            e["zh-cn"] = "玩家有进行中的游戏，暂不能创建自定义游戏";
            e["zh-tw"] = "玩家有进行中的游戏，暂不能创建自定义游戏";
            e["en"] = "Players who have a game in progress cannot create custom games";
            e["pr"] = "Jogadores com uma partida em andamento não podem criar jogos personalizados";
            e["vi"] = "Người chơi có trò chơi đang diễn ra, tạm thời không thể tạo trò chơi tùy chỉnh";
            e["hi"] = "जिन खिलाड़ियों का खेल चल रहा है वे कस्टम गेम नहीं बना सकते";
            e["es"] = "Los jugadores que tienen una partida en curso no pueden crear partidas personalizadas";
            e["th"] = "ผู้เล่นมีเกมที่กำลังดำเนินอยู่และไม่สามารถสร้างเกมที่กำหนดเองได้ในขณะนี้";
            e["tl"] = "Ang mga manlalaro na may kasalukuyang laro ay hindi makakagawa ng mga custom na laro";
            e["my"] = "ကစားသမားများသည် ဂိမ်းများလုပ်ဆောင်နေပြီး လက်ရှိအချိန်တွင် စိတ်ကြိုက်ဂိမ်းများကို ဖန်တီး၍မရပါ။";
            e["ms"] = "Pemain ada permainan yang sedang dilakukan, dia tidak boleh menciptakan pemainan suai";
            e["id"] = "Pemain memiliki permainan yang sedang berlangsung dan tidak dapat membuat permainan khusus saat ini.";
            f.ErrorTextDic[11] = e;
            e = new Object;
            e["zh-cn"] = "玩家正在游戏匹配中，暂不能创建自定义游戏";
            e["zh-tw"] = "玩家正在游戏匹配中，暂不能创建自定义游戏";
            e["en"] = "Players are in matchmaking cannot create custom games";
            e["pr"] = "Jogadores estão em busca de equipe e não podem criar jogos personalizados";
            e["vi"] = "Người chơi đang được ghép trong trò chơi ,tạm thời không thể tạo trò chơi tùy chỉnh";
            e["hi"] = "खिलाड़ी मैचमेकिंग में हैं और कस्टम गेम नहीं बना सकते";
            e["es"] = "Los jugadores están en emparejamiento y no pueden crear juegos personalizados";
            e["th"] = "ผู้เล่นอยู่ในการจับคู่เกมและไม่สามารถสร้างเกมที่กำหนดเองได้ในขณะนี้";
            e["tl"] = "Ang mga manlalaro na nasa matchmaking ay hindi makakagawa ng mga custom na laro";
            e["my"] = "ကစားသမားများသည် ဂိမ်းတွင် လိုက်ဖက်ညီနေပြီး လက်ရှိအချိန်တွင် စိတ်ကြိုက်ဂိမ်းတစ်ခုကို သင်ဖန်တီး၍မရပါ။";
            e["ms"] = "Pemain sedang mencocokkan permainan, tidak boleh menciptakan permainan suai";
            e["id"] = "Pemain sedang dalam pencocokan game dan tidak dapat membuat game khusus saat ini.";
            f.ErrorTextDic[12] = e;
            e = new Object;
            e["zh-cn"] = "玩家正在匹配分组中，加入游戏失败";
            e["zh-tw"] = "玩家正在匹配分组中，加入游戏失败";
            e["en"] = "Being matched into groups, players failed to join the game.";
            e["pr"] = "Estando em busca de equipe, os jogadores falharam ao entrar no jogo.";
            e["vi"] = "Người chơi đang được ghép trong nhóm ,không thể tham gia trò chơi";
            e["hi"] = "मैचमेकिंग समूह में खेल में शामिल होने का प्रयास विफल रहा";
            e["es"] = "Al ser emparejados en grupos, los jugadores no pudieron unirse al juego.";
            e["th"] = "ผู้เล่นอยู่ในกลุ่มที่ตรงกันและไม่สามารถเข้าร่วมเกมได้";
            e["tl"] = "Dahil naitugma sa mga grupo, nabigo ang mga manlalaro na sumali sa laro.";
            e["my"] = "ကစားသမားများသည် လိုက်ဖက်ညီသော အုပ်စုတွင် ရှိနေကြပြီး ဂိမ်းတွင် ပါဝင်ခြင်း မအောင်မြင်ပါ။";
            e["ms"] = "Pemain sedang mencocokkan kumpulan, dan menyertai permainan gagal";
            e["id"] = "Pemain berada dalam grup yang cocok dan gagal bergabung dalam permainan.";
            f.ErrorTextDic[13] = e;
            e = new Object;
            e["zh-cn"] = "创建房间失败，请稍后重新尝试创建自定义房间";
            e["zh-tw"] = "创建房间失败，请稍后重新尝试创建自定义房间";
            e["en"] = "Room creation failed, please try creating a custom room again later";
            e["pr"] = "A criação da sala falhou, por favor, tente criar uma sala personalizada novamente mais tarde";
            e["vi"] = "Tạo phòng không thành công, vui lòng thử tạo lại phòng tùy chỉnh sau";
            e["hi"] = "कमरा निर्माण विफल रहा, कृपया बाद में कस्टम कमरा बनाने का प्रयास करें";
            e["es"] = "Error al crear la habitación, intente crear una habitación personalizada de nuevo más tarde";
            e["th"] = "การสร้างห้องล้มเหลว โปรดลองอีกครั้งในภายหลังเพื่อสร้างห้องที่กำหนดเอง";
            e["tl"] = "Nabigo ang paggawa ng kwarto para sa manlalaro, pakisubukang gumawa muli  sa ibang pagkakataon";
            e["my"] = "အခန်းတစ်ခုဖန်တီးရန် မအောင်မြင်ပါ၊ ကျေးဇူးပြု၍ နောက်ပိုင်းတွင် စိတ်ကြိုက်အခန်းတစ်ခုဖန်တီးရန် ကြိုးစားပါ။";
            e["ms"] = "Kegagalan menciptakan bilik, cuba sebentar lagi untuk menciptakan bilik suai";
            e["id"] = "Pembuatan ruang gagal, coba lagi nanti untuk membuat ruang khusus";
            f.ErrorTextDic[14] = e;
            e = new Object;
            e["zh-cn"] = "创建自定义房间失败，游戏参数错误";
            e["zh-tw"] = "创建自定义房间失败，游戏参数错误";
            e["en"] = "Failed to create a custom room, Game system error";
            e["pr"] = "Falha ao criar a sala personalizada, erro de parâmetro do jogo";
            e["vi"] = "Không thể tạo phòng tùy chỉnh, Lỗi thông số trò chơi";
            e["hi"] = "कस्टम कमरा बनाने में विफल, गेम पैरामीटर त्रुटि";
            e["es"] = "Error de crear una habitación personalizada, error de parámetro de juego";
            e["th"] = "ไม่สามารถสร้างห้องแบบกำหนดเองได้ พารามิเตอร์เกมไม่ถูกต้อง";
            e["tl"] = "Nabigong gumawa ng custom na kwarto para sa manlalaro, Game system error";
            e["my"] = "မှားယွင်းသောဂိမ်းကန့်သတ်ချက်များဖြင့် စိတ်ကြိုက်အခန်းကို ဖန်တီး၍မရပါ။";
            e["ms"] = "Kegagalan menciptakan bilik suai, parameter permainan salah";
            e["id"] = "Gagal membuat ruang khusus, parameter game salah";
            f.ErrorTextDic[15] = e;
            e = new Object;
            e["zh-cn"] = "创建房间失败，没有可用的房间号";
            e["zh-tw"] = "创建房间失败，没有可用的房间号";
            e["en"] = "Failed to create room, no room number available";
            e["pr"] = "Falha ao criar a sala, nenhum número da sala disponível";
            e["vi"] = "Tạo phòng không thành công, không có số phòng khả dụng";
            e["hi"] = "कमरा बनाने में विफल, कोई कमरा नंबर उपलब्ध नहीं है";
            e["es"] = "Error de crear habitación, no hay número de habitación disponible";
            e["th"] = "สร้างห้องไม่สำเร็จ ไม่มีหมายเลขห้อง";
            e["tl"] = "Nabigong gumawa ng kwarto para sa manlalaro, walang bakanteng room number";
            e["my"] = "အခန်းဖန်တီးရန် မအောင်မြင်ပါ၊ အခန်းနံပါတ်မရနိုင်ပါ။";
            e["ms"] = "Kegagalan menciptakan bilik, tidak nombor bilik tersedia yang ditemui";
            e["id"] = "Gagal membuat ruang, nomor kamar tidak tersedia";
            f.ErrorTextDic[16] = e;
            e = new Object;
            e["zh-cn"] = "不能踢出正在游戏中的玩家";
            e["zh-tw"] = "不能踢出正在游戏中的玩家";
            e["en"] = "Cannot kick a player who is in the game";
            e["pr"] = "Não é possível expulsar um jogador que está no jogo";
            e["vi"] = "Không thể đá người chơi đang trong trò chơi";
            e["hi"] = "खेल में मौजूद खिलाड़ी को नहीं निकाला जा सकता";
            e["es"] = "No puede patear a un jugador que está en el juego";
            e["th"] = "ไม่สามารถเตะผู้เล่นที่อยู่ในเกมได้";
            e["tl"] = "Hindi maaaring alisin ang isang manlalaro na nasa laro";
            e["my"] = "ဂိမ်းထဲမှာ ကစားသမားတွေကို ထုတ်လို့မရပါဘူး။";
            e["ms"] = "Pemain yang sedang melakukan permainan tidak boleh dikeluarkan";
            e["id"] = "Tidak bisa menendang pemain yang ada di dalam permainan";
            f.ErrorTextDic[17] = e;
            e = new Object;
            e["zh-cn"] = "接口参数错误";
            e["zh-tw"] = "接口参数错误";
            e["en"] = "Interface system error";
            e["pr"] = "Erro de parâmetro da interface";
            e["vi"] = "Lỗi tham số giao diện";
            e["hi"] = "इंटरफेस पैरामीटर त्रुटि";
            e["es"] = "Error en el parámetro de la interfaz";
            e["th"] = "ข้อผิดพลาดของพารามิเตอร์อินเทอร์เฟซ";
            e["tl"] = "Error sa interface ng system";
            e["my"] = "Interface Parameter အမှား";
            e["ms"] = "Parameter antaramuka salah";
            e["id"] = "Kesalahan parameter antarmuka";
            f.ErrorTextDic[18] = e;
            e = new Object;
            e["zh-cn"] = "应用ID参数未找到";
            e["zh-tw"] = "应用ID参数未找到";
            e["en"] = "App ID parameter not found";
            e["pr"] = "O parâmetro ID do aplicativo não foi encontrado";
            e["vi"] = "Không tìm thấy thông số ID ứng dụng";
            e["hi"] = "ऐप ID पैरामीटर नहीं मिला";
            e["es"] = "Parámetro de ID de aplicación no encontrado";
            e["th"] = "ไม่พบพารามิเตอร์รหัสแอปพลิเคชัน";
            e["tl"] = "Hindi nahanap ang parameter ng App ID";
            e["my"] = "အပလီကေးရှင်း ID ဘောင်များကို ရှာမတွေ့ပါ။";
            e["ms"] = "Parameter ID penggunaan belum ditemui";
            e["id"] = "Parameter ID aplikasi tidak ditemukan";
            f.ErrorTextDic[19] = e;
            e = new Object;
            e["zh-cn"] = "有未完成游戏的情况下，无法加入随机匹配分组";
            e["zh-tw"] = "有未完成游戏的情况下，无法加入随机匹配分组";
            e["en"] = "Unable to join random matchmaking groups with unfinished games";
            e["pr"] = "Não é possível participar de grupos de jogo aleatórios com jogos não finalizados";
            e["vi"] = "Nếu có một trò chơi chưa hoàn thành Không thể tham gia nhóm ghép ngẫu nhiên";
            e["hi"] = "अधूरे खेलों के साथ यादृच्छिक मैचमेकिंग समूहों में शामिल नहीं हो सकते";
            e["es"] = "No se puede unir a grupos de emparejamiento aleatorios con juegos sin terminar";
            e["th"] = "หากคุณมีเกมที่ยังเล่นไม่เสร็จ คุณจะไม่สามารถเข้าร่วมกลุ่มจับคู่แบบสุ่มได้";
            e["tl"] = "Hindi makasali sa mga random na grupo ng matchmaking na may mga hindi natapos na laro";
            e["my"] = "မပြီးဆုံးသေးသောဂိမ်းတစ်ခုရှိပါက၊ သင်သည် ကျပန်းပွဲစဉ်အုပ်စုတွင် ပါဝင်၍မရပါ။";
            e["ms"] = "Di bawah situasi yang belum menyelesaikan permainan, anda tidak boleh menggabung kumpulan pencocokan secara rawak";
            e["id"] = "Jika Anda memiliki permainan yang belum selesai, Anda tidak dapat bergabung dengan grup pencocokan acak.";
            f.ErrorTextDic[20] = e;
            e = new Object;
            e["zh-cn"] = "未找到正确的随机匹配游戏数据";
            e["zh-tw"] = "未找到正确的随机匹配游戏数据";
            e["en"] = "The correct random match game data was not found";
            e["pr"] = "Os dados do jogo de correspondência aleatória corretos não foram encontrados";
            e["vi"] = "Không tìm thấy dữ liệu trận đấu ngẫu nhiên chính xác";
            e["hi"] = "सही यादृच्छिक मैच खेल डेटा नहीं मिला";
            e["es"] = "Los datos correctos del juego de coincidencia aleatoria no se encontraron";
            e["th"] = "ไม่พบข้อมูลเกมจับคู่แบบสุ่มที่ถูกต้อง";
            e["tl"] = "Ang tamang random data para sa laro ng pagtutugma ay hindi natagpuan";
            e["my"] = "မှန်ကန်သော ကျပန်းကိုက်ညီသော ဂိမ်းဒေတာကို ရှာမတွေ့ပါ။";
            e["ms"] = "Data permainan cocok rawak yang betul belum ditemui";
            e["id"] = "Data permainan pertandingan acak yang benar tidak ditemukan";
            f.ErrorTextDic[21] = e;
            e = new Object;
            e["zh-cn"] = "您的账号已在其他客户端登录";
            e["zh-tw"] = "您的账号已在其他客户端登录";
            e["en"] = "Your account has been logged in on other clients";
            e["pr"] = "Sua conta já foi logada em outros clientes";
            e["vi"] = "Tài khoản của bạn đã đăng nhập ở nơi khác";
            e["hi"] = "आपका खाता अन्य क्लाइंट्स पर लॉग इन किया गया है";
            e["es"] = "Su cuenta ha iniciado sesión en otros clientes";
            e["th"] = "บัญชีของคุณเข้าสู่ระบบไคลเอนต์อื่นแล้ว";
            e["tl"] = "Ang iyong account ay naka-log in sa ibang kliyente";
            e["my"] = "သင့်အကောင့်သည် အခြားဖောက်သည်များထံ အကောင့်ဝင်ပြီးဖြစ်သည်။";
            e["ms"] = "Nombor akaun anda telah dilog masuk di terminal lain";
            e["id"] = "Akun Anda telah masuk di klien lain";
            f.ErrorTextDic[22] = e;
            e = new Object;
            e["zh-cn"] = "您在其他游戏中有未完成的游戏，\r\n无法参与当前游戏";
            e["zh-tw"] = "您在其他游戏中有未完成的游戏，\r\n无法参与当前游戏";
            e["en"] = "You have unfinished games in other games and \r\n cannot participate in the current game";
            e["pr"] = "Você tem jogos não finalizados em outros jogos e \r\n não pode participar do jogo atual";
            e["vi"] = "Bạn có các trò chơi chưa hoàn thành trong các trò chơi khác ,không thể tham gia trò chơi hiện tại";
            e["hi"] = "आपके अन्य खेलों में अधूरे खेल हैं और आप वर्तमान खेल में भाग नहीं ले सकते";
            e["es"] = "Tiene juegos sin terminar en otros juegos y \r\n no puede participar en el juego actual";
            e["th"] = "คุณมีเกมที่ยังเล่นไม่เสร็จในเกมอื่น ไม่สามารถเข้าร่วมในเกมปัจจุบันได้";
            e["tl"] = "Mayroon kang hindi natapos na mga laro sa iba pang mga laro at \r\n ay hindi maaaring lumahok sa kasalukuyang laro";
            e["my"] = "သင့်တွင် အခြားဂိမ်းများတွင် မပြီးဆုံးသေးသောဂိမ်းများရှိသည်၊ \r\n လက်ရှိဂိမ်းတွင် မပါဝင်နိုင်ပါ။";
            e["ms"] = "Anda ada permainan yang belum selesai,\r\n tidak boleh menyertai permainan kini";
            e["id"] = "Anda memiliki permainan yang belum selesai di permainan lain,\r\ntidak dapat berpartisipasi dalam permainan saat ini";
            f.ErrorTextDic[23] = e;
            e = new Object;
            e["zh-cn"] = "创建自定义房间失败，当前没有可用的游戏服务器";
            e["zh-tw"] = "创建自定义房间失败，当前没有可用的游戏服务器";
            e["en"] = "Failed to create a custom room, there are currently no game servers available";
            e["pr"] = "Falha ao criar a sala personalizada, atualmente não há servidores de jogo disponíveis";
            e["vi"] = "Không thể tạo phòng tùy chỉnh, hiện tại không có máy chủ trò chơi nào khả dụng";
            e["hi"] = "कस्टम कमरा बनाने में विफल, वर्तमान में कोई गेम सर्वर उपलब्ध नहीं है";
            e["es"] = "Error de crear una habitación personalizada, actualmente no hay servidores de juegos disponibles";
            e["th"] = "ไม่สามารถสร้างห้องแบบกำหนดเองได้ ขณะนี้ไม่มีเซิร์ฟเวอร์เกมที่พร้อมใช้งาน";
            e["tl"] = "Nabigong gumawa ng custom na kwarto, kasalukuyang walang available na mga server ng laro";
            e["my"] = "စိတ်ကြိုက်အခန်းကို ဖန်တီး၍မရပါ၊ လောလောဆယ်တွင် ဂိမ်းဆာဗာ မရရှိနိုင်ပါ။";
            e["ms"] = "Kegagalan menciptakan bilik suai, tidak ada server permainan tersedia";
            e["id"] = "Gagal membuat ruang khusus, saat ini tidak ada server game yang tersedia";
            f.ErrorTextDic[24] = e;
            e = new Object;
            e["zh-cn"] = "无法找到当前房间信息";
            e["zh-tw"] = "无法找到当前房间信息";
            e["en"] = "Unable to find current room information";
            e["pr"] = "Não foi possível encontrar as informações da sala atual";
            e["vi"] = "Không thể tìm thấy thông tin phòng hiện tại";
            e["hi"] = "वर्तमान कमरे की जानकारी नहीं मिली";
            e["es"] = "No se puede encontrar la información actual de la habitación";
            e["th"] = "ไม่พบข้อมูลห้องปัจจุบัน";
            e["tl"] = "Hindi mahanap ang kasalukuyang impormasyon";
            e["my"] = "လက်ရှိအခန်းအချက်အလက်ကို ရှာမတွေ့ပါ။";
            e["ms"] = "Maklumat bilik kini tidak boleh ditemui";
            e["id"] = "Tidak dapat menemukan informasi kamar terkini";
            f.ErrorTextDic[25] = e;
            e = new Object;
            e["zh-cn"] = "加入游戏失败，请稍后重新尝试";
            e["zh-tw"] = "加入游戏失败，请稍后重新尝试";
            e["en"] = "Failed to join the game, please try again later";
            e["pr"] = "Falha ao entrar no jogo, por favor, tente novamente mais tarde";
            e["vi"] = "Không thể tham gia trò chơi, vui lòng thử lại sau";
            e["hi"] = "खेल में शामिल होने में विफल, कृपया बाद में पुनः प्रयास करें";
            e["es"] = "No se ha podido unir al juego, por favor, intente de nuevo más tarde";
            e["th"] = "ไม่สามารถเข้าร่วมเกมได้ โปรดลองอีกครั้งในภายหลัง";
            e["tl"] = "Nabigong sumali sa laro, pakisubukang muli sa ibang pagkakataon";
            e["my"] = "ဂိမ်းတွင်ပါဝင်ရန် မအောင်မြင်ပါ၊ ကျေးဇူးပြု၍ နောက်မှ ထပ်ကြိုးစားပါ။";
            e["ms"] = "Kegagalan menyertai permainan, cuba sebentar lagi";
            e["id"] = "Gagal bergabung ke dalam game, coba lagi nanti";
            f.ErrorTextDic[26] = e;
            e = new Object;
            e["zh-cn"] = "退出游戏失败";
            e["zh-tw"] = "退出游戏失败";
            e["en"] = "Failed to exit the game";
            e["pr"] = "Falha ao sair do jogo";
            e["vi"] = "Không thể thoát khỏi trò chơi";
            e["hi"] = "खेल से बाहर निकलने में विफल";
            e["es"] = "Error al salir del juego";
            e["th"] = "ไม่สามารถออกจากเกมได้";
            e["tl"] = "Nabigong lumabas sa laro";
            e["my"] = "ဂိမ်းမှထွက်ရန် မအောင်မြင်ပါ။";
            e["ms"] = "Kegagalan melog keluar daripada permainan";
            e["id"] = "Gagal keluar dari permainan";
            f.ErrorTextDic[27] = e;
            e = new Object;
            e["zh-cn"] = "游戏未结束，不能退出游戏";
            e["zh-tw"] = "游戏未结束，不能退出游戏";
            e["en"] = "The game is not over and you cannot exit the game";
            e["pr"] = "O jogo não acabou e você não pode sair do jogo";
            e["vi"] = "Trò chơi chưa kết thúc ,không thể thoát khỏi trò chơi";
            e["hi"] = "खेल अभी समाप्त नहीं हुआ है और खेल से बाहर नहीं निकल सकते";
            e["es"] = "El juego no ha terminado y no puedes salir del juego";
            e["th"] = "เกมยังไม่จบและไม่สามารถออกจากเกมได้";
            e["tl"] = "Hindi pa tapos ang laro at hindi ka maaaring lumabas sa laro";
            e["my"] = "ဂိမ်းမပြီးသေးဘဲ ဂိမ်းမှထွက်၍မရပါ။";
            e["ms"] = "Permainan belum tamat, tidak boleh melog keluar";
            e["id"] = "Permainan belum berakhir dan tidak bisa keluar dari permainan";
            f.ErrorTextDic[28] = e;
            e = new Object;
            e["zh-cn"] = "游戏已开始，无法解散房间";
            e["zh-tw"] = "游戏已开始，无法解散房间";
            e["en"] = "The game has started and the room cannot be dismissed";
            e["pr"] = "O jogo já começou e a sala não pode ser descartada";
            e["vi"] = "Trò chơi đã bắt đầu ,không thể giải tán phòng ";
            e["hi"] = "खेल शुरू हो चुका है और कमरा खत्म नहीं किया जा सकता";
            e["es"] = "El juego ha comenzado y la sala no se puede descartar";
            e["th"] = "เกมเริ่มต้นแล้วและไม่สามารถยกเลิกห้องได้";
            e["tl"] = "Nagsimula na ang laro at hindi maaaring ikansela";
            e["my"] = "ဂိမ်းစနေပြီ၊ အခန်းကို ဖျက်သိမ်း၍မရပါ။";
            e["ms"] = "Permainan telah dimulai, tidak boleh membubarkan bilik";
            e["id"] = "Permainan telah dimulai dan ruangan tidak dapat ditutup";
            f.ErrorTextDic[29] = e;
            e = new Object;
            e["zh-cn"] = "您不是游戏创建者，无法解散房间";
            e["zh-tw"] = "您不是游戏创建者，无法解散房间";
            e["en"] = "You are not the game creator and cannot dismiss the room";
            e["pr"] = "Você não é o criador do jogo e não pode descartar a sala";
            e["vi"] = "Bạn không phải là người tạo trò chơi, không thể giản tán phòng";
            e["hi"] = "आप खेल के निर्माता नहीं हैं और कमरा खत्म नहीं कर सकते";
            e["es"] = "No es el creador del juego y no puede despedir a la sala";
            e["th"] = "คุณไม่ใช่ผู้สร้างเกมและไม่สามารถยกเลิกห้องได้";
            e["tl"] = "Hindi ikaw ang tagalikha ng laro at hindi maaaring i-dismiss ang kwarto";
            e["my"] = "သင်သည် ဂိမ်းဖန်တီးသူမဟုတ်သလို အခန်းကို ဖျက်သိမ်း၍မရပါ။";
            e["ms"] = "Anda bukan pencipta permainan, tidak boleh membubarkan bilik";
            e["id"] = "Anda bukan pembuat game dan tidak dapat mengabaikan ruangan tersebut";
            f.ErrorTextDic[30] = e;
            e = new Object;
            e["zh-cn"] = "取得游戏数据失败，请稍后重新尝试";
            e["zh-tw"] = "取得游戏数据失败，请稍后重新尝试";
            e["en"] = "Failed to get game data, please try again later";
            e["pr"] = "Falha ao obter os dados do jogo, por favor, tente novamente mais tarde";
            e["vi"] = "Không lấy được dữ liệu trò chơi, vui lòng thử lại sau";
            e["hi"] = "खेल डेटा प्राप्त करने में विफल, कृपया बाद में पुनः प्रयास करें";
            e["es"] = "No se han podido obtener los datos del juego, por favor, intente de nuevo más tarde";
            e["th"] = "ไม่สามารถรับข้อมูลเกมได้ โปรดลองอีกครั้งในภายหลัง";
            e["tl"] = "Nabigong makakuha ng data ng laro, pakisubukang muli sa ibang pagkakataon";
            e["my"] = "ဒေတာကို ရယူရန် မအောင်မြင်ပါ၊ ကျေးဇူးပြု၍ နောက်မှ ထပ်ကြိုးစားပါ။";
            e["ms"] = "Kegagalan mendapatkan data permainan, cuba sebentar lagi";
            e["id"] = "Gagal mendapatkan data game, coba lagi nanti.";
            f.ErrorTextDic[31] = e;
            e = new Object;
            e["zh-cn"] = "游戏操作失败，请稍后重新尝试";
            e["zh-tw"] = "游戏操作失败，请稍后重新尝试";
            e["en"] = "Game operation failed, please try again later";
            e["pr"] = "Operação de jogo falhou, por favor, tente novamente mais tarde";
            e["vi"] = "Thao tác trò chơi thất bại, vui lòng thử lại sau";
            e["hi"] = "खेल संचालन विफल";
            e["es"] = "La operación del juego ha fallado, por favor, intente de nuevo más";
            e["th"] = "การทำงานของเกมล้มเหลว โปรดลองอีกครั้งในภายหลัง";
            e["tl"] = "Nabigo ang pagpapatakbo ng laro, pakisubukang muli sa ibang pagkakataon";
            e["my"] = "ပါ။ ဂိမ်းလည်ပတ်မှု မအောင်မြင်ပါ၊ ကျေးဇူးပြု၍ နောက်မှ ထပ်စမ်းကြည့်ပါ။";
            e["ms"] = "Kegagalan mengoperasikan permainan, cuba sebentar lagi";
            e["id"] = "Pengoperasian game gagal, coba lagi nanti";
            f.ErrorTextDic[32] = e;
            e = new Object;
            e["zh-cn"] = "您的余额不足，请及时充值";
            e["zh-tw"] = "您的余额不足，请及时充值";
            e["en"] = "Your balance is insufficient, please recharge in time.";
            e["pr"] = "Seu saldo é insuficiente, por favor recarregue a tempo.";
            e["vi"] = "Số dư của bạn không đủ, vui lòng nạp tiền";
            e["hi"] = "आपका शेष राशि अपर्याप्त है";
            e["es"] = "Su saldo es insuficiente, recargue a tiempo.";
            e["th"] = "ยอดคงเหลือของคุณไม่เพียงพอ โปรดเติมเงินให้ทันเวลา";
            e["tl"] = "Hindi sapat ang iyong balanse, mangyaring mag-recharge sa oras.";
            e["my"] = "ါ။ သင့်လက်ကျန်ငွေ မလုံလောက်ပါ၊ အချိန်မီ အားပြန်သွင်းပါ။ ";
            e["ms"] = "Baki anda tak cukup, sila tambah nilai masa tepat";
            e["id"] = "Saldo Anda tidak mencukupi, harap isi ulang tepat waktu";
            f.ErrorTextDic[33] = e;
            e = new Object;
            e["zh-cn"] = "当前应用已经停用";
            e["zh-tw"] = "当前应用已经停用";
            e["en"] = "The current application is disabled";
            e["pr"] = "O aplicativo atual está desativado";
            e["vi"] = "Ứng dụng hiện tại đã bị ngưng hoạt động";
            e["hi"] = "वर्तमान एप्लिकेशन निष्क्रिय है";
            e["es"] = "La aplicación actual está deshabilitada";
            e["th"] = "แอปพลิเคชันปัจจุบันถูกปิดใช้งานแล้ว";
            e["tl"] = "Ang kasalukuyang aplikasyon ay hindi gumagana";
            e["my"] = "လက်ရှိအပလီကေးရှင်းကို ပိတ်ထားသည်။ ";
            e["ms"] = "Aplikasi kini telah dinyahdayakan";
            e["id"] = "Aplikasi saat ini telah dinonaktifkan";
            f.ErrorTextDic[34] = e;
            e = new Object;
            e["zh-cn"] = "当前类型游戏已经停用";
            e["zh-tw"] = "当前类型游戏已经停用";
            e["en"] = "The current type of game has been disabled";
            e["pr"] = "O tipo de jogo atual foi desativado";
            e["vi"] = "Loại trò chơi hiện tại đã ngưng hoạt động";
            e["hi"] = "वर्तमान प्रकार का खेल निष्क्रिय है";
            e["es"] = "El tipo de juego actual se ha desactivado";
            e["th"] = "ประเภทของเกมปัจจุบันถูกปิดใช้งาน";
            e["tl"] = "Ang kasalukuyang uri ng laro ay hindi gumagana";
            e["my"] = "လက်ရှိဂိမ်းအမျိုးအစားကို ပိတ်ထားသည်။ ";
            e["ms"] = "Permainan sejenis kini telah dinyahdayakan";
            e["id"] = "Jenis permainan saat ini telah dinonaktifkan";
            f.ErrorTextDic[35] = e;
            e = new Object;
            e["zh-cn"] = "当前游戏已经停用";
            e["zh-tw"] = "当前游戏已经停用";
            e["en"] = "The current game is disabled";
            e["pr"] = "O jogo atual está desativado";
            e["vi"] = "Trò chơi hiện tại đã ngưng hoạt động";
            e["hi"] = "वर्तमान खेल निष्क्रिय है";
            e["es"] = "El juego actual está desactivado";
            e["th"] = "เกมปัจจุบันถูกปิดใช้งานแล้ว";
            e["tl"] = "Ang kasalukuyang laro ay hindi gumagana";
            e["my"] = "လက်ရှိဂိမ်းကို ပိတ်ထားသည်။ ";
            e["ms"] = "Permainan kini telah dinyahdayakan";
            e["id"] = "Game saat ini telah dinonaktifkan";
            f.ErrorTextDic[36] = e;
            e = new Object;
            e["zh-cn"] = "您选择的游戏底注错误";
            e["zh-tw"] = "您选择的游戏底注错误";
            e["en"] = "Wrong ante on the game you selected";
            e["pr"] = "Valor de ante errado no jogo selecionado";
            e["vi"] = "Bạn chọn trò chơi số tiền cược thấp nhất  không đúng";
            e["hi"] = "आपके द्वारा चयनित खेल में गलत एंटी है";
            e["es"] = "Ante incorrecto en el juego que seleccionó";
            e["th"] = "เกมที่คุณเลือกมีเดิมพันที่ไม่ถูกต้อง";
            e["tl"] = "Maling ante sa larong pinili mo";
            e["my"] = "သင်ရွေးချယ်ထားသော ဂိမ်းအောက်ခြေလောင်းကြေးမှာ မှားနေပါသည်။";
            e["ms"] = "Ante permainan yang diseleksi anda salah";
            e["id"] = "Game yang Anda pilih memiliki taruhan yang salah";
            f.ErrorTextDic[37] = e;
            e = new Object;
            e["zh-cn"] = "游戏客户端类型不匹配";
            e["zh-tw"] = "游戏客户端类型不匹配";
            e["en"] = "Game client type mismatch";
            e["pr"] = "Incompatibilidade de tipo de cliente de jogo";
            e["vi"] = "Loại máy khách trò chơi không khớp";
            e["hi"] = "गेम क्लाइंट प्रकार असंगत है";
            e["es"] = "El tipo de cliente del juego no coincide";
            e["th"] = "ประเภทไคลเอนต์เกมไม่ตรงกัน";
            e["tl"] = "Hindi tugma ang uri ng kliyente ng laro";
            e["my"] = "ဂိမ်း client အမျိုးအစား မကိုက်ညီပါ။";
            e["ms"] = "Jenis aplikasi pelanggan permainan tidak bercocok";
            e["id"] = "Jenis klien game tidak cocok";
            f.ErrorTextDic[38] = e;
            e = new Object;
            e["zh-cn"] = "未找到正确的游戏配置数据";
            e["zh-tw"] = "未找到正确的游戏配置数据";
            e["en"] = "The correct game configuration data was not found";
            e["pr"] = "Os dados de configuração do jogo correto não foram encontrados";
            e["vi"] = "Không tìm thấy dữ liệu cấu hình trò chơi chính xác";
            e["hi"] = "सही खेल कॉन्फ़िगरेशन डेटा नहीं मिला";
            e["es"] = "Los datos de configuración del juego correctos no se encontraron";
            e["th"] = "ไม่พบข้อมูลการกำหนดค่าเกมที่ถูกต้อง";
            e["tl"] = "Hindi nakita ang tamang data ng configuration ng laro";
            e["my"] = "မှန်ကန်သော ဂိမ်းဖွဲ့စည်းပုံဒေတာကို ရှာမတွေ့ပါ။";
            e["ms"] = "Data konfigurasi permainan betul tidak ditemui";
            e["id"] = "Data konfigurasi game yang benar tidak ditemukan";
            f.ErrorTextDic[39] = e;
            e = new Object;
            e["zh-cn"] = "加入游戏失败，您选择的座位已经被其他玩家占用";
            e["zh-tw"] = "加入游戏失败，您选择的座位已经被其他玩家占用";
            e["en"] = "Failed to join the game, the seat you selected is already occupied by other players";
            e["pr"] = "Falha ao entrar no jogo, o assento selecionado já está ocupado por outros jogadores";
            e["vi"] = "Không thể tham gia trò chơi, vị trí bạn chọn đã có người chơi khác chiếm dụng";
            e["hi"] = "खेल में शामिल होने में विफल, आपके द्वारा चुनी गई सीट पहले से अन्य खिलाड़ियों द्वारा घेरी गई है";
            e["es"] = "No se ha podido unir al juego, el asiento que ha seleccionado ya está ocupado por otros jugadores";
            e["th"] = "ไม่สามารถเข้าร่วมเกมได้ ที่นั่งที่คุณเลือกมีผู้เล่นคนอื่นครอบครองแล้ว";
            e["tl"] = "Nabigong sumali sa laro, ang napili mong upuan ay inookupahan na ng ibang mga manlalaro";
            e["my"] = "ဂိမ်းတွင်ပါဝင်ခြင်း မအောင်မြင်ပါ၊ သင်ရွေးချယ်ထားသောထိုင်ခုံကို အခြားကစားသမားများက သိမ်းပိုက်ထားသည်။";
            e["ms"] = "Kegagalan menggabung ke dalam permainan, duduk yang dipilih anda telah digunakan oleh pemain lain";
            e["id"] = "Gagal bergabung dalam permainan. Kursi yang Anda pilih sudah ditempati oleh pemain lain.";
            f.ErrorTextDic[40] = e;
            e = new Object;
            e["zh-cn"] = "加入游戏失败，房间座位已满";
            e["zh-tw"] = "加入游戏失败，房间座位已满";
            e["en"] = "Failed to join the game, the room is full";
            e["pr"] = "Falha ao entrar no jogo, a sala está cheia";
            e["vi"] = "Không thể tham gia trò chơi, phòng đã đầy";
            e["hi"] = "खेल में शामिल होने में विफल, कमरा पूरा भरा हुआ है";
            e["es"] = "No se ha podido unir al juego, la sala está llena";
            e["th"] = "ไม่สามารถเข้าร่วมเกมได้ ห้องเต็ม";
            e["tl"] = "Nabigong sumali sa laro, puno ang kwarto";
            e["my"] = "ဂိမ်းတွင်ပါဝင်ခြင်း မအောင်မြင်သဖြင့် အခန်းထိုင်ခုံများ ပြည့်နေပါသည်။";
            e["ms"] = "Kegagalan menggabung permainan, duduk bilik telah penuh";
            e["id"] = "Gagal ikut permainan, ruangan penuh";
            f.ErrorTextDic[41] = e;
            e = new Object;
            e["zh-cn"] = "当前不是您的操作轮次";
            e["zh-tw"] = "当前不是您的操作轮次";
            e["en"] = "Not currently your turn";
            e["pr"] = "Não é a sua vez no momento";
            e["vi"] = "Hiện chưa đến lượt bạn thao tác";
            e["hi"] = "अभी आपकी बारी नहीं है";
            e["es"] = "Actualmente no es tu turno";
            e["th"] = "ปัจจุบันยังไม่ถึงรอบการดำเนินงานของคุณ";
            e["tl"] = "Hindi pa para sayo ang kasalukuyang laro";
            e["my"] = "ဒါဟာ မင်းရဲ့ လည်ပတ်မှု မဟုတ်ဘူး";
            e["ms"] = "Kini bukan giliran anda";
            e["id"] = "Ini bukan giliran operasi Anda saat ini";
            f.ErrorTextDic[42] = e;
            e = new Object;
            e["zh-cn"] = "管理网站验证码错误";
            e["zh-tw"] = "管理网站验证码错误";
            e["en"] = "Management website captcha error";
            e["pr"] = "Erro de captcha no site de gerenciamento";
            e["vi"] = "Lỗi captcha quản lý website";
            e["hi"] = "प्रबंधन वेबसाइट कैप्चा त्रुटि";
            e["es"] = "Error de captcha del sitio web de gestión";
            e["th"] = "ข้อผิดพลาดรหัสยืนยันเว็บไซต์การจัดการ";
            e["tl"] = "Error sa captcha ng website ng pamamahala";
            e["my"] = "ဝဘ်ဆိုက်အတည်ပြုကုဒ်အမှားကို စီမံပါ။";
            e["ms"] = "Kod pengesahan laman web pengurusan salah";
            e["id"] = "Kesalahan kode verifikasi situs web manajemen";
            f.ErrorTextDic[43] = e;
            e = new Object;
            e["zh-cn"] = "管理网站登陆IP不在白名单内";
            e["zh-tw"] = "管理网站登陆IP不在白名单内";
            e["en"] = "The login IP of the management website is not in the whitelist";
            e["pr"] = "O IP de login do site de gerenciamento não está na lista branca";
            e["vi"] = "IP đăng nhập của website quản lý không có trong whitelist";
            e["hi"] = "प्रबंधन वेबसाइट का लॉगिन IP सफेद सूची में नहीं है";
            e["es"] = "La IP de inicio de sesión del sitio web de gestión no está en la lista blanca";
            e["th"] = "IP การเข้าสู่ระบบเว็บไซต์การจัดการไม่อยู่ในรายการที่อนุญาต";
            e["tl"] = "Ang login IP ng website ng pamamahala ay wala sa whitelist";
            e["my"] = "စီမံခန့်ခွဲမှုဝဘ်ဆိုဒ် login ip သည် whitelist တွင်မရှိပါ။";
            e["ms"] = "IP logmasuk laman web pengurusan tidak ada di dalam senarai putih";
            e["id"] = "IP login situs web manajemen tidak ada dalam daftar putih";
            f.ErrorTextDic[44] = e;
            e = new Object;
            e["zh-cn"] = "用户登录凭证无效";
            e["zh-tw"] = "用户登录凭证无效";
            e["en"] = "Invalid user login credentials";
            e["pr"] = "Credenciais de login de utilizador inválidas";
            e["vi"] = "Thông tin xác thực đăng nhập của người dùng không hợp lệ.";
            e["hi"] = "अमान्य उपयोगकर्ता लॉगिन क्रेडेंशियल";
            e["es"] = "los datos del usuario no existen";
            e["th"] = "ข้อมูลรับรองการเข้าสู่ระบบของผู้ใช้ไม่ถูกต้อง";
            e["tl"] = "wala ang data ng user";
            e["my"] = "အသုံးပြုသူဒေတာမရှိပါ။";
            e["ms"] = "Bukti kelayakan log masuk pengguna tidak sah";
            e["id"] = "Kredensial login pengguna tidak valid";
            f.ErrorTextDic[45] = e;
            e = new Object;
            e["zh-cn"] = "服务器停服维护中，请在维护结束重新尝试进入游戏";
            e["zh-tw"] = "服务器停服维护中，请在维护结束重新尝试进入游戏";
            e["en"] = "The server has been shut down for maintenance, please wait until the maintenance is over and try to enter the game again";
            e["pr"] = "O servidor foi desligado para manutenção, por favor aguarde até que a manutenção termine e tente entrar no jogo novamente";
            e["vi"] = "Máy chủ đang bảo trì, vui lòng đợi bảo trì xong rồi thử vào lại game";
            e["hi"] = "सर्वर रखरखाव के लिए बंद है, कृपया रखर खाव समाप्त होने तक प्रतीक्षा करें और फिर खेल में प्रवेश करने का प्रयास करें";
            e["es"] = "El servidor ha sido cerrado por mantenimiento, por favor espere hasta que el mantenimiento haya terminado e intente entrar en el juego de nuevo";
            e["th"] = "เซิร์ฟเวอร์ปิดให้บริการเพื่อการบำรุงรักษา โปรดลองเข้าเกมอีกครั้งหลังจากการบำรุงรักษาเสร็จสิ้น";
            e["tl"] = "Na-shut down ang server para sa maintenance, mangyaring maghintay hanggang matapos ang maintenance at subukang pumasok muli sa laro";
            e["my"] = "ပြုပြင်ထိန်းသိမ်းမှုအတွက် ဆာဗာကို ရပ်ထားပါသည်၊ ပြုပြင်ထိန်းသိမ်းမှုအဆုံးတွင် ဂိမ်းကို ထပ်မံဝင်ရောက်ကြည့်ပါ။";
            e["ms"] = "Server ada di pemeliharaan, cuba semula untuk memasuki permainan selepas pemeliharaan tamat";
            e["id"] = "Server sedang tidak berfungsi untuk pemeliharaan. Silakan coba masuk ke dalam game lagi setelah pemeliharaan selesai.";
            f.ErrorTextDic[46] = e;
            e = new Object;
            e["zh-cn"] = "服务器平滑启动失败，没有找到对应的服务器连接";
            e["zh-tw"] = "服务器平滑启动失败，没有找到对应的服务器连接";
            e["en"] = "The server failed to start smoothly, and no corresponding server connection was found";
            e["pr"] = "O servidor falhou ao iniciar corretamente, e nenhuma conexão de servidor correspondente foi encontrada";
            e["vi"] = "Máy chủ khởi động không thành công, Không tìm thấy kết nối máy chủ tương ứng";
            e["hi"] = "सर्वर सुचारू रूप से शुरू नहीं हो पाया, और कोई संबंधित सर्वर कनेक्शन नहीं मिला";
            e["es"] = "El servidor no se inició sin problemas y no se encontró ninguna conexión de servidor correspondiente";
            e["th"] = "เซิร์ฟเวอร์ไม่สามารถเริ่มต้นได้อย่างราบรื่นและไม่พบการเชื่อมต่อเซิร์ฟเวอร์ที่เกี่ยวข้อง";
            e["tl"] = "Nabigo ang server na magsimula nang maayos, at walang nakitang katumbas na koneksyon sa server";
            e["my"] = "ဆာဗာသည် စတင်ခြင်းအား ချောမွေ့စေပြီး၊ သက်ဆိုင်ရာ ဆာဗာချိတ်ဆက်မှုကို ရှာမတွေ့ပါ။";
            e["ms"] = "Kegagalan menghidupkan server secara licin, sambungan server yang bercocok tidak ditemui";
            e["id"] = "Server gagal memulai dengan lancar dan tidak ditemukan koneksi server yang sesuai.";
            f.ErrorTextDic[47] = e;
            e = new Object;
            e["zh-cn"] = "聊天文字内容长度超过最大输入限制";
            e["zh-tw"] = "聊天文字内容长度超过最大输入限制";
            e["en"] = "Chat text content length exceeds the maximum input limit";
            e["pr"] = "O comprimento do conteúdo do texto de chat excede o limite máximo de entrada";
            e["vi"] = "Độ dài nội dung văn bản trò chuyện vượt quá giới hạn đầu vào tối đa";
            e["hi"] = "चैट टेक्स्ट सामग्री की लंबाई अधिकतम इनपुट सीमा से अधिक है";
            e["es"] = "La longitud del contenido del texto del chat supera el límite máximo de entrada";
            e["th"] = "ความยาวของข้อความแชทเกินขีดจำกัดการป้อนข้อมูลสูงสุด";
            e["tl"] = "Ang haba ng nilalaman ng text ng chat ay lumampas sa maximum na limitasyon sa pag-input";
            e["my"] = "ချတ်စာသား အကြောင်းအရာ အရှည်သည် အများဆုံး ထည့်သွင်းမှု ကန့်သတ်ချက်ထက် ကျော်လွန်နေပါသည်။";
            e["ms"] = "Kepanjangan kandungan pembincangan telah melebihi had maksimum ";
            e["id"] = "Panjang teks chat melebihi batas maksimal input";
            f.ErrorTextDic[48] = e;
            e = new Object;
            e["zh-cn"] = "未找到自定义游戏配置数据检查管理器";
            e["zh-tw"] = "未找到自定义游戏配置数据检查管理器";
            e["en"] = "No custom game configuration data check manager found";
            e["pr"] = "Não foi encontrado um gerente para verificar os dados de configuração do jogo personalizado";
            e["vi"] = "Không tìm thấy trình quản lý kiểm tra dữ liệu cấu hình trò chơi tùy chỉnh nào";
            e["hi"] = "कस्टम गेम कॉन्फ़िगरेशन डेटा जांच प्रबंधक नहीं मिला";
            e["es"] = "No se ha encontrado ningún gestor de comprobación de datos de configuración de juego";
            e["th"] = "ไม่พบตัวจัดการตรวจสอบข้อมูลการกำหนดค่าเกมแบบกำหนดเอง";
            e["tl"] = "Walang nakitang tagapamahala ng pagsusuri ng data ng custom na configuration ng laro";
            e["my"] = "စိတ်ကြိုက်ဂိမ်းဖွဲ့စည်းမှုပုံစံဒေတာစစ်ဆေးခြင်းမန်နေဂျာမတွေ့ပါ။";
            e["ms"] = "Alat pengurusan data konfigurasi permainan suai belum ditemui";
            e["id"] = "Manajer pemeriksaan data konfigurasi game khusus tidak ditemukan";
            f.ErrorTextDic[49] = e;
            e = new Object;
            e["zh-cn"] = "您创建的自定义游戏的总数达到最大值，\r\n无法创建新的游戏";
            e["zh-tw"] = "您创建的自定义游戏的总数达到最大值，\r\n无法创建新的游戏";
            e["en"] = "The total number of custom games you have created has reached the maximum, \r\n cannot create new games";
            e["pr"] = "O número total de jogos personalizados que você criou atingiu o máximo, \r\n não é possível criar novos jogos";
            e["vi"] = "Tổng số trò chơi tùy chỉnh bạn đã tạo đã đạt đến mức tối đa , Không thể tạo trò chơi mới";
            e["hi"] = "आपके द्वारा बनाए गए कस्टम गेमों की कुल संख्या अधिकतम पहुँच गई है, नए गेम नहीं बना सकते";
            e["es"] = "El número total de juegos personalizados que ha creado ha alcanzado el máximo, \r\n no puede crear nuevos juegos";
            e["th"] = "จำนวนเกมที่กำหนดเองทั้งหมดที่คุณสร้างถึงจำนวนสูงสุดแล้ว ไม่สามารถสร้างเกมใหม่ได้";
            e["tl"] = "Ang kabuuang bilang ng mga custom na laro na iyong nilikha ay umabot na sa maximum, \r\n ay hindi makakalikha ng mga bagong laro";
            e["my"] = "သင်ဖန်တီးထားသော စိတ်ကြိုက်ဂိမ်းစုစုပေါင်းအရေအတွက်သည် အမြင့်ဆုံးတန်ဖိုးသို့ရောက်ရှိသွားသည်၊ \r\n ဂိမ်းအသစ်ကို ဖန်တီး၍မရပါ။";
            e["ms"] = "Jumlah permainan suai yang diciptakan anda telah mencapai maksimumnya, \r\n tidak boleh menciptakan permainan baru";
            e["id"] = "Jumlah total game khusus yang Anda buat telah mencapai jumlah maksimum,\r\nTidak ada game baru yang dapat dibuat";
            f.ErrorTextDic[50] = e;
            e = new Object;
            e["zh-cn"] = "您在当前应用中创建的自定义游戏的数量达到最大值，无法创建新的游戏";
            e["zh-tw"] = "您在当前应用中创建的自定义游戏的数量达到最大值，无法创建新的游戏";
            e["en"] = "The number of custom games created in the current app has reached the maximum and you cannot create new games";
            e["pr"] = "O número de jogos personalizados criados no aplicativo atual atingiu o máximo e você não pode criar novos jogos";
            e["vi"] = "Bạn đã đạt đến số trò chơi tùy chỉnh tối đa được tạo trong ứng dụng hiện tại, Không thể tạo trò chơi mới";
            e["hi"] = "वर्तमान ऐप में आपके द्वारा बनाए गए कस्टम गेमों की अधिकतम संख्या पहुँच गई है, नए गेम नहीं बना सकते";
            e["es"] = "El número de juegos personalizados creados en la aplicación actual ha alcanzado el máximo y no puede crear nuevos juegos";
            e["th"] = "จำนวนเกมที่กำหนดเองที่คุณสร้างในแอปพลิเคชันปัจจุบันถึงขีดจำกัดสูงสุดแล้ว และไม่สามารถสร้างเกมใหม่ได้";
            e["tl"] = "Ang bilang ng mga custom na laro na ginawa sa kasalukuyang app ay umabot na sa maximum at hindi ka makakagawa ng mga bagong laro";
            e["my"] = "လက်ရှိအက်ပ်တွင် သင်ဖန်တီးသည့် စိတ်ကြိုက်ဂိမ်းအရေအတွက်သည် အမြင့်ဆုံးတန်ဖိုးသို့ရောက်ရှိပြီး ဂိမ်းအသစ်တစ်ခုကို ဖန်တီး၍မရပါ။";
            e["ms"] = "Jumlah permainan suai yang diciptakan anda di aplikasi kini telah mencapai maksimumnya, tidak boleh menciptakan permainan baru";
            e["id"] = "Jumlah permainan khusus yang Anda buat di aplikasi saat ini telah mencapai batas maksimum, dan permainan baru tidak dapat dibuat.";
            f.ErrorTextDic[51] = e;
            e = new Object;
            e["zh-cn"] = "您要查看的游戏回放数据不存在";
            e["zh-tw"] = "您要查看的游戏回放数据不存在";
            e["en"] = "The game replay data you are looking for does not exist";
            e["pr"] = "Os dados de replay do jogo que você está procurando não existem";
            e["vi"] = "Dữ liệu phát lại trò chơi bạn đang tìm kiếm không tồn tại";
            e["hi"] = "आपके द्वारा खोजी जा रही खेल पुनरावृत्ति डेटा मौजूद नहीं है";
            e["es"] = "Los datos de reproducción del juego que está buscando no existen";
            e["th"] = "ไม่มีข้อมูลการเล่นซ้ำเกมที่คุณต้องการดู";
            e["tl"] = "Ang data ng replay ng laro na iyong hinahanap ay wala";
            e["my"] = "သင်ကြည့်ရှုလိုသော ဂိမ်းပြန်ဖွင့်ခြင်းဒေတာ မရှိပါ။";
            e["ms"] = "Data main semula permainan yang anda mahu menonton tidak wujud";
            e["id"] = "Data replay game yang ingin Anda lihat tidak ada";
            f.ErrorTextDic[52] = e;
            e = new Object;
            e["zh-cn"] = "您已提出过该局游戏的举报，请勿重复提交";
            e["zh-tw"] = "您已提出过该局游戏的举报，请勿重复提交";
            e["en"] = "You have already submitted a report for this game, please do not submit it again";
            e["pr"] = "Você já enviou um relatório para este jogo, por favor, não envie novamente";
            e["vi"] = "Bạn đã gửi báo cáo cho trò chơi này, vui lòng không gửi lặp lại";
            e["hi"] = "आपने इस खेल के लिए पहले ही एक रिपोर्ट जमा कर दी है, कृपया फिर से जमा न करें";
            e["es"] = "Ya ha enviado un informe para este juego, por favor, no lo envíe de nuevo";
            e["th"] = "คุณได้ส่งรายงานสำหรับเกมนี้แล้ว โปรดอย่าส่งอีก";
            e["tl"] = "Nagsumite ka na ng ulat para sa larong ito, mangyaring huwag itong muling isumite";
            e["my"] = "သင်သည် ဂိမ်း၏ဂိမ်းကို အစီရင်ခံပြီးဖြစ်သည်၊ ကျေးဇူးပြု၍ ၎င်းကို ထပ်ခါတလဲလဲ မတင်ပါနှင့်";
            e["ms"] = "Anda telah menyerah laporan permainan pusingan ini, jangan serah lagi";
            e["id"] = "Anda sudah mengirimkan laporan untuk game ini, mohon jangan mengirimkannya lagi.";
            f.ErrorTextDic[53] = e;
            e = new Object;
            e["zh-cn"] = "只有参与该局游戏的玩家才可以发起举报";
            e["zh-tw"] = "只有参与该局游戏的玩家才可以发起举报";
            e["en"] = "Only players who participated in the game can initiate a report";
            e["pr"] = "Somente jogadores que participaram do jogo podem iniciar um relatório";
            e["vi"] = "Chỉ những người chơi đã tham gia trò chơi mới có thể gửi báo cáo";
            e["hi"] = "केवल उन खिलाड़ियों द्वारा रिपोर्ट दर्ज की जा सकती है जिन्होंने खेल में भाग लिया है";
            e["es"] = "Solo los jugadores que participaron en el juego pueden iniciar un informe";
            e["th"] = "เฉพาะผู้เล่นที่เข้าร่วมในเกมเท่านั้นที่สามารถเริ่มรายงานได้";
            e["tl"] = "Ang mga manlalaro lamang na lumahok sa laro ang maaaring magsimula ng isang ulat";
            e["my"] = "ဂိမ်းတွင်ပါဝင်သည့် ကစားသမားများသာ အစီရင်ခံစာကို စတင်နိုင်သည်။";
            e["ms"] = "Cuma pemain yang menyertai pusingan permainan ini baru melakukan laporan";
            e["id"] = "Hanya pemain yang berpartisipasi dalam permainan yang dapat memulai laporan";
            f.ErrorTextDic[54] = e;
            e = new Object;
            e["zh-cn"] = "您的余额不足，本场要求最低余额为：%d元";
            e["zh-tw"] = "您的余额不足，本场要求最低余额为：%d元";
            e["en"] = "Your balance is insufficient, the minimum balance required by this round is: %d yuan";
            e["pr"] = "Seu saldo é insuficiente, o saldo mínimo exigido por esta rodada é: %d yuan";
            e["vi"] = "Số dư của bạn không đủ, số dư tối thiểu mà trận này yêu cầu là: %d nhân dân tệ";
            e["hi"] = "आपका शेष राशि अपर्याप्त है, इस बाजार द्वारा आवश्यक न्यूनतम शेष राशि है: %d RS";
            e["es"] = "Su saldo es insuficiente, el saldo mínimo requerido por esta ronda es: %d yuan";
            e["th"] = "ยอดคงเหลือของคุณไม่เพียงพอ ยอดเงินขั้นต่ำที่จำเป็นสำหรับเกมนี้คือ: %d หยวน";
            e["tl"] = "Ang iyong balanse ay hindi sapat, ang minimum na balanse na kinakailangan ng round na ito ay: %d yuan";
            e["my"] = "သင့်လက်ကျန်ငွေ မလုံလောက်ပါက၊ ဤအကွက်အတွက် လိုအပ်သော အနည်းဆုံးလက်ကျန်မှာ- %d ယွမ်";
            e["ms"] = "Baki anda tak cukup, baki minimum yang diperlukan pusingan ini adalah: %d yuan";
            e["id"] = "Saldo Anda tidak mencukupi. Saldo minimum yang diperlukan untuk permainan ini adalah: %d yuan";
            f.ErrorTextDic[55] = e;
            e = new Object;
            e["zh-cn"] = "游戏匹配已成功，请耐心等待房间初始化完成";
            e["zh-tw"] = "游戏匹配已成功，请耐心等待房间初始化完成";
            e["en"] = "The game matching has been successful, please wait patiently for the room initialization to complete";
            e["pr"] = "A correspondência do jogo foi bem-sucedida, por favor, aguarde pacientemente a inicialização da sala para ser concluída";
            e["vi"] = "Ghép game đã thành công, vui lòng kiên nhẫn chờ quá trình khởi tạo phòng hoàn tất";
            e["hi"] = "खेल मिलान सफल रहा है, कृपया कमरे के आरंभीकरण के पूरा होने की प्रतीक्षा करें";
            e["es"] = "La coincidencia del juego ha sido exitosa, por favor espere pacientemente a que se complete la inicialización de la sala";
            e["th"] = "การจับคู่เกมสำเร็จแล้ว โปรดรออย่างอดทนเพื่อให้การเริ่มต้นห้องเสร็จสิ้น";
            e["tl"] = "Naging matagumpay ang pagtutugma ng laro, mangyaring matiyagang maghintay para makumpleto ang pagsisimula ng kwarto";
            e["my"] = "ဂိမ်းကိုက်ညီမှု အောင်မြင်ပြီးပြီ၊ အခန်းကို စတင်လုပ်ဆောင်ရန် စိတ်ရှည်စွာ စောင့်ပါ။";
            e["ms"] = "Kejayaan mencocokkan permainan, tunggu sabar sehingga permulaan bilik selesai";
            e["id"] = "Pencocokan game telah berhasil, harap tunggu dengan sabar hingga inisialisasi ruangan selesai.";
            f.ErrorTextDic[56] = e;
            e = new Object;
            e["zh-cn"] = "匹配失败已经加入过其他匹配队列";
            e["zh-tw"] = "匹配失败已经加入过其他匹配队列";
            e["en"] = "Matching failed, you already joined other matching queues";
            e["pr"] = "Falha na correspondência, você já juntou outras filas de correspondência";
            e["vi"] = "Ghép game thất bại , đã tham gia xếp hàng đợi phù hợp khác";
            e["hi"] = "मिलान विफल रहा क्योंकि पहले ही अन्य मिलान कतारों में शामिल हो चुके हैं";
            e["es"] = "Error al emparejar, ya se ha unido a otras colas de emparejamiento";
            e["th"] = "การจับคู่ล้มเหลว เข้าร่วมคิวที่ตรงกันอื่นแล้ว";
            e["tl"] = "Nabigo ang pagtutugma, sumali ka na sa iba pang tumutugmang pila";
            e["my"] = "ပွဲစဉ်မအောင်မြင်ပါက အခြားကိုက်ညီသောတန်းစီများပါ၀င်သည်။";
            e["ms"] = "Kegagalan mencocokkan, pernah menyertai barisan cocokan lainnya";
            e["id"] = "Pencocokan gagal. Sudah bergabung dengan antrean pencocokan lainnya.";
            f.ErrorTextDic[57] = e;
            e = new Object;
            e["zh-cn"] = "玩家匹配基础配置数据错误";
            e["zh-tw"] = "玩家匹配基础配置数据错误";
            e["en"] = "Player matchmaking base configuration data error";
            e["pr"] = "Erro nos dados de configuração básica de correspondência de jogadores";
            e["vi"] = "Lỗi dữ liệu cấu hình cơ sở ghép nười chơi";
            e["hi"] = "खिलाड़ी मैचमेकिंग बेस कॉन्फ़िगरेशन डेटा त्रुटि";
            e["es"] = "Error de datos de configuración de base de emparejamiento de jugador";
            e["th"] = "ผู้เล่นตรงกับข้อมูลการกำหนดค่าพื้นฐานผิดพลาด";
            e["tl"] = "Error sa data ng configuration ng base ng matchmaking ng player";
            e["my"] = "အခြေခံဖွဲ့စည်းပုံဒေတာနှင့် ကိုက်ညီသော ကစားသမား";
            e["ms"] = "Data konfigurasi data yang dicocok pemain salah";
            e["id"] = "Kesalahan data konfigurasi dasar pencocokan pemutar";
            f.ErrorTextDic[58] = e;
            e = new Object;
            e["zh-cn"] = "操作无效，当前游戏已经结束";
            e["zh-tw"] = "操作无效，当前游戏已经结束";
            e["en"] = "The game is over and cannot be operated";
            e["pr"] = "O jogo acabou e não pode ser operado";
            e["vi"] = "Trò chơi đã kết thúc, không thể thao tác";
            e["hi"] = "खेल समाप्त हो चुका है और संचालित नहीं किया जा सकता";
            e["es"] = "El juego ha terminado y no se puede operar";
            e["th"] = "การดำเนินการไม่ถูกต้อง เกมปัจจุบันสิ้นสุดลงแล้ว";
            e["tl"] = "Tapos na ang laro at hindi na mapapatakbo";
            e["my"] = "လုပ်ဆောင်ချက်သည် မမှန်ကန်ပါ၊ လက်ရှိဂိမ်း ပြီးဆုံးသွားပါပြီ။လ";
            e["ms"] = "Pengoperasian tidak sah, permainan kini telah tamat";
            e["id"] = "Operasi ini tidak valid, permainan saat ini telah berakhir";
            f.ErrorTextDic[59] = e;
            e = new Object;
            e["zh-cn"] = "操作无效，系统停服维护中";
            e["zh-tw"] = "操作无效，系统停服维护中";
            e["en"] = "The systen is shut down for maintenance and the game operation cannot be performed";
            e["pr"] = "O sistema está desligado para manutenção e a operação do jogo não pode ser realizada";
            e["vi"] = "Không thể thao tác, hệ thống ngừng phục vụ đang bảo trì";
            e["hi"] = "पृष्ठभूमि सेवा बंद है, और खेल संचालन नहीं किया जा सकता";
            e["es"] = "El sistema está apagado por mantenimiento y no se puede realizar la operación del juego";
            e["th"] = "การดำเนินการไม่ถูกต้อง และระบบไม่สามารถให้บริการเพื่อการบำรุงรักษาได้";
            e["tl"] = "Ang systen ay isinara para sa pagpapanatili at ang pagpapatakbo ng laro ay hindi maisagawa";
            e["my"] = "လုပ်ဆောင်ချက်သည် မမှန်ကန်ပါ၊ ပြုပြင်ထိန်းသိမ်းမှုအတွက် စနစ်ကို ရပ်ထားသည်။";
            e["ms"] = "Pengoperasian tidak sah, sistem sedang dipelihara";
            e["id"] = "Operasi ini tidak valid dan sistem tidak dapat digunakan untuk pemeliharaan.";
            f.ErrorTextDic[60] = e;
            e = new Object;
            e["zh-cn"] = "操作无效，请在动画播放结束后再次尝试";
            e["zh-tw"] = "操作无效，请在动画播放结束后再次尝试";
            e["en"] = "Animation is playing and the game operation cannot be performed. Please try again later";
            e["pr"] = "A animação está em andamento e a operação do jogo não pode ser realizada. Por favor, tente novamente mais tarde";
            e["vi"] = "Không thể thao tác,vui lòng thử lại sau khi phát ảnh động kết thúc";
            e["hi"] = "खेल विभिन्न एनिमेशन कर रहा है, और खेल संचालन नहीं किया जा सकता";
            e["es"] = "La animación se está reproduciendo y la operación del juego no se puede realizar. Por favor, vuelva a intentar más tarde";
            e["th"] = "การดำเนินการไม่ถูกต้อง โปรดลองอีกครั้งหลังจากภาพเคลื่อนไหวสิ้นสุดลง";
            e["tl"] = "Naglalaro ang animation at hindi maisagawa ang operasyon ng laro. Subukang muli mamaya";
            e["my"] = "လုပ်ဆောင်ချက်သည် မမှန်ကန်ပါ၊ ကာတွန်းပြီးဆုံးပြီးနောက် ထပ်စမ်းကြည့်ပါ။";
            e["ms"] = "Pengoperasian tidak sah, cuba selepas rekaman animasi tamat";
            e["id"] = "Operasi ini tidak valid, silakan coba lagi setelah animasi berakhir.";
            f.ErrorTextDic[61] = e;
            e = new Object;
            e["zh-cn"] = "游戏未开局，无法进行操作";
            e["zh-tw"] = "游戏未开局，无法进行操作";
            e["en"] = "The game has not started yet, and the game operation cannot be performed";
            e["pr"] = "O jogo ainda não começou e a operação do jogo não pode ser realizada";
            e["vi"] = "Trò chơi chưa bắt đầu ,không thể thực hiện thao tác trò chơi";
            e["hi"] = "खेल अभी शुरू नहीं हुआ है, और खेल संचालन नहीं किया जा सकता";
            e["es"] = "El juego aún no ha comenzado y no se puede realizar la operación del juego";
            e["th"] = "เกมยังไม่เริ่มและไม่สามารถดำเนินการได้";
            e["tl"] = "Hindi pa nagsisimula ang laro, at hindi maisagawa ang operasyon ng laro";
            e["my"] = "ဂိမ်းမစတင်သေးဘဲ လည်ပတ်၍မရပါ။";
            e["ms"] = "Permainan belum dimulai, tidak boleh melakukan pengoperasian";
            e["id"] = "Permainan belum dimulai dan tidak dapat dioperasikan.";
            f.ErrorTextDic[62] = e;
            e = new Object;
            e["zh-cn"] = "当前玩家不在游戏中，无法进行操作";
            e["zh-tw"] = "当前玩家不在游戏中，无法进行操作";
            e["en"] = "This player is not in the game and cannot perform game operations";
            e["pr"] = "Este jogador não está no jogo e não pode realizar operações de jogo";
            e["vi"] = "Người chơi này không có trong trò chơi ,không thể thực hiện thao tác ";
            e["hi"] = "यह खिलाड़ी खेल में नहीं है और खेल संचालन नहीं कर सकता";
            e["es"] = "Este jugador no está en el juego y no puede realizar operaciones de juego";
            e["th"] = "ผู้เล่นปัจจุบันไม่ได้อยู่ในเกมและไม่สามารถดำเนินการได้";
            e["tl"] = "Ang player na ito ay wala sa laro at hindi maaaring magsagawa ng mga operasyon ng laro";
            e["my"] = "လက်ရှိကစားသမားသည် ဂိမ်းတွင်မရှိသည့်အပြင် လည်ပတ်၍မရပါ။";
            e["ms"] = "Pemain kini tidak ada di dalam permainan, tidak boleh melakukan pengoperasian";
            e["id"] = "Pemain saat ini tidak ada dalam permainan dan tidak dapat melakukan operasi.";
            f.ErrorTextDic[63] = e;
            e = new Object;
            e["zh-cn"] = "尚未轮到当前玩家操作";
            e["zh-tw"] = "尚未轮到当前玩家操作";
            e["en"] = "It is not the turn for the current player";
            e["pr"] = "Não é a vez do jogador atual";
            e["vi"] = "Vẫn chưa đến lượt người chơi hiện tại thao tác";
            e["hi"] = "वर्तमान खिलाड़ी के लिए कोई संचालन नहीं";
            e["es"] = "No es el turno para el jugador actual";
            e["th"] = "ยังไม่ถึงตาของผู้เล่นคนปัจจุบัน";
            e["tl"] = "Hindi ito ang tamang oras para sa kasalukuyang manlalaro";
            e["my"] = "၎င်းသည် လက်ရှိကစားသမား၏ လည်ပတ်ရန်အလှည့်မဟုတ်ပေ။";
            e["ms"] = "Tidak ada operasi untuk pemain kini";
            e["id"] = "Ini belum giliran pemain saat ini";
            f.ErrorTextDic[64] = e;
            e = new Object;
            e["zh-cn"] = "这个房间已经解散了";
            e["zh-tw"] = "这个房间已经解散了";
            e["en"] = "This room has been dismissed";
            e["pr"] = "Esta sala foi descartada";
            e["vi"] = "Phòng này đã bị giải tán";
            e["hi"] = "यह कमरा भंग कर दिया गया है";
            e["es"] = "Esta habitación ha sido despedida";
            e["th"] = "ห้องนี้ถูกยุบแล้ว";
            e["tl"] = "Na-dismiss na ang kwartong ito.";
            e["my"] = "ဒီအခန်းကို ဖျက်သိမ်းလိုက်ပါပြီ။";
            e["ms"] = "Bilik ini telah dibubarkan";
            e["id"] = "Ruangan ini telah dibubarkan";
            f.ErrorTextDic[65] = e;
            e = new Object;
            e["zh-cn"] = "投注金额错误";
            e["zh-tw"] = "投注金额错误";
            e["en"] = "Wrong betting amount";
            e["pr"] = "Valor da aposta errado";
            e["vi"] = "Số tiền đặt cược sai";
            e["hi"] = "गलत बेटिंग राशि";
            e["es"] = "Importe de apuesta incorrecto";
            e["th"] = "จำนวนเงินเดิมพันไม่ถูกต้อง";
            e["tl"] = "Maling halaga ng pagtaya";
            e["my"] = "မှားယွင်းသောလောင်းကစားပမာဏ";
            e["ms"] = "Amaun taruhan salah";
            e["id"] = "Jumlah taruhan salah";
            f.ErrorTextDic[66] = e;
            e = new Object;
            e["zh-cn"] = "投注金额超过上限";
            e["zh-tw"] = "投注金额超过上限";
            e["en"] = "The betting amount exceeds the upper limit";
            e["pr"] = "O valor da aposta excede o limite superior";
            e["vi"] = "Số tiền đặt cược vượt quá giới hạn trên";
            e["hi"] = "बेटिंग राशि ऊपरी सीमा से अधिक है";
            e["es"] = "El importe de la apuesta supera el límite superior";
            e["th"] = "จำนวนเงินเดิมพันเกินขีดจำกัดบน";
            e["tl"] = "Ang halaga ng pagtaya ay lumampas sa itaas na limitasyon";
            e["my"] = "လောင်းကစားပမာဏသည် အထက်ကန့်သတ်ချက်ထက် ကျော်လွန်နေပါသည်။";
            e["ms"] = "Amaun taruhan telah melebihi had atas";
            e["id"] = "Jumlah taruhan melebihi batas atas";
            f.ErrorTextDic[67] = e;
            e = new Object;
            e["zh-cn"] = "您的投注余额不足";
            e["zh-tw"] = "您的投注余额不足";
            e["en"] = "Your betting balance is insufficient";
            e["pr"] = "Seu saldo de apostas é insuficiente";
            e["vi"] = "Số dư đặt cược của bạn không đủ";
            e["hi"] = "आपकी बेटिंग शेष राशि अपर्याप्त है";
            e["es"] = "Su saldo de apuestas es insuficiente";
            e["th"] = "ยอดเดิมพันของคุณไม่เพียงพอ";
            e["tl"] = "Ang iyong balanse sa pagtaya ay hindi sapat";
            e["my"] = "သင်၏လောင်းကြေးလက်ကျန်သည် မလုံလောက်ပါ။";
            e["ms"] = "Baki taruhan anda tidak cukup";
            e["id"] = "Saldo taruhan Anda tidak mencukupi";
            f.ErrorTextDic[68] = e;
            e = new Object;
            e["zh-cn"] = "您现在已经是庄家请等待游戏结束后重新上庄";
            e["zh-tw"] = "您现在已经是庄家请等待游戏结束后重新上庄";
            e["en"] = "You are now the banker, please wait for game over and re-become the banker";
            e["pr"] = "Você é o banco e por favor espere o jogo acabar e tornar-se o banco novamente";
            e["vi"] = "Bây giờ bạn đã là nhà cái, Vui lòng đợi cho đến khi trò chơi kết thúc và vào lại nhà cái";
            e["hi"] = "आप अभी बैंकर हैं, कृपया खेल के समाप्त होने का इंतजार करें और फिर से बैंकर बनें";
            e["es"] = "Ahora usted es el banquero, por favor espere a que termine el juego y vuelva a ser el banquero";
            e["th"] = "ตอนนี้คุณเป็นเจ้ามือแล้ว โปรดรอจนกว่าเกมจะจบลงเพื่อกลับเข้าครองเจ้ามืออีกครั้ง";
            e["tl"] = "Ikaw na ngayon ang tagabangko, mangyaring hintayin ang laro matapos at muling maging tagabangko";
            e["my"] = "သင်သည် ယခု banker ဖြစ်နေပြီ၊ ဂိမ်းပြန်ပြီးရန် စောင့်ပါ။";
            e["ms"] = "Sekarang anda telah menjadi dealer, tunggu sehingga permainan tamat sebelum memasuki lagi untuk banker";
            e["id"] = "Anda sekarang adalah bankir. Harap tunggu hingga permainan selesai untuk masuk kembali ke bankir.";
            f.ErrorTextDic[69] = e;
            e = new Object;
            e["zh-cn"] = "您的上庄金额低于最低上庄要求金额";
            e["zh-tw"] = "您的上庄金额低于最低上庄要求金额";
            e["en"] = "Your bankroll amount is lower than the minimum bankroll requirement";
            e["pr"] = "O valor do seu banco é inferior ao requisito mínimo de banco";
            e["vi"] = "Số tiền nhà cái của bạn thấp hơn yêu cầu nhà cái tối thiểu";
            e["hi"] = "आपकी बैंकरोल राशि न्यूनतम बैंकरोल आवश्यकता से कम है";
            e["es"] = "La cantidad de su bankroll es inferior al requisito mínimo de bankroll";
            e["th"] = "จำนวนเงินของคุณต่ำกว่าข้อกำหนดขั้นต่ำในการเป็นเจ้ามือ";
            e["tl"] = "Ang halaga ng iyong bankroll ay mas mababa kaysa sa minimum na kinakailangan ng bankroll";
            e["my"] = "သင်၏ bankroll ပမာဏသည် အနိမ့်ဆုံး bankroll လိုအပ်သောပမာဏထက် နိမ့်ပါသည်။";
            e["ms"] = "Amaun bankroll anda kurang daripada amaun maksimum persyaratan";
            e["id"] = "Jumlah pendanaan Anda lebih rendah dari persyaratan minimum pendanaan";
            f.ErrorTextDic[70] = e;
            e = new Object;
            e["zh-cn"] = "您的上庄金额高于最高上庄要求金额";
            e["zh-tw"] = "您的上庄金额高于最高上庄要求金额";
            e["en"] = "Your bankroll amount is higher than the maximum bankroll requirement";
            e["pr"] = "O valor do seu banco é superior ao requisito máximo de banco";
            e["vi"] = "Số tiền nhà cái của bạn cao hơn yêu cầu nhà cái tối thiểu";
            e["hi"] = "आपकी बैंकरोल राशि अधिकतम बैंकरोल आवश्यकता से अधिक है";
            e["es"] = "La cantidad de tu bankroll es mayor que el requisito máximo de bankroll";
            e["th"] = "จำนวนเงินเดิมพันของคุณสูง กว่าจำนวนเงินเดิมพันสูงสุดที่ต้องการ";
            e["tl"] = "Ang halaga ng iyong bankroll ay mas mataas kaysa sa maximum na kinakailangan ng bankroll";
            e["my"] = "သင်၏ bankroll ပမာဏသည် အများဆုံး bankroll လိုအပ်သောပမာဏထက် မြင့်ပါသည်။";
            e["ms"] = "Amaun bankroll anda melebihi daripada amaun maksimum persyaratan";
            e["id"] = "Jumlah taruhan Anda lebih tinggi dari jumlah taruhan maksimum yang diperlukan";
            f.ErrorTextDic[71] = e;
            e = new Object;
            e["zh-cn"] = "您已经处于上庄队列中";
            e["zh-tw"] = "您已经处于上庄队列中";
            e["en"] = "You are already in the banker queue";
            e["pr"] = "Você já está na fila de banco";
            e["vi"] = "Bạn đã ở trong danh sách nhà cái";
            e["hi"] = "आप पहले से कतार में हैं";
            e["es"] = "Ya está en la cola de la banca";
            e["th"] = "คุณอยู่ในคิวการเดิมพันแล้ว";
            e["tl"] = "Nasa banker queue ka na";
            e["my"] = "သင်သည် bankroll တန်းစီတွင်ရှိနေပြီဖြစ်သည်။";
            e["ms"] = "Anda telah ada di barisan dealer";
            e["id"] = "Anda sudah berada dalam antrian taruhan";
            f.ErrorTextDic[72] = e;
            e = new Object;
            e["zh-cn"] = "上庄队列已满请稍后申请上庄";
            e["zh-tw"] = "上庄队列已满请稍后申请上庄";
            e["en"] = "The banker queue is full, please apply for becoming the banker later";
            e["pr"] = "A fila de banco está cheia, por favor, solicite para se tornar o banco mais tarde";
            e["vi"] = "Danh sách nhà cái đã đầy, vui lòng đăng ký nhà cái sau";
            e["hi"] = "डीलरशिप कतार पूरी भरी हुई है, कृपया बाद में डीलरशिप के लिए आवेदन करें";
            e["es"] = "La cola del banquero está llena, por favor, solicite convertirse en el banquero más tarde";
            e["th"] = "คิวลงประกาศเต็มแล้ว กรุณาสมัครภายหลัง";
            e["tl"] = "Puno na ang pila ng bangkero, mangyaring mag-apply para maging tagabangko mamaya";
            e["my"] = "bankroll ၏တန်းစီသည်ပြည့်နေပြီ၊ ကျေးဇူးပြု၍ bankroll ကိုနောက်မှလျှောက်ထားပါ။";
            e["ms"] = "Barisan dealer telah penuh, mohon sebentar lagi";
            e["id"] = "Antrian untuk mendaftar sudah penuh. Silakan mengajukan permohonan untuk mendaftar nanti.";
            f.ErrorTextDic[73] = e;
            e = new Object;
            e["zh-cn"] = "您的余额不足无法上";
            e["zh-tw"] = "您的余额不足无法上";
            e["en"] = "Your balance is insufficient and application failed.";
            e["pr"] = "Seu saldo é insuficiente e a solicitação falhou.";
            e["vi"] = "Số dư của bạn không đủ";
            e["hi"] = "आपका शेष राशि अपर्याप्त है";
            e["es"] = "Su saldo es insuficiente y la aplicación falló.";
            e["th"] = "ยอดคงเหลือของคุณไม่เพียงพอและคุณไม่สามารถเป็นเจ้ามือได้";
            e["tl"] = "Hindi sapat ang iyong balanse at nabigo ang aplikasyon.";
            e["my"] = "သင်၏လက်ကျန်ငွေသည် ဝင်ရောက်ရန် မလုံလောက်ပါ။";
            e["ms"] = "Baki anda tak cukup";
            e["id"] = "Saldo Anda tidak mencukupi dan Anda tidak dapat mengunggah";
            f.ErrorTextDic[74] = e;
            e = new Object;
            e["zh-cn"] = "您没有加入过上庄队列 ";
            e["zh-tw"] = "您没有加入过上庄队列 ";
            e["en"] = "You have not joined the banker queue";
            e["pr"] = "Você não entrou na fila de banco";
            e["vi"] = "Bạn chưa tham gia danh sách của nhà cái";
            e["hi"] = "आप शांग्झूआंग कतार में शामिल नहीं हुए हैं";
            e["es"] = "No se ha unido a la cola de la banca";
            e["th"] = "คุณยังไม่ได้เข้าร่วมคิวเจ้ามือ";
            e["tl"] = "Hindi ka sumali sa pila ng bangkero";
            e["my"] = "သင်သည် bankroll တန်းစီတွင် မပါဝင်ခဲ့ပါ။";
            e["ms"] = "Anda tak pernah menyertai barisan dealer";
            e["id"] = "Anda belum bergabung dengan antrean Zhuangzhuang";
            f.ErrorTextDic[75] = e;
            e = new Object;
            e["zh-cn"] = "加入房间失败游戏已达最大人数限制";
            e["zh-tw"] = "加入房间失败游戏已达最大人数限制";
            e["en"] = "Failed to join the room. The players in the game has reached the maximum number";
            e["pr"] = "Falha ao entrar na sala. O número de jogadores no jogo atingiu o máximo";
            e["vi"] = "Không thể tham gia phòng, Trò chơi đã đạt đến số lượng người tối đa";
            e["hi"] = "कमरे में शामिल होने में विफल, खेल ने अधिकतम लोगों की संख्या पहुँच गई है";
            e["es"] = "No se ha podido unir a la sala. Los jugadores en el juego han alcanzado el número máximo";
            e["th"] = "เข้าร่วมห้องไม่สำเร็จ เกมมีผู้เล่นถึงขีดจำกัดสูงสุดแล้ว";
            e["tl"] = "Nabigong sumali sa kwarto para sa laro. Ang mga manlalaro ay umabot sa maximum na bilang";
            e["my"] = "အခန်းတွင်ပါဝင်ရန် ပျက်ကွက်သည့်ဂိမ်းသည် အများဆုံးလူအရေအတွက်ကန့်သတ်ချက်သို့ ရောက်ရှိသွားပါသည်။";
            e["ms"] = "Kegagalan menggabung ke bilik kerana telah mencapai had pemain maksimum";
            e["id"] = "Gagal bergabung ke ruangan. Permainan telah mencapai jumlah maksimum orang.";
            f.ErrorTextDic[76] = e;
            e = new Object;
            e["zh-cn"] = "百人场游戏参数配置错误 ";
            e["zh-tw"] = "百人场游戏参数配置错误 ";
            e["en"] = "Hundred-person game parameter configuration error";
            e["pr"] = "Erro de configuração do parâmetro do jogo de centenas de pessoas";
            e["vi"] = "Lỗi cấu hình tham số trò chơi trận trăm người";
            e["hi"] = "सैकड़ों गेम पैरामीटर कॉन्फ़िगरेशन त्रुटि";
            e["es"] = "Error de configuración de parámetro de juego de cien personas";
            e["th"] = "เกิดข้อผิดพลาดในการกำหนดค่าพารามิเตอร์เกมรอบร้อยคน";
            e["tl"] = "Error sa configuration ng parameter ng laro ng daang tao";
            e["my"] = "လူ 100 အကွက်ဂိမ်းဘောင်များကို မှားယွင်းသတ်မှတ်ထားသည်။";
            e["ms"] = "Konfigurasi parameter permainan ratusan salah";
            e["id"] = "Kesalahan konfigurasi parameter game ratusan orang";
            f.ErrorTextDic[77] = e;
            e = new Object;
            e["zh-cn"] = "您是庄家不可以投注";
            e["zh-tw"] = "您是庄家不可以投注";
            e["en"] = "You are the banker and cannot bet";
            e["pr"] = "Você é o banco e não pode apostar";
            e["vi"] = "Bạn là nhà cái và không thể đặt cược";
            e["hi"] = "आप पुस्तककर्ता हैं और शर्त नहीं लगा सकते";
            e["es"] = "Usted es el banquero y no puede apostar";
            e["th"] = "คุณเป็นนายเจ้ามือและไม่สามารถวางเดิมพันได้";
            e["tl"] = "Ikaw ang tagabangko at hindi makakapusta";
            e["my"] = "သင်သည် စာရင်းသွင်းသူဖြစ်ပြီး လောင်းကစား၍မရပါ။";
            e["ms"] = "Anda adalah dealer dan tidak boleh menaruh";
            e["id"] = "Anda adalah seorang bankir dan tidak dapat memasang taruhan";
            f.ErrorTextDic[78] = e;
            e = new Object;
            e["zh-cn"] = "此区域投注已满，对应区域投注增加后方可继续投注";
            e["zh-tw"] = "此区域投注已满，对应区域投注增加后方可继续投注";
            e["en"] = "The betting in this area is full, and the betting can only be continued after the betting in the corresponding area is increased";
            e["pr"] = "A área de apostas está cheia, e as apostas só podem ser continuadas após o aumento das apostas na área correspondente";
            e["vi"] = "Đặt cược trong khu vực này đã đầy và chỉ có thể tiếp tục đặt cược trong khu vực tương ứng sau khi tăng cược trong khu vực tương ứng";
            e["hi"] = "इस क्षेत्र में बेटिंग भरी हुई है, और संबंधित क्षेत्र में बेटिंग बढ़ाए जाने के बाद ही बेटिंग जारी रखी जा सकती है";
            e["es"] = "Las apuestas en esta área están completas, y las apuestas solo pueden continuar después de que se aumente la apuesta en el área correspondiente";
            e["th"] = "การเดิมพันในพื้นที่นี้เต็มแล้ว คุณสามารถเดิมพันต่อได้หลังจากที่เพิ่มการเดิมพันในพื้นที่ที่เกี่ยวข้องแล้วเท่านั้น";
            e["tl"] = "Ang pagtaya sa lugar na ito ay puno na, at ang pagtaya ay maaari lamang ipagpatuloy pagkatapos tumaas ang pagtaya sa kaukulang lugar";
            e["my"] = "ဤဧရိယာရှိ အလောင်းအစားများ ပြည့်နေပြီး သက်ဆိုင်ရာ ဧရိယာလောင်းကစားသည် ဆက်လက်လောင်းနိုင်သည်။";
            e["ms"] = "Pertaruhan di rantau ini telah penuh, pertaruhan baru diteruskan selepas pertaruhan di rantau sesuainya ditambah";
            e["id"] = "Taruhan di area ini sudah penuh. Anda dapat terus bertaruh hanya setelah taruhan di area terkait ditingkatkan.";
            f.ErrorTextDic[79] = e;
            e = new Object;
            e["zh-cn"] = "玩家收藏游戏条数已达最大值";
            e["zh-tw"] = "玩家收藏游戏条数已达最大值";
            e["en"] = "The player's favorite games have reached the maximum number";
            e["pr"] = "Os jogos favoritos do jogador atingiram o número máximo";
            e["vi"] = "Trò chơi yêu thích của người chơi đã đạt đến số lượng tối đa";
            e["hi"] = "खिलाड़ी के पसंदीदा खेलों की अधिकतम संख्या पहुँच गई है";
            e["es"] = "Los juegos favoritos del jugador han alcanzado el número máximo";
            e["th"] = "เกมที่ผู้เล่นรวบรวมได้ถึงจำนวนสูงสุดแล้ว";
            e["tl"] = "Ang mga paboritong laro ng manlalaro ay umabot na sa pinakamataas na bilang";
            e["my"] = "ကစားသမားများ စုဆောင်းထားသော ဂိမ်းအရေအတွက်သည် အမြင့်ဆုံးတန်ဖိုးသို့ ရောက်ရှိသွားပါသည်။";
            e["ms"] = "Kuantiti batang permainan yang disimpan oleh pemain telah mencapai maksimumnya";
            e["id"] = "Jumlah permainan yang dikumpulkan pemain telah mencapai nilai maksimal.";
            f.ErrorTextDic[80] = e;
            e = new Object;
            e["zh-cn"] = "游戏开奖结果数据未找到";
            e["zh-tw"] = "游戏开奖结果数据未找到";
            e["en"] = "Game lottery result data not found";
            e["pr"] = "Dados do resultado da loteria do jogo não encontrados";
            e["vi"] = "Không tìm thấy dữ liệu kết quả mở thưởng trò chơi";
            e["hi"] = "खेल लॉटरी परिणाम डेटा नहीं मिला";
            e["es"] = "Datos del resultado de la lotería del juego no encontrados";
            e["th"] = "ไม่พบข้อมูลผลการออกรางวัลลอตเตอรีเกม";
            e["tl"] = "Hindi nakita ang data ng resulta ng lottery ng laro";
            e["my"] = "ဂိမ်းထီရလဒ်ဒေတာကို ရှာမတွေ့ပါ။";
            e["ms"] = "Data hasil pencabutan permainan belum ditemui";
            e["id"] = "Data hasil undian permainan tidak ditemukan";
            f.ErrorTextDic[81] = e;
            e = new Object;
            e["zh-cn"] = "操作失败，游戏阶段已经转换";
            e["zh-tw"] = "操作失败，游戏阶段已经转换";
            e["en"] = "Operation failed, game phase has been switched";
            e["pr"] = "Operação falhou, a fase do jogo foi alternada";
            e["vi"] = "Thao tác không thành công, giai đoạn trò chơi đã được chuyển đổi";
            e["hi"] = "संचालन विफल, खेल चरण बदल गया है";
            e["es"] = "Error en la operación, la fase de juego se ha cambiado";
            e["th"] = "การดำเนินการล้มเหลวและขั้นตอนของเกมมีการเปลี่ยนแปลง";
            e["tl"] = "Nabigo ang operasyon, ang yugto ng laro ay inilipat";
            e["my"] = "လုပ်ဆောင်ချက် မအောင်မြင်ပါ၊ ဂိမ်းအဆင့်ကို ပြောင်းလဲလိုက်ပါပြီ။";
            e["ms"] = "Kegagalan beroperasi, tahap permainan telah dialihkan";
            e["id"] = "Operasi gagal dan panggung permainan telah diubah.";
            f.ErrorTextDic[82] = e;
            e = new Object;
            e["zh-cn"] = "操作失败，投注金额不符合要求";
            e["zh-tw"] = "操作失败，投注金额不符合要求";
            e["en"] = "The operation failed, the betting amount does not meet the requirements";
            e["pr"] = "A operação falhou, o valor da aposta não atende aos requisitos";
            e["vi"] = "Thao tác không thành công, số tiền đặt cược không đạt yêu cầu";
            e["hi"] = "संचालन विफल, बेटिंग राशि आवश्यकताओं को पूरा नहीं करती";
            e["es"] = "La operación ha fallado, el importe de la apuesta no cumple con los requisitos";
            e["th"] = "การดำเนินการล้มเหลวและจำนวนเงินเดิมพันไม่ตรงตามข้อกำหนด";
            e["tl"] = "Nabigo ang operasyon, ang halaga ng pagtaya ay hindi nakakatugon sa mga kinakailangan";
            e["my"] = "လည်ပတ်မှု မအောင်မြင်ပါ၊ လောင်းကစားပမာဏသည် လိုအပ်ချက်များနှင့် မကိုက်ညီပါ။";
            e["ms"] = "Kegagalan beroperasi, amaun taruhan tidak memenuhi persyaratan";
            e["id"] = "Operasi gagal dan jumlah taruhan tidak memenuhi persyaratan.";
            f.ErrorTextDic[83] = e;
            e = new Object;
            e["zh-cn"] = "操作失败，您选择的注单不存在或者已经结算";
            e["zh-tw"] = "操作失败，您选择的注单不存在或者已经结算";
            e["en"] = "The operation failed, the bet you selected does not exist or has already been settled";
            e["pr"] = "A operação falhou, a aposta que você selecionou não existe ou já foi liquidada";
            e["vi"] = "Thao tác không thành công, cược bạn chọn không tồn tại hoặc đã được thanh toán";
            e["hi"] = "संचालन विफल, आपके द्वारा चुनी गई बेट मौजूद नहीं है या पहले ही निपटान कर दी गई है";
            e["es"] = "La operación falló, la apuesta que seleccionó no existe o ya se ha liquidado";
            e["th"] = "การดำเนินการล้มเหลว เดิมพันที่คุณเลือกไม่มีอยู่หรือได้รับการตัดสินแล้ว";
            e["tl"] = "Nabigo ang operasyon, ang taya na iyong pinili ay wala o naayos na";
            e["my"] = "လုပ်ဆောင်ချက် မအောင်မြင်ပါ၊ သင်ရွေးချယ်ထားသော အလောင်းအစားသည် မရှိပါ သို့မဟုတ် ဖြေရှင်းပြီးဖြစ်သည်။";
            e["ms"] = "Kegagalan beroperasi, taruhan yang anda memilih tidak wujud atau telah diselesaikan";
            e["id"] = "Operasi gagal. Taruhan yang Anda pilih tidak ada atau telah diselesaikan.";
            f.ErrorTextDic[84] = e;
            e = new Object;
            e["zh-cn"] = "操作失败，重复投注";
            e["zh-tw"] = "操作失败，重复投注";
            e["en"] = "Operation failed, repeated betting";
            e["pr"] = "Operação falhou, aposta repetida";
            e["vi"] = "Thao tác không thành công, đặt cược lặp lại";
            e["hi"] = "संचालन विफल, दोहरी बेटिंग";
            e["es"] = "Operación fallida, apuestas repetidas";
            e["th"] = "การดำเนินการล้มเหลว เดิมพันซ้ำ";
            e["tl"] = "Nabigo ang operasyon, paulit-ulit na pagtaya";
            e["my"] = "လုပ်ဆောင်ချက် မအောင်မြင်ပါ၊ ထပ်ခါတလဲလဲ လောင်းကစားပါ။";
            e["ms"] = "Kegagalan beroperasi, taruh secara terulang";
            e["id"] = "Operasi gagal, ulangi taruhan";
            f.ErrorTextDic[85] = e;
            e = new Object;
            e["zh-cn"] = "操作失败，请重新尝试";
            e["zh-tw"] = "操作失败，请重新尝试";
            e["en"] = "Operation failed, please try again";
            e["pr"] = "Operação falhou, por favor, tente novamente";
            e["vi"] = "Thao tác không thành công, vui lòng thử lại";
            e["hi"] = "संचालन विफल, कृपया पुनः प्रयास करें";
            e["es"] = "Operación fallida, por favor, intente de nuevo";
            e["th"] = "การดำเนินการล้มเหลว โปรดลองอีกครั้ง";
            e["tl"] = "Nabigo ang operasyon, pakisubukang muli";
            e["my"] = "လုပ်ဆောင်ချက် မအောင်မြင်ပါ၊ ကျေးဇူးပြု၍ ထပ်စမ်းကြည့်ပါ။";
            e["ms"] = "Kegagalan beroperasi, cuba";
            e["id"] = "Operasi gagal, silakan coba lagi";
            f.ErrorTextDic[86] = e;
            e = new Object;
            e["zh-cn"] = "操作失败，已超过最大投注次数限制";
            e["zh-tw"] = "操作失败，已超过最大投注次数限制";
            e["en"] = "The operation failed and the maximum number of bets has been exceeded.";
            e["pr"] = "A operação falhou e o número máximo de apostas foi excedido.";
            e["vi"] = "Thao tác không thành công, đã vượt quá số lượng cược tối đa ";
            e["hi"] = "संचालन विफल और अधिकतम दांव की संख्या पार कर गई है";
            e["es"] = "La operación ha fallado y se ha superado el número máximo de apuestas.";
            e["th"] = "การดำเนินการล้มเหลวและเกินจำนวนเดิมพันสูงสุดแล้ว";
            e["tl"] = "Nabigo ang operasyon at nalampasan na ang maximum na bilang ng mga taya.";
            e["my"] = "လည်ပတ်မှု မအောင်မြင်ပါ၊ အများဆုံး လောင်းကြေးအရေအတွက်သည် ကန့်သတ်ချက်ကို ကျော်လွန်သွားပါသည်။";
            e["ms"] = "Kegagalan beroperasi, telah melebihi had maksimum pertaruhan ";
            e["id"] = "Operasi gagal dan jumlah taruhan maksimum telah terlampaui.";
            f.ErrorTextDic[87] = e;
            e = new Object;
            e["zh-cn"] = "操作失败，商户模式配置错误";
            e["zh-tw"] = "操作失败，商户模式配置错误";
            e["en"] = "Operation failed, merchant mode configuration error.";
            e["pr"] = "Operação falhou, erro de configuração do modo do comerciante.  ";
            e["vi"] = "Thao tác thất bại,lỗi cấu hình chế độ người bán ";
            e["hi"] = "การดําเนินการล้มเหลว และโหมดผู้ขายถูกกําหนดค่าไม่ถูกต้อง";
            e["es"] = "Operation failed, merchant mode configuration error.";
            e["th"] = "การดําเนินการล้มเหลว และโหมดผู้ขายถูกกําหนดค่าไม่ถูกต้อง";
            e["tl"] = "Operation failed, merchant mode configuration error.";
            e["my"] = "Operation failed, merchant mode configuration error.";
            e["ms"] = "Operasi gagal, dan mod peniaga telah salah konfigurasi";
            e["id"] = "Operasi gagal, dan mode pedagang salah dikonfigurasi";
            f.ErrorTextDic[88] = e;
            e = new Object;
            e["zh-cn"] = "操作失败，商户参数配置错误";
            e["zh-tw"] = "操作失败，商户参数配置错误";
            e["en"] = "Operation failed, the merchant parameter configuration was incorrect.";
            e["pr"] = "Operação falhou, o parâmetro de configuração do comerciante estava incorreto. ";
            e["vi"] = "Thao tác thất bại,lỗi cấu hình tham số người bán ";
            e["hi"] = "การดําเนินการล้มเหลว และพารามิเตอร์ผู้ขายถูกกําหนดค่าไม่ถูกต้อง";
            e["es"] = "Operation failed, the merchant parameter configuration was incorrect.";
            e["th"] = "การดําเนินการล้มเหลว และพารามิเตอร์ผู้ขายถูกกําหนดค่าไม่ถูกต้อง";
            e["tl"] = "Operation failed, the merchant parameter configuration was incorrect.";
            e["my"] = "Operation failed, the merchant parameter configuration was incorrect.";
            e["ms"] = "Operasi gagal dan parameter peniaga salah dikonfigurasikan";
            e["id"] = "Operasi gagal dan parameter pedagang tidak dikonfigurasi dengan benar";
            f.ErrorTextDic[89] = e;
            e = new Object;
            e["zh-cn"] = "操作失败，调用商户接口失败";
            e["zh-tw"] = "操作失败，调用商户接口失败";
            e["en"] = "Operation failed and the call to the merchant interface failed.";
            e["pr"] = "Operação falhou e a chamada para a interface do comerciante falhou.  ";
            e["vi"] = "Thao tác thất bại,lỗi kết nối giao diện người bán";
            e["hi"] = "การดําเนินการล้มเหลว และมีการเรียก API ของผู้ขาย";
            e["es"] = "Operation failed and the call to the merchant interface failed.";
            e["th"] = "การดําเนินการล้มเหลว และมีการเรียก API ของผู้ขาย";
            e["tl"] = "Operation failed and the call to the merchant interface failed.";
            e["my"] = "Operation failed and the call to the merchant interface failed.";
            e["ms"] = "Operasi gagal, dan API peniaga dipanggil";
            e["id"] = "Operasi gagal, dan API pedagang dipanggil";
            f.ErrorTextDic[90] = e;
            e = new Object;
            e["zh-cn"] = "操作失败，商户被暂时封禁";
            e["zh-tw"] = "操作失败，商户被暂时封禁";
            e["en"] = "Operation failed, the merchant was temporarily banned.";
            e["pr"] = "Operação falhou, o comerciante foi temporariamente banido.";
            e["vi"] = "Thao tác thất bại,người bán tạm thời bị cấm ";
            e["hi"] = "การดําเนินการล้มเหลวและผู้ค้าถูกแบนชั่วคราว";
            e["es"] = "Operation failed, the merchant was temporarily banned.";
            e["th"] = "การดําเนินการล้มเหลวและผู้ค้าถูกแบนชั่วคราว";
            e["tl"] = "Operation failed, the merchant was temporarily banned.";
            e["my"] = "Operation failed, the merchant was temporarily banned.";
            e["ms"] = "Operasi gagal, dan peniaga diharamkan buat sementara waktu";
            e["id"] = "Operasi gagal, dan pedagang itu dilarang sementara";
            f.ErrorTextDic[91] = e
        }
    }
    Common.Config.Tcp.ErrorTextMaster = b.ErrorTextMaster = f;
    b.static(f, ["ErrorTextDic", function() {
        return this.ErrorTextDic = new Object
    }]);
    Common.Dto = {};
    class Be {
        constructor(e, t, a, i, n, s, r) {
            this.app_id = 0;
            this.img_count = 0;
            this.xinRenTuiJian = 0;
            this.zhongJiangGL = 0;
            this.daJiangGL = 0;
            this.daJiangED = 0;
            this.fanJiangGL = 0;
            this.app_id = e;
            this.img_count = t;
            this.xinRenTuiJian = a;
            this.zhongJiangGL = i;
            this.daJiangGL = n;
            this.daJiangED = s;
            this.fanJiangGL = r
        }
    }
    Common.Dto.AppraiseDto = b.AppraiseDto = Be;
    class He {
        constructor() {
            this.minNum = 0;
            this.scale = 1
        }
    }
    Common.Dto.AutoScaleDto = b.AutoScaleDto = He;
    class Fe {
        constructor() {
            this.tp = 0;
            this.msg = "";
            this.time = 0
        }
    }
    Common.Dto.BonusAnnouncementDto = b.BonusAnnouncementDto = Fe;
    class Ye {
        constructor() {
            this.isLoading = true;
            this.usedArr = [];
            this.loadingArr = []
        }
    }
    Common.Dto.DolSkeletonDto = b.DolSkeletonDto = Ye;
    class je {
        constructor() {
            this.stage = 1;
            this.choc = 0
        }
    }
    Common.Dto.EliminateStageDto = b.EliminateStageDto = je;
    class We {
        constructor() {
            this.im = 0;
            this.am = 0;
            this.mwm = 0;
            this.mwm = 0;
            this.dt = 0;
            this.brd = "";
            this.ss = "";
            this.ss256 = "";
            this.rs256 = "";
            this.gs = "";
            this.win = "";
            this.bm = "";
            this.tm = 0
        }
    }
    Common.Dto.FairSimpleGameDto = b.FairSimpleGameDto = We;
    class ze {
        constructor() {
            this.rbd = "";
            this.bm = 1;
            this.auto = false;
            this.totalLose = 0;
            this.totalWin = 0;
            this.perWin = 0
        }
    }
    Common.Dto.FairSimpleMyBetDto = b.FairSimpleMyBetDto = ze;
    class Ve {
        constructor() {
            this.game_id = 0;
            this.game_type = 0;
            this.game_sub_type = 0;
            this.game_name = "";
            this.is_enbale = true;
            this.max_count = 0;
            this.min_multiple = 0;
            this.game_money = []
        }
    }
    Common.Dto.GameIDConfigDto = b.GameIDConfigDto = Ve;
    class Ke {
        constructor() {
            this.app_id = 0;
            this.classify_id = 0;
            this.app_name = "";
            this.app_name_en = ""
        }
    }
    Common.Dto.HallAppDto = b.HallAppDto = Ke;
    class qe {
        constructor() {
            this.balance = 0;
            this.bet_line = 0;
            this.bet_list = [];
            this.bet_money = .1;
            this.bet_index = 0;
            this.pay_money = 0;
            this.win_money = 0;
            this.bet_multiple = 1;
            this.free_count = 0;
            this.all_total_free_count = 0;
            this.total_free_count = 0;
            this.free_money = 0;
            this.total_free_money = 0;
            this.free_mul = 1;
            this.free_mul_add = 1;
            this.is_extra_game = false;
            this.symbols = [];
            this.bonus_mul = 0;
            this.bingo_symbol_id = 0;
            this.bonus_step = [];
            this.line_list = [];
            this.scatter_list = [];
            this.fixed_wild_list = [];
            this.isBonus = 0;
            this.sSymbol = -1;
            this.add_symbols = [];
            this.win = [];
            this.suit = [];
            this.columnsToWild = 0;
            this.all_line_list = [];
            this.free_again = 0;
            this.is_free_again = 0;
            this.is_bingo_free_again = 0;
            this.wild_pos = [];
            this.change_id = -1;
            this.change_pos = [];
            this.bfg_money = .1;
            this.bfg_multiple = .1;
            this.mul_start = 1
        }
    }
    Common.Dto.InitDto = b.InitDto = qe;
    class Je {
        constructor() {
            this.count = 0;
            this.orientation = 0;
            this.tips = [];
            this.line = 0;
            this.mul = 0;
            this.symbol_id = 0
        }
    }
    Common.Dto.LineDto = b.LineDto = Je;
    class Xe {
        constructor() {
            this.balance = 0;
            this.win_money = 0;
            this.banker_money = 0;
            this.record_id = "";
            this.success = false
        }
    }
    Common.Dto.MulBankerOverDto = b.MulBankerOverDto = Xe;
    class Ze {
        constructor() {
            this.uid = 0;
            this.user_name = "";
            this.portrait_id = 0;
            this.count = 0
        }
    }
    Common.Dto.MulBankerQueueDto = b.MulBankerQueueDto = Ze;
    class Qe {
        constructor() {
            this.c_list = [];
            this.r_list = [];
            this.c_type = 0;
            this.m_result = 0;
            this.first_card = 0;
            this.first_id = 0;
            this.second_card = 0;
            this.second_id = 0;
            this.card_array = []
        }
    }
    Common.Dto.MulBankerResultDto = b.MulBankerResultDto = Qe;
    class $e {
        constructor(e, t = 0) {
            this.pos = 0;
            this.money = 0;
            this.pos = e;
            this.money = t
        }
    }
    Common.Dto.MulBetDto = b.MulBetDto = $e;
    class et {
        constructor() {
            this.pos = 0;
            this.c_list = [];
            this.r_list = [];
            this.c_type = 0;
            this.b_money = 0;
            this.result = 0
        }
    }
    Common.Dto.MulGamblerResultDto = b.MulGamblerResultDto = et;
    class tt {
        constructor(e = null) {
            this.now_bet = 0;
            this.bet_data = [];
            this.vip_bet_data = [];
            e && (this.now_bet = e.now_bet || 0);
            for (var t = 0; t < L.Instance.MulMenCount; t++) {
                if (e && e.bet_data && e.bet_data[t]) {
                    this.bet_data.push(new $e(e.bet_data[t].pos, e.bet_data[t].money))
                } else {
                    this.bet_data.push(new $e(t))
                }
            }
        }
        fix() {
            if (!this.bet_data) {
                this.bet_data = []
            }
            while (this.bet_data.length < L.Instance.MulMenCount) {
                this.bet_data.push(new $e(this.bet_data.length))
            }
        }
        add(e, t) {
            this.now_bet = 0;
            for (var a = 0; a < this.bet_data.length; a++) {
                if (a < e.length) {
                    this.bet_data[a].money += e[a];
                    if (t && t.bet_data && t.bet_data[a]) {
                        if (this.bet_data[a].money > t.bet_data[a].money) {
                            this.bet_data[a].money = t.bet_data[a].money
                        }
                    }
                    this.now_bet += this.bet_data[a].money
                }
            }
        }
        isEqual(e) {
            if (e) {
                if (!(e instanceof Common.Dto.MulGameBetDto)) {
                    e = new tt(e)
                }
                this.fix();
                e.fix();
                for (var t = 0; t < L.Instance.MulMenCount; t++) {
                    if (this.bet_data[t].money != e.bet_data[t].money) {
                        return false
                    }
                }
                return true
            }
            return false
        }
    }
    Common.Dto.MulGameBetDto = b.MulGameBetDto = tt;
    class at {
        constructor() {
            this.room_id = "";
            this.app_id = 0;
            this.game_id = 0;
            this.game_type = 0;
            this.game_status = 0;
            this.max_queue = 0;
            this.banker_draw_rate = 0;
            this.bet_draw_rate = 0;
            this.min_money = 0;
            this.max_money = 0;
            this.fail_money = 0;
            this.player_count = 0;
            this.resent_game_array = [];
            this.banker_queue = [];
            this.time_left = 0;
            this.game_index = 0;
            this.banker_id = 0;
            this.banker_pid = 0;
            this.banker_name = "";
            this.banker_money = 0;
            this.max_bet = 0;
            this.player_bet_data = [];
            this.money_result = null
        }
    }
    Common.Dto.MulGameDto = b.MulGameDto = at;
    class it {
        constructor() {
            this.round_id = "";
            this.record_id = "";
            this.game_index = 0;
            this.banker_name = "";
            this.time = 0
        }
    }
    Common.Dto.MulGameResultDto = b.MulGameResultDto = it;
    class nt {
        constructor() {
            this.round_id = "";
            this.record_id = "";
            this.open_time_id = "";
            this.open_time = "";
            this.flow_reason = "";
            this.c_time = "";
            this.c_list = "";
            this.dtf_value = 0
        }
    }
    Common.Dto.MulQiQuGameResultDto = b.MulQiQuGameResultDto = nt;
    class st {
        constructor() {
            this.game_id = 0;
            this.config_id = 0;
            this.name = "";
            this.room_id = "";
            this.worker_type = 0;
            this.worker_id = 0;
            this.max_count = 0
        }
    }
    Common.Dto.MulRoomConfigDto = b.MulRoomConfigDto = st;
    class rt {
        constructor() {
            this.tbm = 0;
            this.tbc = 0
        }
    }
    Common.Dto.ProMulBetDto = b.ProMulBetDto = rt;
    class ot {
        constructor(e = null) {
            this.ud = "";
            this.un = "";
            this.pd = 0;
            this.bx = 1;
            this.bm = 0;
            this.mul = "";
            this.rm = "";
            this.ix = 0
        }
    }
    Common.Dto.ProMulGameBetDto = b.ProMulGameBetDto = ot;
    class lt {
        constructor() {
            this.rd = "";
            this.ad = 0;
            this.gd = 0;
            this.wd = 0;
            this.cd = 0;
            this.gt = 0;
            this.sta = 0;
            this.im = 0;
            this.am = 0;
            this.mwm = 0;
            this.mc = 0;
            this.rbd = "";
            this.tl = 0;
            this.ss = "";
            this.ss256 = "";
            this.rs256 = "";
            this.mul = "";
            this.tbm = 0;
            this.tbc = 0;
            this.gr = "";
            this.tm = 0;
            this.sbl = [];
            this.bl = [];
            this.hl = []
        }
    }
    Common.Dto.ProMulGameDto = b.ProMulGameDto = lt;
    class ht {
        constructor() {
            this.rd = "";
            this.mul = ""
        }
    }
    Common.Dto.ProMulGameResultDto = b.ProMulGameResultDto = ht;
    class _t {
        constructor() {
            this.symbol = 0;
            this.mul = 0;
            this.posList = []
        }
    }
    Common.Dto.SlotAllLineDto = b.SlotAllLineDto = _t;
    class ct {
        constructor() {}
    }
    Common.Dto.VersionFileDto = b.VersionFileDto = ct;
    Common.Logic = {};
    class L {
        constructor() {
            this.IsGameHallMode = false;
            this.ChangeBetHTTP = false;
            this.OnlyPCV = false;
            this.AppID = 0;
            this.UrlPid = "";
            this.ModuleName = "";
            this.AppVersion = "1.0.0";
            this.user_name = "";
            this.Currency = "1";
            this.CurrencyStr = "";
            this.AreaCode = "1";
            this.MessageBoxSkin = "GameUI/Common/Dialog/MessageBox.json";
            this.MessageYesNoBoxSkin = "GameUI/Common/Dialog/MessageYesNoBox.json";
            this.ReconnectMessageBoxSkin = "GameUI/Common/Dialog/ReconnectMessageBox.json";
            this.CommonMarqueeManagerSkin = "GameUI/Common/View/MarqueeView.json";
            this.GameMarqueeManagerSkin = "GameUI/Common/View/MarqueeView.json";
            this.MarqueePosArr = [new c(0, 160), new c(0, 0)];
            this.CommonDynamicMsgSkin = "GameUI/Common/View/DynamicMsgView.json";
            this.DynamicMsgSkin = "GameUI/Common/View/DynamicMsgView.json";
            this.PGGameLoadingBarNewSkin = "GameUI/CommonPGGame/View/GameLoadingBarNew.json";
            this.cacheAsType = "none";
            this.zipLoad = false;
            this.GameScene = null;
            this.notShowLeading = false;
            this.LeadingScene = null;
            this.BonusGame = null;
            this.GameResConfig = null;
            this.OtherGameScene = {};
            this.canChangeLine = true;
            this.isFirstIn = true;
            this.isHasBannerHelp = true;
            this.isHasBannerSetting = true;
            this.isHasBannerLang = true;
            this.isHasBannerSound = true;
            this.isHasPaytable = true;
            this.isHasMobileMenuQuick = true;
            this.isHasMobileMenuPaytable = true;
            this.isTwowaySetting = true;
            this.CellClass = null;
            this.TooltipClass = null;
            this._symbolNumber = 10;
            this.AllSymbol = [];
            this.MaxLineNumber = 10;
            this.MaxBetMultNumber = 10;
            this.CellNumber = 3;
            this.ShowCellNumber = 3;
            this.ReelNumber = 5;
            this.DEFAULT_ACCURACY = 2;
            this.DEFAULT_DELZERO = true;
            this.ReelRollTimes = [4, 8, 12, 16, 24];
            this.QuickReelRollTimes = [0, 1, 2, 3, 4];
            this.ReelFanTimes = [10, 14, 18, 22, 26];
            this.SymbolTypeConfig = [
                [0, 1, 2, 3, 4],
                [5, 6, 7, 8, 9],
                [10],
                [11],
                [11]
            ];
            this.SymbolMoneyConfig = [{
                3: 3,
                4: 20,
                5: 50
            }, {
                3: 3,
                4: 20,
                5: 75
            }, {
                3: 3,
                4: 25,
                5: 100
            }, {
                3: 3,
                4: 25,
                5: 125
            }, {
                3: 5,
                4: 50,
                5: 150
            }, {
                3: 5,
                4: 50,
                5: 250
            }, {
                3: 10,
                4: 75,
                5: 250
            }, {
                3: 10,
                4: 75,
                5: 400
            }, {
                3: 20,
                4: 100,
                5: 500
            }, {
                3: 20,
                4: 150,
                5: 750
            }, {
                3: 50,
                4: 200,
                5: 1e3
            }, {
                2: 1,
                3: 3,
                4: 15,
                5: 150
            }];
            this.SymbolLangArr = [];
            this.BigWinMul = [0, 8, 15, 20];
            this.BigWinName = ["", "BigWin", "MegaWin", "SuperWin"];
            this.SymbolInterval = 62;
            this.PayLine = [];
            this.reelAngle = 90;
            this.stageCount = 3;
            this.rowConfig = [4, 5, 6];
            this.chocCountConfig = [15, 15, 15];
            this.ChocClass = null;
            this.ScoreViewClass = null;
            this.nowGameStatus = 0;
            this._nowSceneType = 0;
            this.uid = 0;
            this.pid = 1;
            this.user_name = "";
            this.PidArr = [1, 2, 4, 6];
            this.MalePidArr = [4, 6];
            this._balance = 0;
            this.ping = 0;
            this.replay_no = "";
            this.replay_game_id = 0;
            this.replay_uid = 0;
            this.replay_data = null;
            this.token = "";
            this.is_demo = true;
            this.isRealReplay = false;
            this.isSSL = false;
            this.tcp_address_url = null;
            this.http_address_list = [];
            this.http_demo_address_list = [];
            this.http_try_index = 0;
            this.current_game_id = 0;
            this.is_local_debug = false;
            this.is_show_stat = false;
            this.location = null;
            this.version_file_name = "";
            this.atlas_file_name = "";
            this.is_finish_res_loading = false;
            this.skLoadedCount = 0;
            this.fontArr = ["common"];
            this.autoPlayArray = [10, 50, 100, 500, 1e3, "∞"];
            this.skNeedChangeSkin = [];
            this.clearMask = true;
            this.commonTipList = ["CommonDY_1", "CommonDY_2", "CommonDY_3", "CommonDY_4", "CommonDY_5", "CommonDY_6", "CommonDY_7", "CommonDY_8", "CommonDY_9", "CommonDY_10"];
            this.gameTipList = [];
            this.notResLangList = ["ko", "es", "vi", "th", "ja", "hi"];
            this.langSkList = ["zh-cn", "en"];
            this.langMenuList = [];
            this.fsg_next_interval = 800;
            this.fsg_cs_next_interval = 0;
            this.fsg_ope_next_interval = 1e3;
            this.hide_win_interval = 2e3;
            this.help_pos_x = 137;
            this.logo_pos_x = 87;
            this.MEN_COUNT = 0;
            this.HORSE_COUNT = 8;
            this.GameKind = 2;
            this.LoadingScene = Xt;
            this.RoleView = ia;
            this.UserInfoClass = BaseFSG.Base.View.UserInfo;
            this.game_language = "zh-cn";
            this.http_address = "wss://tsqp.testbasepartner.cn/";
            this.http_demo_address = "wss://tsqp.testbasepartner.cn/";
            this.http_replay_address = "http://api.testlayaslot.com/api/replay";
            this.http_history_address = "http://192.168.1.249:4444/GameHistory/replay";
            this.http_greendetailed_address = "https://www.miniwebtool.com/sha256-hash-generator/";
            this.game_config_dic = new Object;
            this.loadingSceneType = 0;
            this.LoadingSceneClass = Xt
        }
        initGameConfigDic(e) {
            this.game_config_dic = new Object;
            if (e != null && e.length > 0) {
                var t;
                for (var a in e) {
                    t = e[a];
                    var i = new Ve;
                    i.game_id = t.game_id;
                    i.game_type = t.game_type;
                    i.game_sub_type = t.game_sub_type;
                    i.game_name = t.game_name;
                    i.is_enbale = t.is_enbale;
                    i.max_count = t.max_count;
                    i.min_multiple = t.min_multiple;
                    i.game_money = t.game_money;
                    this.game_config_dic[i.game_id] = i
                }
            }
        }
        getGameIDConfig(e) {
            return this.game_config_dic[e]
        }
        addBalance(e) {
            this._balance += e
        }
        getFpsCountByTime(e) {
            return Math.floor(e / 1e3 * this.fps)
        }
        getTimeByFps(e) {
            return 1e3 * e / this.fps
        }
        canTryNextUrl() {
            var e = this.is_demo ? this.http_demo_address_list : this.http_address_list;
            this.http_try_index++;
            if (!e || this.http_try_index >= e.length) {
                return false
            } else {
                return true
            }
        }
        dealWithUrl(e, t = false) {
            e = e.toLowerCase();
            var a = "";
            if (I.startWith(e, "http://")) {
                a = "http://"
            } else if (I.startWith(e, "https://")) {
                a = "https://"
            }
            if (a != "") {
                e = e.slice(a.length)
            }
            if (e.indexOf(".") > 0 && e.indexOf(".") == e.lastIndexOf(".")) {
                e = this.UrlPid + (t ? "demo" : "") + "." + e
            }
            if (a != "") {
                e = a + e
            } else {
                if (this.isSSL) {
                    e = "https://" + e
                } else {
                    e = "http://" + e
                }
            }
            if (!I.endWith(e, "/")) {
                e += "/"
            }
            return e
        }
        onAppRestartEvent() {
            O.restartApp()
        }
        onAppExitEvent() {
            O.exitApp()
        }
        GotoHallScene(e = false) {
            this.nowGameStatus = 0;
            if (e || this.nowSceneType != 1) {
                A.Instance.init();
                this._nowSceneType = 1;
                zt.Instance.StartScene(this.GameHallScene);
                o.dispatch("NC_SCENE_CHANGED", [1])
            }
        }
        GotoLoadingScene() {
            this.nowGameStatus = 0;
            if (this.nowSceneType != 3) {
                this._nowSceneType = 3;
                zt.Instance.StartScene(this.LoadingScene)
            }
        }
        GotoGameScene(e = false) {
            if (this.GameKind == 0) {
                if (A.Instance.game_id == 0) {
                    return
                }
                var t = Common.Logic.AppContext.Instance.GameScene;
                var a = A.Instance.game_id.toString();
                if (Common.Logic.AppContext.Instance.OtherGameScene && Common.Logic.AppContext.Instance.OtherGameScene.hasOwnProperty(a) && Common.Logic.AppContext.Instance.OtherGameScene[a]) {
                    t = Common.Logic.AppContext.Instance.OtherGameScene[a]
                }
                if (e || this.nowSceneType != 2) {
                    this._nowSceneType = 2;
                    zt.Instance.StartScene(t);
                    o.dispatch("NC_SCENE_CHANGED", [2])
                }
            } else {
                if (this.nowSceneType != 2) {
                    this._nowSceneType = 2;
                    zt.Instance.StartScene(Common.Logic.AppContext.Instance.GameScene)
                }
            }
        }
        getSex(e = null) {
            e = e || Common.Logic.AppContext.Instance.pid;
            if (this.MalePidArr.indexOf(e) >= 0) {
                return 1
            } else {
                return 0
            }
        }
        InitAppContext() {
            this.initLoadingScene();
            if (C.onPC && !C.onRealMobile) {
                F.stateMap = {
                    mouseup: 1,
                    mouseover: 1,
                    mousedown: 2,
                    mouseout: 0
                }
            }
            this.location = k.location;
            this.is_local_debug = true;
            if (this.location.protocol == "http:" || this.location.protocol == "https:") {
                this.isSSL = this.location.protocol == "https:";
                this.is_local_debug = false
            } else if (this.location.protocol == "file:") {
                this.is_local_debug = true;
                b.isZip = false
            }
            if (d.getQueryString("localdebug", 2) == "true") {
                this.is_local_debug = true
            }
            if (d.getQueryString("currency")) {
                this.Currency = d.getQueryString("currency")
            }
            if (d.getQueryString("currency_signal")) {
                this.CurrencyStr = O.base64Decode(d.getQueryString("currency_signal")).replace("%S", "%s")
            }
            var e = d.getQueryString("area");
            if (e) {
                this.AreaCode = e
            }
            f.initError();
            _.initError();
            n.initMsg();
            o.on("GLOABLE_EVENT_APP_RESTART", this, this.onAppRestartEvent);
            o.on("GLOABLE_EVENT_APP_EXIT", this, this.onAppExitEvent);
            o.on("GLOABLE_GAME_RES_LOAD_FINISH", this, this.preloadOther);
            o.on("GLOABLE_DYNAMIC_MESSAGE", this, this.onShowDynamicMessage);
            if (d.getQueryString("is_demo", 2) == "true") {
                this.is_demo = true
            } else {
                this.is_demo = false
            }
            if (d.getQueryString("gamehall", 2) == "true") {
                this.IsGameHallMode = true
            }
            if (d.getQueryString("stat", 2) == "true") {
                this.is_show_stat = true
            }
            this.UrlPid = d.getQueryString("pid", 1) || "";
            this.replay_no = d.getQueryString("replay_no");
            if (!this.IsReplayMode) {
                this.token = d.getQueryString("token");
                if (!this.is_demo) {
                    if (this.token == null || this.token == "") {
                        S.showError(100003);
                        return
                    }
                } else {
                    if (this.token == null || this.token == "") {
                        this.token = O.Guid();
                        L.restartDemoApp(this.token);
                        return
                    }
                }
                if (d.getQueryString("gamehall", 2) == "true") {
                    this.IsGameHallMode = true
                }
            } else {
                this.isRealReplay = true;
                var t = d.getQueryString("replay_game_id");
                if (t == null || t == "") {
                    S.showError(100001);
                    return
                }
                this.replay_game_id = parseInt(t);
                if (d.getQueryString("replay_uid") != null && d.getQueryString("replay_uid") != "") {
                    this.replay_uid = parseInt(d.getQueryString("replay_uid"))
                }
            }
            if (this.is_local_debug) {
                g.IS_DEBUG_MODE = true;
                b.alertGlobalError = true;
                this.http_address = this.dealWithUrl("wss://tsqp.testbasepartner.cn/");
                this.http_demo_address = this.dealWithUrl("wss://tsqp.testbasepartner.cn/", true);
                this.version_file_name = "Json/" + this.ModuleName + "Version.json";
                this.atlas_file_name = "Json/" + this.ModuleName + "FileConfig.json"
            } else {
                if (d.getQueryString("isdebug", 2) == "true") {
                    g.IS_DEBUG_MODE = true;
                    b.alertGlobalError = true
                } else {
                    g.IS_DEBUG_MODE = false;
                    b.alertGlobalError = false
                }
            }
            if (!this.IsDebugMode) {
                console.log = function() {};
                console.warn = function() {}
            }
            this.getHttpAddressAndFileName()
        }
        getHttpAddressAndFileName() {
            if (!this.getWssConfig()) {
                alert("服务器链接地址加载失败，请重新生成游戏链接！");
                return
            }
            if (!C.window.FileVerNames) {
                S.showError(100009);
                return
            }
            var e = T.find(C.window.FileVerNames, function(e) {
                return e.AppID == this.AppID.toString()
            }, this);
            if (!e) {
                this.version_file_name = "Json/" + this.ModuleName + "Version.json";
                this.atlas_file_name = "Json/" + this.ModuleName + "FileConfig.json"
            } else {
                this.version_file_name = e.VersionFileName;
                this.atlas_file_name = e.AtlasFileName
            }
            if (this.version_file_name == null || this.version_file_name == "" || this.atlas_file_name == null || this.atlas_file_name == "") {
                S.showError(100009);
                return
            }
            if (this.IsGameHallMode && this.AppID == 0) {
                o.dispatch("GLOABLE_HALL_TCP")
            } else {
                o.dispatch("GLOABLE_APP_CONTEXT_INIT_FINISH")
            }
        }
        changeToReplayMode(e, t) {
            t = t || A.Instance.game_id;
            if (!this.isRealReplay) {
                this.replay_no = e;
                if (this.IsReplayMode) {
                    this.replay_uid = this.uid;
                    this.replay_game_id = t;
                    this.onGameResLoadFinish()
                } else {
                    this.GotoHallScene()
                }
            }
        }
        onReplayGetOutRoom() {
            this.GotoHallScene();
            o.off("NC_GET_OUT_ROOM_OK", this);
            if (this.GameScene != null) {
                o.dispatch("GLOABLE_EVENT_APP_READY_TO_RUN")
            } else {
                S.showError(100010)
            }
        }
        changeToNormalMode() {
            if (!this.isRealReplay) {
                this.replay_no = ""
            }
        }
        openReplayApp(e, t) {
            k.open(this.getReplayUrl(e, t))
        }
        getReplayUrl(e, t) {
            var a = k.location;
            var i = a.href;
            if (i.lastIndexOf("?") >= 0) {
                var n = i.substr(i.lastIndexOf("?") + 1);
                i = i.substr(0, i.lastIndexOf("?") + 1)
            }
            i = i + "appid=" + this.AppID;
            this.is_local_debug && (i = i + "&localdebug=" + this.is_local_debug);
            i = i + "&replay_game_id=" + e;
            i = i + "&replay_no=" + t;
            i = i + "&replay_uid=" + this.uid;
            i = i + "&pid=" + this.UrlPid;
            i = i + "&is_demo=" + this.is_demo;
            return i
        }
        onHttpErrorHandler(e) {
            g.IS_DEBUG_MODE && console.info("onHttpErrorHandler", e);
            var t = {};
            t.callback = function() {
                o.dispatch("GLOABLE_EVENT_APP_RESTART")
            };
            t.text = O.GetErrorText(100006);
            C.window.showSwal(t)
        }
        getSoundSettingKey() {
            return "QiPaiSetting" + this.ModuleName
        }
        saveSoundSetting() {
            m.saveToLocal(this.getSoundSettingKey())
        }
        initClass() {
            this.ResultCellClass = BaseFSG.Base.View.ResultViewCell;
            this.CheckRoundSeedClass = BaseFSG.Base.View.CheckRoundSeed
        }
        onGameResLoadFinish() {
            this.recoverHandler();
            m.loadFromLocal(this.getSoundSettingKey());
            var e = "";
            var t = new $;
            if (this.AppID > 90 && this.AppID < 100) {
                o.dispatch("GLOABLE_EVENT_APP_READY_TO_RUN")
            } else if (this.IsReplayMode) {
                this.is_finish_res_loading = true;
                e = this.http_replay_address + "?replay_no=" + this.replay_no + "&game_id=" + this.replay_game_id + "&pid=" + this.UrlPid + "&is_demo=" + this.is_demo;
                O.IsDebugMode && console.log("replay url:" + e);
                jt.Instance.tryHttp(e, 3e3, 3, this, this.onReplayHttpCompleteHandler, this.onReplayHttpErrorHandler)
            } else {
                this.is_finish_res_loading = true;
                o.dispatch("GLOABLE_EVENT_APP_READY_TO_RUN")
            }
            b.stage.event(M.RESIZE)
        }
        recoverHandler() {
            o.off("GLOABLE_GAME_RES_LOAD_FINISH", this);
            ae && ae._onProcessChange && v.recoverCaller(null, ae._onProcessChange);
            v.recoverCaller(this, this.skLoadOK);
            var e;
            for (var t in ne.loadingHandlers) {
                e = ne.loadingHandlers[t];
                e && e.recover()
            }
            ne.loadingHandlers = []
        }
        getWssConfig() {
            try {
                var e = d.getQueryString("gep");
                if (e) {
                    var t = JSON.parse(O.base64Decode(e));
                    this.tcp_address_url = t.gl;
                    this.http_replay_address = t.rl;
                    if (this.http_replay_address.length > 0) {
                        this.http_replay_address = this.http_replay_address[0]
                    }
                    return true
                }
            } catch (e) {
                return false
            }
        }
        preloadOther() {
            this.onLoadAllOK()
        }
        onShowDynamicMessage(e) {
            if (!e) {
                return
            }
            var t = "";
            if (typeof e == "string") {
                t = e
            } else if (e.msg) {
                t = e.msg
            }
            if (t && t != "") {
                Yt.Instance.showText(t)
            }
        }
        onLoadAllOK() {
            this.onGameResLoadFinish()
        }
        skLoadOK(e = null) {
            this.skLoadedCount++;
            if (this.skLoadedCount >= this.GameResConfig.RES_SK.length) {
                e && e.run()
            }
        }
        preLoadSk(e = null) {
            if (this.GameResConfig.RES_SK && this.GameResConfig.RES_SK.length > 0) {
                this.skLoadedCount = 0;
                for (var t = 0; t < this.GameResConfig.RES_SK.length; t++) {
                    Kt.preloadSk(this.GameResConfig.RES_SK[t], v.create(this, this.skLoadOK, [e]))
                }
            } else {
                e && e.run()
            }
        }
        fntLoadOK(e) {
            this.skLoadedCount++;
            if (this.skLoadedCount >= this.GameResConfig.RES_FNT.length) {
                e.run()
            }
        }
        preLoadFnt(e) {
            if (this.GameResConfig.RES_FNT && this.GameResConfig.RES_FNT.length > 0) {
                this.skLoadedCount = 0;
                for (var t = 0; t < this.GameResConfig.RES_FNT.length; t++) {
                    Qt.preloadFnt(this.GameResConfig.RES_FNT[t], v.create(this, this.fntLoadOK, [e]))
                }
            } else {
                e.run()
            }
        }
        onReplayHttpCompleteHandler(e) {
            g.IS_DEBUG_MODE && console.info("onReplayHttpCompleteHandler", e);
            if (e.error > 0) {
                S.showError(e);
                this.changeToNormalMode();
                return
            }
            if (e.replay_data) {
                if (typeof e.replay_data == "string") {
                    e.game_replay_json = JSON.parse(e.replay_data)
                }
            }
            this.replay_data = e;
            if (e.game_replay_json.app_id != this.AppID) {
                S.showError(100015);
                return
            }
            if (!this.replay_uid || this.replay_uid == 0) {
                if (e.game_replay_json && e.game_replay_json.player_info && e.game_replay_json.player_info.length > 0) {
                    this.replay_uid = e.game_replay_json.player_info[0].uid
                }
            }
            if (!this.isRealReplay) {
                o.on("NC_GET_OUT_ROOM_OK", this, this.onReplayGetOutRoom);
                o.dispatch("NC_GET_OUT_ROOM", [2])
            } else {
                this.onReplayGetOutRoom()
            }
        }
        onReplayHttpErrorHandler(e) {
            g.IS_DEBUG_MODE && console.info("onReplayHttpErrorHandler", e);
            S.showError(100002);
            this.changeToNormalMode()
        }
        isMe(e) {
            if (e) {
                if (typeof e == "object" && e.hasOwnProperty("uid") && e.uid == this.uid) {
                    return true
                } else if (e == this.uid) {
                    return true
                }
            }
            return false
        }
        gotoOtherGame(e) {
            if (e) {
                C.window.restartApp(k.location.href.replace(/appid=(\d+)/i, "appid=" + e))
            }
        }
        getNowPidIndex() {
            return this.PidArr.indexOf(this.pid)
        }
        initLoadingScene() {
            switch (this.loadingSceneType) {
                case 0:
                    this.LoadingSceneClass = Xt;
                    break;
                case 2:
                    this.LoadingSceneClass = Xt;
                    break
            }
        }
        setScaleMode(e) {
            b.stage.defaultMode = e;
            if (L.twoUIList.indexOf(this.AppID) >= 0) {
                b.stage.scaleMode = "fixed2ui"
            } else {
                b.stage.scaleMode = e
            }
        }
        getGameName(e, t = "") {
            if (!t || t == "" || C.langList.indexOf(t) < 0) {
                t = this.lang
            }
            return Ue.GameNames[e][t]
        }
        getGameNameForHall(e, t = "") {
            if (Common.Logic.AppContext.Instance.isCH) {
                return Ue.GameNames[e]["zh-cn"]
            } else {
                return Ue.GameNames[e]["en"]
            }
        }
        getCellNumByReelIndex(e, t = true) {
            var a = t ? this.ShowCellNumber : this.CellNumber;
            if (a instanceof Array) {
                return a[e]
            } else {
                return a
            }
        }
        getSymbolTypeByID(e) {
            for (var t = 0; t < this.SymbolTypeConfig.length; t++) {
                if (this.SymbolTypeConfig[t].indexOf(e) > -1) {
                    return t
                }
            }
        }
        getRollTimesByIndex(e) {
            if (A.Instance.getQuickMode) {
                return this.QuickReelRollTimes[e]
            } else {
                return this.ReelRollTimes[e]
            }
        }
        isSymbolType(e, t) {
            if (this.SymbolTypeConfig[t] instanceof Array) {
                return this.SymbolTypeConfig[t].indexOf(e) > -1
            }
            return false
        }
        set supportPlatform(e) {
            C.supportPlatform = e
        }
        get balance() {
            if (this.GameKind == 1) {
                var e = A.Instance.MulGameData.game_status;
                switch (e) {
                    case 0:
                    case 1:
                    case 4:
                        if (A.Instance.MulGameData.game_id == 600 && A.Instance.MulGameData.game_status == 4) {
                            return this._balance - this.allMyBet
                        }
                        return this._balance;
                        break;
                    case 2:
                    case 3:
                        return this._balance - this.allMyBet;
                        break
                }
            }
            return this._balance
        }
        set balance(e) {
            this._balance = e
        }
        get nowSceneType() {
            return this._nowSceneType
        }
        get allMyBet() {
            var e = 0;
            var t = A.Instance.MulGameData.player_bet_data;
            if (t && t.length > 0) {
                for (var a = 0; a < t.length; a++) {
                    var i = t[a];
                    if (i) {
                        e += i.money
                    }
                }
            }
            return e
        }
        set moblieType(e) {
            if (e == 1 || e == 2) {
                C.moblieScreenType = e
            }
        }
        get AtlasFileName() {
            return this.atlas_file_name
        }
        get IsReplayMode() {
            if (this.replay_no == "" || this.replay_no == null) return false;
            return true
        }
        get IsLocalDebug() {
            return this.is_local_debug
        }
        get IsShowStat() {
            return this.is_show_stat
        }
        get VersionFileName() {
            return this.version_file_name
        }
        get fps() {
            if (b.stage.frameRate == Ce.FRAME_FAST) {
                return 60
            } else if (b.stage.frameRate == Ce.FRAME_SLOW) {
                return 30
            }
            return 1
        }
        get timer() {
            if (!this._myTimer) this._myTimer = new Ie(true);
            return this._myTimer
        }
        get HttpAddress() {
            var e = this.is_demo ? this.http_demo_address_list : this.http_address_list;
            if (!e || e.length == 0) {
                if (this.is_demo) {
                    return this.dealWithUrl(this.http_demo_address, true)
                } else {
                    return this.dealWithUrl(this.http_address)
                }
            } else {
                this.http_try_index = this.http_try_index % e.length;
                return this.dealWithUrl(e[this.http_try_index], true)
            }
        }
        get IsFinishResLoading() {
            return this.is_finish_res_loading
        }
        get lang() {
            return C.lang
        }
        get isCH() {
            return this.lang == "zh-cn" || this.lang == "zh-tw"
        }
        get IsDebugMode() {
            return this.is_local_debug || g.IS_DEBUG_MODE
        }
        get SymbolNumber() {
            return this._symbolNumber
        }
        set SymbolNumber(e) {
            if (e > 0) {
                this._symbolNumber = e;
                this.AllSymbol = [];
                for (var t = 0; t < e; t++) {
                    this.AllSymbol.push(t)
                }
            }
        }
        static restartDemoApp(e) {
            var t = k.location;
            var a = t.href;
            if (a.lastIndexOf("?") >= 0) {
                var i = a.substr(a.lastIndexOf("?") + 1);
                a = a.substr(0, a.lastIndexOf("?") + 1);
                var n = i.split("&");
                if (n.length > 0) {
                    for (var s = 0; s < n.length; s++) {
                        var r = n[s].split("=");
                        if (r.length == 2) {
                            if (r[0] == "rand") {
                                continue
                            }
                            a = a + r[0] + "=" + r[1] + "&"
                        }
                    }
                    a = a + "rand=" + O.random(1e3, 99999999)
                } else {
                    a = a + "rand=" + O.random(1e3, 99999999)
                }
            } else {
                a = a + "?rand=" + O.random(1e3, 99999999)
            }
            a = a + "&token=" + e;
            O.IsDebugMode && console.info("restartDemoApp Url:", a);
            C.window.restartApp(a)
        }
    }
    Common.Logic.AppContext = b.AppContext = L;
    b.static(L, ["Instance", function() {
        return this.Instance = new L
    }, "twoUIList", function() {
        return this.twoUIList = [800]
    }]);
    class ut {
        constructor() {
            this._bonusAnnouncementList = []
        }
        tryPlayBonusAnima(e) {
            this._bonusAnnouncementList.push(e);
            if (!this._isRunning) {
                this.playBonusAnima()
            }
        }
        playBonusAnima() {
            var n = this;
            if (this._bonusAnnouncementList.length > 0) {
                this._isRunning = true;
                var e = this._bonusAnnouncementList[0];
                this._bonusAnnouncementList.splice(0, 1);
                O.createView(la, v.create(this, function(e, t) {
                    var a = (1900 - b.stage.realDesignHeight) / 2;
                    if (b.stage.width > b.stage.height) {
                        a = 0
                    }
                    t.setBonusDto(e);
                    t.anchorX = .5;
                    t.anchorY = 0;
                    t.zOrder = 99;
                    t.x = b.stage.width / 2;
                    t.y = a - t.height;
                    b.stage.addChild(t);
                    this._nowBonusView = t;
                    var i = P.create(v.create(this, n.onPlayComplete, [e]));
                    i.addTweenChild(w.createTo(t, {
                        y: a
                    }, 500));
                    i.addTweenChild(w.createTo(t, {}, 4e3 + t.needTime));
                    i.addTweenChild(w.createTo(t, {
                        y: a - t.height
                    }, 500));
                    i.addTweenChild(w.createTo(t, {}, 2e3));
                    i.run()
                }, [e]))
            }
        }
        onPlayComplete(e) {
            this._nowBonusView && this._nowBonusView.destroy();
            this._nowBonusView = null;
            this._isRunning = false;
            L.Instance.timer.frameOnce(1, this, this.playBonusAnima)
        }
    }
    Common.Logic.BonusAnnouncementLogic = b.BonusAnnouncementLogic = ut;
    b.static(ut, ["Instance", function() {
        return this.Instance = new ut
    }]);
    class A {
        constructor() {
            this.room_type = 0;
            this.game_id = 0;
            this.game_money = 0;
            this.room_id = "";
            this._worker_type = 0;
            this._worker_id = 0;
            this.max_time = 0;
            this.room_status = 0;
            this._game_status = 0;
            this.GetIntoGameRoom = null;
            this.GetReady = null;
            this.hasGame = false;
            this.config_id = 0;
            this.mul_room_list = null;
            this.recharge_url = "";
            this.betCount = 1;
            this.balance_change_list = [0];
            this.single_win_list = [0];
            this.isAuto = false;
            this.isAutoGaming = false;
            this.autoObj = {};
            this.mineCount = 3;
            this.CELL_COUNT = 25;
            this.nowColumn = 0;
            this.gameHistoryList = [];
            this.MyClientBalance = 0;
            this.CHIP_COUNT = 6;
            this.SHOW_CHIP_COUNT = 6;
            this.lastBrd = {};
            this.animation_open = true;
            this.selected = 1;
            this.autoPlayTimes = 0;
            this.has_chips_setting = false;
            this.InitData = new qe;
            this.NowGameMode = 0;
            this.PlayerCountInGameID = new Object;
            this.myBetList = [];
            this.myBetInfoList = [];
            this.autoArray = [];
            this.BET_OPE_LIST = [];
            this.SHOW_BET_LIST = [];
            this.LAST_BET_LIST = [];
            this.init()
        }
        checkGoalSelect(e) {
            var t = Math.floor(e / 100);
            if (this.FairSimple.sp_array == null || this.FairSimple.sp_array == undefined) {
                if (t == 0) {
                    return true
                }
            } else if (t == this.FairSimple.sp_array.length) {
                return true
            }
            return false
        }
        checkSelectMax() {
            if (this.isAuto) {
                if (this.autoArray.length + this.mineCount >= this.CELL_COUNT) {
                    return true
                }
            } else {
                var e = 0;
                if (this.FairSimple.sp_array != null) {
                    e = this.FairSimple.sp_array.length
                }
                if (e + this.mineCount >= this.CELL_COUNT) {
                    return true
                }
            }
            return false
        }
        init() {
            var e = O.getLocalStorageItem("COOKIEMUSIC", "1");
            if (e == "1") {
                m.musicMuted = false
            } else {
                m.musicMuted = true
            }
            e = O.getLocalStorageItem("COOKIESOUND", "1");
            if (e == "1") {
                m.soundMuted = false
            } else {
                m.soundMuted = true
            }
        }
        SetCmdDataWorkerInfo(e = null) {
            if (this.room_id != "" && this.worker_id != 0 && this.worker_type != 0) {
                if (e) {
                    this.room_id != "" && (e.room_id = this.room_id);
                    this.worker_id != 0 && (e.worker_id = this.worker_id);
                    this.worker_type != 0 && (e.worker_type = this.worker_type)
                }
                return true
            }
            return false
        }
        setInfoByMyRoomCell(e) {
            if (e) {
                this.room_id = e.room_id;
                this._worker_id = e.worker_id;
                this._worker_type = e.worker_type
            }
        }
        getMyBetData(e) {
            if (this.ProMulGameData && this.ProMulGameData.bl != null && this.ProMulGameData.bl.length > 0) {
                for (var t = 0; t < this.ProMulGameData.bl.length; t++) {
                    var a = this.ProMulGameData.bl[t];
                    if (a.rbd == this.ProMulGameData.rbd && a.bx == e) {
                        return a
                    }
                }
            }
            return null
        }
        getMyBetCount() {
            var e = 2;
            var t = O.getLocalStorageItem("COOKIEBETCOUNT", "2");
            if (t == null && t != "" && t != "NaN") {
                e = parseInt(t)
            }
            if (this.ProMulGameData && this.ProMulGameData.bl != null && this.ProMulGameData.bl.length > 0) {
                for (var a = 0; a < this.ProMulGameData.bl.length; a++) {
                    var i = this.ProMulGameData.bl[a];
                    if (i.rbd == this.ProMulGameData.rbd) {
                        if (i.bx == 2) {
                            e = 2
                        }
                    }
                }
            }
            return e
        }
        makeGetIntoGameRoomDtoByData(e) {
            if (e) {
                this.GetIntoGameRoom = new Common.Dto.GetIntoGameRoomDto;
                T.copyObjPropToObj(e, this.GetIntoGameRoom);
                e.game_id && (this.game_id = e.game_id);
                e.game_money && (this.game_money = e.game_money);
                e.room_id && (this.room_id = e.room_id);
                this.room_status = e.room_status;
                this.game_status = e.game_status;
                this.room_type = e.room_mode
            }
        }
        makeGetReadyDtoByData(e) {
            if (e) {
                this.GetReady = new Common.Dto.GetReadyDto;
                T.copyObjPropToObj(e, this.GetReady);
                this.room_status = e.room_status;
                this.game_status = e.game_status
            }
        }
        makeGetPlayerInDeskData(e) {
            if (e) {
                if (!this.GetReady) {
                    this.GetReady = new Common.Dto.GetReadyDto
                }
                this.GetReady.observer = e.observer;
                this.GetReady.game_data.player_array = e.game_data.player_array
            }
        }
        onRoomOver() {
            this.room_status = 3;
            this.GetIntoGameRoom = null;
            this._worker_id = 0;
            this._worker_type = 0;
            this.room_id = ""
        }
        getPlayerDtoByUid(t = 0) {
            t = t || L.Instance.uid;
            if (this.GetReady && this.GetReady.game_data && this.GetReady.game_data.player_array instanceof Array) {
                var e = T.find(this.GetReady.game_data.player_array, function(e) {
                    return e.uid == t
                });
                return e
            }
            return null
        }
        updatePlayerDto(t) {
            if (t && t.uid && this.GetReady && this.GetReady.game_data && this.GetReady.game_data.player_array && this.GetReady.game_data.player_array instanceof Array) {
                var e = T.find(this.GetReady.game_data.player_array, function(e) {
                    return e.uid == t.uid
                });
                if (e) {
                    T.copyObjPropToObj(t, e);
                    e.online = true
                } else {
                    var a = new Common.Dto.BasePlayerDto;
                    T.copyObjPropToObj(t, a);
                    this.GetReady.game_data.player_array.push(a)
                }
            }
        }
        updatePlayerCountInGame(e) {
            this.PlayerCountInGameID[e.game_id] = e
        }
        removePlayerDto(t) {
            T.deleteItemByFunc(Common.Logic.GameContext.Instance.GetReady.game_data.player_array, function(e) {
                return e.uid == t
            })
        }
        isInGame() {
            return this.game_status == 1
        }
        getLeftSeatCount() {
            if (this.GetIntoGameRoom == null || this.GetReady.game_data.player_array == null) {
                return 0
            }
            return this.GetIntoGameRoom.player_count - this.GetReady.game_data.player_array.length
        }
        setAllPlayerReady(e = true) {
            if (this.GetReady && this.GetReady.game_data && this.GetReady.game_data.player_array instanceof Array) {
                for (var t = 0; t < this.GetReady.game_data.player_array.length; t++) {
                    var a = this.GetReady.game_data.player_array[t];
                    if (a) {
                        a.ready = e
                    }
                }
            }
        }
        setGameRoomStatus(e) {
            if (this.GetIntoGameRoom == null) {
                return
            }
            if (e == 1) {
                this.room_status = 2;
                this.game_status = 1
            } else if (e == 2) {
                this.game_status = 0
            }
            if (this.GetReady && this.GetReady.game_data && this.GetReady.game_data.player_array && this.GetReady.game_data.player_array.length > 0) {
                var t;
                for (var a in this.GetReady.game_data.player_array) {
                    t = this.GetReady.game_data.player_array[a];
                    if (e == 1) {
                        t.status = 1;
                        t.ready = true
                    } else if (e == 2) {
                        t.status = 0;
                        t.ready = false
                    }
                }
            }
        }
        hasSit() {
            return this.GetReady && !this.GetReady.observer
        }
        makeReplayGameInfo() {
            if (!L.Instance.replay_data || !L.Instance.replay_data.game_replay_json) return false;
            var e = L.Instance.replay_data.game_replay_json;
            this.GetIntoGameRoom = new Common.Dto.GetIntoGameRoomDto;
            T.copyObjPropToObj(e, this.GetIntoGameRoom);
            this.GetIntoGameRoom.player_count = e.game_option.player_count;
            e.game_id && (this.game_id = e.game_id);
            e.game_money && (this.game_money = e.game_money);
            this.room_status = 1;
            this.game_status = 1;
            if (e.player_info) {
                var t = T.find(e.player_info, function(e) {
                    return e.uid == L.Instance.replay_uid
                });
                if (!t) {
                    L.Instance.replay_uid = e.player_info[0].uid
                }
            }
            return true
        }
        mulUpdateBet(e) {
            if (e.money != 0 && this.MulGameData) {
                if (!this.MulGameData.game_bet_data) {
                    this.MulGameData.game_bet_data = new tt
                }
                this.MulGameData.game_bet_data.now_bet += e.money;
                if (!this.MulGameData.game_bet_data.bet_data) {
                    this.MulGameData.game_bet_data.bet_data = []
                }
                if (!this.MulGameData.game_bet_data.bet_data[e.pos]) {
                    this.MulGameData.game_bet_data.bet_data[e.pos] = new $e(e.pos)
                }
                this.MulGameData.game_bet_data.bet_data[e.pos].money += e.money
            }
        }
        mulUpdateMyBet(e) {
            if (e.money != 0 && e.pos < L.Instance.MulMenCount && this.MulGameData) {
                if (!this.MulGameData.player_bet_data) {
                    this.MulGameData.player_bet_data = []
                }
                for (var t = 0; t < L.Instance.MulMenCount; t++) {
                    if (!this.MulGameData.player_bet_data[t]) {
                        this.MulGameData.player_bet_data[t] = new $e(t)
                    }
                }
                this.MulGameData.player_bet_data[e.pos].money += e.money
            }
        }
        mulClearMyBet() {
            this.MulGameData.player_bet_data = [];
            for (var e = 0; e < L.Instance.MulMenCount; e++) {
                this.MulGameData.player_bet_data.push(new $e(e))
            }
        }
        getBigWinTypeByMoney(e = -1) {
            if (e < 0) {
                e = this.InitData.win_money
            }
            var t = this.InitData.pm;
            var a = Math.round(e / t);
            return this.getBigWinTypeByMul(a)
        }
        getBigWinTypeByMul(e) {
            for (var t = L.Instance.BigWinMul.length - 1; t >= 0; t--) {
                if (e >= L.Instance.BigWinMul[t]) {
                    return t
                }
            }
            return 0
        }
        getFlashTimesByIndex(e) {
            if (Common.Logic.GameContext.Instance.isQuickMode) {
                return [20, 20, 20, 20, 20, 20, 20, 20, 20][e]
            } else {
                return this.ReelFlashTimes[e]
            }
        }
        get game_status() {
            return this._game_status
        }
        set game_status(e) {
            if (e == null) {
                console.log("errroeroeoreoreoreo")
            } else {
                this._game_status = e
            }
        }
        get mulGetMyBankerQueueIndex() {
            for (var e = 0; e < this.MulGameData.banker_queue.length; e++) {
                if (this.MulGameData.banker_queue[e].uid == L.Instance.uid) {
                    return e
                }
            }
            return -1
        }
        get worker_id() {
            return this._worker_id || 0
        }
        set worker_id(e) {
            this._worker_id = e
        }
        get isRoomOver() {
            return this.room_status == 3
        }
        get worker_type() {
            return this._worker_type || 0
        }
        set worker_type(e) {
            this._worker_type = e
        }
        get isObserver() {
            if (this.GetReady && !this.GetReady.observer) {
                return false
            }
            return true
        }
        get game_name() {
            var e = "";
            if (L.Instance.IsReplayMode) {
                if (L.Instance.replay_data && L.Instance.replay_data.game_replay_json) {
                    e = L.Instance.replay_data.game_replay_json.game_name
                }
            } else {
                var t = L.Instance.getGameIDConfig(this.game_id);
                if (t) {
                    e = t.game_name
                }
            }
            return e
        }
        get isRoomFull() {
            if (!this.GetIntoGameRoom || !this.GetReady || !this.GetReady.game_data) {
                return false
            }
            var e = this.GetReady.game_data.player_array;
            var t = Common.Logic.GameContext.Instance.GetIntoGameRoom.player_count;
            var a = e.length >= t;
            return a
        }
        get isGrouping() {
            if (this.room_type == 1 && (L.Instance.nowGameStatus == 12 || L.Instance.nowGameStatus == 13)) {
                return true
            }
            return false
        }
        get mulMeIsBanker() {
            return L.Instance.uid == this.MulGameData.banker_id
        }
        get isMulWaitBankerStatus() {
            return this.MulGameData.game_status == 0
        }
    }
    Common.Logic.GameContext = b.GameContext = A;
    b.static(A, ["Instance", function() {
        return this.Instance = new A
    }]);
    class mt {
        constructor() {
            this.spinError = false;
            this.ignoreErrorCMDList = [1];
            this.retryNumber = 2;
            this.retryCount = 0;
            this.retryErrorList = [E.ERROR_DATA_DECODE_FAIL];
            this.notRefreshErrorList = [E.ERROR_PID_DISBALE, E.ERROR_NOW_CLUSTER_DISENABLE, E.ERROR_GAME_STOP_RUNNING, E.ERROR_USER_MONEY_IS_NOT_ENOUGH, E.ERROR_API_SYSTEM_ERROR, E.ERROR_API_TOKEN_NOT_FOUND_OR_INVALID, E.ERROR_API_DATA_DECRYPT_FAIL, E.ERROR_API_PARAMETER_WRONG, E.ERROR_API_USER_MONEY_IS_NOT_ENOUGH, E.ERROR_HTTP_CONNECT_ERROR]
        }
        showLoading(e = true) {}
        sendHttpMsg(e, t, a) {
            if (this.ignoreErrorCMDList.indexOf(e) < 0) {
                b.timer.once(1500, this, this.showLoading)
            }
            t = t || {};
            e > 0 && (t.cmd = e);
            A.Instance.setPostDataToData(t);
            this.name = "test111";
            jt.Instance.SendData(L.Instance.HttpAddress, t, v.create(this, this.onHttpComplete, [t, a]))
        }
        onHttpComplete(e, t, a, i) {
            b.timer.clear(this, this.showLoading);
            this.showLoading(false);
            if (a) {
                if (L.Instance.canTryNextUrl()) {
                    this.sendHttpMsg(0, e, t)
                } else {
                    if (this.ignoreErrorCMDList.indexOf(e.cmd) >= 0) {
                        return
                    }
                    console.warn("http error:" + i);
                    var n = {};
                    n.callback = function() {
                        o.dispatch("GLOABLE_EVENT_APP_RESTART")
                    };
                    n.text = O.GetErrorText(E.ERROR_HTTP_CONNECT_ERROR, this.notRefreshErrorList);
                    Aa.Instance.showMessage(n.text, v.create(this, function(e) {
                        if (e == K.YES) {
                            n.callback && n.callback()
                        }
                    }))
                }
            } else {
                if (i) {
                    if (i.error != null && i.error != 0) {
                        if (this.retryErrorList.indexOf(i.error) >= 0 && this.retryCount < this.retryNumber) {
                            this.retryCount++;
                            this.sendHttpMsg(0, e, t);
                            return
                        }
                        if (this.ignoreErrorCMDList.indexOf(e.cmd) >= 0) {
                            return
                        }
                        var n = {};
                        if (this.notRefreshErrorList.indexOf(i.error) < 0) {
                            n.callback = function() {
                                o.dispatch("GLOABLE_EVENT_APP_RESTART")
                            }
                        }
                        n.text = O.GetErrorText(i);
                        if (A.Instance.recharge_url != "" && (i.error == E.ERROR_API_USER_MONEY_IS_NOT_ENOUGH || i.error == E.ERROR_USER_MONEY_IS_NOT_ENOUGH)) {
                            Ca.Instance.showMessage(l.DIALOG_NOMONEY, l.DIALOG_NOMONEY, v.create(this, function(e) {
                                if (e == K.YES) {
                                    O.openNewWindow(A.Instance.recharge_url)
                                }
                            }), l.DIALOG_NOMONEY);
                            Ca.Instance.yesType = l.YESNO_YES_RIGHT
                        } else {
                            Aa.Instance.showMessage(n.text, v.create(this, function(e) {
                                if (e == K.YES) {
                                    n.callback && n.callback()
                                }
                            }))
                        }
                    }
                    this.retryCount = 0;
                    t && t.runWith(i)
                }
            }
        }
        doLogin() {
            A.Instance.NowGameStatus = l.GAME_STATUS_LOGINING;
            this.sendHttpMsg(2, {}, v.create(this, function(e) {
                if (e && !e.error) {
                    A.Instance.loginOk(e);
                    Common.Logic.HttpLogicManager.Instance.doInit()
                }
            }))
        }
        doHallLogin() {
            A.Instance.NowGameStatus = l.GAME_STATUS_LOGINING;
            this.sendHttpMsg(s.CMD_LOGIN_HALL, {}, v.create(this, function(e) {
                if (e && !e.error) {
                    A.Instance.loginOk(e);
                    L.Instance.user_name = e.user_name || "";
                    L.Instance.balance = e.balance || 0;
                    this.onReadyGotoGame()
                }
            }))
        }
        doCollectGame(t, a) {
            this.sendHttpMsg(36, {
                app_id: t,
                is_collect: a
            }, v.create(this, function(e) {
                if (e && !e.error) {
                    if (!A.Instance.collect_list) {
                        A.Instance.collect_list = []
                    }
                    T.deleteItemFromArray(A.Instance.collect_list, t);
                    if (a) {
                        A.Instance.collect_list.push(t)
                    }
                }
            }))
        }
        doPing() {
            var a = new Date;
            this.sendHttpMsg(1, {}, v.create(this, function(e) {
                if (e && !e.error) {
                    var t = new Date;
                    L.Instance.ping = t.getTime() - a.getTime();
                    o.dispatch("GLOABLE_EVENT_REFRESH_PING")
                }
            }))
        }
        doSendAdvice(e, t) {
            var a = this;
            this.sendHttpMsg(37, {
                content: e,
                contact: t
            }, v.create(this, function(e) {
                if (e && !e.error) {
                    a.feedbackDate = new Date;
                    o.dispatch("NC_FEEDBACK_OK");
                    Yt.Instance.showText(O.getMsgForNowLang("FEEDBACK_OK"))
                }
            }))
        }
        doInit() {
            this.sendHttpMsg(parseInt(L.Instance.AppID + "01"), {}, v.create(this, function(e) {
                if (e && !e.error) {
                    A.Instance.initOk(e);
                    o.dispatch(r.NC_READY_GOTO_GAME)
                }
            }))
        }
        doSpin() {
            A.Instance.NowGameStatus = 0;
            var e = {};
            var t = A.Instance.InitData;
            e.bet_money = t.bet_money;
            e.bet_line = t.bet_line;
            e.bet_multiple = t.bet_multiple;
            this.spinError = false;
            this.sendHttpMsg(parseInt(L.Instance.AppID + "02"), e, v.create(this, function(e) {
                if (!(e instanceof Object)) return;
                if (e && !e.error) {
                    A.Instance.spinOk(e);
                    A.Instance.NowGameStatus = 1;
                    o.dispatch("HTTP_SPIN_OK")
                } else {
                    this.spinError = true;
                    A.Instance.NowGameStatus = 1;
                    o.dispatch(r.NC_HTTP_ERROR)
                }
            }))
        }
        doBonus(e, t) {
            A.Instance.NowGameStatus = 0;
            e = e || {};
            this.sendHttpMsg(parseInt(L.Instance.AppID + "03"), e, v.create(this, function(e) {
                if (e && !e.error) {
                    A.Instance.NowGameStatus = 0;
                    t && t.runWith(e)
                }
                if (e.balance) {
                    A.Instance.balance = e.balance
                }
            }))
        }
        doGetBonusAnnouncement(e, t) {
            e = e || {};
            this.sendHttpMsg(s.CMD_GET_BONUS_ANNOUNCEMENT, e, v.create(this, function(e) {
                if (e && !e.error) {
                    t && t.runWith(e)
                }
            }))
        }
        doChangeBet() {
            A.Instance.NowGameStatus = 0;
            var e = {};
            e.bet_money = A.Instance.InitData.bet_money;
            this.sendHttpMsg(parseInt(L.Instance.AppID + "04"), e, v.create(this, function(e) {
                if (e && !e.error) {
                    A.Instance.changeBetOk(e);
                    A.Instance.NowGameStatus = 0;
                    o.dispatch("NC_BET_CHANGE")
                } else {
                    this.spinError = true;
                    A.Instance.NowGameStatus = 0;
                    o.dispatch(r.NC_HTTP_ERROR)
                }
            }))
        }
        doBuyFreeSpin() {
            A.Instance.NowGameStatus = 0;
            var e = {};
            var t = A.Instance.InitData;
            e.bet_money = t.bet_money;
            e.bet_line = t.bet_line;
            e.bet_multiple = t.bet_multiple;
            this.spinError = false;
            this.sendHttpMsg(parseInt(L.Instance.AppID + "05"), e, v.create(this, function(e) {
                if (!(e instanceof Object)) return;
                if (e && !e.error) {
                    A.Instance.spinOk(e);
                    A.Instance.NowGameStatus = 1;
                    o.dispatch("HTTP_SPIN_OK");
                    A.Instance.balance = e.balance;
                    o.dispatch(r.NC_UPDATE_BALANCE);
                    A.Instance.isBuyFree = false
                } else {
                    this.spinError = true;
                    A.Instance.NowGameStatus = 1;
                    o.dispatch(r.NC_HTTP_ERROR)
                }
            }))
        }
    }
    Common.Logic.HttpLogicManager = b.HttpLogicManager = mt;
    b.static(mt, ["Instance", function() {
        return this.Instance = new mt
    }]);
    class dt {
        constructor() {
            this.error_times_join = 0;
            this.error_times_get_workerid = 0;
            this.try_get_config_times = 0;
            this.need_get_balance = false;
            this.resent_game_count = 15;
            this.tipOffsetTime = 3e3;
            this.tipping = false;
            this.isClientJump = true;
            this.betChangeTime = 350;
            this.isBetting = false;
            this.canBackToHall = true;
            this.isSending = false;
            this.isInit = true;
            this.initDto = null;
            this.registeOffDispatcher()
        }
        registeOffDispatcher() {
            o.on("GLOABLE_CLOSE_APP", this, this.offAllDispatcher)
        }
        offAllDispatcher() {
            G.off(78, this)
        }
        offAllDispatcher() {
            o.off("GLOABLE_EVENT_APP_READY_TO_RUN", this);
            o.off("NC_GET_OUT_ROOM", this);
            o.off("NC_TCP_CHANGE_USER_PORTRAIT", this);
            o.off("GLOABLE_EVENT_TCP_ON_CONNECT", this);
            o.off("GLOABLE_EVENT_WANT_INIT_TCP_LOGIC", this);
            G.off(51, this);
            G.off(55, this);
            G.off(60, this);
            G.off(69, this);
            G.off(50, this);
            G.off(85, this);
            G.off(86, this);
            G.off(87, this);
            G.off(88, this);
            b.timer.clearAll(this)
        }
        InitTcpLogic() {
            G.on(78, this, this.onPushBonusAnnouncement);
            o.on("GLOABLE_EVENT_APP_READY_TO_RUN", this, this.onAppReadyToRun);
            o.on("GLOABLE_EVENT_WANT_RESTART_TCP_LOGIC", this, this.onWantRestartTcp);
            o.on("NC_GET_OUT_ROOM", this, this.doGetOutGameRoom);
            o.on("NC_TCP_CHANGE_USER_PORTRAIT", this, this.doChangeUserPortrait);
            o.on("GLOABLE_EVENT_WANT_INIT_TCP_LOGIC", this, this.onInitTcp);
            if (L.Instance.IsReplayMode == false) {
                o.on("GLOABLE_EVENT_TCP_ON_CONNECT", this, this.onTcpConnected);
                G.on(51, this, this.onTcpUserBalanceChange);
                G.on(55, this, this.onTcpMarqueeMsg);
                G.on(60, this, this.onTcpKickOff);
                G.on(69, this, this.onTcpServerMaintenance);
                G.on(50, this, this.onGameServerRestart)
            }
        }
        onPushBonusAnnouncement(e) {
            ut.Instance.tryPlayBonusAnima(e)
        }
        onAppReadyToRun() {
            if (L.Instance.IsReplayMode) {
                if (A.Instance.makeReplayGameInfo()) {
                    zt.Instance.StartScene(L.Instance.GameScene, L.Instance.replay_data)
                }
            } else {
                G.Instance.connectTo(L.Instance.tcp_address_url)
            }
        }
        onWantRestartTcp() {
            if (!G.Instance.IsConnected) {
                G.Instance.connectTo(L.Instance.tcp_address_url)
            }
        }
        onInitTcp() {
            this.isInit = false;
            this.doGetFairSimpleInitGame(false, this.initDto)
        }
        onTcpUserBalanceChange(e) {
            if (e.balance != null) {
                o.dispatch("GLOABLE_USER_BALANCE_TOPUP", [e.balance - L.Instance.balance]);
                L.Instance.balance = e.balance;
                o.dispatch("GLOABLE_USER_BALANCE_CHANGE")
            }
        }
        onTcpMarqueeMsg(e) {
            if (e.content != null && e.content != "") {
                var t = e.count == null ? 1 : e.count;
                Wt.Instance.showMarquee(e.content, t)
            }
        }
        onTcpKickOff(e) {
            G.Instance.isTicked = true;
            S.showError(e)
        }
        onTcpServerMaintenance(e) {
            G.Instance.closeSocket();
            S.showError(100012)
        }
        onGameServerRestart(e) {
            this.doNextStep()
        }
        onTcpConnected() {
            this.showLoading(false);
            this.doLoginApp()
        }
        getMaxIX() {
            var e = 0;
            var t = A.Instance;
            if (t.ProMulGameData && t.ProMulGameData.sbl != null && t.ProMulGameData.sbl.length > 0) {
                for (var a = 0; a < t.ProMulGameData.sbl.length; a++) {
                    var i = t.ProMulGameData.sbl[a];
                    if (i.ix > e) {
                        e = i.ix
                    }
                }
            }
            return e
        }
        onCancelBet(t) {
            var a = A.Instance;
            if (t && t.rd && t.rd == a.ProMulGameData.rd) {
                if (a.ProMulGameData && a.ProMulGameData.sbl != null && a.ProMulGameData.sbl.length > 0)
                    if (a.ProMulGameData && a.ProMulGameData.sbl != null && a.ProMulGameData.sbl.length > 0) {
                        T.deleteItemByFunc(a.ProMulGameData.sbl, function(e) {
                            return e.ud == t.ud && e.bx == t.bx
                        })
                    }
                o.dispatch("MFG_BET_LIST_CHANGE");
                if (a.ProMulBetData == null) {
                    a.ProMulBetData = new rt
                }
                a.ProMulGameData.tbc = t.tbc;
                a.ProMulGameData.tbm = t.tbm;
                o.dispatch("MFG_USER_CANCLE_BET");
                o.dispatch("MFG_TOTAL_BET_CHANGE");
                if (this.isMe(t)) {
                    if (a.ProMulGameData && a.ProMulGameData.bl != null && a.ProMulGameData.bl.length > 0) {
                        var e = T.deleteItemByFunc(a.ProMulGameData.bl, function(e) {
                            return e.rbd == a.ProMulGameData.rbd && e.bx == t.bx
                        })
                    }
                    o.dispatch("MFG_MY_BET_LIST_CHANGE");
                    o.dispatch("GLOABLE_USER_BALANCE_CHANGE")
                }
            }
        }
        isMe(e) {
            if (e && e.hasOwnProperty("ud")) {
                if (L.Instance.uid == e.ud) {
                    return true
                }
            }
            return false
        }
        doChangeUserPortrait(t) {
            if (t == L.Instance.pid) {
                o.dispatch("NC_CHANGE_CHA_OK");
                return
            }
            var e = O.MakeCmdData(89);
            e.pid = t;
            G.Instance.SendData(e, v.create(this, function(e) {
                if (O.IsNoError(e)) {
                    L.Instance.pid = t;
                    o.dispatch("NC_CHANGE_CHA_OK")
                } else {
                    O.showMessage(O.GetErrorText(e), e.error)
                }
            }))
        }
        doRefreshUserBalance(t = true) {
            var e = O.MakeCmdData(4);
            G.Instance.SendData(e, v.create(this, function(e) {
                if (O.IsNoError(e) && e.balance != null) {
                    L.Instance.balance = e.balance;
                    t && o.dispatch("GLOABLE_USER_BALANCE_CHANGE")
                }
            }))
        }
        doLoginApp() {
            this.betLastData = new tt;
            var e = O.MakeCmdData(2);
            e.token = L.Instance.token;
            e.app_id = L.Instance.AppID;
            G.Instance.SendData(e, v.create(this, function(e) {
                if (O.IsNoError(e)) {
                    L.Instance.uid = e.uid;
                    L.Instance.pid = e.pid;
                    L.Instance.balance = e.balance;
                    L.Instance.user_name = e.user_name;
                    if (e.hasOwnProperty("pd")) {
                        L.Instance.UrlPid = e.pd
                    }
                    if (e.hasOwnProperty("mode")) {
                        L.Instance.mode = e.mode
                    } else {
                        L.Instance.mode = 1
                    }
                    if (L.Instance.mode == 2) {
                        g.TCP_CALL_TIMEOUT_TIME_SPAN = 3e4
                    }
                    e.recharge_url && (A.Instance.recharge_url = e.recharge_url);
                    this.doGetMyGameStatus();
                    o.dispatch("NC_LONGIN_OK")
                } else {
                    if (e.error == 23 && e.app_id > 0) {
                        O.showMessage(O.GetErrorText(e), e.error, v.create(this, function(e) {
                            L.Instance.gotoOtherGame(e)
                        }, [e.app_id]))
                    } else {
                        O.showMessage(O.GetErrorText(e), e.error)
                    }
                }
            }))
        }
        doGetMyGameStatus() {
            var e = O.MakeCmdData(5);
            G.Instance.SendData(e, v.create(this, function(e) {
                if (O.IsNoError(e)) {
                    if (e.is_in_game || e.is_in_group) {
                        if (e.app_id !== L.Instance.AppID) {
                            G.Instance.closeSocket();
                            S.showError(100014, null, e.app_id);
                            return
                        }
                    }
                    this.doNextStep()
                } else {
                    O.showMessageRestartApp(O.GetErrorText(e), e.error)
                }
            }))
        }
        doGetFairSimpleInitGame(e = false, t = null, a) {
            var i = this;
            this.try_get_config_times++;
            if (t == null) {
                t = O.MakeCmdData(91);
                t.app_id = L.Instance.AppID;
                t.game_id = L.Instance.AppID
            } else {
                t.cmd = 91;
                t.app_id = L.Instance.AppID;
                t.game_id = L.Instance.AppID
            }
            if (e) {
                t.fc = true
            }
            G.Instance.SendData(t, v.create(this, function(e, t) {
                if (O.IsNoError(t)) {
                    G.Instance.isBetting = false;
                    if (A.Instance.FairSimple != null && A.Instance.FairSimple != undefined) {
                        i.freshDT(t)
                    }
                    A.Instance.FairSimple = t;
                    if (t.hasOwnProperty("balance")) {
                        L.Instance.balance = t.balance;
                        o.dispatch("GLOABLE_USER_BALANCE_CHANGE")
                    } else {
                        if (i.isInit == false) {
                            i.doRefreshUserBalance()
                        }
                    }
                    if (t.hasOwnProperty("accuracy")) {
                        L.Instance.DEFAULT_ACCURACY = t.accuracy
                    }
                    o.dispatch("TCP_GET_READY_FINISH");
                    L.Instance.GotoGameScene();
                    e && e.run()
                } else {
                    O.showMessageRestartApp(O.GetErrorText(t), t.error)
                }
            }, [a]))
        }
        showTip(e) {
            if (!this.tipping) {
                o.dispatch("MUL_OPE_ERROR");
                Yt.Instance.showText(e, 2);
                this.tipping = true;
                b.timer.once(this.tipOffsetTime, this, this.resumeTip)
            }
        }
        resumeTip() {
            this.tipping = false
        }
        doSendFairSimpleStartByData(n, e, t = true) {
            var s = this;
            if (G.Instance.isBetting) {
                return
            }
            if (n == null) {
                return
            }
            if ((new Date).getTime() - A.Instance.not_enough_time <= 2e3) {
                S.showError(33);
                e && e.runWith({
                    error: 33
                });
                return
            }
            n.cmd = 92;
            n.app_id = L.Instance.AppID;
            n.game_id = L.Instance.AppID;
            G.Instance.isBetting = true;
            b.timer.once(1e3, this, this.showLoading, [true]);
            G.Instance.SendData(n, v.create(this, function(e, t) {
                b.timer.clear(this, s.showLoading);
                s.showLoading(false);
                G.Instance.isBetting = false;
                if (O.IsNoError(t)) {
                    s.freshDT(t);
                    if (!A.Instance.FairSimple.bm) A.Instance.FairSimple.bm = 0;
                    if (A.Instance.FairSimple.is_over) A.Instance.FairSimple.bm = 0;
                    if (t.pm != null && t.pm > 0) {
                        A.Instance.FairSimple.bm += t.pm
                    }
                    t.bm = A.Instance.FairSimple.bm;
                    A.Instance.FairSimple.rm = t.rm;
                    A.Instance.FairSimple.bet_pos = t.bet_pos;
                    s.freshLastBrd(t);
                    s.freshSha(t);
                    s.freshAutoRunBalance(t);
                    s.freshBalance(t);
                    o.dispatch("NC_FSG_START", [n, t]);
                    if (A.Instance.FairSimple.is_over) {
                        o.dispatch("NC_FSG_OVER", [t]);
                        var a = L.Instance.fsg_next_interval;
                        b.timer.once(a, this, function() {
                            o.dispatch("NC_FSG_NEXT")
                        })
                    }
                } else {
                    var i = [67, 68, E.ERROR_WRONG_GAME_STAGE_CHANGE_POSE, E.ERROR_WRONG_GAME_CHANGE_POSE_AFTER_BET, E.ERROR_WRONG_ONLY_VIP_FOR_EXP, E.ERROR_WRONG_NOT_BET_STATUS, E.ERROR_WRONG_NOT_BET_CANNOT_CANCLE];
                    if (33 == t.error) {
                        s.freshBalance(t);
                        A.Instance.not_enough_time = (new Date).getTime()
                    }
                    if (i.indexOf(t.error) >= 0) {
                        this.showTip(O.GetErrorText(t))
                    } else {
                        S.showError(t)
                    }
                    o.dispatch("GLOABLE_INTERFACE_ERROR", [t.error])
                }
                if (e) {
                    e.runWith(t)
                }
            }, [e]), t)
        }
        freshAutoRunBalance(e) {
            A.Instance.single_win_list[0] = O.caculateAndFixed(A.Instance.FairSimple.rm, A.Instance.FairSimple.bm, 2);
            A.Instance.balance_change_list[0] += O.caculateAndFixed(A.Instance.FairSimple.rm, A.Instance.FairSimple.bm, 2)
        }
        freshBalance(e, t = true) {
            if (e.hasOwnProperty("balance")) {
                L.Instance.balance = e.balance;
                if (t) {
                    o.dispatch("GLOABLE_USER_BALANCE_CHANGE")
                }
            }
        }
        freshDT(e) {
            if (e.hasOwnProperty("dt")) {
                if (e.dt != A.Instance.FairSimple.dt) {
                    A.Instance.FairSimple.dt = e.dt;
                    o.dispatch("NC_FSG_DT_CHANGE")
                }
            }
            var t = false;
            if (e.hasOwnProperty("im")) {
                if (e.im != A.Instance.FairSimple.im) {
                    A.Instance.FairSimple.im = e.im;
                    t = true
                }
            }
            if (e.hasOwnProperty("am")) {
                if (e.am != A.Instance.FairSimple.am) {
                    A.Instance.FairSimple.am = e.am;
                    t = true
                }
            }
            if (e.hasOwnProperty("mwm")) {
                if (e.mwm != A.Instance.FairSimple.mwm) {
                    A.Instance.FairSimple.mwm = e.mwm;
                    t = true
                }
            }
            if (t) {
                o.dispatch("NC_FSG_CONFIG_CHANGE")
            }
        }
        freshLastBrd(e) {
            A.Instance.lastBrd.ss256 = A.Instance.FairSimple.ss256;
            A.Instance.lastBrd.rs256 = A.Instance.FairSimple.rs256;
            A.Instance.lastBrd.brd = e.brd;
            A.Instance.lastBrd.ss = e.ss;
            A.Instance.lastBrd.gs = e.gs;
            A.Instance.lastBrd.rm = e.rm;
            A.Instance.lastBrd.bm = e.bm;
            A.Instance.lastBrd.h_p = e.h_p
        }
        freshSha(e) {
            A.Instance.FairSimple.brd = e.brd;
            A.Instance.FairSimple.ss256 = e.ss256;
            A.Instance.FairSimple.rs256 = e.rs256;
            if (e.hasOwnProperty("is_over")) {
                A.Instance.FairSimple.is_over = e.is_over;
                A.Instance.FairSimple.ss = e.ss;
                A.Instance.FairSimple.gs = e.gs
            } else {
                A.Instance.FairSimple.is_over = false;
                A.Instance.FairSimple.ss = "";
                A.Instance.FairSimple.gs = ""
            }
        }
        showLoading(e) {
            o.dispatch("NC_SHOW_LOADING", [e])
        }
        doSendFairSimpleOpeByData(n, e, s = true) {
            var r = this;
            if (G.Instance.isBetting) {
                return
            }
            if (n == null) {
                return
            }
            if ((new Date).getTime() - A.Instance.not_enough_time <= 2e3) {
                S.showError(33);
                e && e.runWith({
                    error: 33
                });
                return
            }
            n.cmd = 93;
            n.app_id = L.Instance.AppID;
            n.game_id = L.Instance.AppID;
            G.Instance.isBetting = true;
            b.timer.once(1e3, this, this.showLoading, [true]);
            G.Instance.SendData(n, v.create(this, function(e, t) {
                b.timer.clear(this, r.showLoading);
                r.showLoading(false);
                G.Instance.isBetting = false;
                if (O.IsNoError(t)) {
                    o.dispatch("NC_FSG_OPE_CALLBACK", [n, t]);
                    A.Instance.FairSimple.is_over = t.is_over;
                    if (A.Instance.FairSimple.is_over) {
                        A.Instance.FairSimple.bm += t.pm;
                        A.Instance.FairSimple.rm = t.rm;
                        r.freshDT(t);
                        r.freshBalance(t, s);
                        r.freshSha(t);
                        r.freshAutoRunBalance(t);
                        if (A.Instance.FairSimple.is_over) {
                            o.dispatch("NC_FSG_OVER");
                            var a = L.Instance.fsg_ope_next_interval;
                            if (2 == n.ope && L.Instance.fsg_cs_next_interval > 0) {
                                a = L.Instance.fsg_cs_next_interval
                            }
                            b.timer.once(a, this, function() {
                                o.dispatch("NC_FSG_NEXT")
                            })
                        }
                    } else {
                        o.dispatch("NC_FSG_OPE_OVER")
                    }
                } else {
                    var i = [67, 68, E.ERROR_WRONG_GAME_STAGE_CHANGE_POSE, E.ERROR_WRONG_GAME_CHANGE_POSE_AFTER_BET, E.ERROR_WRONG_ONLY_VIP_FOR_EXP, E.ERROR_WRONG_NOT_BET_STATUS, E.ERROR_WRONG_NOT_BET_CANNOT_CANCLE];
                    if (t.error == 33) {
                        r.freshBalance(t);
                        A.Instance.not_enough_time = (new Date).getTime()
                    }
                    if (i.indexOf(n.error) >= 0) {
                        this.showTip(O.GetErrorText(t))
                    } else {
                        S.showError(t)
                    }
                }
                if (e) {
                    e.runWith(t)
                }
            }, [e]))
        }
        doNextStep() {
            this.doGetFairSimpleInitGame(false, this.initDto)
        }
        dataError() {}
        doCheckRoundSeed(e) {
            var t = O.MakeCmdData(90);
            t.record_id = e;
            G.Instance.SendData(t, v.create(this, function(e) {
                if (O.IsNoError(e)) {
                    var t = A.Instance;
                    if (!t.CheckRoundSeedData) {
                        t.CheckRoundSeedData = new lt
                    }
                    t.CheckRoundSeedData.rd = e.rd;
                    t.CheckRoundSeedData.gd = e.gd;
                    t.CheckRoundSeedData.ss = e.ss;
                    t.CheckRoundSeedData.ss256 = e.ss256;
                    t.CheckRoundSeedData.rs256 = e.rs256;
                    t.CheckRoundSeedData.gr = e.gr;
                    t.CheckRoundSeedData.tm = e.tm;
                    o.dispatch("NC_SHOW_CHECKROUN_SEED")
                } else {
                    O.showMessage(O.GetErrorText(e), e.error)
                }
            }))
        }
        doChangeUserImageHead(t) {
            if (t == L.Instance.pid) {
                o.dispatch("NC_CHANGE_CHA_OK");
                return
            }
            var e = O.MakeCmdData(89);
            var a = A.Instance;
            e.room_id = a.room_id;
            e.app_id = L.Instance.AppID;
            e.worker_type = a.worker_type;
            e.worker_id = a.worker_id;
            e.pid = t;
            G.Instance.SendData(e, v.create(this, function(e) {
                if (O.IsNoError(e)) {
                    L.Instance.pid = t
                } else {
                    O.showMessage(O.GetErrorText(e), e.error)
                }
            }))
        }
    }
    Common.Logic.TcpLogicManager = b.TcpLogicManager = dt;
    b.static(dt, ["Instance", function() {
        return this.Instance = new dt
    }]);
    Common.UI = {};
    class gt {
        constructor() {
            this.showType = 0;
            this._aniPath = "";
            this._scaleMin = .7;
            this._offSet = 5;
            this._scaleMax = 1.1;
            this._speed = 3;
            this._pointsNumber = 80;
            this._isHasRotation = true;
            this._isHasScale = true;
            this._bothOri = true;
            this._ori = 1;
            this._leftMaxX = 630;
            this._rightMaxX = 730;
            this._hasAnima = false;
            this._firstPoint = new c(0, 1500);
            this._midPoint = new c(0, 0);
            this._endPoint = new c(0, 1500)
        }
        initPointByOri(e) {
            if (this.showType == 0) {
                this._firstPoint = new c(-100, 1500);
                this._midPoint = new c(630, -500);
                this._endPoint = new c(b.stage.width / 2, 1500)
            } else if (this.showType == 1) {
                this._firstPoint = new c(b.stage.width / 2, 1500);
                this._midPoint = new c(630, -1080)
            }
        }
        start(e, t = true) {
            this.spNode = e;
            this._hasAnima = true;
            this._aniPath = L.Instance.ModuleName + "/common/common/anim/aniCoin.atlas";
            b.timer.frameLoop(this._speed, this, this.birthCoin)
        }
        stop() {
            b.timer.clearAll(this);
            if (this.spNode && this.spNode.getChildren().length > 0) {
                Et.Instance.recover(this.spNode.getChildren())
            }
            this._hasAnima = false
        }
        birthCoin() {
            var e = Et.Instance.getItemByClass(ta);
            this.spNode.addChild(e);
            e.source = this._aniPath;
            e.interval = L.Instance.SymbolInterval;
            e.play(0, true);
            e.y = this._firstPoint.y;
            if (this._bothOri) {
                this._ori = this._ori * -1
            }
            if (this._isHasRotation) {
                e.rotation = O.randomFloat(-360, 360)
            }
            if (this._isHasScale) {
                var t = O.randomFloat(this._scaleMin, this._scaleMax);
                e.scale(t, t)
            }
            this.initPointByOri();
            var a = [];
            var i = new c(0, 0);
            var n = new c(0, 0);
            var s = new c(0, 0);
            if (this.showType == 0) {
                var r = this._ori == 1 ? this._firstPoint.x : Math.abs(this._firstPoint.x) + u.width;
                var o = this._ori == 1 ? this._leftMaxX + O.random(-this._offSet, this._offSet) : this._rightMaxX + O.random(-this._offSet, this._offSet);
                e.x = r;
                i = new c(r, this._firstPoint.y);
                n = new c(o, this._midPoint.y + O.random(-this._offSet, this._offSet));
                s = this._endPoint
            } else if (this.showType == 1) {
                var o = this._ori == 1 ? this._firstPoint.x / 2 + O.random(-this._offSet, this._offSet) : this._firstPoint.x * 3 / 2 + O.random(-this._offSet, this._offSet);
                var l = this._ori == 1 ? this._firstPoint.x - 200 : this._firstPoint.x + 200;
                e.x = this._firstPoint;
                i = this._firstPoint;
                n = new c(o, this._midPoint.y + O.random(-this._offSet, this._offSet));
                s = new c(l, this._endPoint.y)
            }
            a.push(i);
            a.push(n);
            a.push(s);
            var h = this.createBezierPoints(a, this._pointsNumber);
            var _ = 0;
            b.timer.frameLoop(1, this, function() {
                if (_ > h.length - 1) {
                    _ = 0;
                    e.destroy()
                }
                e.pos(h[_].x, h[_].y);
                _++
            })
        }
        createBezierPoints(e, t) {
            var a = [];
            for (var i = 0; i < t; i++) {
                var n = this.multiPointBezier(e, i / t);
                a.push(n)
            }
            return a
        }
        multiPointBezier(e, t) {
            var a = e.length;
            var i = 0;
            var n = 0;
            for (var s = 0; s < a; s++) {
                var r = e[s];
                i += r.x * Math.pow(1 - t, a - 1 - s) * Math.pow(t, s) * this.erxiangshi(a - 1, s);
                n += r.y * Math.pow(1 - t, a - 1 - s) * Math.pow(t, s) * this.erxiangshi(a - 1, s)
            }
            return {
                x: i,
                y: n
            }
        }
        erxiangshi(e, t) {
            var a = 1,
                i = 1;
            while (t > 0) {
                a *= e;
                i *= t;
                e--;
                t--
            }
            return a / i
        }
    }
    Common.UI.ThrowCoin = b.ThrowCoin = gt;
    b.static(gt, ["Instance", function() {
        return this.Instance = new gt
    }]);
    Common.Utils = {};
    class T {
        constructor() {}
        static array_unique(e) {
            for (var t = e.length - 1; t >= 0; t--) {
                if (T.indexOf(e[t], e) < t) {
                    e.splice(t, 1)
                }
            }
        }
        static indexOf(e, t) {
            if (t instanceof Array || t instanceof Array) {
                for (var a = 0; a < t.length; a++) {
                    var i = t[a];
                    if (i === e) {
                        return a
                    }
                    if (e instanceof Array && T.array_is_same(e, i)) {
                        return a
                    }
                    if (typeof e == "object" && "equals" in e) {
                        if (e.equals(i)) {
                            return a
                        }
                    }
                }
            }
            return -1
        }
        static in_array(e, t) {
            if (T.indexOf(e, t) >= 0) {
                return true
            }
            return false
        }
        static deleteItemFromArray(e, t, a = 1) {
            if (a <= 0) {
                return e
            }
            for (var i = 0; i < a; i++) {
                var n = T.indexOf(t, e);
                if (n >= 0) {
                    e.splice(n, 1)
                }
            }
            return e
        }
        static deleteArrayFormArray(e, t) {
            if (e && t) {
                for (var a = 0; a < t.length; a++) {
                    T.deleteItemFromArray(e, t[a])
                }
            }
            return e
        }
        static clearAll(e) {
            if (e && e instanceof Array && e.length > 0) {
                while (e.length > 0) {
                    e.pop()
                }
            }
        }
        static arrayIsContain(e, t) {
            var a = e.concat();
            var i = t.concat();
            T.array_unique(a);
            T.array_unique(i);
            var n = T.array_intersect(a, i);
            if (T.array_is_same(n, t)) {
                return true
            }
            return false
        }
        static array_is_same(e, t) {
            if (e.length !== t.length) {
                return false
            }
            var a = e.concat();
            var i = t.concat();
            a.sort();
            i.sort();
            for (var n = 0; n < a.length; n++) {
                if (a[n] !== i[n]) {
                    return false
                }
            }
            return true
        }
        static keysInObject(e) {
            var t = [];
            for (var a in e) {
                t.push(a)
            }
            return t
        }
        static array_count_values(e) {
            var t = {};
            if (e) {
                for (var a = 0; a < e.length; a++) {
                    var i = e[a];
                    if (!t[i]) {
                        t[i] = 0
                    }++t[i]
                }
            }
            return t
        }
        static values_count_array(e) {
            var t = [];
            if (e) {
                for (var a in e) {
                    var i = e[a];
                    if (typeof i == "number") {
                        for (var n = 0; n < i; n++) {
                            t.push(Number(a))
                        }
                    }
                }
            }
            return t
        }
        static clone(e) {
            var t;
            if (e instanceof Array) {
                t = []
            } else if (e instanceof Array) {
                t = []
            } else {
                t = {}
            }
            if (e && typeof e === "object") {
                for (var a in e) {
                    if (O.hasOwnProperty(e, a)) {
                        if (e[a] && typeof e[a] === "object") {
                            t[a] = T.clone(e[a])
                        } else {
                            t[a] = e[a]
                        }
                    }
                }
            }
            return t
        }
        static array_merge(e = null, t = null) {
            if ((e == null || e.length == 0) && (t == null || t.length == 0)) {
                return []
            }
            if (e == null || e.length == 0) {
                return T.clone(t)
            } else if (t == null || t.length == 0) {
                return T.clone(e)
            }
            var a = e.concat(T.clone(t));
            return a
        }
        static array_intersect(e) {
            var t = arguments;
            var a = [];
            var i = [];
            var n = 0;
            for (n = 0; n < arguments.length; n++) {
                var s = arguments[n];
                if (s instanceof Array) {
                    i = i.concat(s)
                }
            }
            T.array_unique(i);
            for (n = 0; n < i.length; n++) {
                var r = i[n];
                var o = true;
                for (var l = 0; l < arguments.length; l++) {
                    var h = arguments[l];
                    if (h instanceof Array) {
                        if (!T.in_array(r, h)) {
                            o = false;
                            break
                        }
                    }
                }
                if (o) {
                    a.push(r)
                }
            }
            return a
        }
        static combination(e, t = -1) {
            var a = [];
            var i = e.length;
            if (t <= 0 || t > i) {
                return a
            }
            for (var n = 0; n < i; ++n) {
                var s = [];
                s.push(e[n]);
                if (t == 1) {
                    a.push(s)
                } else {
                    var r = T.array_slice(e, n + 1);
                    var o = T.combination(r, t - 1);
                    var l;
                    for (var h in o) {
                        l = o[h];
                        a.push(T.array_merge(s, l))
                    }
                }
            }
            return a
        }
        static array_slice(e, t, a = -1) {
            var i = [];
            var n = 0;
            if (e == null && e.length <= 0) {
                return i
            }
            if (a < 0) {
                a = e.length
            }
            for (var s = 0; s < e.length; ++s) {
                if (s >= t) {
                    i.push(e[s]);
                    n = n + 1;
                    if (a > 0 && n >= a) {
                        return i
                    }
                }
            }
            return i
        }
        static find(e, t, a = null) {
            if (e == null || t == null) {
                return null
            }
            for (var i in e) {
                if (t.call(a, e[i]) == true) {
                    return e[i]
                }
            }
            return null
        }
        static findIndex(e, t, a = null) {
            if (e == null || t == null) {
                return null
            }
            for (var i in e) {
                if (t.call(a, e[i]) == true) {
                    return i
                }
            }
            return null
        }
        static findAll(e, t, a = null) {
            if (e == null || t == null) {
                return []
            }
            var i = [];
            for (var n in e) {
                if (t.call(a, e[n]) == true) {
                    i.push(e[n])
                }
            }
            return i
        }
        static deleteItemByFunc(e, t, a = 0) {
            if (e == null || t == null) {
                return
            }
            var i = 0;
            for (var n = 0; n < e.length; n++) {
                if (t(e[n]) == true) {
                    e.splice(n, 1);
                    n--;
                    i++
                }
                if (a > 0 && i >= a) {
                    break
                }
            }
        }
        static copyObjPropToObj(e, t, a = false) {
            if (!e || !t) {
                return
            }
            for (var i in e) {
                if (a || e[i] != null && O.hasOwnProperty(t, i)) {
                    t[i] = e[i]
                }
            }
        }
        static remove_all(e) {
            for (var t = 0, a = e.length; t < a; t++) {
                e.splice(0, 1)
            }
        }
        static removebyvalue(e, t) {
            var a = e.indexOf(t);
            if (a >= 0) {
                e.splice(a, 1)
            }
            return a
        }
        static randomArray(e) {
            var t = [];
            if (!e || !(e instanceof Array)) return t;
            var a = T.clone(e);
            var i = e.length;
            for (var n = 0; n < i; n++) {
                var s = O.random(0, a.length - 1);
                t.push(a[s]);
                a.splice(s, 1)
            }
            return t
        }
        static getValueFromArr(e, t) {
            if (e == null || t > e.length) {
                return
            }
            var a = e.slice(0);
            var i = [];
            for (var n = 0; n < t; n++) {
                var s = a.length - 1;
                var r = O.random(0, s);
                var o = a[r];
                a.splice(r, 1);
                i.push(o)
            }
            return i
        }
    }
    Common.Utils.ArrayUtils = b.ArrayUtils = T;
    class pt {
        constructor(e, t = null) {
            this.Data = null;
            this.SessionID = 0;
            this.StartTime = 0;
            this._id = 0;
            this.setTo(e, t)
        }
        setTo(e, t = null) {
            this._id = pt._gid++;
            this.Data = e;
            this.SessionID = this.Data.session;
            this.CallBack = t;
            this.StartTime = C.now();
            return this
        }
        runWith(e) {
            if (this.CallBack == null) return;
            var t = this._id;
            this.CallBack.runWith(e);
            this.CallBack = null;
            this._id === t && this.recover()
        }
        clear() {
            this.SessionID = 0;
            this.Data = null;
            this.StartTime = 0;
            if (this.CallBack != null) this.CallBack.recover();
            this.CallBack = null;
            return this
        }
        recover() {
            if (this._id > 0) {
                this._id = 0;
                pt._pool.push(this.clear())
            }
        }
        static create(e, t) {
            if (pt._pool.length) return pt._pool.pop().setTo(e, t);
            return new pt(e, t)
        }
    }
    Common.Utils.CallBackHandler = b.CallBackHandler = pt;
    pt._pool = [];
    pt._gid = 1;
    class O {
        constructor() {}
        static get IsDebugMode() {
            if (g.IS_DEBUG_MODE || u.debug || d.getQueryString("debug") == "true") return true;
            return false
        }
        static autoLabelWidth(e, t) {
            if (e == null) {
                return
            }
            if (e instanceof laya.ui.Label) {
                if (e.width > t) {
                    e.scale(t / e.width, t / e.width)
                } else {
                    e.scale(1, 1)
                }
            } else if (e instanceof Common.UI.ImageNumber) {
                if (e.MyWidth > t) {
                    e.scale(t / e.MyWidth, t / e.MyWidth)
                } else {
                    e.scale(1, 1)
                }
            }
        }
        static deepClone(e) {
            if (e == null || e == undefined) {
                return {}
            }
            return JSON.parse(JSON.stringify(e))
        }
        static getDecimalCount(e) {
            var t = 0;
            var a = e.toString().split(".");
            if (a != null && a.length > 1) {
                t = a[1].length
            }
            return t
        }
        static caculateAndFixed(e, t, a = 1, i = -1) {
            if (e == null || t == null) {
                return 0
            }
            if (i == -1) {
                var n = O.getDecimalCount(e);
                var s = O.getDecimalCount(t);
                if (a == 1 || a == 2) {
                    i = Math.max(n, s)
                } else if (a == 3) {
                    i = n + s
                } else {
                    i = n
                }
            }
            var r = 0;
            if (a == 1) {
                r = O.fixed(e + t, i)
            } else if (a == 2) {
                r = O.fixed(e - t, i)
            } else if (a == 3) {
                r = O.fixed(e * t, i)
            } else {
                r = O.fixed(e / t, i)
            }
            return r
        }
        static fixed(e, t = 2, a = 0) {
            var i = e;
            var n = Math.pow(10, t);
            i = (i * n).toFixed(5);
            if (a == 0) {
                i = Math.floor(i)
            } else if (a == 1) {
                i = Math.ceil(i)
            } else if (a == 2) {
                i = Math.round(i)
            }
            i = i / n;
            return i
        }
        static getChipSkin(e) {
            if (e) {
                var t = 0;
                var a = g.CHIP_LIST;
                for (var i = a.length - 1; i >= 0; i--) {
                    if (e >= a[i]) {
                        t = i;
                        return L.Instance.ModuleName + "/" + Common.Utils.CommonUtils.getPCOrMobilePath(this) + "/common/ui/img_chip" + t + ".png"
                    }
                }
            } else {
                return L.Instance.ModuleName + "/" + Common.Utils.CommonUtils.getPCOrMobilePath(this) + "/common/ui/img_chip0.png"
            }
        }
        static getChipArray(e, t, a) {
            e = Common.Utils.CommonUtils.formatNumber(e);
            if (a == null || a.length == 0) {
                a = g.CHIP_LIST
            }
            if (t == null) {
                t = []
            }
            var i = Common.Utils.CommonUtils.formatNumber(O.getMaxChip(e, a));
            if (i == 0) {
                return t
            } else {
                t.push(i);
                return O.getChipArray(e - i, t, a)
            }
        }
        static getMaxChip(e, t) {
            if (t == null || t.length == 0) {
                t = g.CHIP_LIST
            }
            for (var a = t.length - 1; a >= 0; a--) {
                if (t[a] <= e) {
                    return t[a]
                }
            }
            return 0
        }
        static setTextOverflowByEllipsis(e, t) {
            var a = "";
            if (e == null || t <= 0) {
                return a
            }
            if (e.text != "" && e.width > t) {
                var i = e.text;
                var n = 1;
                while (e.width > t || e.text == "...") {
                    e.text = i.substring(0, i.length - n) + "...";
                    a = e.text;
                    n++
                }
            }
            return a
        }
        static getPCOrMobilePath(e) {
            if (C.onPC) {
                return "pc"
            }
            return "m"
        }
        static makeLabelWordOneByOne(e, t, a = 20, i = 1) {
            if (e == null != t == null || t == undefined || t == "") {
                return
            }
            var n = t.length;
            if (n <= i) {
                e.text = t;
                return
            }
            if (a == null) {
                a = 10
            }
            var s = 0;
            b.timer.clearAll(e);
            b.timer.loop(a, e, function() {
                s += i;
                s = Math.min(n, s);
                e.text = t.substring(0, s);
                if (s >= n) {
                    b.timer.clearAll(e)
                }
            })
        }
        static getGoalMultiple(e, t, a, i = 1, n = 3, s = 4, r = 2, o = 2) {
            var l = 0;
            if (a == 0) {
                return l
            }
            var h = Math.max(1, a);
            var h = Math.min(s, a);
            var _ = n / (n - i);
            l = e * Math.pow(_, h) * ((1e3 - t) / 1e3);
            var c = 1;
            if (r > 0) {
                c = Math.pow(10, r)
            }
            l = parseFloat(l * c).toPrecision(12);
            if (o == 1) {
                l = Math.round(l)
            } else if (o == 2) {
                l = Math.floor(l)
            } else {
                l = Math.ceil(l)
            }
            l = l / c;
            return l
        }
        static getReturnMoney(e, t, a, i, n = 25, s = 2, r = 2) {
            var o = 0;
            var l = Math.max(1, a);
            l = Math.min(l, n - i);
            var h = O.getReturnRate(n, n - i, l);
            o = h * e * (1e3 - t) / 1e3;
            var _ = 1;
            if (s > 0) {
                _ = Math.pow(10, s)
            }
            o = parseFloat(o * _).toPrecision(12);
            if (r == 1) {
                o = Math.round(o)
            } else if (r == 2) {
                o = Math.floor(o)
            } else {
                o = Math.ceil(o)
            }
            o = o / _;
            return o
        }
        static getReturnRate(e, t, a) {
            if (a > e - t) {
                var i = a - e + t;
                return O.permutations(e, a - i) * 1 / O.permutations(t - i, a - i)
            } else {
                return O.permutations(e, a) * 1 / O.permutations(t, a)
            }
        }
        static permutations(e, t) {
            if (e <= 0 || t <= 0) {
                return 1
            }
            var a = Math.max(1, t);
            var i = 1;
            for (var n = 0; n < t; n++) {
                i = i * (e - n)
            }
            return i
        }
        static trimWithChar(e, t = "0", a = false) {
            var i = new String;
            if (e == null || e == "") {
                return i
            }
            i = e;
            do {
                if (i == "") {
                    return ""
                }
                var n = new String;
                if (a) {
                    n = i.substring(0, 1)
                } else {
                    n = i.substring(i.length - 1, i.length)
                }
                var s = false;
                if (n == t) {
                    s = true
                }
                if (s) {
                    if (a) {
                        i = i.substring(1, i.length)
                    } else {
                        i = i.substring(0, i.length - 1)
                    }
                }
            } while (s);
            return i
        }
        static trimMoney(e) {
            var t = 0;
            t = e.toFixed(2);
            var a = t.toString();
            var i = a.split(".");
            if (i.length == 2) {
                var n = O.trimWithChar(i[1]);
                if (n == "") {
                    t = parseFloat(i[0])
                } else {
                    t = parseFloat(i[0] + "." + n)
                }
            } else {
                t = parseFloat(i[0])
            }
            return t
        }
        static setClipboard(e) {
            var t = b.Browser.window.document.createElement("textarea");
            t.setAttribute("id", "cp_zdy_input");
            t.value = e;
            b.Browser.window.document.getElementsByTagName("body")[0].appendChild(t);
            b.Browser.window.document.getElementById("cp_zdy_input").select();
            b.Browser.window.document.execCommand("copy");
            b.Browser.window.document.getElementById("cp_zdy_input").remove()
        }
        static FillInWithChar(e, t = "0", a = 2, i = true) {
            var n = new String;
            if (e == null) {
                return n
            }
            n = e.toString();
            var s = n.length;
            if (s >= a) {
                return n
            }
            for (var r = s; r < a; r++) {
                if (i) {
                    n = t + n
                } else {
                    n += t
                }
            }
            return n
        }
        static formartUTCtoLocalTime(e = 0, t = "-", a = true, i = false, n = false, s = 4) {
            var r = "";
            var o = new Date(e * 1e3);
            var l = L.Instance.lang;
            var h = "";
            var _ = "";
            var c = "";
            var u = "";
            var m = "";
            var d = "";
            if (a) {
                h = O.FillInWithChar(o.getHours());
                _ = O.FillInWithChar(o.getMinutes())
            }
            if (i) {
                c = O.FillInWithChar(o.getSeconds())
            }
            if (n) {
                m = O.FillInWithChar(o.getMonth() + 1);
                d = O.FillInWithChar(o.getDate());
                if (s == 4) {
                    u = o.getFullYear().toString()
                } else if (s == 2) {
                    u = (o.getFullYear() % 100).toString()
                }
            }
            if (l == "vi") {
                if (d != "") {
                    r = d
                }
                if (m != "") {
                    r += t + m
                }
                if (u != "") {
                    r += t + u
                }
                if (h != "") {
                    if (r == "") {
                        r += h
                    } else {
                        r += " " + h
                    }
                }
                if (_ != "") {
                    r += ":" + _
                }
                if (c != "") {
                    r += ":" + c
                }
            } else if (l == "hi") {
                if (m != "") {
                    r = m
                }
                if (d != "") {
                    r += t + d
                }
                if (u != "") {
                    r += t + u
                }
                if (h != "") {
                    if (r == "") {
                        r += h
                    } else {
                        r += " " + h
                    }
                }
                if (_ != "") {
                    r += ":" + _
                }
                if (c != "") {
                    r += ":" + c
                }
            } else {
                if (u != "") {
                    r += u
                }
                if (m != "") {
                    r += t + m
                }
                if (d != "") {
                    r += t + d
                }
                if (h != "") {
                    if (r == "") {
                        r += h
                    } else {
                        r += " " + h
                    }
                }
                if (_ != "") {
                    r += ":" + _
                }
                if (c != "") {
                    r += ":" + c
                }
            }
            return r
        }
        static formartUTCtoLocalTimeByDayMonthYear(e = 0, t = "-", a = true, i = false, n = false, s = 4) {
            var r = "";
            var o = new Date(e * 1e3);
            var l = L.Instance.lang;
            var h = "";
            var _ = "";
            var c = "";
            var u = "";
            var m = "";
            var d = "";
            if (a) {
                h = O.FillInWithChar(o.getHours());
                _ = O.FillInWithChar(o.getMinutes())
            }
            if (i) {
                c = O.FillInWithChar(o.getSeconds())
            }
            if (n) {
                m = O.FillInWithChar(o.getMonth() + 1);
                d = O.FillInWithChar(o.getDate());
                if (s == 4) {
                    u = o.getFullYear().toString()
                } else if (s == 2) {
                    u = (o.getFullYear() % 100).toString()
                }
            }
            if (d != "") {
                r = d
            }
            if (m != "") {
                r += t + m
            }
            if (u != "") {
                r += t + u
            }
            if (h != "") {
                if (r == "") {
                    r += h
                } else {
                    r += " " + h
                }
            }
            if (_ != "") {
                r += ":" + _
            }
            if (c != "") {
                r += ":" + c
            }
            return r
        }
        static getUTCTime() {
            var e = new Date;
            var t = new Date(e.getUTCFullYear(), e.getUTCMonth(), e.getUTCDate(), e.getUTCHours(), e.getUTCMinutes(), e.getUTCSeconds());
            var a = Date.parse(t);
            return a / 1e3 - (new Date).getTimezoneOffset() * 60
        }
        static ConvertVersion(e) {
            var t = 0;
            var a = e.split(".");
            if (a != null && a.length > 0) {
                var i;
                for (var n in a) {
                    i = a[n];
                    t = t * 1e3 + parseInt(i)
                }
            }
            return t
        }
        static MakeCmdData(e) {
            var t = new Object;
            t.cmd = e;
            return t
        }
        static showMessageExitApp(e, t = -1, a = null) {
            Aa.Instance.showMessage(e, t, v.create(null, function(e) {
                if (e != null) e.run();
                o.dispatch("GLOABLE_EVENT_APP_EXIT")
            }, [a]))
        }
        static showMessageRestartApp(e, t = -1, a = null) {
            Aa.Instance.showMessage(e, t, v.create(null, function(e) {
                if (e != null) e.run();
                o.dispatch("GLOABLE_EVENT_APP_RESTART")
            }, [a]))
        }
        static showMessageRestartTCP(e, t = -1, a = null) {
            Aa.Instance.showMessage(e, t, v.create(null, function(e) {
                if (e != null) e.run();
                o.dispatch("GLOABLE_EVENT_WANT_RESTART_TCP_LOGIC")
            }, [a]))
        }
        static showNormalMessageInitTcp(e, t = -1, a = null) {
            Aa.Instance.showMessage(e, t, v.create(null, function(e) {
                o.dispatch("GLOABLE_EVENT_WANT_INIT_TCP_LOGIC");
                if (e != null) e.run()
            }, [a]))
        }
        static showMessageInitTcp(e, t = -1, a = null) {
            Ta.Instance.showMessage(e, t, v.create(null, function(e) {
                o.dispatch("GLOABLE_EVENT_WANT_INIT_TCP_LOGIC");
                if (e != null) e.run()
            }, [a]))
        }
        static showMessage(e, t = -1, a = null) {
            R.Instance.playSound("sound_open");
            Aa.Instance.showMessage(e, t, v.create(null, function(e) {
                if (e != null) e.run()
            }, [a]))
        }
        static IsNoError(e) {
            if (e == null || e.error == null || e.error == 0) return true;
            else {
                if (e.error == 22) {
                    G.Instance.closeSocket()
                }
                return false
            }
        }
        static CheckIsEmptyObject(e) {
            if (e == null) return true;
            var t;
            for (var a in e) {
                t = e[a];
                return false
            }
            return true
        }
        static GetErrorText(e, t = null, a = null) {
            a = a || L.Instance.lang;
            var i = 0;
            if (typeof e == "number" && Math.floor(e) == e) {
                i = e
            } else {
                if (e.error != null && e.error > 0) i = e.error
            }
            if (i <= 0) return "";
            var n = "";
            var e = null;
            if (t != null) {
                e = t[i];
                if (e != null) {
                    n = e[a];
                    return n + "(Error:" + i + ")"
                }
            }
            e = _.ErrorTextDic[i];
            if (e != null) {
                n = e[a];
                return n + "(Error:" + i + ")"
            }
            e = f.ErrorTextDic[i];
            if (e != null) {
                n = e[a];
                return n + "(Error:" + i + ")"
            }
            return n
        }
        static getIsTcpError(e) {
            if (f.ErrorTextDic[e] != null) return true;
            return false
        }
        static getMsgForNowLang(e) {
            var t = n.MsgTextDic[e];
            if (t) {
                if (typeof t[L.Instance.lang] == "string") {
                    return t[L.Instance.lang]
                }
            }
            return ""
        }
        static getMsgForNowLangDic(e, t = null) {
            if (!t) t = n.MsgTextDic;
            var a = t[e];
            if (a) {
                if (typeof a[L.Instance.lang] == "string") {
                    return a[L.Instance.lang]
                }
            }
            return ""
        }
        static random(e, t) {
            return Math.floor(Math.random() * (t - e + 1)) + e
        }
        static randomFloat(e, t) {
            return Math.random() * (t - e) + e
        }
        static randomFromArray(e, t = null) {
            var a;
            if (e == null || e.length == 0) {
                return null
            }
            if (t != null && t.length > 0) {
                if (T.arrayIsContain(t, e)) {
                    t = null
                }
            }
            do {
                a = e[O.random(0, e.length - 1)];
                if (t == null || t.length == 0) {
                    break
                } else {
                    if (t.indexOf(a) < 0) {
                        break
                    }
                }
            } while (true);
            return a
        }
        static restartApp() {
            var e = k.location;
            var t = e.href;
            if (t.lastIndexOf("?") >= 0) {
                var a = t.substr(t.lastIndexOf("?") + 1);
                t = t.substr(0, t.lastIndexOf("?") + 1);
                var i = a.split("&");
                if (i.length > 0) {
                    for (var n = 0; n < i.length; n++) {
                        var s = i[n].split("=");
                        if (s.length == 2) {
                            if (s[0] == "rand") {
                                continue
                            }
                            t = t + s[0] + "=" + s[1] + "&"
                        }
                    }
                    t = t + "rand=" + O.random(1e3, 99999999)
                } else {
                    t = t + "rand=" + O.random(1e3, 99999999)
                }
            } else {
                t = t + "?rand=" + O.random(1e3, 99999999)
            }
            Common.Utils.CommonUtils.IsDebugMode && console.info("restartApp Url:", t);
            C.window.restartApp(t)
        }
        static exitApp() {
            C.window.exitApp()
        }
        static getUCByName(e, t) {
            if (!e || !t || t == "") {
                return null
            }
            var a = e.getChildByName(t);
            if (a) {
                return a
            }
            for (var i = 0; i < e.numChildren; i++) {
                var n = O.getUCByName(e.getChildAt(i), t);
                if (n) {
                    return n
                }
            }
            return null
        }
        static findInSub(e, t) {
            if (!e || !t) {
                return null
            }
            if (e[t] != null) {
                return e[t]
            }
            for (var a in e) {
                if (a.charAt(0) == "_") {
                    continue
                }
                if (typeof e[a] == "object") {
                    var i = O.findInSub(e[a], t);
                    if (i != null) {
                        return i
                    }
                }
            }
            return null
        }
        static Guid() {
            var e = "";
            for (var t = 1; t <= 32; t++) {
                var a = Math.floor(Math.random() * 16).toString(16);
                e += a
            }
            return e.toUpperCase()
        }
        static createView(e, t = null, a = null, i = null) {
            var n;
            if (a) {
                if (i) {
                    n = a.getItemByName(i, e)
                } else {
                    n = a.getItemByClass(e)
                }
            } else {
                n = new e
            }
            if (n.IsLoaded) {
                t && t.runWith(n)
            } else {
                t && n.on(r.EVENT_ON_VIEW_CREATE_END, t.caller, t.method, t.args)
            }
            return n
        }
        static stopAllAction(e) {
            if (e == null) return;
            P.clearTarget(e);
            D.clearTarget(e);
            w.clearTarget(e)
        }
        static hasAction(e) {
            return w.hasAction(e) || P.hasAction(e) || D.hasAction(e)
        }
        static formatNumber(e, t = L.Instance.DEFAULT_ACCURACY, a = L.Instance.DEFAULT_DELZERO) {
            var i = (Math.round(e * 1e8) / 1e8).toFixed(t + 6);
            if (i.indexOf(".") >= 0) {
                i = i.substring(0, i.length - 6)
            }
            if (a) {
                i = i.replace(".00", "");
                if (i.indexOf(".") >= 0 && I.endWith(i, "0")) {
                    i = i.substr(0, i.length - 1)
                }
            }
            return parseFloat(i)
        }
        static getMoneyTextByNumber(e, t = false, a = L.Instance.DEFAULT_ACCURACY, i = L.Instance.DEFAULT_DELZERO) {
            var n = (Math.round(e * 1e8) / 1e8).toFixed(a + 6);
            if (n.indexOf(".") >= 0) {
                n = n.substring(0, n.length - 6)
            }
            if (i) {
                n = n.replace(".00", "");
                if (n.indexOf(".") >= 0 && I.endWith(n, "0")) {
                    n = n.substr(0, n.length - 1)
                }
            }
            if (t) {
                n = I.format(Common.Utils.CommonUtils.getDollarByCurrency(), n)
            }
            return n
        }
        static getDollarByCurrency() {
            if (ke.CurrencyConfig[L.Instance.Currency]) {
                return ke.CurrencyConfig[L.Instance.Currency]
            }
            return ""
        }
        static performWithDelay(e, t, a) {
            if (e == null) {
                return
            }
            if (a > 0) {
                w.to(e, {}, 0, null, t, a)
            } else {
                t && t.run()
            }
        }
        static randomPosition(e, t) {
            if (t == 0) return e;
            var a = Math.abs(t) / 2;
            var i = O.randomFloat(e.x - a, e.x + a);
            var n = O.randomFloat(e.y - a, e.y + a);
            return new c(i, n)
        }
        static randomPositionXY(e, t, a) {
            var i = Math.abs(t) / 2;
            var n = Math.abs(a) / 2;
            var s = O.randomFloat(e.x - i, e.x + i);
            var r = O.randomFloat(e.y - n, e.y + n);
            return new c(s, r)
        }
        static Vecter3Add(e, t) {
            if (!e && !t) {
                return new Le(0, 0, 0)
            }
            if (!e) {
                return t.clone()
            } else if (!t) {
                return e.clone()
            } else {
                return new Le(e.x + t.x, e.y + t.y, e.z + t.z)
            }
        }
        static setPosByOtherSp(e, t, a = 0, i = 0) {
            if (e && t && e.parent && t.parent) {
                e.anchorX = t.anchorX;
                e.anchorY = t.anchorY;
                if (e.parent == t.parent) {
                    e.pos(t.x + a, t.y + i, true)
                } else {
                    var n = t.parent.localToGlobal(new c(t.x, t.y));
                    var s = e.parent.globalToLocal(n);
                    e.pos(s.x + a, s.y + i, true)
                }
            }
        }
        static getDistanceByTwoPos(e, t, a, i) {
            var n = a - e;
            var s = i - t;
            return Math.sqrt(n * n + s * s)
        }
        static getDirectionByTwoPos(e, t) {
            if (null == e || null == t) return 0;
            var a = new c(t.x - e.x, t.y - e.y);
            if (a.x == 0) {
                if (a.y > 0) {
                    return 90
                } else {
                    return 270
                }
            }
            var i = Math.atan(a.y / a.x) / Math.PI * 180;
            if (a.x > 0) {
                i = i
            } else {
                i = i + 180
            }
            i = (i + 360) % 360;
            return i
        }
        static initFromPool(e) {
            e.anchorX = null;
            e.anchorY = null;
            e.rotation = 0;
            e.alpha = 1;
            e.pos(0, 0, true);
            e.scale(1, 1, true)
        }
        static recoverToPool(e) {
            e.offAll();
            b.timer.clearAll(e)
        }
        static checkMusicExist(e) {
            var t = L.Instance.GameResConfig.RES_SOUND;
            for (var a = 0, i = t.length; a < i; a++) {
                var n = t[a];
                if (I.endWith(n, e + ".mp3")) {
                    return true
                }
            }
            return false
        }
        static createTweenSequence(e, t, a, i) {
            if (!e || !t || !a || !i || !t.length || !a.length || !i.length || a.length != i.length) {
                return
            }
            var n = P.create();
            for (var s = 0; s < a.length; s++) {
                var r = {};
                for (var o = 0; o < t.length; o++) {
                    r[t[o]] = a[s]
                }
                n.addTweenChild(w.createTo(e, r, i[s]))
            }
            n.run(e)
        }
        static createHandler(e, t, a) {
            if (e && t) {
                return v.create(e, t, a)
            }
            return null
        }
        static openNewWindow(e) {
            var t = C.window.open(e)
        }
        static hasOwnProperty(e, t) {
            return t in e
        }
        static shakeNode(i, e = 3, t = 5, n = 50) {
            var s = this;
            if (!i) {
                return
            }
            O.stopShake(i);
            i.savePos();
            var a = [];
            var r = [];
            a.push(Common.Utils.CommonUtils.random(1, 4));
            a.push((a[0] + 4 + (Math.random() > .5 ? 0 : -2)) % 4 + 1);
            a.push((a[1] + 1) % 4 + 1);
            for (var o = 0; o < 3; o++) {
                r.push(O.randomPointInQua(e, t, a[o]))
            }
            var l = function(e) {
                if (e == 3) {
                    var t = i._orgPos.x;
                    var a = i._orgPos.y
                } else {
                    var t = i.x + r[e].x;
                    var a = i.y + r[e].y
                }
                w.to(i, {
                    x: t,
                    y: a
                }, n, null, v.create(s, l, [++e > 3 ? 0 : e]))
            };
            l(0)
        }
        static stopShake(e) {
            Common.Utils.CommonUtils.stopAllAction(e);
            e.loadPos()
        }
        static randomPointInQua(e, t, a) {
            var i = Common.Utils.CommonUtils.random(e, t);
            var n = Common.Utils.CommonUtils.random(e, t);
            switch (a) {
                case 2:
                    i = -i;
                    break;
                case 3:
                    n = -n;
                    break;
                case 4:
                    i = -i;
                    n = -n
            }
            return {
                x: i,
                y: n
            }
        }
        static calOffsetX(e, t) {
            if (e <= -180 || e >= 180 || e == 0) {
                return 0
            }
            if (e == 90 || e == -90 || t == 0) {
                return 0
            }
            var a = 0;
            var i = Math.abs(e);
            var n = 1;
            if (e > 90 || e < -90) {
                i = 180 - Math.abs(e);
                n = -1
            }
            a = t / Math.sin(i * 2 * Math.PI / 360) * Math.sin((90 - i) * 2 * Math.PI / 360);
            a = a * n;
            return a
        }
        static randomArray(e) {
            var t = e.concat();
            var a = t.length;
            for (var i = 0; i < a; i++) {
                var n = Math.floor(Math.random() * t.length);
                var s = t[n];
                t[n] = t[i];
                t[i] = s
            }
            return t
        }
        static labelJumpTo(e, t, a, i, n, s = 1, r = false, o = null, l = null, h = false, _ = "") {
            if (e) {
                var c = e.getComponent(bt);
                if (!c) {
                    c = e.addComponent(bt)
                }
                c.jumpTo(t, a, i, n, s, r, o, l, h, _)
            }
        }
        static base64Encode(e) {
            return k.btoa(encodeURIComponent(e).replace(/%([0-9A-F]{2})/g, toSolidBytes = function(e, t) {
                return String.fromCharCode("0x" + t)
            }))
        }
        static base64Decode(e) {
            return decodeURIComponent(k.atob(e).split("").map(function(e) {
                return "%" + ("00" + e.charCodeAt(0).toString(16)).slice(-2)
            }).join(""))
        }
        static setLocalStorageItem(e, t, a = true) {
            var i = L.Instance.AppID + "_" + e;
            if (a) {
                i += "_" + L.Instance.uid
            }
            se.setItem(i, t)
        }
        static getLocalStorageItem(e, t = "", a = true) {
            var i = L.Instance.AppID + "_" + e;
            if (a) {
                i += "_" + L.Instance.uid
            }
            var n = se.getItem(i);
            if (n == null || typeof n == "undefined") n = t;
            return n
        }
        static setLocalStorageJson(e, t, a = true) {
            var i = L.Instance.AppID + "_" + e;
            if (a) {
                i += "_" + L.Instance.uid
            }
            se.setJSON(i, t)
        }
        static getLocalStorageJson(e, t = {}, a = true) {
            var i = L.Instance.AppID + "_" + e;
            if (a) {
                i += "_" + L.Instance.uid
            }
            var n = se.getJSON(i);
            if (n == null || typeof n == "undefined") n = t;
            return n
        }
        static getLang() {
            var e = Common.Utils.CommonUtils.getLocalStorageItem("lang", "en", false);
            if (C.langList != null && C.langList.length > 0 && C.langList.indexOf(e) >= 0) {
                C.lang = e
            }
        }
        static setLang(e) {
            if (C.langList != null && C.langList.length > 0 && C.langList.indexOf(e) >= 0) {
                Common.Utils.CommonUtils.setLocalStorageItem("lang", e.toString(), false);
                k.location.reload()
            }
        }
        static setMobileScreenType(e) {
            if (e == 1 || e == 2) {
                Common.Utils.CommonUtils.setLocalStorageItem(L.Instance.AppID + "mobileScreen", e.toString(), false);
                k.location.reload()
            }
        }
        static getMobileScreenType(e) {
            var t = Common.Utils.CommonUtils.getLocalStorageItem(L.Instance.AppID + "mobileScreen", "", false);
            if (t == "") return e;
            var a = parseInt(t);
            if (a == 1 || a == 2) return a;
            return e
        }
        static getCurrencyStrBySignal(e) {
            e = e.toString();
            if (L.Instance.CurrencyStr != "") {
                if (L.Instance.CurrencyStr.indexOf("%s") < 0) {
                    L.Instance.CurrencyStr = "%s" + L.Instance.CurrencyStr
                }
                return I.format(L.Instance.CurrencyStr, e)
            }
            return e
        }
        static getCurrencySignal() {
            return L.Instance.CurrencyStr.replace("%s", "")
        }
        static autoIframe(e, t, a = true, i = false) {
            if (b.stage.scaleMode == "pchmv" && C.onMobile) {
                var n = 1900;
                var s = 1600;
                var r = 900;
                var o = 900;
                var l = b.stage.realDesignWidth;
                var h = b.stage.realDesignHeight;
                var _ = C.clientWidth;
                var c = C.clientHeight;
                if (a) {
                    n = 1900;
                    s = 1600;
                    r = 900;
                    o = 900
                } else {
                    n = 900;
                    s = 900;
                    r = 1900;
                    o = 1600
                }
                if (C.clientWidth > C.clientHeight) {
                    a = true;
                    var _ = C.clientHeight;
                    var c = C.clientWidth
                } else {
                    a = false
                }
                if (t.width <= s && t.height <= o) {
                    t.x = t.x - (n - l) / 2;
                    t.y = t.y - (r - h) / 2;
                    t.width = t.width + (n - l) / 2;
                    t.height = t.height + (r - h) / 2
                }
                var u = _ / l;
                var m = c / h;
                var d = Math.min(u, m);
                if (e) {
                    e.style.transform = "rotate(0deg)";
                    var g = (_ - d * l) / 2 + t.x * d;
                    var p = (c - d * h) / 2 + t.y * d;
                    var E = t.width * l / n * d;
                    var f = t.height * h / r * d;
                    if (a) {
                        e.style["transform-origin"] = "left top";
                        e.style.transform = "rotate(270deg)";
                        var A = g;
                        g = p;
                        p = _ - A
                    }
                    e.style.left = g + "px";
                    e.style.top = p + "px";
                    e.style.width = E + "px";
                    e.style.height = f + "px"
                }
            } else {
                var n = 1900;
                var s = 1600;
                var r = 900;
                var o = 900;
                var l = b.stage.realDesignWidth;
                var h = b.stage.realDesignHeight;
                var _ = C.clientWidth;
                var c = C.clientHeight;
                if (a) {
                    n = 1900;
                    s = 1600;
                    r = 900;
                    o = 900
                } else {
                    n = 900;
                    s = 900;
                    r = 1900;
                    o = 1600
                }
                if (i) {
                    if (C.clientWidth < C.clientHeight) {
                        a = false;
                        var _ = C.clientHeight;
                        var c = C.clientWidth
                    } else {
                        a = true
                    }
                }
                if (t.width <= s && t.height <= o) {
                    t.x = t.x - (n - l) / 2;
                    t.y = t.y - (r - h) / 2;
                    t.width = t.width + (n - l) / 2;
                    t.height = t.height + (r - h) / 2
                }
                var u = _ / l;
                var m = c / h;
                var d = Math.min(u, m);
                if (e) {
                    e.style.transform = "rotate(0deg)";
                    var g = (_ - d * l) / 2 + t.x * d;
                    var p = (c - d * h) / 2 + t.y * d;
                    var E = t.width * l / n * d;
                    var f = t.height * h / r * d;
                    if (i && !a) {
                        e.style.transform = "rotate(90deg)";
                        var A = g;
                        g = c - p;
                        p = A
                    }
                    e.style.left = g + "px";
                    e.style.top = p + "px";
                    e.style.width = E + "px";
                    e.style.height = f + "px"
                }
            }
        }
    }
    Common.Utils.CommonUtils = b.CommonUtils = O;
    class Et {
        constructor() {
            this._poolDic = {};
            this.showLog = false
        }
        getPoolByClass(e, t = "") {
            return this._getPoolBySign(Et._getClassSign(e) + t)
        }
        getItemByClass(e, t = "") {
            var a = this.getPoolByClass(e, t);
            var i;
            if (a.length > 0) {
                i = a.pop();
                if (!i["__InPool"]) {
                    return this.getItemByClass(e)
                }
                if (this.showLog) {
                    console.log("池中找到了一个可用的：")
                }
            } else {
                if (this.showLog) {
                    console.log("池中没找到 new 一个：")
                }
                i = new e
            }
            if (O.hasOwnProperty(i, "initFromPool")) {
                i.initFromPool()
            }
            if (i instanceof p) {
                O.initFromPool(i)
            }
            i["__InPool"] = false;
            i["__Sign"] = t;
            return i
        }
        recover(e, t = null, a = null) {
            if (e) {
                if (e instanceof Array) {
                    for (var i = e.length - 1; i >= 0; i--) {
                        this.recover(e[i])
                    }
                } else {
                    if (!a || a == "") {
                        a = e["__className"] || e.constructor.name
                    }
                    if (e["__Sign"]) {
                        a += e["__Sign"]
                    }
                    if (a) {
                        var n = this._getPoolBySign(a);
                        e["__InPool"] = true;
                        if (n.indexOf(e) < 0) {
                            if (O.hasOwnProperty(e, "recoverToPool")) {
                                e.recoverToPool()
                            }
                            if (e instanceof laya.display.Sprite) {
                                O.recoverToPool(e)
                            }
                            if (t) {
                                t.runWith(e)
                            } else {
                                if (e.removeSelf) {
                                    e.removeSelf()
                                }
                            }
                            n.push(e)
                        }
                    }
                }
            }
        }
        destroy(e = null, t = null) {
            if (e) {
                this._destroyOnePool(Et._getClassSign(e), t)
            } else {
                for (var a in this._poolDic) {
                    this._destroyOnePool(a, t)
                }
            }
        }
        _getPoolBySign(e) {
            return this._poolDic[e] || (this._poolDic[e] = [])
        }
        _destroyOnePool(e, t = null) {
            if (this._poolDic[e]) {
                var a = this._poolDic[e];
                for (var i = 0; i < a.length; i++) {
                    a[i]["__InPool"] = false;
                    if (t) {
                        t.runWith(a[i])
                    } else if (O.hasOwnProperty(a[i], "destroy")) {
                        a[i].destroy()
                    }
                }
                this._poolDic[e] = []
            }
        }
        logMe() {
            console.log("===========DolPool Log Me:");
            for (var e in this._poolDic) {
                console.log(e + ":" + this._poolDic[e].length)
            }
        }
        static _getClassSign(e) {
            if (!e || e == "") {
                return "_defualt"
            }
            if (typeof e == "string") {
                return e
            }
            var t = e["__className"] || e.name;
            if (!t) {
                e.name = t = d.getGID() + ""
            }
            return t
        }
    }
    Common.Utils.DolPool = b.DolPool = Et;
    Et.POOLSIGN = "__InPool";
    Et.SIGN = "__Sign";
    b.static(Et, ["Instance", function() {
        return this.Instance = new Et
    }]);
    class S {
        constructor() {}
        static showTcpError(e, t) {
            O.IsDebugMode && console.info("Tcp errorText", t)
        }
        static showError(e, t = null) {
            var a = 0;
            if (typeof e == "number" && Math.floor(e) == e) {
                a = e
            } else {
                if (e.error > 0) a = e.error
            }
            var i = O.GetErrorText(a);
            if (i != null && i != "") {
                if (a == 83 || E.ERROR_WRONG_FSG_OPERATION_FAIL == a) {
                    O.showNormalMessageInitTcp(i, t)
                } else if (O.getIsTcpError(a)) {
                    S.showTcpError(a, i);
                    O.showMessage(i, a, t)
                } else {
                    if (L.Instance.IsFinishResLoading == false) {
                        Yt.Instance.showText(i);
                        if (t != null) {
                            t.run()
                        }
                        return
                    }
                    if (a == 100006 || a == 100002 || a == 100005 || a == 100001 || a == 100009 || a == 22 || a == 100013) {
                        O.showMessageRestartApp(i, t)
                    } else if (a == 100008 || a == 100004 || a == 100007 || a == 100012) {
                        O.showMessageRestartTCP(i, t)
                    } else if (a == 1e5) {
                        O.showMessageInitTcp(i, t)
                    } else if (a == 100003 || a == 100010 || a == 100011 || a == 100014 || a == 100015) {
                        O.showMessageExitApp(i, t)
                    } else {
                        O.showMessage(i, a, t)
                    }
                }
            }
        }
    }
    Common.Utils.ErrorShower = b.ErrorShower = S;
    class ft {
        constructor() {}
        checkHV(e) {
            if (b.stage.scaleMode == "pchmv") {
                for (var t = e.length - 1; t >= 0; t--) {
                    var a = e[t];
                    if (C.onPC && a.indexOf("_v") >= 0 || C.onMobile && a.indexOf("_h") >= 0) {
                        e.splice(t, 1)
                    }
                }
            }
        }
        checkLang(e) {
            for (var t = e.length - 1; t >= 0; t--) {
                var a = e[t];
                var i = "/m/";
                if (C.onMobile) {
                    i = "/pc/"
                }
                if (!a.indexOf) {
                    console.log("error:", a)
                }
                if (a.indexOf(i) > -1) {
                    e.splice(t, 1);
                    continue
                }
                var n = false;
                for (var s = 0; s < C.langList.length; s++) {
                    var r = C.langList[s];
                    if (r != L.Instance.lang && a.indexOf("/" + r + "/") > -1) {
                        n = true;
                        break
                    }
                    if (r != L.Instance.lang && a.indexOf("/" + r + ".atlas") > -1) {
                        n = true;
                        break
                    }
                }
                if (n) {
                    e.splice(t, 1);
                    continue
                }
            }
        }
        DoLoadGameResource(t, e, a) {
            var i = this;
            var n = 0;
            var s = 0;
            var r = 0;
            var o = 0;
            var l = 0;
            var h = 0;
            var _ = 0;
            var c = 0;
            var u = 0;
            var m = 0;
            var d = 0;
            var g = (L.Instance.GameResConfig.RES_2D || []).concat();
            var p = (L.Instance.GameResConfig.RES_3D_LMAT || []).concat();
            var E = (L.Instance.GameResConfig.RES_3D || []).concat();
            var f = (L.Instance.GameResConfig.RES_UI || []).concat();
            var A = (L.Instance.GameResConfig.RES_SOUND || []).concat();
            this.checkLang(g);
            this.checkLang(p);
            this.checkLang(E);
            this.checkLang(f);
            this.checkHV(f);
            this.checkLang(A);
            this.checkLang(L.Instance.GameResConfig.RES_SK);
            s = g.length;
            r = p.length;
            o = E.length;
            l = f.length;
            h = A.length;
            e && e.runWith(0);
            n = s + r + o;
            if (n <= 0 || _ + c + u >= n) {
                t && t.run();
                return
            }
            b.loader.on(M.ERROR, this, R);
            var C = v.create(null, I, [e], false);
            Ct.create().addHandler(0, v.create(this, function(e) {
                if (r > 0) {
                    b.loader.create(p, e, v.create(null, T, null, false), ae.MATERIAL)
                } else {
                    e && e.run()
                }
            })).addHandler(0, v.create(this, function(e) {
                c = r;
                C && C.run();
                if (o > 0) {
                    b.loader.create(E, e, v.create(null, O, null, false), ae.HIERARCHY)
                } else {
                    e && e.run()
                }
            })).addHandler(0, v.create(this, function(e) {
                u = o;
                C && C.run();
                if (s > 0) {
                    b.loader.load(g, e, v.create(null, S, null, false))
                } else {
                    e && e.run()
                }
            })).addHandler(0, v.create(this, function(e) {
                _ = s;
                C && C.run();
                if (l > 0) {
                    b.loader.load(f, e, v.create(null, y, null, false))
                } else {
                    e && e.run()
                }
            })).addHandler(0, v.create(this, function(e) {
                m = l;
                C && C.run();
                L.Instance.preLoadFnt(e)
            })).addHandler(0, v.create(this, function(e) {
                L.Instance.preLoadSk(e)
            })).addHandler(0, v.create(this, function(e) {
                if (h > 0) {
                    b.loader.load(A, e, v.create(null, N, null, false), ie.SOUND)
                } else {
                    e && e.run()
                }
            })).addHandler(0, v.create(this, function(e) {
                d = h;
                C && C.run();
                b.loader.offAllCaller(this);
                v.recoverCaller(null, N);
                v.recoverCaller(null, y);
                v.recoverCaller(null, S);
                v.recoverCaller(null, O);
                v.recoverCaller(null, T);
                v.recoverCaller(null, I);
                t && t.run();
                e && e.run()
            })).run();

            function T(e) {
                c = e * r;
                C && C.run()
            }

            function O(e) {
                u = e * o;
                C && C.run()
            }

            function S(e) {
                _ = e * s;
                C && C.run()
            }

            function y(e) {
                m = e * l;
                C && C.run()
            }

            function N(e) {
                d = e * h;
                C && C.run()
            }

            function R(e) {
                b.loader.offAllCaller(i);
                a && a.runWith(e)
            }

            function I(e) {
                var t = 5;
                var a = 2;
                var i = (c * a + u * t + _ + m + d) / (r * a + o * t + s + l + h);
                e && e.runWith(i)
            }
        }
        loadSound() {
            var e = L.Instance.GameResConfig.RES_SOUND || [];
            b.loader.load(e, null, null, ie.SOUND)
        }
        static get Instance() {
            return ft._instance
        }
    }
    Common.Utils.GameResLoader = b.GameResLoader = ft;
    b.static(ft, ["_instance", function() {
        return this._instance = new ft
    }]);
    class At {
        constructor(e, t = 1) {
            this._content = "";
            this._count = 1;
            this._content = e;
            this._count = t
        }
        finishOnce() {
            this._count--
        }
        get Content() {
            return this._content
        }
        get Count() {
            return this._count
        }
    }
    Common.Utils.MarqueeItem = b.MarqueeItem = At;
    class y {
        constructor() {}
        static encrypt(e) {
            return y.hex_md5(e)
        }
        static hex_md5(e) {
            return y.rstr2hex(y.rstr_md5(y.str2rstr_utf8(e)))
        }
        static b64_md5(e) {
            return y.rstr2b64(y.rstr_md5(y.str2rstr_utf8(e)))
        }
        static any_md5(e, t) {
            return y.rstr2any(y.rstr_md5(y.str2rstr_utf8(e)), t)
        }
        static hex_hmac_md5(e, t) {
            return y.rstr2hex(y.rstr_hmac_md5(y.str2rstr_utf8(e), y.str2rstr_utf8(t)))
        }
        static b64_hmac_md5(e, t) {
            return y.rstr2b64(y.rstr_hmac_md5(y.str2rstr_utf8(e), y.str2rstr_utf8(t)))
        }
        static any_hmac_md5(e, t, a) {
            return y.rstr2any(y.rstr_hmac_md5(y.str2rstr_utf8(e), y.str2rstr_utf8(t)), a)
        }
        static md5_vm_test() {
            return y.hex_md5("abc") == "900150983cd24fb0d6963f7d28e17f72"
        }
        static rstr_md5(e) {
            return y.binl2rstr(y.binl_md5(y.rstr2binl(e), e.length * 8))
        }
        static rstr_hmac_md5(e, t) {
            var a = y.rstr2binl(e);
            if (a.length > 16) a = y.binl_md5(a, e.length * 8);
            var i = Array(16),
                n = Array(16);
            for (var s = 0; s < 16; s++) {
                i[s] = a[s] ^ 909522486;
                n[s] = a[s] ^ 1549556828
            }
            var r = y.binl_md5(i.concat(y.rstr2binl(t)), 512 + t.length * 8);
            return y.binl2rstr(y.binl_md5(n.concat(r), 512 + 128))
        }
        static rstr2hex(e) {
            var t = y.hexcase ? "0123456789ABCDEF" : "0123456789abcdef";
            var a = "";
            var i = NaN;
            for (var n = 0; n < e.length; n++) {
                i = e.charCodeAt(n);
                a += t.charAt(i >>> 4 & 15) + t.charAt(i & 15)
            }
            return a
        }
        static rstr2b64(e) {
            var t = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/";
            var a = "";
            var i = e.length;
            for (var n = 0; n < i; n += 3) {
                var s = e.charCodeAt(n) << 16 | (n + 1 < i ? e.charCodeAt(n + 1) << 8 : 0) | (n + 2 < i ? e.charCodeAt(n + 2) : 0);
                for (var r = 0; r < 4; r++) {
                    if (n * 8 + r * 6 > e.length * 8) a += y.b64pad;
                    else a += t.charAt(s >>> 6 * (3 - r) & 63)
                }
            }
            return a
        }
        static rstr2any(e, t) {
            var a = t.length;
            var i = [];
            var n = NaN,
                s = NaN,
                r = NaN,
                o;
            var l = Array(e.length / 2);
            for (n = 0; n < l.length; n++) {
                l[n] = e.charCodeAt(n * 2) << 8 | e.charCodeAt(n * 2 + 1)
            }
            while (l.length > 0) {
                o = [];
                r = 0;
                for (n = 0; n < l.length; n++) {
                    r = (r << 16) + l[n];
                    s = Math.floor(r / a);
                    r -= s * a;
                    if (o.length > 0 || s > 0) o[o.length] = s
                }
                i[i.length] = r;
                l = o
            }
            var h = "";
            for (n = i.length - 1; n >= 0; n--) h += t.charAt(i[n]);
            return h
        }
        static str2rstr_utf8(e) {
            var t = "";
            var a = -1;
            var i = NaN,
                n = NaN;
            while (++a < e.length) {
                i = e.charCodeAt(a);
                n = a + 1 < e.length ? e.charCodeAt(a + 1) : 0;
                if (55296 <= i && i <= 56319 && 56320 <= n && n <= 57343) {
                    i = 65536 + ((i & 1023) << 10) + (n & 1023);
                    a++
                }
                if (i <= 127) t += String.fromCharCode(i);
                else if (i <= 2047) t += String.fromCharCode(192 | i >>> 6 & 31, 128 | i & 63);
                else if (i <= 65535) t += String.fromCharCode(224 | i >>> 12 & 15, 128 | i >>> 6 & 63, 128 | i & 63);
                else if (i <= 2097151) t += String.fromCharCode(240 | i >>> 18 & 7, 128 | i >>> 12 & 63, 128 | i >>> 6 & 63, 128 | i & 63)
            }
            return t
        }
        static str2rstr_utf16le(e) {
            var t = "";
            for (var a = 0; a < e.length; a++) t += String.fromCharCode(e.charCodeAt(a) & 255, e.charCodeAt(a) >>> 8 & 255);
            return t
        }
        static str2rstr_utf16be(e) {
            var t = "";
            for (var a = 0; a < e.length; a++) t += String.fromCharCode(e.charCodeAt(a) >>> 8 & 255, e.charCodeAt(a) & 255);
            return t
        }
        static rstr2binl(e) {
            var t = Array(e.length >> 2);
            for (var a = 0; a < t.length; a++) t[a] = 0;
            for (var a = 0; a < e.length * 8; a += 8) t[a >> 5] |= (e.charCodeAt(a / 8) & 255) << a % 32;
            return t
        }
        static binl2rstr(e) {
            var t = "";
            for (var a = 0; a < e.length * 32; a += 8) t += String.fromCharCode(e[a >> 5] >>> a % 32 & 255);
            return t
        }
        static binl_md5(e, t) {
            e[t >> 5] |= 128 << t % 32;
            e[(t + 64 >>> 9 << 4) + 14] = t;
            var a = 1732584193;
            var i = -271733879;
            var n = -1732584194;
            var s = 271733878;
            for (var r = 0; r < e.length; r += 16) {
                var o = a;
                var l = i;
                var h = n;
                var _ = s;
                a = y.md5_ff(a, i, n, s, e[r + 0], 7, -680876936);
                s = y.md5_ff(s, a, i, n, e[r + 1], 12, -389564586);
                n = y.md5_ff(n, s, a, i, e[r + 2], 17, 606105819);
                i = y.md5_ff(i, n, s, a, e[r + 3], 22, -1044525330);
                a = y.md5_ff(a, i, n, s, e[r + 4], 7, -176418897);
                s = y.md5_ff(s, a, i, n, e[r + 5], 12, 1200080426);
                n = y.md5_ff(n, s, a, i, e[r + 6], 17, -1473231341);
                i = y.md5_ff(i, n, s, a, e[r + 7], 22, -45705983);
                a = y.md5_ff(a, i, n, s, e[r + 8], 7, 1770035416);
                s = y.md5_ff(s, a, i, n, e[r + 9], 12, -1958414417);
                n = y.md5_ff(n, s, a, i, e[r + 10], 17, -42063);
                i = y.md5_ff(i, n, s, a, e[r + 11], 22, -1990404162);
                a = y.md5_ff(a, i, n, s, e[r + 12], 7, 1804603682);
                s = y.md5_ff(s, a, i, n, e[r + 13], 12, -40341101);
                n = y.md5_ff(n, s, a, i, e[r + 14], 17, -1502002290);
                i = y.md5_ff(i, n, s, a, e[r + 15], 22, 1236535329);
                a = y.md5_gg(a, i, n, s, e[r + 1], 5, -165796510);
                s = y.md5_gg(s, a, i, n, e[r + 6], 9, -1069501632);
                n = y.md5_gg(n, s, a, i, e[r + 11], 14, 643717713);
                i = y.md5_gg(i, n, s, a, e[r + 0], 20, -373897302);
                a = y.md5_gg(a, i, n, s, e[r + 5], 5, -701558691);
                s = y.md5_gg(s, a, i, n, e[r + 10], 9, 38016083);
                n = y.md5_gg(n, s, a, i, e[r + 15], 14, -660478335);
                i = y.md5_gg(i, n, s, a, e[r + 4], 20, -405537848);
                a = y.md5_gg(a, i, n, s, e[r + 9], 5, 568446438);
                s = y.md5_gg(s, a, i, n, e[r + 14], 9, -1019803690);
                n = y.md5_gg(n, s, a, i, e[r + 3], 14, -187363961);
                i = y.md5_gg(i, n, s, a, e[r + 8], 20, 1163531501);
                a = y.md5_gg(a, i, n, s, e[r + 13], 5, -1444681467);
                s = y.md5_gg(s, a, i, n, e[r + 2], 9, -51403784);
                n = y.md5_gg(n, s, a, i, e[r + 7], 14, 1735328473);
                i = y.md5_gg(i, n, s, a, e[r + 12], 20, -1926607734);
                a = y.md5_hh(a, i, n, s, e[r + 5], 4, -378558);
                s = y.md5_hh(s, a, i, n, e[r + 8], 11, -2022574463);
                n = y.md5_hh(n, s, a, i, e[r + 11], 16, 1839030562);
                i = y.md5_hh(i, n, s, a, e[r + 14], 23, -35309556);
                a = y.md5_hh(a, i, n, s, e[r + 1], 4, -1530992060);
                s = y.md5_hh(s, a, i, n, e[r + 4], 11, 1272893353);
                n = y.md5_hh(n, s, a, i, e[r + 7], 16, -155497632);
                i = y.md5_hh(i, n, s, a, e[r + 10], 23, -1094730640);
                a = y.md5_hh(a, i, n, s, e[r + 13], 4, 681279174);
                s = y.md5_hh(s, a, i, n, e[r + 0], 11, -358537222);
                n = y.md5_hh(n, s, a, i, e[r + 3], 16, -722521979);
                i = y.md5_hh(i, n, s, a, e[r + 6], 23, 76029189);
                a = y.md5_hh(a, i, n, s, e[r + 9], 4, -640364487);
                s = y.md5_hh(s, a, i, n, e[r + 12], 11, -421815835);
                n = y.md5_hh(n, s, a, i, e[r + 15], 16, 530742520);
                i = y.md5_hh(i, n, s, a, e[r + 2], 23, -995338651);
                a = y.md5_ii(a, i, n, s, e[r + 0], 6, -198630844);
                s = y.md5_ii(s, a, i, n, e[r + 7], 10, 1126891415);
                n = y.md5_ii(n, s, a, i, e[r + 14], 15, -1416354905);
                i = y.md5_ii(i, n, s, a, e[r + 5], 21, -57434055);
                a = y.md5_ii(a, i, n, s, e[r + 12], 6, 1700485571);
                s = y.md5_ii(s, a, i, n, e[r + 3], 10, -1894986606);
                n = y.md5_ii(n, s, a, i, e[r + 10], 15, -1051523);
                i = y.md5_ii(i, n, s, a, e[r + 1], 21, -2054922799);
                a = y.md5_ii(a, i, n, s, e[r + 8], 6, 1873313359);
                s = y.md5_ii(s, a, i, n, e[r + 15], 10, -30611744);
                n = y.md5_ii(n, s, a, i, e[r + 6], 15, -1560198380);
                i = y.md5_ii(i, n, s, a, e[r + 13], 21, 1309151649);
                a = y.md5_ii(a, i, n, s, e[r + 4], 6, -145523070);
                s = y.md5_ii(s, a, i, n, e[r + 11], 10, -1120210379);
                n = y.md5_ii(n, s, a, i, e[r + 2], 15, 718787259);
                i = y.md5_ii(i, n, s, a, e[r + 9], 21, -343485551);
                a = y.safe_add(a, o);
                i = y.safe_add(i, l);
                n = y.safe_add(n, h);
                s = y.safe_add(s, _)
            }
            return [a, i, n, s]
        }
        static md5_cmn(e, t, a, i, n, s) {
            return y.safe_add(y.bit_rol(y.safe_add(y.safe_add(t, e), y.safe_add(i, s)), n), a)
        }
        static md5_ff(e, t, a, i, n, s, r) {
            return y.md5_cmn(t & a | ~t & i, e, t, n, s, r)
        }
        static md5_gg(e, t, a, i, n, s, r) {
            return y.md5_cmn(t & i | a & ~i, e, t, n, s, r)
        }
        static md5_hh(e, t, a, i, n, s, r) {
            return y.md5_cmn(t ^ a ^ i, e, t, n, s, r)
        }
        static md5_ii(e, t, a, i, n, s, r) {
            return y.md5_cmn(a ^ (t | ~i), e, t, n, s, r)
        }
        static safe_add(e, t) {
            var a = (e & 65535) + (t & 65535);
            var i = (e >> 16) + (t >> 16) + (a >> 16);
            return i << 16 | a & 65535
        }
        static bit_rol(e, t) {
            return e << t | e >>> 32 - t
        }
    }
    Common.Utils.MD5 = b.MD5 = y;
    y.HEX_FORMAT_LOWERCASE = 0;
    y.HEX_FORMAT_UPPERCASE = 1;
    y.BASE64_PAD_CHARACTER_DEFAULT_COMPLIANCE = "";
    y.BASE64_PAD_CHARACTER_RFC_COMPLIANCE = "=";
    y.hexcase = 1;
    y.b64pad = "";
    class N {
        constructor() {}
        static Init() {
            if (N.tonyenc_header == null) {
                var e = new Y;
                e.writeUint8(102);
                e.writeUint8(136);
                e.writeUint8(255);
                e.writeUint8(79);
                e.writeUint8(104);
                e.writeUint8(134);
                e.writeUint8(71);
                e.writeUint8(86);
                e.writeUint8(17);
                e.writeUint8(97);
                e.writeUint8(22);
                e.writeUint8(24);
                e.writeUint8(63);
                e.writeUint8(167);
                e.writeUint8(91);
                e.writeUint8(198);
                N.tonyenc_header = e.buffer;
                e.clear()
            }
        }
        static makeRandomEncodeKey() {
            var e = O.random(4, 12 + 1);
            var t = new Y;
            for (var a = 0; a < e; a++) {
                t.writeUint8(O.random(33, 127 + 1))
            }
            return t
        }
        static tonyenc_encode(e, t) {
            var a = 0;
            for (var i = 0; i < e.length; ++i) {
                if ((i & 1) == 1) {
                    a += t[a] + i;
                    a %= t.length;
                    e[i] = ~(e[i] ^ t[a])
                }
            }
        }
        static tonyenc_decode(e, t) {
            var a = 0;
            for (var i = 0; i < e.length; ++i) {
                if ((i & 1) == 1) {
                    a += t[a] + i;
                    a %= t.length;
                    e[i] = ~e[i] ^ t[a]
                }
            }
        }
        static EncodeData(e) {
            N.Init();
            if (g.IS_TCP_PROTOCAL_ENCRYPTION_ENABLE == false) {
                return JSON.stringify(e)
            } else {
                var t = 0;
                var a = 0;
                var i = new Y;
                var n = 0;
                i.writeArrayBuffer(N.tonyenc_header);
                var s = N.makeRandomEncodeKey();
                s.pos = 0;
                var r = s.buffer;
                i.writeUint8(r.byteLength);
                i.writeArrayBuffer(r);
                var o = new Y;
                o.writeArrayBuffer(r);
                o.pos = 0;
                var l = "";
                a = s.bytesAvailable;
                for (t = 0; t < a; t++) {
                    l = l + o.readUint8()
                }
                var h = JSON.stringify(e);
                var e = y.encrypt(l + h) + h;
                o.clear();
                o.writeUTFBytes(e);
                o.pos = 0;
                var _ = [];
                a = o.bytesAvailable;
                for (t = 0; t < a; t++) {
                    _.push(o.getUint8())
                }
                var c = [];
                a = s.bytesAvailable;
                for (t = 0; t < a; t++) {
                    c.push(s.getUint8())
                }
                N.tonyenc_encode(_, c);
                for (t = 0; t < _.length; t++) {
                    i.writeUint8(_[t])
                }
                s.clear();
                o.clear();
                var u = i.buffer;
                i.clear();
                return u
            }
        }
        static DecodeData(e) {
            N.Init();
            if (typeof e == "string") return JSON.parse(e);
            if (e instanceof ArrayBuffer) {
                var t = new Object;
                var a = new Y;
                a.writeArrayBuffer(e);
                a.pos = 0;
                if (a.bytesAvailable <= N.tonyenc_header.byteLength) {
                    t = a.readUTFBytes();
                    a.clear();
                    return JSON.parse(t)
                } else {
                    var i = 0;
                    var n = 0;
                    var s = a.readArrayBuffer(N.tonyenc_header.byteLength);
                    if (N.checkArrayBuffSame(s, N.tonyenc_header) == false) {
                        a.pos = 0;
                        t = a.readUTFBytes();
                        a.clear();
                        return JSON.parse(t)
                    }
                    var r = a.readUint8();
                    if (a.bytesAvailable <= r) {
                        a.clear();
                        t = new Object;
                        t.error = 2;
                        return t
                    }
                    var o = a.readArrayBuffer(r);
                    var l = new Y;
                    l.writeArrayBuffer(o);
                    l.pos = 0;
                    var h = "";
                    n = l.bytesAvailable;
                    for (i = 0; i < n; i++) {
                        h = h + l.readUint8()
                    }
                    l.pos = 0;
                    var _ = [];
                    n = a.bytesAvailable;
                    for (i = 0; i < n; i++) {
                        _.push(a.getUint8())
                    }
                    var c = [];
                    n = l.bytesAvailable;
                    for (i = 0; i < n; i++) {
                        c.push(l.getUint8())
                    }
                    l.clear();
                    N.tonyenc_decode(_, c);
                    a.clear();
                    for (i = 0; i < _.length; i++) {
                        a.writeUint8(_[i])
                    }
                    a.pos = 0;
                    var u = a.readUTFBytes();
                    a.clear();
                    if (u.length <= 32) {
                        t = new Object;
                        t.error = 2;
                        return t
                    }
                    var e = u.substring(32);
                    var m = u.substring(0, 32);
                    if (y.encrypt(h + e) != m) {
                        t = new Object;
                        t.error = 3;
                        return t
                    }
                    return JSON.parse(e)
                }
            }
            return null
        }
        static checkArrayBuffSame(e, t) {
            var a = true;
            if (e.byteLength != t.byteLength) return false;
            if (e.byteLength == 0 || t.byteLength == 0) return true;
            var i = new Y;
            i.writeArrayBuffer(e);
            i.pos = 0;
            var n = new Y;
            n.writeArrayBuffer(t);
            n.pos = 0;
            for (var s = 0; s < i.bytesAvailable; s++) {
                if (i.readUint8() != n.readUint8()) {
                    a = false;
                    break
                }
            }
            i.clear();
            n.clear();
            return a
        }
    }
    Common.Utils.Protocal = b.Protocal = N;
    N.tonyenc_header = null;
    N._MinKeySize = 4;
    N._MaxKeySize = 12;
    N._KeyStart = 33;
    N._KeyEnd = 127;
    class R {
        constructor() {
            this.gameDirNameArray = ["common", "Mahjong", "NiuNiu", "ThirteenWater", "ZhaJinHua", "SanGong"];
            this._soundPath = "";
            this._isFading = false;
            this._intervalArray = [];
            this._soundPath = "Assets/" + L.Instance.ModuleName + "/Sound/"
        }
        playMusicInHall() {
            this._channel = m.playMusic(this.getSoundName("music_hall"), 0)
        }
        playMusicInGame(e, t = 2e3) {
            this.fadeMusicVolume(v.create(this, function() {
                this.playMusic(e)
            }), false, t)
        }
        playMusic(e, t = 0, a = null, i = false) {
            if (e && O.checkMusicExist(e)) {
                if (!i && this._channel && this._channel.completeHandler) {
                    this._channel.completeHandler.recover();
                    this._channel.completeHandler = null
                }
                this._channel = m.playMusic(this.getSoundName(e), t, a);
                return this._channel
            }
            return null
        }
        stopMusic() {
            m.stopMusic()
        }
        continueMusicWithAnother(a) {
            var i = this;
            this.fadeMusicVolume(v.create(this, function() {
                if (a && O.checkMusicExist(a)) {
                    var e = m;
                    var t = e._bgMusic && e._musicChannel && !e._musicChannel.isStopped ? e._musicChannel.position : 0;
                    e.stopMusic();
                    e.playMusic(i.getSoundName(a), 0, null, t);
                    i.fadeMusicVolume(null, true, 500)
                } else {
                    m.stopMusic()
                }
            }), false, 500)
        }
        fadeMusicVolume(e, t = false, a = 2e3, i = true) {
            var n = this;
            var s = L.Instance;
            var r = m;
            if (this._isFading) {
                L.Instance.timer.clearAll(this);
                this._isFading = false
            }
            if (r._bgMusic && r._musicChannel && !r._musicChannel.isStopped && a > 0) {
                this._isFading = true;
                var o = r.musicVolume;
                var l = .1 * r.musicVolume;
                var h = a / 10;
                var _ = r.musicVolume;
                var c = t ? r.musicVolume : 0;
                var u;
                if (t) {
                    r._bgMusic && r._setVolume(r._bgMusic, 0);
                    _ = 0;
                    c = r.musicVolume;
                    u = function() {
                        return (_ += l) > r.musicVolume ? r.musicVolume : _
                    }
                } else {
                    u = function() {
                        return (_ -= l) > .01 ? _ : 0
                    }
                }
                L.Instance.timer.loop(h, this, function() {
                    if (!r._bgMusic || !r._musicChannel || r._musicChannel.isStopped) {
                        n.stopFade(c, i);
                        e && e.run();
                        return
                    }
                    r._bgMusic && r._setVolume(r._bgMusic, u());
                    if (_ < c + .01 && _ > c - .01) {
                        n.stopFade(c, i);
                        e && e.run()
                    }
                })
            } else {
                e && e.run()
            }
        }
        stopFade(e, t = true) {
            var a = m;
            L.Instance.timer.clearAll(this);
            m._musicChannel.volume = e;
            if (e > 0) {} else {
                if (t) {
                    a.stopMusic()
                }
            }
            this._isFading = false
        }
        saveMusicVolume() {
            this._orgMusicVolume = m.musicVolume
        }
        loadMusicVolume() {
            m.setMusicVolume(this._orgMusicVolume)
        }
        getSavedMusicVolume() {
            return this._orgMusicVolume
        }
        playSound(e, t = false, a = "mp3", i = 0) {
            if (O.checkMusicExist(e)) {
                var n;
                if (this._intervalArray.indexOf(e) < 0) {
                    n = m.playSound(this.getSoundName(e, a), t ? 0 : 1);
                    if (i > 0) {
                        this._intervalArray.push(e);
                        L.Instance.timer.once(i, this, this.onIntervalFunc, [e])
                    }
                }
                return n
            }
            return null
        }
        onIntervalFunc(e) {
            T.deleteItemFromArray(this._intervalArray, e)
        }
        stopSound(e, t = "mp3") {
            m.stopSound(this.getSoundName(e, t))
        }
        getSoundName(e, t = "mp3") {
            t = t || "mp3";
            if (e == null || e == "") return;
            if (e.indexOf(".") < 0) {
                e = e + "." + t
            }
            var a = I.format("%s%s", this._soundPath, e);
            return a
        }
        get bgMusicVolume() {
            return m.musicVolume
        }
        set bgMusicVolume(e) {
            m.setMusicVolume(e)
        }
    }
    Common.Utils.SoundUtils = b.SoundUtils = R;
    b.static(R, ["Instance", function() {
        return this.Instance = new R
    }]);
    class I {
        constructor() {}
        static startWith(e, t) {
            if (e && t && e.length > 0 && t.length > 0 && e.length >= t.length) {
                if (e.substr(0, t.length) == t) {
                    return true
                }
            }
            return false
        }
        static endWith(e, t) {
            if (e && t && e.length > 0 && t.length > 0 && e.length >= t.length) {
                if (e.substr(e.length - t.length, t.length) == t) {
                    return true
                }
            }
            return false
        }
        static format(e, t) {
            var S = [];
            for (var y = 1, a = arguments.length; y < a; y++) S.push(arguments[y]);
            var y = 0;
            var i = e.replace(/%(0)?(\d+)?(.)?(0)?(\d+)?([dfs])/gi, function(e, t, a, i, n, s, r) {
                if (!y) y = 0;
                var o = S[y++];
                if (o == null) {
                    return e
                }
                var l = 0;
                var h = 0;
                var _ = t ? t : " ";
                var c = n ? n : " ";
                var u = a ? a : 0;
                var m = s ? s : 0;
                var d = r;
                var g = "";
                var p = "";
                var E = o.toString();
                if (d == "d") {
                    E = parseInt(o).toString();
                    g = E
                } else if (d == "f") {
                    E = parseFloat(o).toString();
                    var f = E.split(".");
                    var A = f[0];
                    var C = f[1];
                    g = A;
                    p = C || ""
                } else {
                    g = E
                }
                for (l = 0, h = u - g.length; l < h; ++l) {
                    g = _ + g
                }
                var T = g;
                if (d == "f") {
                    if (m > 0) {
                        p = p.substring(0, Math.min(p.length, m));
                        var O = p.length;
                        for (l = p.length - 1; l >= 0; --l) {
                            if (p.charAt(l) == "0") {
                                O = l
                            } else {
                                break
                            }
                        }
                        if (O > 0) {
                            p = p.substr(0, O)
                        } else {
                            p = ""
                        }
                        for (l = 0, h = m - p.length; l < h; ++l) {
                            p += c
                        }
                        if (c == " ") {
                            p = I.trim(p)
                        }
                    }
                    if (p.length > 0) {
                        T += ".";
                        T += p
                    }
                }
                return T
            });
            if (i.indexOf("NAN") >= 0) {
                console.log("22222222222222222")
            }
            return i
        }
        static toStringWithCom(e) {
            var t = "";
            var a = e.toString();
            var i = e.split(".");
            if (i.length == 2) {
                a = i[0];
                t = "." + i[1]
            }
            var n = a.length;
            for (var s = 0; s < n; s++) {
                t = a.charAt(n - 1 - s) + t;
                if (s % 3 == 2 && s != n - 1) {
                    t = "," + t
                }
            }
            return t
        }
        static convertString(e) {
            switch (e) {
                case ".":
                    return "Dot";
                case ",":
                    return "Com";
                case "x":
                case "*":
                    return "10";
                case "+":
                    return "11";
                case "-":
                    return "12";
                case "(":
                    return "13";
                case ")":
                    return "14";
                case "∞":
                    return "15";
                case "/":
                    return "16"
            }
            return e
        }
        static getPingString(e) {
            return e.toString() + "ms"
        }
        static getGoldString(e, t = 0) {
            var a = "";
            if (t == 1) {
                if (e > 1e8) {
                    a = Common.Utils.StringUtils.format("%.2f", e / 1e8) + "亿"
                } else if (e > 1e4) {
                    a = Common.Utils.StringUtils.format("%.2f", e / 1e4) + "万"
                } else {
                    a = Common.Utils.StringUtils.format("%.2f", e)
                }
            } else if (t == 2) {
                var i = e.toString();
                var n = i.split(".");
                if (n.length == 2) {
                    i = n[0];
                    a = "." + n[1]
                }
                var s = i.length;
                for (var r = 0; r < s; r++) {
                    a = i.charAt(s - 1 - r) + a;
                    if (r % 3 == 2 && r != s - 1) {
                        a = "," + a
                    }
                }
            } else {
                a = e.toString()
            }
            return a
        }
        static trim(e, t = " ") {
            return I.trimR(I.trimL(e, t), t)
        }
        static trimL(e, t) {
            if (t.length == 1) {
                t = I.revertChr(t);
                var a = new RegExp("^" + t + "+", "g");
                return e.replace(a, "")
            }
            return e
        }
        static trimR(e, t) {
            if (t.length == 1) {
                t = I.revertChr(t);
                var a = new RegExp(t + "+$", "g");
                return e.replace(a, "")
            }
            return e
        }
        static revertChr(e) {
            var t = ["$", "(", ")", "*", "+", ".", "[", "]", "?", "\\", "^", "{", "}", "|"];
            if (t.indexOf(e) >= 0) {
                e = "\\" + e
            }
            return e
        }
        static getMoneyStringByNumber(e) {
            var t = "";
            var a = e.toString().split(".");
            var i = 0;
            if (a.length > 0) {
                var n = a[0];
                if (n != "0") {
                    for (i = 0; i < n.length; i++) {
                        var s = n.length - i - 1;
                        var r = n.charAt(s);
                        switch (i) {
                            case 0:
                                if (r == "0") {
                                    t = "y" + t
                                } else {
                                    t = r + "y" + t
                                }
                                break;
                            case 1:
                                if (r != "0") {
                                    if (r == "1") {
                                        t = "a" + t
                                    } else {
                                        t = r + "a" + t
                                    }
                                }
                                break;
                            case 2:
                                t = n.charAt(s) + "b" + t;
                                break
                        }
                    }
                }
            }
            if (a.length > 1) {
                var o = a[1];
                for (i = 0; i < o.length; i++) {
                    switch (i) {
                        case 0:
                            t += o.charAt(i) + "j";
                            break;
                        case 1:
                            t += o.charAt(i) + "f";
                            break
                    }
                }
            }
            return t
        }
        static replayString(e, t, a, i) {
            return e.replace(new RegExp(t + "([\\s\\S]*?)" + a), t + i + a)
        }
        static arrayBufferToBase64(e) {
            var t = "";
            var a = new Uint8Array(e);
            var i = a.byteLength;
            for (var n = 0; n < i; n++) {
                t += String.fromCharCode(a[n])
            }
            return C.window.btoa(t)
        }
        static doCaluAutoScale(e, t) {
            var a = 1;
            if (e != "" && t.length > 0) {
                var i = e.replace(/,/g, "");
                var n = parseFloat(i) || parseFloat(i.substr(1));
                if (typeof n == "number") {
                    for (var s = 0; s < t.length; s++) {
                        var r = t[s];
                        if (n >= r.minNum) {
                            a = r.scale
                        } else {
                            break
                        }
                    }
                }
            }
            return a
        }
    }
    Common.Utils.StringUtils = b.StringUtils = I;
    class Ct extends X {
        constructor() {
            super();
            this._handleArray = [];
            this._index = 0;
            this._destroy = false;
            this._isRunning = false;
            this._autoRecovery = true;
            this._usedHandler = [];
            this._ownerName = "HandlerSequence"
        }
        initFromPool() {
            this._handleArray = [];
            this._usedHandler = [];
            this._index = 0;
            this._destroy = false
        }
        recoverToPool() {
            b.timer.clearAll(this);
            this.offAll();
            this._destroy = true;
            this._owner = null;
            for (var e = 0; e < this._usedHandler.length; e++) {
                if (this._usedHandler[e] && this._usedHandler[e].owner == this._ownerName) {
                    this._usedHandler[e].recover()
                }
            }
            this._usedHandler = []
        }
        addHandler(e, t) {
            if (this._destroy) {
                console.warn("handler is destroyed, can not addHandler");
                return
            }
            var a = new Object;
            a.time = e;
            a.handler = t;
            t.once = false;
            t.owner = this._ownerName;
            this._handleArray.push(a);
            this._usedHandler.push(t);
            return this
        }
        run(e = true) {
            if (this._destroy) {
                console.warn("handler is destroyed, can not run");
                return
            }
            this._autoRecovery = e;
            if (this._handleArray.length == 0) {
                this.stop(e)
            }
            this.stop(false);
            this._isRunning = true;
            this.runOneHandler();
            return this
        }
        runOneHandler(e = 0) {
            if (this._destroy || !this._isRunning) {
                return
            }
            if (e < 0) {
                e = 0
            }
            if (e >= this._handleArray.length) {
                this.stop(this._autoRecovery);
                return
            }
            this._index = e;
            var t = this._handleArray[e];
            if (t.time == null || t.handler == null) {
                this.stop(this._autoRecovery);
                return
            }
            if (t.time <= 0) {
                t.handler && t.handler.runWith(this.createResolve())
            } else {
                b.timer.frameOnce(L.Instance.getFpsCountByTime(t.time), this, this.timerFunc, [t.handler])
            }
        }
        createResolve() {
            var e = v.create(this, this.resolve, [], false);
            this._usedHandler.push(e);
            return e
        }
        resolve() {
            this.runOneHandler(this._index + 1)
        }
        timerFunc(e) {
            e && e.runWith(this.createResolve())
        }
        stop(e = true) {
            if (!this._destroy) {
                b.timer.clearAll(this);
                this.offAll();
                if (e) {
                    T.deleteItemFromArray(Ct._allHSArray, this);
                    Et.Instance.recover(this)
                }
                this._isRunning = false
            }
        }
        get isRunning() {
            return this._isRunning
        }
        set isRunning(e) {
            super.isRunning = e
        }
        static create(e = null) {
            var t = Et.Instance.getItemByClass(Ct);
            t._owner = e;
            Ct._allHSArray.push(t);
            return t
        }
        static stopAllOwner(e, t = true) {
            if (e) {
                for (var a = Ct._allHSArray.length - 1; a >= 0; a--) {
                    var i = Ct._allHSArray[a];
                    if (i._owner == e) {
                        i.stop(t)
                    }
                }
            }
        }
    }
    Common.Utils.HandlerSequence = b.HandlerSequence = Ct;
    Ct._allHSArray = [];
    class w extends X {
        constructor() {
            super();
            this.gid = 0;
            this._repeat = 1;
            this._count = 0;
            this._isTo = true;
            this._isRunning = false;
            this._reverse = false;
            this._isNowPositive = true
        }
        _create(e, t, a, i, n, s, r, o, l, h, _ = 1, c = false, u = null) {
            if (!e) throw new Error("TweenLite:target is null");
            this._duration = a;
            this._ease = i || t.ease || w.easeNone;
            this._complete = n || t.complete;
            this._start = u;
            this._delay = s || 0;
            this._positiveProps = [];
            this._reverseProps = [];
            this._rawProps = t;
            this._usedTimer = 0;
            this._startTimer = C.now();
            this._usedPool = false;
            this._delayParam = null;
            this.update = t.update;
            this._repeat = _;
            this._count = 0;
            this._isTo = o;
            this._isRunning = false;
            this._reverse = c;
            this._isNowPositive = true;
            if (e != null && e.$_GID == null) e.$_GID = d.getGID();
            var m = e.$_GID;
            if (!w.tweenMap[m]) {
                w.tweenMap[m] = [this]
            } else {
                if (r) w.clearTween(e);
                w.tweenMap[m].push(this)
            }
            this._target = e;
            h && this.run();
            return this
        }
        firstStart() {
            if (this._target != null && this._target.destroyed) {
                this.clear();
                return
            }
            this._initProps();
            this._beginLoop()
        }
        _initProps() {
            if (this._count <= 0 && this._isNowPositive) {
                this._positiveProps = [];
                for (var e in this._rawProps) {
                    if (typeof this._target[e] == "number") {
                        var t = this._isTo ? this._target[e] : this._rawProps[e];
                        var a = this._isTo ? this._rawProps[e] : this._target[e];
                        this._positiveProps.push([e, t, a - t]);
                        if (!this._isTo) this._target[e] = t
                    } else if (this._target[e] instanceof laya.d3.math.Vector3) {
                        var i = this._isTo ? this._target[e] : this._rawProps[e];
                        var n = this._isTo ? this._rawProps[e] : this._target[e];
                        var s = new Le(n.x - i.x, n.y - i.y, n.z - i.z);
                        this._positiveProps.push([e, i.clone(), s]);
                        if (!this._isTo) this._target[e] = i
                    }
                }
                if (this._reverse) {
                    this._reverseProps = [];
                    for (var e in this._rawProps) {
                        if (typeof this._target[e] == "number") {
                            var t = this._isTo ? this._rawProps[e] : this._target[e];
                            var a = this._isTo ? this._target[e] : this._rawProps[e];
                            this._reverseProps.push([e, t, a - t])
                        } else if (this._target[e] instanceof laya.d3.math.Vector3) {
                            var i = this._isTo ? this._rawProps[e] : this._target[e];
                            var n = this._isTo ? this._target[e] : this._rawProps[e];
                            var s = new Le(n.x - i.x, n.y - i.y, n.z - i.z);
                            this._reverseProps.push([e, i.clone(), s])
                        }
                    }
                }
            } else {
                if (this._isNowPositive) {
                    for (var r = 0, o = this._positiveProps.length; r < o; r++) {
                        var l = this._positiveProps[r];
                        if (typeof l[1] == "number") {
                            this._target[l[0]] = l[1]
                        } else if (l[1] instanceof laya.d3.math.Vector3) {
                            this._target[l[0]] = new Le(l[1].x, l[1].y, l[1].z)
                        }
                    }
                } else {
                    for (var r = 0, o = this._reverseProps.length; r < o; r++) {
                        var l = this._reverseProps[r];
                        if (typeof l[1] == "number") {
                            this._target[l[0]] = l[1]
                        } else if (l[1] instanceof laya.d3.math.Vector3) {
                            this._target[l[0]] = new Le(l[1].x, l[1].y, l[1].z)
                        }
                    }
                }
            }
        }
        _beginLoop() {
            b.timer.frameLoop(1, this, this._doEase)
        }
        _doEase() {
            this._updateEase(C.now())
        }
        _updateEase(e) {
            var t = this._target;
            if (!t) return;
            if (t.destroyed) return w.clearTween(t);
            var a = e - this._startTimer - this._delay;
            if (a < 0) return;
            if (a >= this._duration) return this.complete();
            var i = a > 0 ? this._ease(a, 0, 1, this._duration, .3) : 0;
            var n = null;
            if (this._isNowPositive) n = this._positiveProps;
            else n = this._reverseProps;
            for (var s = 0, r = n.length; s < r; s++) {
                var o = n[s];
                if (typeof o[1] == "number") {
                    t[o[0]] = o[1] + i * o[2]
                } else if (o[1] instanceof laya.d3.math.Vector3) {
                    t[o[0]] = new Le(o[1].x + i * o[2].x, o[1].y + i * o[2].y, o[1].z + i * o[2].z)
                }
            }
            if (this.update) this.update.run()
        }
        complete() {
            if (!this._target) return;
            if (this.update) this.update.run();
            var e = this._target;
            var t = null;
            if (this._isNowPositive) t = this._positiveProps;
            else t = this._reverseProps;
            var a = this._complete;
            for (var i = 0, n = t.length; i < n; i++) {
                var s = t[i];
                if (typeof s[1] == "number") {
                    e[s[0]] = s[1] + s[2]
                } else if (s[1] instanceof laya.d3.math.Vector3) {
                    var r = new Le(s[1].x + s[2].x, s[1].y + s[2].y, s[1].z + s[2].z);
                    e[s[0]] = r
                }
            }
            if (this._reverse) {
                if (!this._isNowPositive) {
                    this._count++
                }
            } else {
                this._count++
            }
            if (this._count >= this._repeat) {
                if (a) {
                    if (!a.run) {
                        console.log("erroror!!!!")
                    } else {
                        a.run()
                    }
                }
                this.event("TweenEnd", this);
                this.clear()
            } else {
                if (this._reverse) {
                    this._isNowPositive = !this._isNowPositive
                }
                this.run()
            }
        }
        pause() {
            b.timer.clear(this, this._beginLoop);
            b.timer.clear(this, this._doEase);
            b.timer.clear(this, this.firstStart);
            var e = C.now();
            var t;
            t = e - this._startTimer - this._delay;
            this._usedTimer = t
        }
        resume() {
            if (this._usedTimer >= this._duration) return;
            this._startTimer = C.now() - this._usedTimer - this._delay;
            if (this._delayParam) {
                if (this._usedTimer < 0) {
                    b.timer.once(-this._usedTimer, this, this.firstStart, this._delayParam)
                } else {
                    this.firstStart.apply(this, this._delayParam)
                }
            } else {
                this._usedTimer = 0;
                this._beginLoop()
            }
        }
        setStartTime(e) {
            this._startTimer = e
        }
        clear(e = false) {
            if (this._target) {
                this._remove();
                this._clear(e)
            }
        }
        _clear(e = false) {
            this.pause();
            b.timer.clear(this, this.firstStart);
            if (e && this._complete != null && this._complete instanceof v) {
                this._complete.recover()
            }
            this._complete = null;
            this._target = null;
            this._ease = null;
            this._positiveProps = null;
            this._reverseProps = null;
            this._rawProps = null;
            this._delayParam = null;
            this._delay = 0;
            this._count = 0;
            this._isTo = true;
            this._repeat = 1;
            this._isRunning = false;
            this._usedTimer = 0;
            this._startTimer = 0;
            this._reverse = false;
            this._isNowPositive = true;
            this.update = null;
            if (this._usedPool) {
                le.recover("TweenLite", this)
            }
        }
        recover() {
            this._usedPool = false;
            this.clear()
        }
        _remove() {
            var e = w.tweenMap[this._target.$_GID];
            if (e) {
                for (var t = 0, a = e.length; t < a; t++) {
                    if (e[t] === this) {
                        e.splice(t, 1);
                        break
                    }
                }
                if (e.length == 0) {
                    delete w.tweenMap[this._target.$_GID]
                }
            }
        }
        run(e) {
            this._start && this._start.run();
            this._usedTimer = 0;
            this._startTimer = C.now();
            this._isRunning = true;
            b.timer.once(this._delay, this, this.firstStart)
        }
        static logMe() {
            for (var e in w.tweenMap) {
                console.log(e, w.tweenMap[e])
            }
        }
        static logTarget(e, t) {
            if (!e || !e.$_GID) return;
            var a = w.tweenMap[e.$_GID];
            if (!a) return;
            console.log(t, a.length)
        }
        static to(e, t, a, i = null, n = null, s = 0, r = false, o = 1, l = false, h = true) {
            return le.getItemByClass("TweenLite", w)._create(e, t, a, i, n, s, l, true, h, true, o, r)
        }
        static from(e, t, a, i = null, n = null, s = 0, r = false, o = 1, l = false, h = true) {
            return le.getItemByClass("TweenLite", w)._create(e, t, a, i, n, s, l, false, h, true, o, r)
        }
        static createTo(e, t, a, i = null, n = null, s = 0, r = false, o = 1, l = false, h = true, _ = null) {
            return le.getItemByClass("TweenLite", w)._create(e, t, a, i, n, s, l, true, h, false, o, r, _)
        }
        static createFrom(e, t, a, i = null, n = null, s = 0, r = false, o = 1, l = false, h = true) {
            return le.getItemByClass("TweenLite", w)._create(e, t, a, i, n, s, l, false, h, false, o, r)
        }
        static clearTarget(e) {
            if (!e || !e.$_GID) return;
            var t = w.tweenMap[e.$_GID];
            if (t) {
                for (var a = 0, i = t.length; a < i; a++) {
                    t[a]._clear(true)
                }
                t.length = 0;
                delete w.tweenMap[e.$_GID]
            }
        }
        static hasAction(e) {
            if (!e || !e.$_GID) return false;
            var t = w.tweenMap[e.$_GID];
            if (t && t.length > 0) return true;
            return false
        }
        static clear(e) {
            e.clear()
        }
        static clearTween(e) {
            w.clearTarget(e)
        }
        static easeNone(e, t, a, i) {
            return a * e / i + t
        }
    }
    Common.Utils.TweenLite = b.TweenLite = w;
    w.tweenMap = {};
    class P extends X {
        constructor() {
            super();
            this._id = 0;
            this._index = 0;
            this._totalCount = 0;
            this._isPause = false;
            this._isPauseNext = false;
            this.tweenItemArray = []
        }
        init(e = null) {
            this._id = P._gid++;
            this._complete = e;
            this._index = 0;
            this._totalCount = 0
        }
        addTweenChild(e) {
            var t = this;
            if (e instanceof Common.Utils.TweenLite || e instanceof Common.Utils.TweenSpawn || e instanceof Common.Utils.TweenSequence) {
                e.once("TweenEnd", this, function() {
                    if (this._isPause) {
                        this._isPauseNext = true
                    } else {
                        t.tweenItemArray.shift();
                        this.doOneStep()
                    }
                });
                this.tweenItemArray.push(e)
            } else {
                throw "addTweenChild Fail Wrong TweenType!"
            }
            return this
        }
        finishTween() {
            j.I.callLater(this, function() {
                this._complete && this._complete.run();
                this._complete = null;
                this.event("TweenEnd", this);
                this.recover()
            })
        }
        run(e = null) {
            if (e != null && e.$_GID == null) e.$_GID = d.getGID();
            if (e != null) {
                var t = e.$_GID;
                if (!P.tweenMap[t]) {
                    P.tweenMap[t] = [this]
                } else {
                    P.tweenMap[t].push(this)
                }
            }
            this._target = e;
            this._index = 0;
            this._totalCount = this.tweenItemArray.length;
            this.doOneStep()
        }
        _remove() {
            if (this._target != null) {
                var e = P.tweenMap[this._target.$_GID];
                if (e) {
                    for (var t = 0, a = e.length; t < a; t++) {
                        if (e[t] === this) {
                            e.splice(t, 1);
                            break
                        }
                    }
                }
            }
        }
        pause() {
            var e = this.tweenItemArray[0];
            e && e.pause && e.pause();
            this._isPause = true
        }
        resume() {
            var e = this.tweenItemArray[0];
            e && e.resume && e.resume();
            this._isPause = false;
            if (this._isPauseNext) {
                this.tweenItemArray.shift();
                this.doOneStep()
            }
            this._isPauseNext = false
        }
        doOneStep() {
            if (this._index >= this._totalCount) {
                this.finishTween();
                return
            }
            var e = this.tweenItemArray[0];
            this._index++;
            e.run(this._target)
        }
        recover() {
            if (this._id == 0) return;
            while (this.tweenItemArray.length > 0) {
                var e = this.tweenItemArray.pop();
                e.off("TweenEnd", this, this.onTweenEndHandler, true);
                e.recover()
            }
            this.tweenItemArray = [];
            var t = P._TweenSequenceArray.indexOf(this);
            if (t >= 0) {
                P._TweenSequenceArray.splice(t, 1)
            }
            this._remove();
            this._target = null;
            this._index = 0;
            this._totalCount = 0;
            this._id = 0;
            this._complete && this._complete.recover();
            this._complete = null
        }
        static logMe() {
            console.log("===== TweenSequence's count:" + P._TweenSequenceArray.length)
        }
        static create(e = null) {
            var t = new P;
            P._TweenSequenceArray.push(t);
            t.init(e);
            return t
        }
        static clearTarget(e) {
            if (!e || !e.$_GID) return;
            var t = P.tweenMap[e.$_GID];
            if (t) {
                for (var a = 0; a < t.length;) {
                    var i = t[a];
                    i && i.recover()
                }
                t.length = 0
            }
        }
        static hasAction(e) {
            if (!e || !e.$_GID) return false;
            var t = P.tweenMap[e.$_GID];
            if (t && t.length > 0) return true;
            return false
        }
        static clearAll() {
            var e;
            for (var t in P._TweenSequenceArray) {
                e = P._TweenSequenceArray[t];
                e.recover()
            }
            P._TweenSequenceArray = [];
            P.tweenMap = []
        }
    }
    Common.Utils.TweenSequence = b.TweenSequence = P;
    P._TweenSequenceArray = [];
    P.tweenMap = [];
    P._gid = 1;
    class D extends X {
        constructor() {
            super();
            this._id = 0;
            this._totalCount = 0;
            this.tweenItemArray = []
        }
        init(e = null) {
            this._id = D._gid++;
            this._complete = e;
            this._totalCount = 0
        }
        addTweenChild(t) {
            var a = this;
            if (t instanceof Common.Utils.TweenLite || t instanceof Common.Utils.TweenSpawn || t instanceof Common.Utils.TweenSequence) {
                t.once("TweenEnd", this, function() {
                    var e = a.tweenItemArray.indexOf(t);
                    if (e >= 0) {
                        a.tweenItemArray.splice(e, 1)
                    }
                    this._totalCount--;
                    if (this._totalCount <= 0) {
                        this.finishTween()
                    }
                });
                this.tweenItemArray.push(t)
            } else {
                throw "addTweenChild Fail Wrong TweenType!"
            }
            return this
        }
        finishTween() {
            j.I.callLater(this, function() {
                this._complete && this._complete.run();
                this._complete = null;
                this.event("TweenEnd", this);
                this.recover()
            })
        }
        run(e = null) {
            if (e != null && e.$_GID == null) e.$_GID = d.getGID();
            if (e != null) {
                var t = e.$_GID;
                if (!D.tweenMap[t]) {
                    D.tweenMap[t] = [this]
                } else {
                    D.tweenMap[t].push(this)
                }
            }
            this._target = e;
            this._totalCount = this.tweenItemArray.length;
            if (this._totalCount <= 0) {
                this.finishTween();
                return
            }
            for (var a = 0; a < this.tweenItemArray.length; a++) {
                var e = this.tweenItemArray[a];
                e.run(this._target)
            }
        }
        pause() {
            for (var e = 0; e < this.tweenItemArray.length; e++) {
                var t = this.tweenItemArray[e];
                t.pause()
            }
        }
        resume() {
            for (var e = 0; e < this.tweenItemArray.length; e++) {
                var t = this.tweenItemArray[e];
                t.resume()
            }
        }
        _remove() {
            if (this._target != null) {
                var e = D.tweenMap[this._target.$_GID];
                if (e) {
                    for (var t = 0, a = e.length; t < a; t++) {
                        if (e[t] === this) {
                            e.splice(t, 1);
                            break
                        }
                    }
                }
            }
        }
        recover() {
            if (this._id == 0) return;
            while (this.tweenItemArray.length > 0) {
                var e = this.tweenItemArray.pop();
                e.off("TweenEnd", this, this.onTweenEndHandler, true);
                e.recover()
            }
            this.tweenItemArray = [];
            var t = D._TweenSpawnArray.indexOf(this);
            if (t >= 0) {
                D._TweenSpawnArray.splice(t, 1)
            }
            this._remove();
            this._target = null;
            this._id = 0;
            this._totalCount = 0;
            this._complete && this._complete.recover();
            this._complete = null;
            le.recover("TweenSpwan", this)
        }
        static logMe() {
            console.log("===== TweenSpawn's count:" + D._TweenSpawnArray.length)
        }
        static create(e = null) {
            var t = le.getItemByClass("TweenSpwan", D);
            D._TweenSpawnArray.push(t);
            t.init(e);
            return t
        }
        static clearTarget(e) {
            if (!e || !e.$_GID) return;
            var t = D.tweenMap[e.$_GID];
            if (t) {
                for (var a = 0; a < t.length;) {
                    var i = t[a];
                    i && i.recover()
                }
                t.length = 0
            }
        }
        static hasAction(e) {
            if (!e || !e.$_GID) return false;
            var t = D.tweenMap[e.$_GID];
            if (t && t.length > 0) return true;
            return false
        }
        static clearAll() {
            var e;
            for (var t in D._TweenSpawnArray) {
                e = D._TweenSpawnArray[t];
                e.recover()
            }
            D._TweenSpawnArray = [];
            D.tweenMap = []
        }
    }
    Common.Utils.TweenSpawn = b.TweenSpawn = D;
    D._TweenSpawnArray = [];
    D.tweenMap = [];
    D._gid = 1;
    class Tt extends q {
        constructor() {
            super()
        }
        getZipNameConfigFileName() {
            return L.Instance.version_file_name
        }
    }
    Common.Utils.GameZipHelper = b.GameZipHelper = Tt;
    Common.Script = {};
    class Ot extends ge {
        constructor() {
            super();
            this.time = 0
        }
        onAwake() {
            super.onAwake();
            if (this.owner instanceof laya.display.Animation) {
                var e = this.owner;
                this.time = parseFloat(this.delayTime);
                if (this.time == 0) {
                    e.play()
                } else {
                    e.on(M.COMPLETE, this, this.onAnimationFinish, [e]);
                    b.timer.once(this.time, e, e.play, [0, false])
                }
            }
        }
        onAnimationFinish(e) {
            if (e) {
                b.timer.once(this.time, e, e.play, [0, false])
            }
        }
    }
    Common.Script.AddAnimationScript = b.AddAnimationScript = Ot;
    class St extends ge {
        constructor() {
            super();
            this.left = false;
            this.right = false;
            this.top = false;
            this.bottom = false;
            this.Grid = false
        }
        onAwake() {
            super.onAwake();
            if (this.owner instanceof laya.display.Sprite) {
                var e = this.owner;
                this.orgRect = new ce(e.x, e.y, e.width, e.height);
                this.orgMargin = new ce(e.left, e.right, e.top, e.bottom);
                this.orgParentRect = new ce(e.parent.x, e.parent.y, e.parent.width, e.parent.height)
            }
            b.stage.on(M.RESIZE, this, this.onResize);
            b.stage.on("orientationchanged", this, this.onOriChanged)
        }
        onStart() {
            super.onStart();
            this.onResize()
        }
        onOriChanged() {
            this.onResize()
        }
        onResize() {
            if (b.stage.scaleMode != "exactfit") return;
            var e = this.owner;
            var t = C.width / C.height * b.stage.designHeight / b.stage.designWidth;
            if (this.owner.name == "boxHeader") {}
            if (u.isH) {
                if (this.owner instanceof laya.ui.Box) {
                    if (e.parent instanceof laya.display.Scene || e.parent instanceof laya.ui.Dialog || e.parent instanceof laya.ui.View) {
                        e.scaleX = 1 / t
                    }
                    if (this.left) {
                        e.left = this.orgMargin.x
                    }
                    if (this.right) {
                        e.right = this.orgMargin.y
                    }
                    if (this.top) {
                        e.top = this.orgMargin.width
                    }
                    if (this.bottom) {
                        e.bottom = this.orgMargin.height
                    }
                } else {
                    if (!this.top && !this.bottom) {
                        var a = this.owner.parent.height / this.orgParentRect.height;
                        this.owner.y = this.orgRect.y * a
                    }
                    if (!this.left && !this.right) {
                        var a = this.owner.parent.width / this.orgParentRect.width;
                        this.owner.x = this.orgRect.x * a
                    }
                    if (this.owner instanceof laya.ui.Image && !this.Grid) {
                        if (this.left && this.right && this.top && this.bottom) {
                            var i = this.owner.parent.width / this.orgParentRect.width;
                            var n = this.owner.parent.height / this.orgParentRect.height;
                            var a = Math.max(i, n);
                            this.owner.scaleX = a;
                            this.owner.scaleY = a;
                            this.owner.y = this.orgRect.y * (this.owner.parent.height / this.orgParentRect.height);
                            this.owner.x = this.orgRect.x * (this.owner.parent.width / this.orgParentRect.width)
                        } else if (this.left && this.right) {
                            var i = this.owner.parent.width / this.orgParentRect.width;
                            this.owner.scaleX = i;
                            this.owner.scaleY = i
                        } else if (this.top && this.bottom) {
                            var n = this.owner.parent.height / this.orgParentRect.height;
                            this.owner.scaleX = n;
                            this.owner.scaleY = n
                        }
                    }
                }
            } else {
                if (this.owner instanceof laya.ui.Box) {
                    if (e.parent instanceof laya.display.Scene || e.parent instanceof laya.ui.Dialog || e.parent instanceof laya.ui.View) {
                        e.scaleY = t
                    }
                    if (this.top) {
                        e.y = this.orgRect.y * t;
                        if (this.bottom) {
                            var s = b.stage.designHeight - this.orgRect.y - this.orgRect.height;
                            e.height = this.orgRect.height / t + (this.orgRect.y - e.y) / t + s * (1 - t) / t
                        }
                    } else if (this.bottom) {
                        e.y = this.orgRect.y + this.orgRect.height * (1 - t)
                    }
                } else {
                    if (!this.top && !this.bottom) {
                        var a = this.owner.parent.height / this.orgParentRect.height;
                        this.owner.y = this.orgRect.y * a
                    } else if (this.top && this.bottom) {
                        var a = this.owner.parent.height / this.orgParentRect.height;
                        this.owner.y = this.orgRect.y * a;
                        if (this.Grid) {
                            e.height = e.parent.height - this.orgParentRect.height + this.orgRect.height
                        }
                        if (e.name == "imgList") {}
                    } else if (this.bottom) {
                        this.owner.y = this.owner.parent.height - (this.orgParentRect.height - this.orgRect.y)
                    } else if (this.top) {}
                    if (!this.left && !this.right) {
                        var a = this.owner.parent.width / this.orgParentRect.width;
                        this.owner.x = this.orgRect.x * a
                    } else if (this.left && this.right) {
                        var a = this.owner.parent.width / this.orgParentRect.width;
                        this.owner.x = this.orgRect.x * a
                    } else if (this.left) {} else if (this.right) {
                        this.owner.x = this.owner.parent.width - (this.orgParentRect.width - this.orgRect.x)
                    }
                    if (this.owner instanceof laya.ui.Image && !this.Grid) {
                        if (this.left && this.right && this.top && this.bottom) {
                            var i = this.owner.parent.width / this.orgParentRect.width;
                            var n = this.owner.parent.height / this.orgParentRect.height;
                            var a = Math.max(i, n);
                            this.owner.scaleX = a;
                            this.owner.scaleY = a
                        } else if (this.left && this.right) {
                            var i = this.owner.parent.width / this.orgParentRect.width;
                            this.owner.scaleX = i;
                            this.owner.scaleY = i
                        } else if (this.top && this.bottom) {
                            var n = this.owner.parent.height / this.orgParentRect.height;
                            this.owner.scaleX = n;
                            this.owner.scaleY = n
                        }
                    }
                }
            }
        }
    }
    Common.Script.AddAutoLayoutScript = b.AddAutoLayoutScript = St;
    class yt extends ge {
        constructor() {
            super()
        }
        onUpdate() {
            if (this.owner && O.hasOwnProperty(this.owner, "fontSize")) {
                if (this.owner instanceof laya.ui.Label) {
                    var e = this.owner;
                    var t = e.text;
                    console.log(e.width);
                    if (t.length > this.numberCount) {
                        e.fontSize = this.smallFontSize
                    }
                }
            }
        }
    }
    Common.Script.AddAutoWidthNumberScript = b.AddAutoWidthNumberScript = yt;
    class Nt extends ge {
        constructor() {
            super()
        }
        onAwake() {
            super.onAwake();
            var e = this.owner;
            e.NORMAL_SCALE = this.normalScale;
            e.SELECTED_SCALE = this.selectedScale;
            e.NORMAL_POSY = this.normalPosY;
            e.SELECTED_POSY = this.selectedposY
        }
    }
    Common.Script.AddBetRadio = b.AddBetRadio = Nt;
    class Rt extends ge {
        constructor() {
            super();
            this.disabledSkin = "";
            this.playDefaultSound = false;
            this.customClickSound = "";
            this.disabledAlpha = 0
        }
        onAwake() {
            super.onAwake();
            if (this.owner instanceof Common.UI.DolButton) {
                var e = this.owner;
                if (this.disabledSkin && this.disabledSkin != "") {
                    e.disabledSkin = this.disabledSkin
                } else if (e.skin != "") {}
                e.playDefaultSound = this.playDefaultSound;
                e.customClickSound = this.customClickSound;
                e.disabledAlpha = this.disabledAlpha
            }
        }
    }
    Common.Script.AddDolButtonScript = b.AddDolButtonScript = Rt;
    class It extends ge {
        constructor() {
            super();
            this.align = "middle"
        }
        onAwake() {
            super.onAwake();
            if (this.owner instanceof Common.UI.ImageNumber) {
                var e = this.owner;
                this.setImageNumberProp(e)
            }
        }
        setImageNumberProp(e) {
            if (e) {
                e.align = this.align;
                e.skin = this.skin;
                e.setAutoScaleString(this.autoScale);
                e.offsetType = this.offsetType;
                e.offset = parseFloat(this.offset)
            }
        }
    }
    Common.Script.AddImageNumberScript = b.AddImageNumberScript = It;
    class bt extends ge {
        constructor() {
            super();
            this._isJumping = false;
            this._nownumber = 0;
            this._moneyper = 0;
            this._maxnumber = 0;
            this._fixed = 0;
            this._mintime = 0;
            this._isWithCom = false;
            this._preStr = ""
        }
        jumpTo(e, t, a, i, n = 1, s = false, r = null, o = null, l = false, h = "") {
            if (!this.owner || !O.hasOwnProperty(this.owner, "text")) {
                return
            }
            this._isJumping = true;
            var _ = Math.ceil(i / L.Instance.getTimeByFps(n));
            var c = Math.abs(Math.ceil((t - e) / a));
            var u = a;
            var m = 0;
            if (!s) {
                var d = a.toString();
                var g = d.indexOf(".");
                if (g >= 0) {
                    m = d.length - g - 1
                }
            } else {
                m = 2
            }
            this._fixed = m;
            this._nownumber = e;
            this._moneyper = u;
            this._maxnumber = t;
            this._mintime = n;
            this._isWithCom = s;
            this._caller = r;
            this._callback = o;
            this._nownumber += this._moneyper;
            this._preStr = h;
            if (_ >= c) {
                _ = c
            } else {
                u = (t - e) / _
            }
            this.owner.text = this.addPre(this.getTextByNumber(e, m, s));
            if (l) {
                console.log(L.Instance.getTimeByFps(n));
                b.timer.loop(L.Instance.getTimeByFps(n), this, this.jumpFunc)
            } else {
                var p = L.Instance.getTimeByFps(n * _);
                w.to(this, {
                    jumpValue: t
                }, p, null, v.create(this, this.onComplete));
                b.timer.loop(L.Instance.getTimeByFps(n), this, this.callBackFunc)
            }
        }
        addPre(e) {
            if (!e) {
                console.log("11111111111111111111111")
            }
            if (this._preStr.indexOf("%s") >= 0) {
                return I.format(this._preStr, e.toString())
            } else {
                return this._preStr + e
            }
        }
        stopJump() {
            if (this._isJumping) {
                b.timer.clear(this, this.jumpFunc);
                this._callback = null;
                this._caller = null;
                this.owner.event(M.STOPPED);
                this._isJumping = false
            }
            O.stopAllAction(this)
        }
        jumpFunc() {
            if (!this._isJumping) {
                return
            }
            if (this._nownumber == this._maxnumber) {
                this.owner.text = this.addPre(this.getTextByNumber(this._maxnumber, this._fixed, this._isWithCom));
                this.doCaller([this._maxnumber]);
                this.owner.event(M.COMPLETE);
                this._isJumping = false;
                b.timer.clear(this, this.jumpFunc);
                b.timer.clear(this, this.callBackFunc)
            } else {
                this.owner.text = this.addPre(this.getTextByNumber(this._nownumber, this._fixed, this._isWithCom));
                this.doCaller([this._nownumber]);
                this._nownumber += this._moneyper
            }
        }
        doCaller(e) {
            if (this._caller && this._callback) {
                this._callback.apply(this._caller, e)
            }
        }
        callBackFunc() {
            if (this._nownumber < this._maxnumber) {
                this.doCaller([this._nownumber])
            }
        }
        onComplete() {
            this.owner.text = this.addPre(this.getTextByNumber(this._maxnumber, this._fixed, this._isWithCom));
            this.doCaller([this._maxnumber]);
            this.owner.event(M.COMPLETE);
            this._isJumping = false;
            b.timer.clear(this, this.jumpFunc)
        }
        getTextByNumber(e, t, a) {
            if (a) {
                return I.toStringWithCom(e.toFixed(t))
            } else {
                return e.toFixed(t)
            }
        }
        jumpToEqualInterval(e, t, a, i = null, n = null, s = true) {
            if (!this.owner || !this.owner.hasOwnProperty("text")) {
                return
            }
            this._isJumping = true;
            var r = Math.ceil(t / a);
            this._nownumber = 0;
            this.owner.text = this.addPre(this.getTextByNumber(0, 0, false));
            this._moneyper = a;
            this._maxnumber = t;
            if (s) {
                this._fixed = 2
            } else {
                this._fixed = 0
            }
            this._isWithCom = false;
            this._callback = n;
            this._caller = i;
            this._nownumber += this._moneyper;
            b.timer.loop(e, this, this.jumpFunc)
        }
        stopJumpEqualInterval() {
            if (this._isJumping) {
                this.owner.text = this.addPre(this.getTextByNumber(this._maxnumber, this._fixed, this._isWithCom));
                b.timer.clear(this, this.jumpFunc);
                this._caller = null;
                this._callback = null;
                this.owner.event(M.STOPPED);
                this._isJumping = false
            }
            O.stopAllAction(this)
        }
        get jumpValue() {
            return this._nownumber
        }
        set jumpValue(e) {
            this._nownumber = e;
            this.owner.text = this.addPre(this.getTextByNumber(this._nownumber, this._fixed, this._isWithCom))
        }
        get isJumping() {
            return this._isJumping
        }
        set isJumping(e) {
            super.isJumping = e
        }
    }
    Common.Script.AddJumpToScript = b.AddJumpToScript = bt;
    class Mt extends ge {
        constructor() {
            super();
            this.disWidth = 0
        }
        onAwake() {
            super.onAwake();
            if (this.owner instanceof laya.ui.Label) {
                var e = this.owner;
                if (e.text != "" && e.width > this.disWidth) {
                    var t = e.text;
                    var a = 1;
                    while (e.width > this.disWidth && e.text != "...") {
                        e.text = t.split(0, t.length - a) + "...";
                        a++
                    }
                    this.owner.text = e.text
                }
            }
        }
    }
    Common.Script.AddLabelScrollScript = b.AddLabelScrollScript = Mt;
    class vt extends ge {
        constructor() {
            super()
        }
        onAwake() {
            if (this.owner) {
                var e = "";
                var t = "";
                if (this.owner instanceof laya.ui.Image) {
                    var a = this.owner;
                    e = a.skin;
                    t = "skin"
                } else if (this.owner instanceof laya.ui.Button) {
                    var i = this.owner;
                    e = i.skin;
                    t = "skin"
                } else if (this.owner instanceof laya.display.Animation) {
                    var n = this.owner;
                    e = n.source;
                    if (e instanceof b.Texture) {
                        e = e.url
                    }
                    t = "source"
                } else if (this.owner instanceof laya.display.Sprite) {
                    var n = this.owner;
                    e = n.texture;
                    if (e instanceof b.Texture) {
                        e = e.url
                    }
                    t = "texture"
                }
                if (e && typeof e == "string" && e != "") {
                    e = de.getSkinByLang(e);
                    this.owner[t] = e
                }
            }
        }
    }
    Common.Script.AddLangSpriteScript = b.AddLangSpriteScript = vt;
    class Lt extends ge {
        constructor() {
            super()
        }
        onAwake() {
            if (this.owner && O.hasOwnProperty(this.owner, "text")) {
                var e = O.getMsgForNowLang(this.LangName);
                if (e != "") {
                    if (this.owner instanceof laya.ui.Button) {
                        this.owner["label"] = e
                    } else {
                        this.owner["text"] = e
                    }
                }
            }
        }
    }
    Common.Script.AddLangTextScript = b.AddLangTextScript = Lt;
    class wt extends ge {
        constructor() {
            super();
            this.values = "";
            this.showValues = ""
        }
        onAwake() {
            super.onAwake();
            if (this.owner instanceof Common.UI.NumberSelecter) {
                if (this.values != "" && this.showValues != "") {
                    var e = this.values.split(",");
                    var t = this.showValues.split(",");
                    var a = new Object;
                    for (var i = 0; i < e.length; i++) {
                        a[e[i]] = t[i]
                    }
                    this.owner.showValues = a
                }
            }
        }
    }
    Common.Script.AddNumberSelecterScript = b.AddNumberSelecterScript = wt;
    class Pt extends ge {
        constructor() {
            super();
            this.paylineId = 0
        }
        onAwake() {
            super.onAwake();
            if (this.owner instanceof Common.UI.PayLineCell) {
                var e = this.owner;
                e.paylineId = this.paylineId
            }
        }
    }
    Common.Script.AddPayLineCellScript = b.AddPayLineCellScript = Pt;
    class Dt extends ge {
        constructor() {
            super();
            this.isLang = false;
            this.closeDelayTime = 0;
            this.maskColor = "";
            this.defaultName = "";
            this.autoPlayTime = "";
            this.autoPlayName = "";
            this.autoPlayLoop = false;
            this.listLoopType = "random";
            this.isWithOri = false;
            this.isAnotherAuto = false;
            this.prefixAnotherAuto = "";
            this._autoPlayName = [];
            this._nowIndex = 0
        }
        onAwake() {
            super.onAwake();
            if (this.owner instanceof Common.UI.DolSkeleton) {
                var e = this.owner;
                if (I.endWith(this.skin, ".sk")) {
                    if (this.isLang) {
                        this.skin = de.getSkinByLang(this.skin)
                    }
                    e.skin = this.skin;
                    e.closeDelayTime = this.closeDelayTime;
                    e.animMaskColor = this.maskColor;
                    e.isLoop = this.autoPlayLoop;
                    e.isWithOri = this.isWithOri;
                    e.defaultName = this.defaultName;
                    if (this.autoPlayTime != "" && this.autoPlayName != "") {
                        if (this.autoPlayTime.indexOf(",") > 0) {
                            var t = this.autoPlayTime.split(",");
                            this._minTime = parseInt(t[0]);
                            this._maxTime = parseInt(t[1])
                        } else {
                            this._minTime = parseInt(this.autoPlayTime);
                            this._maxTime = this._minTime
                        }
                        if (this.autoPlayName.indexOf(",") > 0) {
                            var a = this.autoPlayName.split(",");
                            for (var i = 0; i < a.length; i++) {
                                if (a[i] != "") {
                                    this._autoPlayName.push(a[i])
                                }
                            }
                        } else {
                            this._autoPlayName.push(this.autoPlayName)
                        }
                        if (this.defaultName == "") {
                            this.loopPlayFunc()
                        } else {
                            this.owner.timer.once(this.getTime(), this, this.loopPlayFunc)
                        }
                    }
                } else {
                    console.warn("dolskeleton skin is invalid!:" + this.skin);
                    console.log(this.owner.name)
                }
            }
        }
        getTime() {
            if (this._minTime == this._maxTime) {
                return this._minTime
            } else {
                return O.random(Math.min(this._minTime, this._maxTime), Math.max(this._minTime, this._maxTime))
            }
        }
        loopPlayFunc() {
            var e = "";
            if (this.listLoopType == "random") {
                e = O.randomFromArray(this._autoPlayName)
            } else {
                this._nowIndex = (this._nowIndex + this._autoPlayName.length) % this._autoPlayName.length;
                e = this._autoPlayName[this._nowIndex];
                this._nowIndex++;
                this._nowIndex = (this._nowIndex + this._autoPlayName.length) % this._autoPlayName.length
            }
            if (this.isAnotherAuto) {
                e = this.prefixAnotherAuto + e
            }
            this.owner.setNextPlayName(e);
            this.owner.timer.once(this.getTime(), this, this.loopPlayFunc)
        }
    }
    Common.Script.AddSkeletonScript = b.AddSkeletonScript = Dt;
    class Gt extends ge {
        constructor() {
            super();
            this.maskColor = "";
            this.hasMask = false;
            this.maskTouchEvent = false;
            this.clickCloseParent = false
        }
        onAwake() {
            super.onAwake();
            if (this.owner instanceof b.Sprite) {
                var e = this.owner;
                e.maskColor = this.maskColor;
                e.hasMask = this.hasMask;
                if (this.hasMask && this.maskColor && this.maskColor != "") {
                    b.stage.on(M.ORIENTATION_CHANGED, this.owner, this.owner.drawRect)
                }
                e.mouseEnabled = this.maskTouchEvent;
                e.mouseThrough = !this.maskTouchEvent;
                if (this.clickCloseParent) {
                    e.on(M.CLICK, e, function() {
                        if (this.parent instanceof laya.ui.View) {
                            this.parent.destroy()
                        }
                    })
                }
            }
        }
    }
    Common.Script.AddSpriteDrawRectScript = b.AddSpriteDrawRectScript = Gt;
    class kt extends ge {
        constructor() {
            super();
            this.symbolId = 0
        }
        onAwake() {
            super.onAwake();
            if (this.owner instanceof Common.UI.SymbolMoneyCell) {
                var e = this.owner;
                e.symbolId = this.symbolId
            }
        }
    }
    Common.Script.AddSymbolMoneyScript = b.AddSymbolMoneyScript = kt;
    class Ut extends p {
        constructor() {
            super();
            this._value = 0
        }
        init() {
            super.onEnable();
            this.bg = this.getChildByName("bg");
            this.pro = this.getChildByName("pro");
            this.pro && (this._proWidth = this.pro.width)
        }
        set value(e) {
            if (this.pro) {
                this.pro.width = this._proWidth * (e / 100)
            }
        }
        get value() {
            return super.value
        }
    }
    Common.UI.DolProgress = b.DolProgress = Ut;
    class xt extends p {
        constructor() {
            super();
            this._skin = "";
            this._text = "";
            this._align = "left";
            this._offsetType = "";
            this._offset = 0;
            this._spNumber = 0;
            this._autoScaleConfig = [];
            this._oldNumber = 0;
            this._newNumber = 0;
            this._isLoading = false;
            this._isJumping = false;
            this._isAnimating = false;
            this._numAnimating = 0;
            this._numAniComplete = 0;
            this._numbers = [];
            this._node = new p;
            this.addChild(this._node)
        }
        initFromPool() {
            this.anchorX = null;
            this.anchorY = null;
            this.rotation = 0;
            this.alpha = 1;
            this.pos(0, 0, true);
            this.scale(1, 1, true);
            this._isLoading = false
        }
        recoverToPool() {
            this.stopJump();
            this._skin = "";
            this._text = "";
            this._align = "left";
            this._offsetType = "";
            this._offset = 0;
            this._spNumber = 0;
            Et.Instance.recover(this._node.getChildren());
            this._numbers = [];
            this._autoScaleConfig = [];
            this.offAll();
            this.timer.clearAll(this)
        }
        resetNumber() {
            if (this._skin != "") {
                this.stopAnim();
                Et.Instance.recover(this._node.getChildren());
                L.Instance.timer.clear(this, this.handlerFunc);
                this._numbers = [];
                this.size(0, 0);
                this._spNumber = 0;
                if (this._text.length > 0) {
                    this._isLoading = true;
                    for (var e = 0; e < this._text.length; e++) {
                        var t = this._text.charAt(e);
                        this.createSp(this.getNumberSpriteName(t), e)
                    }
                }
            }
        }
        getNumberSpriteName(e) {
            if (this.skin == "") {
                return ""
            }
            return this.skin + I.convertString(e) + ".png"
        }
        createSp(e, t) {
            var a = this;
            var i = Et.Instance.getItemByClass(Bt);
            i.index = t;
            i.loadImage(e, v.create(this, function(e) {
                if (this.destroyed) return;
                this._spNumber++;
                a._node.addChild(i);
                a._numbers.push(i);
                if (this._spNumber >= this._text.length) {
                    this._isLoading = false;
                    if (this._loadText != null && this._loadText != this.text) {
                        var t = this._loadText;
                        this._loadText = null;
                        this.text = t
                    } else {
                        this.doCaluSize()
                    }
                }
            }, [t]))
        }
        doCaluSize() {
            var e = 0;
            var t = 0;
            if (this._numbers.length == 0) {
                return
            }
            this._numbers.sort(function(e, t) {
                return e.index - t.index
            });
            var a = 0;
            for (var i = 0; i < this._numbers.length; i++) {
                var n = this._numbers[i];
                var s = n.texture;
                switch (this._offsetType) {
                    case "fixed":
                        n.pos(e, 0, true);
                        if (i < this._numbers.length - 1) {
                            e += this._offset
                        } else {
                            e += s.sourceWidth
                        }
                        break;
                    case "imgWithFixed":
                        n.pos(e, 0, true);
                        if (i < this._numbers.length - 1) {
                            e += s.sourceWidth + this._offset
                        } else {
                            e += s.sourceWidth
                        }
                        break;
                    default:
                        n.pos(e, 0, true);
                        e += s.sourceWidth;
                        break
                }
                t = Math.max(t, s.sourceHeight)
            }
            this.resize(e, t)
        }
        resize(e, t) {
            this._myWidth = e;
            this._myHeight = t;
            this._node.y = -t / 2;
            if (this.align == "left") {
                this._node.x = 0
            } else if (this.align == "right") {
                this._node.x = -e
            } else if (this.align == "middle") {
                this._node.x = -e / 2
            }
        }
        jumpTo(e, t, a, i, n = 1, s = false, r = null, o = null, l = false, h = "") {
            var _ = this.getComponent(bt);
            if (!_) {
                _ = this.addComponent(bt)
            }
            _.jumpTo(e, t, a, i, n, s, r, o, l, h);
            this._isJumping = _.isJumping
        }
        stopJump() {
            var e = this.getComponent(bt);
            if (e) {
                e.stopJump();
                this._isJumping = e.isJumping
            }
        }
        setAutoScaleString(e) {
            if (e && e != "") {
                var t = [];
                var a = e.split(";");
                for (var i = 0; i < a.length; i++) {
                    var n = a[i];
                    var s = n.split(":");
                    if (s.length == 2) {
                        var r = new He;
                        r.minNum = parseFloat(s[0]);
                        r.scale = parseFloat(s[1]);
                        if (r.minNum != null && r.scale != null) {
                            t.push(r)
                        }
                    }
                }
                if (t.length > 0) {
                    this.setAutoScaleConfig(t)
                }
            }
        }
        setAutoScaleConfig(e) {
            if (e && e instanceof Array) {
                this._autoScaleConfig = e.concat();
                this._autoScaleConfig.sort(function(e, t) {
                    return e.minNum - t.minNum
                });
                this.doCaluAutoScale()
            }
        }
        doCaluAutoScale() {
            var e = 1;
            if (this.text != "" && this._autoScaleConfig.length > 0) {
                var t = this.text.replace(/,/g, "");
                var a = parseFloat(t) || parseFloat(t.substr(1));
                if (typeof a == "number") {
                    for (var i = 0; i < this._autoScaleConfig.length; i++) {
                        var n = this._autoScaleConfig[i];
                        if (a >= n.minNum) {
                            e = n.scale
                        } else {
                            break
                        }
                    }
                }
                this.scale(e, e, true)
            }
        }
        doAnimationTo(e, t = 0, a = 200) {
            if (this.text == "") {
                this.text = e;
                return
            }
            if (this._isAnimating && this._aniHandler != null) {
                this._aniHandler.run()
            }
            if (this._isLoading) {
                return
            }
            this._isAnimating = true;
            var i = Math.max(this.text.length, e.length);
            var n = 0;
            var s = 0;
            var r = false;
            this._aniHandler = v.create(this, this.onAnimationComplete, [e]);
            if (this.align == "middle" && this.text.length != e.length) {
                this._aniImageNumber = new xt;
                this._aniImageNumber.skin = this.skin;
                this._aniImageNumber.text = e;
                this._aniImageNumber.align = this.align;
                this._aniImageNumber.offset = this.offset;
                this._aniImageNumber.offsetType = this.offsetType;
                this.addChild(this._aniImageNumber);
                for (var o = 0; o < this._numbers.length; o++) {
                    var l = this._numbers[o];
                    n = Math.max(n, l.height);
                    var h = t == 0 ? l.y + l.height : l.y - l.height;
                    w.to(l, {
                        y: h
                    }, a);
                    s += l.width
                }
                this._aniImageNumber.y = t == 0 ? -n : n;
                this._aniImageNumber.alpha = .5;
                w.to(this._aniImageNumber, {
                    y: 0,
                    alpha: 1
                }, a);
                L.Instance.timer.once(a, this, this.handlerFunc, [this._aniHandler]);
                r = true
            } else {
                var _ = this.align == "left";
                for (var o = 0; o < i; o++) {
                    var c = _ ? o : this.text.length - o - 1;
                    var u = this.text.length >= o ? this.text.charAt(c) : " ";
                    var m = e.length >= o ? e.charAt(_ ? o : e.length - o - 1) : " ";
                    if (c < this._numbers.length) {
                        l = this._numbers[c];
                        n = Math.max(n, l.height);
                        s += l.width
                    }
                    if (m == u) {
                        continue
                    }
                    this._numAnimating++;
                    var l;
                    if (c < this._numbers.length) {
                        l = this._numbers[c];
                        var h = t == 0 ? l.y + l.height : l.y - l.height;
                        r = true;
                        w.to(l, {
                            y: h,
                            alpha: .5
                        }, a)
                    }
                    if (m != " ") {
                        var d = Et.Instance.getItemByClass(Bt);
                        d.loadImage(this.getNumberSpriteName(m));
                        if (l != null) {
                            d.x = l.x;
                            d.y = l.y;
                            this._node.addChild(d);
                            d.y = t == 0 ? l.y - l.height : l.y + l.height;
                            d.alpha = .5;
                            w.to(d, {
                                y: l.y,
                                newSp: 1
                            }, a);
                            n = Math.max(n, d.height);
                            r = true
                        }
                    }
                }
                L.Instance.timer.once(a, this, this.handlerFunc, [this._aniHandler])
            }
            if (r) {
                var g = new p;
                g.graphics.drawRect(-s, -n / .8, s * 2, 2.2 * n, "#000000");
                this.mask = g
            }
        }
        handlerFunc(e) {
            e && e.run()
        }
        onAnimationComplete(e) {
            this._aniHandler = null;
            this.text = e
        }
        destoryImageNumber() {
            if (this._aniImageNumber != null) {
                this._aniImageNumber.destroy();
                this._aniImageNumber = null
            }
        }
        stopAnim() {
            this._isAnimating = false;
            this.destoryImageNumber();
            this._aniHandler = null;
            this.mask = null
        }
        jumpToEqualInterval(e, t, a, i = null, n = null, s = true) {
            var r = this.getComponent(bt);
            if (!r) {
                r = this.addComponent(bt)
            }
            r.jumpToEqualInterval(e, t, a, i, n, s)
        }
        stopJumpEqualInterval() {
            var e = this.getComponent(bt);
            if (e) {
                e.stopJumpEqualInterval()
            }
        }
        get MyWidth() {
            return this._myWidth
        }
        set MyWidth(e) {
            super.MyWidth = e
        }
        get isJumping() {
            return this._isJumping
        }
        set isJumping(e) {
            super.isJumping = e
        }
        get text() {
            return this._text
        }
        set text(e) {
            if (e == null) {
                return
            }
            e = e.toString();
            for (var t in ke.ReplaceCurrencyConfig) {
                e = e.replace(ke.ReplaceCurrencyConfig[t], "")
            }
            if (this._isLoading) {
                this._loadText = e
            } else if (e != null && this._text != e) {
                this._text = e.toString();
                this.resetNumber();
                this.doCaluAutoScale()
            }
        }
        get align() {
            return this._align
        }
        set align(e) {
            this._align = e;
            this.resize(this._myWidth, this._myHeight)
        }
        get skin() {
            return this._skin
        }
        set skin(e) {
            if (e && typeof e == "string" && e != "" && this._skin != e) {
                this._skin = e;
                this.resetNumber()
            }
        }
        get offsetType() {
            return this._offsetType
        }
        set offsetType(e) {
            this._offsetType = e;
            this.doCaluSize()
        }
        get offset() {
            return this._offset
        }
        set offset(e) {
            if (e && typeof e == "number") {
                this._offset = e;
                this.doCaluSize()
            }
        }
        set autoScale(e) {
            this.setAutoScaleString(e)
        }
        get autoScale() {
            return super.autoScale
        }
    }
    Common.UI.ImageNumber = b.ImageNumber = xt;
    class Bt extends p {
        constructor() {
            super()
        }
        recoverToPool() {
            this.offAll();
            this.mask = null;
            O.stopAllAction(this)
        }
    }
    Common.UI.ImageNumberSprite = b.ImageNumberSprite = Bt;
    class Ht extends p {
        constructor() {
            super();
            this._index = -1;
            this._values = []
        }
        onEnable() {
            super.onEnable();
            var e = this.getComponent(Common.Script.AddCreateRoomItemScript);
            if (e) {
                this.valueArray = e.value.split(",")
            }
            for (var t = 0; t < this.numChildren; t++) {
                if (this.getChildAt(t) instanceof laya.ui.Label) {
                    this._lbl = this.getChildAt(t);
                    this._lbl.text = "";
                    break
                }
            }
            if (this._lbl) {
                this._btnPlus = O.getUCByName(this, "btnPlus");
                if (this._btnPlus && this._btnPlus instanceof laya.ui.Button) {
                    this._btnPlus.on(M.CLICK, this, this.onPlus)
                }
                this._btnMinus = O.getUCByName(this, "btnMinus");
                if (this._btnMinus && this._btnMinus instanceof laya.ui.Button) {
                    this._btnMinus.on(M.CLICK, this, this.onMinus)
                }
                this.resetLabel(0)
            }
        }
        onPlus() {
            if (this._index < this._values.length - 1) {
                R.Instance.playSound("button_click");
                this.resetLabel(this._index + 1)
            }
        }
        onMinus() {
            if (this._index > 0) {
                R.Instance.playSound("button_click");
                this.resetLabel(this._index - 1)
            }
        }
        resetLabel(e) {
            if (this._lbl && e >= 0 && e < this._values.length) {
                this._index = e;
                var t = this._values[this._index];
                if (this.showValues && O.hasOwnProperty(this.showValues, t)) {
                    this._lbl.text = this.showValues[t]
                } else {
                    this._lbl.text = t
                }
                if (this._index <= 0) {
                    this._btnMinus.disabled = true
                } else {
                    this._btnMinus.disabled = false
                }
                if (this._index >= this._values.length - 1) {
                    this._btnPlus.disabled = true
                } else {
                    this._btnPlus.disabled = false
                }
                this.event(M.CHANGE)
            }
        }
        onDisable() {
            super.onDisable();
            if (this._btnMinus) this._btnMinus.off(M.CLICK, this, this.onMinus);
            if (this._btnPlus) this._btnPlus.off(M.CLICK, this, this.onPlus)
        }
        get selectIndex() {
            return this._index
        }
        set selectIndex(e) {
            super.selectIndex = e
        }
        get valueArray() {
            return this._values
        }
        set valueArray(e) {
            if (e && e instanceof Array) {
                var t = this.value;
                this._values = e.concat();
                var a = this._values.indexOf(t);
                if (a >= 0) {
                    this.resetLabel(a)
                } else {
                    this.resetLabel(0)
                }
            }
        }
        get value() {
            return this._values[this._index]
        }
        set value(e) {
            var t = this._values.indexOf(e);
            this.resetLabel(t)
        }
    }
    Common.UI.NumberSelecter = b.NumberSelecter = Ht;
    class Ft extends p {
        constructor() {
            super();
            this._allAniArray = [];
            this._playIndex = 0;
            this._isPlay = false
        }
        onEnable() {
            super.onEnable();
            this.on(M.FOCUS_CHANGE, this, this.onFocusChange);
            this.loadConfig()
        }
        onFocusChange(e) {
            this.timer.clear(this, this.startPlayAnimation);
            this.playAnimation(e);
            if (e) {
                this._allAniArray[this._playIndex] && (this._allAniArray[this._playIndex].index = 0)
            }
        }
        loadConfig() {
            for (var e = 0; e < this.numChildren; e++) {
                var t = this.getChildAt(e);
                if (t && t instanceof laya.display.Animation) {
                    this._allAniArray.push(t);
                    t.on(M.COMPLETE, this, this.onAniStoped);
                    t.interval = L.Instance.SymbolInterval
                }
            }
        }
        onAniStoped() {
            if (this._allAniArray.length > 0 && this._isPlay) {
                this._playIndex = (this._playIndex + 1) % this._allAniArray.length;
                this.playNextAnim()
            }
        }
        playNextAnim() {
            this._allAniArray[this._playIndex].play(0, false)
        }
        playAnimation(e) {
            if (this._allAniArray.length > 0) {
                this._isPlay = e;
                this._allAniArray[this._playIndex].stop();
                if (e) {
                    this.timer.once(100, this, this.startPlayAnimation)
                }
            }
        }
        startPlayAnimation() {
            this._playIndex = 0;
            this._allAniArray[0].play(0, false)
        }
    }
    Common.UI.PaytablePage = b.PaytablePage = Ft;
    class Yt extends p {
        constructor() {
            super();
            this.flyTimeSpan = 400;
            this.stayTimeSpan = 3e3;
            this._isActive = false;
            this._spritePool = new Et;
            this._MsgArr = [];
            this.mouseEnabled = false;
            this.zOrder = 2e3;
            b.stage.addChild(this);
            b.stage.on(M.RESIZE, this, this.onResizeHandler);
            this.onResizeHandler(null)
        }
        onExit() {
            this._spritePool.destroy();
            super.onExit()
        }
        onResizeHandler(e = null) {
            this.width = b.stage.width;
            this.height = b.stage.height
        }
        showLog(e) {
            if (!this.logText) {
                this.logText = this.onCreateDynaminMsgView(e);
                P.clearTarget(this.logText)
            }
            this.logText.x = b.stage.width / 2;
            this.logText.y = b.stage.height / 2;
            this.logText.visible = true
        }
        showText(e, t = 0) {
            var a = this;
            if (this._MsgArr.indexOf(e) < 0) {
                this._MsgArr.push(e)
            }
            if (this._isActive) {
                return
            }
            this._isActive = true;
            var i = this.onCreateDynaminMsgView(e, t);
            P.clearTarget(i);
            i.anchorX = .5;
            i.x = b.stage.width / 2;
            i.y = b.stage.height * 1 / 4;
            i.visible = true;
            var n = P.create(v.create(this, function() {
                a._spritePool.recover(i)
            }));
            n.addTweenChild(w.createTo(i, {
                y: (b.stage.height - i.height) / 4
            }, this.flyTimeSpan, J.linearIn));
            n.addTweenChild(w.createTo(i, {
                y: 0
            }, this.flyTimeSpan, J.linearIn, v.create(this, this.showNextText), this.stayTimeSpan));
            n.run(i)
        }
        showNextText() {
            this._isActive = false;
            if (this._MsgArr != null && this._MsgArr.length > 0) {
                this._MsgArr.shift();
                if (this._MsgArr.length > 0) {
                    var e = this._MsgArr[0];
                    this.showText(e)
                }
            }
        }
        onCreateDynaminMsgView(t, a = 0) {
            var e = O.createView(ha, v.create(this, function(e) {
                e.setContent(t, a);
                this.addChild(e)
            }), this._spritePool);
            return e
        }
    }
    Common.Utils.DynamicMessage = b.DynamicMessage = Yt;
    b.static(Yt, ["Instance", function() {
        return this.Instance = new Yt
    }]);
    class jt extends p {
        constructor() {
            super();
            this.maxErrorTimes = 3;
            this.trying = false;
            this.maxTryTimes = 3;
            this.nowTryTimes = 0;
            this.tryUrl = 0;
            this.tryTimeout = 0;
            this.ignoreCmdArray = [6]
        }
        tryHttp(e, t, a, i, n, s) {
            if (!this.trying) {
                this.nowTryTimes = 0;
                this.tryUrl = e;
                this.tryTimeout = t;
                this.maxTryTimes = a;
                this._caller = i;
                this._complete = n;
                this._error = s;
                this.trying = true;
                this.sendHttp()
            }
        }
        onTimeOut() {
            this.nowTryTimes++;
            if (this.nowTryTimes >= this.maxTryTimes) {
                this.tryOver();
                this._error.apply(this._caller, [M.TIME_OUT])
            } else {
                this.sendHttp()
            }
        }
        sendHttp() {
            var e = new $;
            e.timeout = this.tryTimeout;
            e.once(M.COMPLETE, this, this.tryOver);
            e.once(M.COMPLETE, this._caller, this._complete);
            e.once(M.ERROR, this, this.tryOver);
            e.once(M.ERROR, this._caller, this._error);
            e.once(M.TIME_OUT, this, this.onTimeOut);
            e.send(this.tryUrl, "", "get", "json")
        }
        tryOver() {
            this.trying = false
        }
        SendData(e, t, a = null, i = true) {
            if (t == null || !O.hasOwnProperty(t, "cmd") || !(typeof t["cmd"] == "number" && Math.floor(t["cmd"]) == t["cmd"]) || t["cmd"] <= 0) {
                Aa.Instance.showMessage("HTTP send data is not right==>" + JSON.stringify(t));
                return
            }
            var n = N.EncodeData(t);
            var s = new Object;
            s.errorTimes = 0;
            s.url = e;
            s.buff = n;
            var r = [];
            r.push("Content-Type");
            r.push("application/octet-stream");
            r.push("Access-Control-Allow-Origin");
            r.push("*");
            r.push("Access-Control-Allow-Credentials");
            r.push("true");
            var o = new $;
            o.timeout = 2e4;
            o.on(M.COMPLETE, this, this.onHttpCompleteHandler, [o, s, a]);
            o.on(M.ERROR, this, this.onHttpErrorHandler, [o, s, a]);
            o.on(M.TIME_OUT, this, this.onHttpTimeOutHandler, [o, s, a]);
            o.send(e, n, "post", "arraybuffer", r);
            if (t.cmd != null && this.ignoreCmdArray.indexOf(t.cmd) < 0) {
                O.IsDebugMode && console.info("url:" + e);
                O.IsDebugMode && console.info("HTTP DATA SEND:" + JSON.stringify(t))
            }
        }
        onHttpCompleteHandler(e, t, a, i) {
            b.timer.clear(this, this.onHttpTimeOutHandler);
            var n = N.DecodeData(i);
            if (n) {
                O.IsDebugMode && console.log(JSON.stringify(n));
                a && a.runWith([false, n])
            } else {
                a && a.runWith([true, "decode error!"])
            }
            e.offAllCaller(this)
        }
        onHttpErrorHandler(e, t, a, i) {
            b.timer.clear(this, this.onHttpTimeOutHandler);
            if (t && e && t.url && t.buff) {
                t.errorTimes = t.errorTimes || 0;
                t.errorTimes += 1;
                if (t.errorTimes < this.maxErrorTimes) {
                    e.send(t.url, t.buff, "post", "arraybuffer");
                    return
                }
            }
            a && a.runWith([true, i]);
            e.offAllCaller(this)
        }
        onHttpTimeOutHandler(e, t, a) {
            b.timer.clear(this, this.onHttpTimeOutHandler);
            a && a.runWith([true, "time out"]);
            e.offAllCaller(this)
        }
    }
    Common.Utils.HttpManager = b.HttpManager = jt;
    b.static(jt, ["Instance", function() {
        return this.Instance = new jt
    }]);
    class Wt extends p {
        constructor() {
            super();
            this.borderXDistance = 100;
            this.borderYDistance = 100;
            this.rootLayerHeigh = 30;
            this.isAnimRunning = false;
            this.rootLayer = new p;
            this.maskLayer = new p;
            this.itemArray = [];
            this.mouseEnabled = false;
            this.zOrder = 2e3;
            this.addChild(this.rootLayer);
            this.rootLayer.mouseEnabled = false;
            this.rootLayer.visible = false;
            b.stage.addChild(this);
            b.stage.on(M.RESIZE, this, this.onResizeHandler);
            this.onResizeHandler(null)
        }
        onResizeHandler(e = null) {
            var t = this.maskLayer.width = b.stage.width;
            var a = this.maskLayer.height = b.stage.height;
            this.rootLayer.width = t - this.borderXDistance * 2;
            this.rootLayer.height = this.rootLayerHeigh;
            this.rootLayer.x = this.borderXDistance;
            this.rootLayer.y = this.borderYDistance;
            this.maskLayer.graphics.clear();
            this.maskLayer.graphics.drawRect(0, 0, this.rootLayer.width, this.rootLayer.height, 15658734, 15658734);
            this.maskLayer.pos(0, 0);
            this.rootLayer.mask = this.maskLayer
        }
        showMarquee(e, t = 1) {
            this.itemArray.push(new At(e, t));
            this.doOneMarqueeAnimShow()
        }
        doOneMarqueeAnimShow() {
            var e = this;
            if (this.isAnimRunning || this.itemArray.length <= 0) return;
            var t = this.itemArray[0];
            t.finishOnce();
            if (t.Count <= 0) {
                this.itemArray.shift()
            }
            this.rootLayer.visible = true;
            var a = le.getItemByCreateFun("MarqueeText", this.onCreateMarqueeTextHandler, this);
            O.stopAllAction(a);
            this.rootLayer.addChild(a);
            a.text = t.Content;
            var i = a.textWidth;
            var n = this.rootLayer.width;
            var s = -1 * i;
            a.x = n;
            w.to(a, {
                x: s
            }, 8e3, null, v.create(this, function() {
                a.text = "";
                a.removeSelf();
                le.recover("MarqueeText", a);
                e.isAnimRunning = false;
                this.rootLayer.visible = false;
                this.callLater(e.doOneMarqueeAnimShow)
            }), 1e3);
            this.isAnimRunning = true
        }
        onCreateMarqueeTextHandler() {
            var e = new Se;
            e.text = "";
            e.height = this.rootLayerHeigh;
            e.wordWrap = false;
            e.align = "left";
            e.fontSize = 18;
            e.font = "Microsoft YaHei";
            e.color = "#ff0000";
            e.bold = true;
            e.leading = 5;
            e.overflow = Se.VISIBLE;
            return e
        }
    }
    Common.Utils.MarqueeManager = b.MarqueeManager = Wt;
    b.static(Wt, ["Instance", function() {
        return this.Instance = new Wt
    }]);
    class zt extends p {
        constructor() {
            super();
            this._newSceneComplete = 0;
            this._NowScene = null;
            this._OldScene = null;
            this.maskLayer = new p;
            this.mouseEnabled = this.maskLayer.mouseEnabled = true;
            this.zOrder = 1500;
            b.stage.addChild(this);
            b.stage.on(M.RESIZE, this, this.onResizeHandler);
            this.onResizeHandler(null);
            this.maskLayer.visible = false;
            o.on("GLOABLE_NEW_SCENE_COMPLETE", this, this.onNewSceneComplete)
        }
        onResizeHandler(e = null) {
            var t = this.maskLayer.width = b.stage.width;
            var a = this.maskLayer.height = b.stage.height;
            if (g.IS_SHOW_STAGE_BACKGROUND_COLOR) {
                b.stage.graphics.clear();
                b.stage.graphics.drawRect(0, 0, t, a, 15658734)
            }
            this.maskLayer.graphics.clear(true);
            this.maskLayer.graphics.drawRect(0, 0, t, a, "#000000");
            this.maskLayer.alpha = .01
        }
        StartScene(e, t = null, a = 0, i = 250, n = null) {
            this._newSceneComplete = 0;
            this.maskLayer.visible = true;
            var s = new e;
            if (s.ViewCreated) {
                this.onSceneCreateHandler(a, i, s, n)
            } else {
                s.on(r.EVENT_ON_VIEW_CREATE_END, this, function() {
                    this.onSceneCreateHandler(a, i, s, n)
                })
            }
        }
        onSceneCreateHandler(e, t, a, i) {
            var n = a.width = b.stage.width;
            var s = a.height = b.stage.height;
            if (a.parent == null) {
                de.root.addChild(a)
            }
            this.callLater(function() {
                K.closeAll()
            });
            if (e == 0) {
                this.onFinishAnimHandler(a);
                return
            }
            if (e == 1) {
                if (this._NowScene != null) {
                    w.to(this._NowScene, {
                        x: n
                    }, t, i)
                }
                w.from(a, {
                    x: -n
                }, t, i, v.create(this, this.onFinishAnimHandler, [a]))
            } else if (e == 2) {
                if (this._NowScene != null) {
                    w.to(this._NowScene, {
                        x: -n
                    }, t, i)
                }
                w.from(a, {
                    x: n
                }, t, i, v.create(this, this.onFinishAnimHandler, [a]))
            } else if (e == 3) {
                if (this._NowScene != null) {
                    w.to(this._NowScene, {
                        y: -s
                    }, t, i)
                }
                w.from(a, {
                    y: s
                }, t, i, v.create(this, this.onFinishAnimHandler, [a]))
            } else if (e == 4) {
                if (this._NowScene != null) {
                    w.to(this._NowScene, {
                        y: s
                    }, t, i)
                }
                w.from(a, {
                    y: -s
                }, t, i, v.create(this, this.onFinishAnimHandler, [a]))
            } else if (e == 5) {
                if (this._NowScene != null) {
                    w.to(this._NowScene, {
                        alpha: 0
                    }, t, i)
                }
                w.from(a, {
                    alpha: 0
                }, t, i, v.create(this, this.onFinishAnimHandler, [a]))
            }
        }
        onFinishAnimHandler(e) {
            if (this._NowScene != null) {
                this._OldScene = this._NowScene
            }
            this._newSceneComplete++;
            this.destroyOldScene();
            this._NowScene = e;
            e.startEnter();
            this.maskLayer.visible = false
        }
        onNewSceneComplete() {
            this._newSceneComplete++;
            this.destroyOldScene()
        }
        destroyOldScene() {
            if (this._newSceneComplete < 2) {
                b.timer.loop(500, this, this.showWarning)
            } else {
                if (this._newSceneComplete >= 2 && this._OldScene != null) {
                    O.stopAllAction(this._OldScene);
                    this._OldScene.startExit();
                    this._OldScene.removeSelf();
                    this._OldScene.destroy();
                    this._OldScene = null
                }
                b.timer.clear(this, this.showWarning)
            }
        }
        showWarning() {
            console.error("old scene is not destroy!Check it please!")
        }
        get NowScene() {
            return this._NowScene
        }
        set NowScene(e) {
            super.NowScene = e
        }
    }
    Common.Utils.SceneManager = b.SceneManager = zt;
    zt.EFFECT_NONE = 0;
    zt.EFFECT_FROM_LEFT_TO_RIGHT = 1;
    zt.EFFECT_FROM_RIGHT_TO_LEFT = 2;
    zt.EFFECT_FROM_UP_TO_DOWN = 3;
    zt.EFFECT_FROM_DOWN_TO_UP = 4;
    zt.EFFECT_FADE_OUT_AND_IN = 5;
    b.static(zt, ["Instance", function() {
        return this.Instance = new zt
    }]);
    class G extends p {
        constructor() {
            super();
            this.isConnectedError = false;
            this.lastServerTime = -1;
            this.lastLocalTime = -1;
            this.isManulCloseSocket = false;
            this.isGolbalTestMode = false;
            this.isDebugMode = false;
            this.testArray = [];
            this._nowAddress = "";
            this._urlIndex = 0;
            this.isTicked = false;
            this.maskLayer = new p;
            this.blockArray = [];
            this.callBackDic = new Object;
            this.ignoreCmdArray = [];
            this.socket = new fe;
            this.socket.endian = g.TCP_BIT_ENDIAN_MODE;
            this.socket.on(M.OPEN, this, this.openHandler);
            this.socket.on(M.MESSAGE, this, this.beforeReceiveHandler);
            this.socket.on(M.CLOSE, this, this.closeHandler);
            this.socket.on(M.ERROR, this, this.errorHandler);
            this._urlList = [];
            this.mouseEnabled = this.maskLayer.mouseEnabled = true;
            this.maskLayer.mouseThrough = false;
            this.zOrder = 1400;
            b.stage.addChild(this.maskLayer);
            b.stage.addChild(this);
            b.stage.on(M.RESIZE, this, this.onResizeHandler);
            this.onResizeHandler(null);
            this.maskLayer.visible = false;
            this.initIgnoreArray();
            o.on("GLOABLE_EVENT_WANT_NEW_PING", this, this.onTcpPingTimerHandler);
            o.on("GLOABLE_DELETE_TCP_BY_CMD", this, this.onDeleteTcpByCMD);
            if (this.isGolbalTestMode) {
                b.stage.on(M.KEY_DOWN, this, this.onKeyDown)
            }
        }
        initIgnoreArray() {
            this.ignoreCmdArray.push(1)
        }
        onKeyDown(e = null) {
            if (e && e["keyCode"] == 32) {
                this.startTest(true)
            } else if (e && e["keyCode"] == 27) {
                this.startTest(false)
            }
        }
        onResizeHandler(e = null) {
            var t = this.maskLayer.width = b.stage.width;
            var a = this.maskLayer.height = b.stage.height;
            this.maskLayer.graphics.clear(true);
            this.maskLayer.graphics.drawRect(0, 0, t, a, "#000000");
            this.maskLayer.alpha = .01
        }
        onDeleteTcpByCMD(e) {
            if (e) {
                for (var t in this.callBackDic) {
                    if (a.Data.cmd == e) {
                        var a = this.callBackDic[t];
                        a.recover();
                        delete this.callBackDic[t];
                        a = null
                    }
                }
            }
        }
        clearCallBackDic() {
            for (var e in this.callBackDic) {
                var t = this.callBackDic[e];
                t.recover();
                delete this.callBackDic[e];
                t = null
            }
        }
        connectTo(e) {
            this._urlList = this._urlList.concat(e);
            if (this.socket.connected) {
                o.dispatch("GLOABLE_EVENT_TCP_ON_CONNECT");
                return
            }
            this.isManulCloseSocket = false;
            this.isConnectedError = false;
            this._nowAddress = e;
            this.connectToUrl()
        }
        connectToUrl() {
            this.socket.connectByUrl(this._urlList[this._urlIndex])
        }
        closeSocket() {
            if (this.socket.connected) {
                this.isManulCloseSocket = true;
                this.socket.close()
            }
        }
        openHandler(e = null) {
            this.isManulCloseSocket = false;
            this.isConnectedError = false;
            this.clearCallBackDic();
            this.blockArray = [];
            this.maskLayer.visible = false;
            O.IsDebugMode && console.info("TCP 连接成功......");
            this.timer.loop(10, this, this.onTcpCallTimeOutHandler);
            o.dispatch("GLOABLE_EVENT_WANT_NEW_PING");
            o.dispatch("GLOABLE_EVENT_TCP_ON_CONNECT");
            (new Ie).loop(2e3, this, this.testPingTime)
        }
        testPingTime() {
            if (L.Instance.IsDebugMode && this._lastPingDate && this.IsConnected) {
                if (C.now() - this._lastPingDate > 2e4) {
                    console.error("ping is too long!!:" + (C.now() - this._lastPingDate) + "ms")
                }
            }
        }
        onTcpPingTimerHandler() {
            if (this.IsConnected) {
                var e = C.now();
                var t = new Object;
                t.cmd = 1;
                this.SendData(t, v.create(this, this.onTcpPingCallBack, [e]));
                this.timer.once(1e4, this, this.onTcpPingTimerHandler)
            }
        }
        onTcpPingCallBack(e, t) {
            var a = C.now();
            var i = a - e;
            this._lastPingDate = C.now();
            L.Instance.ping = i;
            o.dispatch("GLOABLE_EVENT_REFRESH_PING", i + "ms");
            if (t.error == null || t.error == 0) {
                if (t.time > 0) {
                    this.lastServerTime = parseInt(t.time);
                    this.lastLocalTime = a
                }
            }
        }
        onTcpCallTimeOutHandler() {
            if (O.IsDebugMode) {
                return
            }
            var e = C.now();
            var t = false;
            for (var a in this.callBackDic) {
                var i = this.callBackDic[a];
                if (e - i.StartTime > g.TCP_CALL_TIMEOUT_TIME_SPAN) {
                    if (i && i.Data && i.Data.cmd == 1) {
                        delete this.callBackDic[a];
                        i.CallBack = null;
                        i.recover();
                        i = null
                    } else {
                        console.info("TCP Call Time Out=>", i.Data);
                        if (this.onNeedResendError(i.Data)) {
                            return
                        }
                        delete this.callBackDic[a];
                        if (i.CallBack != null) {
                            var n = new Object;
                            n.error = 1e5;
                            i.CallBack.runWith(n)
                        }
                        i.CallBack = null;
                        i.recover();
                        i = null;
                        t = true
                    }
                }
            }
            if (t) {}
        }
        onNeedResendError(e) {
            O.IsDebugMode && console.info("error!!!:", e);
            var t = e.session;
            if (!G.errorTimesMap[t]) {
                G.errorTimesMap[t] = 0
            }
            G.errorTimesMap[t]++;
            if (G.errorTimesMap[t] < G.retryTimes) {
                if (this.callBackDic[t] != null) {
                    this.callBackDic[t].StartTime = C.now()
                }
                b.timer.once(G.retryTimespan, this, this.ResendData, [t]);
                return true
            }
            return false
        }
        startTest(e) {
            this.isDebugMode = e;
            for (var t = 0; t < this.testArray.length; t++) {
                this.receiveHandler(this.testArray[t])
            }
            this.testArray = []
        }
        beforeReceiveHandler(e = null) {
            if (this.isDebugMode) {
                this.testArray.push(e)
            } else {
                this.receiveHandler(e)
            }
        }
        receiveHandler(e = null) {
            var t = N.DecodeData(e);
            if (t.cmd != null && this.ignoreCmdArray.indexOf(t.cmd) < 0) {
                O.IsDebugMode && console.info("TCP DATA RECEIVE:", JSON.stringify(t))
            }
            if (t.error != null && t.error > 0) {
                if (G.retryErrorList.indexOf(t.error) >= 0 && t.hasOwnProperty("session")) {
                    if (this.onNeedResendError(t)) {
                        return
                    }
                }
                if (G.ignoreErrorCMD.indexOf(t.cmd) < 0) {
                    if (G.ignoreErrorCode.indexOf(t.error) < 0) {
                        S.showError(t)
                    }
                }
            }
            if (t.hasOwnProperty("session")) {
                var a = t.session;
                G.sendObjMap[a] = null;
                var i = this.blockArray.indexOf(a);
                if (i >= 0) {
                    this.blockArray.splice(i, 1);
                    if (this.blockArray.length > 0) this.maskLayer.visible = true;
                    else this.maskLayer.visible = false
                }
                if (this.callBackDic[a] != null) {
                    var n = this.callBackDic[a];
                    delete this.callBackDic[a];
                    n.runWith(t);
                    n = null
                } else {
                    O.IsDebugMode && console.info("TCP CALLBACK FUNCTION NOT FOUND", t)
                }
            } else {
                if (!t.hasOwnProperty("cmd") || t.cmd <= 0) {
                    O.IsDebugMode && console.info("ERROR TCP DATA RECEIVE NO CMD:", t);
                    return
                }
                G.dispatch(t.cmd, t)
            }
        }
        closeHandler(e = null) {
            this.timer.clearAll(this);
            this.clearCallBackDic();
            this.blockArray = [];
            this.maskLayer.visible = false;
            if (this.isConnectedError || this.isManulCloseSocket || this.isTicked) return;
            S.showError(100007)
        }
        errorHandler(e = null) {
            this._urlIndex++;
            if (this._urlIndex < this._urlList.length) {
                this.connectToUrl()
            } else {
                this.realError()
            }
        }
        realError() {
            this.timer.clearAll(this);
            this.clearCallBackDic();
            this.blockArray = [];
            this.maskLayer.visible = false;
            this.isConnectedError = true;
            S.showError(100008)
        }
        ResendData(e) {
            if (G.sendObjMap[e]) {
                O.IsDebugMode && console.info("Resend tcp data:", G.sendObjMap[e]);
                var t = N.EncodeData(G.sendObjMap[e]);
                this.socket.send(t);
                t = null;
                if (this.callBackDic[e]) {
                    this.callBackDic[e].StartTime = C.now()
                }
            }
        }
        SendData(e, t = null, a = true) {
            if (this.socket.connected == false) {
                console.info("未连接TCP发送数据失败!", e);
                return
            }
            if (e == null || !e.hasOwnProperty("cmd") || !(typeof e["cmd"] == "number" && Math.floor(e["cmd"]) == e["cmd"]) || e["cmd"] <= 0) {
                Aa.Instance.showMessage("Tcp send data is not right==>" + JSON.stringify(e));
                return
            }
            if (e["cmd"] == 1) {
                a = false
            }
            G.nowSessionID++;
            e.session = G.nowSessionID;
            G.sendObjMap[G.nowSessionID] = e;
            if (t != null) {
                this.callBackDic[e.session] = pt.create(e, t);
                if (a) {
                    this.maskLayer.visible = true;
                    this.blockArray.push(e.session)
                }
            }
            var i = N.EncodeData(e);
            this.socket.send(i);
            i = null;
            if (e.cmd != null && this.ignoreCmdArray.indexOf(e.cmd) < 0) {
                O.IsDebugMode && console.info("TCP DATA SEND:", JSON.stringify(e))
            }
        }
        get IsConnected() {
            return this.socket.connected
        }
        set IsConnected(e) {
            super.IsConnected = e
        }
        get ServerTime() {
            if (this.lastServerTime <= 0) return 0;
            var e = C.now();
            return this.lastServerTime + parseInt((e - this.lastLocalTime) / 1e3)
        }
        set ServerTime(e) {
            super.ServerTime = e
        }
        static dispatch(e, t = null) {
            o.dispatch("TCP_CMD_EVENT_" + e.toString(), t)
        }
        static on(e, t, a, i = 1) {
            o.on("TCP_CMD_EVENT_" + e.toString(), t, a, i)
        }
        static off(e, t) {
            o.off("TCP_CMD_EVENT_" + e.toString(), t)
        }
        static offAll(e) {
            o.offAll("TCP_CMD_EVENT_" + e.toString())
        }
    }
    Common.Utils.TcpManager = b.TcpManager = G;
    G.retryTimes = 0;
    G.retryTimespan = 500;
    G.nowSessionID = 0;
    b.static(G, ["Instance", function() {
        return this.Instance = new G
    }, "retryErrorList", function() {
        return this.retryErrorList = [5]
    }, "ignoreErrorCMD", function() {
        return this.ignoreErrorCMD = [26, 27, 28]
    }, "ignoreErrorCode", function() {
        return this.ignoreErrorCode = [67, 25, 65, 79, 68, E.ERROR_WRONG_GAME_STAGE_CHANGE_POSE, E.ERROR_WRONG_GAME_CHANGE_POSE_AFTER_BET, E.ERROR_WRONG_ONLY_VIP_FOR_EXP, E.ERROR_WRONG_NOT_BET_CANNOT_CANCLE, E.ERROR_WRONG_NOT_BET_STATUS]
    }, "sendObjMap", function() {
        return this.sendObjMap = new Object
    }, "errorTimesMap", function() {
        return this.errorTimesMap = new Object
    }]);
    class Vt extends de {
        constructor(e) {
            super(e);
            this.IsLoaded = false
        }
        createChildren() {
            super.createChildren();
            this.on("onViewCreateEnd", this, this.onViewLoad);
            this.load2UIJson()
        }
        onViewLoad() {
            this.off("onViewCreateEnd", this, this.onViewLoad);
            this.IsLoaded = true;
            this.setMyAllChildProp();
            this.registeEvent();
            this.onLoad();
            this.event(r.EVENT_ON_VIEW_CREATE_END, this)
        }
        setUIPathByName(e) {
            this._uiPath = "GameUI/" + L.Instance.ModuleName + "/Scenes/" + e
        }
        onLoad() {}
        onEnable() {
            super.onEnable();
            o.dispatch("GLOABLE_NEW_SCENE_COMPLETE")
        }
        registeEvent() {}
        onExit() {
            super.onExit();
            Ct.stopAllOwner(this)
        }
        registeAllButton(e = null, t = false) {
            e = e || this;
            for (var a = 0; a < e.getChildren().length; a++) {
                var i = e.getChildren()[a];
                if (i instanceof Common.Base.BaseView && !t) {
                    continue
                }
                if (i instanceof laya.ui.Button) {
                    i.on(M.CLICK, this, this.onButtonClick, [i.name])
                }
                this.registeAllButton(i, t)
            }
        }
        onButtonClick(e) {}
        onDestroy() {
            super.onDestroy();
            w.clearTarget(this);
            be.clearAll(this);
            this.timer.clearAll(this);
            L.Instance.timer.clearAll(this)
        }
    }
    Common.Base.BaseScene = b.BaseScene = Vt;
    class Kt extends Ee {
        constructor() {
            super();
            this._skin = "";
            this._closeDelayTime = 0;
            this._myMaskColor = "";
            this._isLoaded = false;
            this._isWantToPlay = false;
            this._hasError = false;
            this._isPlaying = false;
            this._defaultName = "";
            this._nowName = "";
            this._url = "";
            this._showSkin = "";
            this.isWithOri = false;
            this._nextPlayName = "";
            this.isLoop = false;
            this.on(M.STOPPED, this, this.onPlayStop)
        }
        createTemplet(e) {
            this.destroyTemplet(false);
            this._url = e;
            if (Kt.templetMap[e]) {
                var t = Kt.templetMap[e];
                if (t.isLoading) {
                    t.loadingArr.push(this)
                } else {
                    this.initBySelfTemplet(t.templet)
                }
            } else {
                var a = new Ye;
                a.templet = new Oe;
                a.isLoading = true;
                a.loadingArr.push(this);
                Kt.templetMap[e] = a;
                a.templet.on(M.COMPLETE, this, this.onComplete, [e]);
                a.templet.on(M.ERROR, this, this.onError);
                a.templet.loadAni(e)
            }
        }
        destroyTemplet(e = true) {
            if (e && this._myTemplet && this._url && Kt.templetMap[this._url]) {
                Kt.destroySk(this._url)
            }
            this._myTemplet = null;
            this._url = ""
        }
        initBySelfTemplet(e) {
            this._myTemplet = e;
            var t = 0;
            var a = T.find(L.Instance.skNeedChangeSkin, function(e) {
                return I.endWith(this._url, "/" + e)
            }, this);
            if (a) {
                t = 1
            }
            this.init(this._myTemplet, t);
            this._isLoaded = true;
            this.checkAutoPlay();
            this._hasError = false;
            if (this._isWantToPlay) {
                this.play.apply(this, this._wantToPlayParam);
                this._isWantToPlay = false
            }
        }
        onComplete(e) {
            var t = Kt.templetMap[e];
            t.templet.offAllCaller(this);
            t.isLoading = false;
            for (var a = 0; a < t.loadingArr.length; a++) {
                var i = t.loadingArr[a];
                if (i && !i.destroyed) {
                    i.initBySelfTemplet(t.templet);
                    t.usedArr.push(i)
                }
            }
            t.loadingArr = []
        }
        onPlayStop() {
            this._isPlaying = false;
            this.timer.frameOnce(1, this, this.checkAutoPlay)
        }
        onError() {
            this.destroyTemplet();
            console.warn("spine load error!!!!!!!!!!!!!!!!!!!!!!!:" + this._skin);
            this._skin = "";
            this._isLoaded = false;
            this._hasError = true;
            if (this._isWantToPlay) {
                this.event(M.STOPPED);
                this._isWantToPlay = false
            }
        }
        setLangSkin() {
            if (L.Instance.langSkList.indexOf(L.Instance.lang) > -1) {
                this.showSkin = L.Instance.lang
            } else if (L.Instance.lang == "zh-tw") {
                this.showSkin = "zh-cn"
            } else {
                this.showSkin = "en"
            }
        }
        checkAutoPlay() {
            if (this._nextPlayName != "") {
                this.play(this._nextPlayName, false, null, this.isWithOri);
                this._nextPlayName = "";
                return
            }
            if (this._defaultName && this._defaultName != "") {
                this.play(this._defaultName, false, null, this.isWithOri);
                return
            }
            if (this.isLoop && this._nowName) {
                this.play(this._nowName, false, null)
            }
        }
        setNextPlayName(e) {
            this._nextPlayName = e;
            if (!this._isPlaying) {
                this.timer.frameOnce(1, this, this.checkAutoPlay)
            }
        }
        play(e, t, a = null, i = false, n = true, s = 0, r = 0, o = true) {
            if (this._isLoaded) {
                if (i && typeof e == "string") {
                    e += b.stage.isHor ? "_h" : "_v"
                }
                this._nowName = e;
                if (this._showSkin != "") {
                    this.showSkinByName(this._showSkin)
                }
                if (!t && a) {
                    this.on(M.STOPPED, this, this.onPlayEndOnce, [a])
                }
                this._isPlaying = true;
                super.play(e, t, n, s, r, o)
            } else if (this._hasError) {
                this.event(M.STOPPED)
            } else {
                this._wantToPlayParam = [e, t, a, i, n, s, r, o];
                this._isWantToPlay = true
            }
        }
        onPlayEndOnce(e) {
            this.off(M.STOPPED, this, this.onPlayEndOnce);
            e && e.run()
        }
        _onStop() {
            this._isPlaying = false;
            super._onStop()
        }
        get skin() {
            return this._skin
        }
        set skin(e) {
            if (e && e != "" && this._skin != e) {
                this._skin = e;
                this.stop();
                this.createTemplet(e)
            }
        }
        get closeDelayTime() {
            return this._closeDelayTime
        }
        set closeDelayTime(e) {
            if (e && this._closeDelayTime != e) {
                this._closeDelayTime = e
            }
        }
        get animMaskColor() {
            return this._myMaskColor
        }
        set animMaskColor(e) {
            if (e && this._myMaskColor != e) {
                this._myMaskColor = e
            }
        }
        get showSkin() {
            return this._showSkin
        }
        set showSkin(e) {
            this._showSkin = e;
            if (this._isLoaded) {
                this.showSkinByName(e)
            }
        }
        get isPlaying() {
            return this._isPlaying
        }
        set isPlaying(e) {
            super.isPlaying = e
        }
        get defaultName() {
            return this._defaultName
        }
        set defaultName(e) {
            this._defaultName = e;
            this.checkAutoPlay()
        }
        get visible() {
            return super.visible
        }
        set visible(e) {
            super.visible = e;
            if (e != this.visible) {
                if (e) {
                    this.on(M.STOPPED, this, this.onPlayStop);
                    this.checkAutoPlay()
                } else {
                    this.off(M.STOPPED, this, this.onPlayEndOnce);
                    this.off(M.STOPPED, this, this.onPlayStop);
                    this.stop()
                }
            }
        }
        get nowName() {
            return this._nowName
        }
        set nowName(e) {
            super.nowName = e
        }
        static preloadSk(e, t = null) {
            if (!Kt.templetMap[e]) {
                var a = new Ye;
                a.templet = new Oe;
                a.templet.loadAni(e);
                Kt.templetMap[e] = a;
                a.isLoading = false;
                if (t) {
                    a.templet.on(M.COMPLETE, t.caller, t.method, t.args.concat([e]));
                    a.templet.on(M.ERROR, t.caller, t.method, t.args.concat([e]))
                }
            } else {
                t && t.run()
            }
        }
        static destroySk(e, t = true) {
            if (e && I.endWith(e, ".sk")) {
                if (Kt.templetMap[e]) {
                    var a = Kt.templetMap[e];
                    if (a.isLoading) {
                        T.deleteItemFromArray(a.loadingArr, this)
                    } else {
                        T.deleteItemFromArray(a.usedArr, this);
                        if (a.usedArr.length == 0) {
                            a.templet.destroy()
                        }
                    }
                }
                t && b.loader.clearTextureRes(e.replace(".sk", ".png"))
            }
        }
    }
    Common.UI.DolSkeleton = b.DolSkeleton = Kt;
    Kt.templetMap = {};
    class qt extends we {
        constructor(e) {
            super(e);
            this.isDownInBg = false;
            this.mouseThrough = true;
            this.maskColor = "#00000099"
        }
        baseInit() {
            super.baseInit();
            this.IsLoaded = false
        }
        createChildren() {
            super.createChildren();
            this.on("onViewCreateEnd", this, this.onViewLoad);
            this.load2UIJson()
        }
        loadSceneByName(e) {
            this.loadScene("GameUI/" + L.Instance.ModuleName + "/View/" + e + ".json")
        }
        setUIPathByName(e) {
            this._uiPath = "GameUI/" + L.Instance.ModuleName + "/View/" + e
        }
        onViewLoad() {
            this.off("onViewCreateEnd", this, this.onViewLoad);
            this.IsLoaded = true;
            this.setMyAllChildProp();
            this.initConfig();
            this.registeEvent();
            this.onLoad();
            this.show();
            this.event(r.EVENT_ON_VIEW_CREATE_END, this)
        }
        show() {
            this.visible = true
        }
        unshow(e = false) {
            this.visible = false;
            e && this.destroy()
        }
        onLoad() {}
        registeEvent() {
            this.on("EVENT_VIEW_TIP_CLICK", this, this.destroy)
        }
        initConfig() {}
        registeAllButton(e = null, t = false) {
            e = e || this;
            for (var a = 0; a < e.getChildren().length; a++) {
                var i = e.getChildren()[a];
                if (i instanceof Common.Base.BaseView && !t) {
                    continue
                }
                if (i instanceof laya.ui.Button) {
                    i.on(M.CLICK, this, this.onButtonClick, [i.name, i])
                }
                this.registeAllButton(i, t)
            }
        }
        onButtonClick(e, t) {}
        showScale(e = 150) {
            this.scale(0, 0);
            w.to(this, {
                scaleX: 1,
                scaleY: 1
            }, e, null, v.create(this, this.onShowed))
        }
        onShowed() {}
        safeCall(e = null, t = null) {
            if (e) {
                if (this.IsLoaded) {
                    e.runWith(t)
                } else {
                    this.on("onViewCreateEnd", e.caller, e.method, t)
                }
            }
        }
        onExit() {
            super.onExit();
            Ct.stopAllOwner(this)
        }
        onDownClick(e) {
            this.isDownInBg = false;
            if (this.bg) {
                var t = new c(e.stageX, e.stageY);
                var a = this.bg.globalToLocal(t);
                if (new ce(0, 0, this.bg.width, this.bg.height).contains(a.x, a.y)) {
                    this.isDownInBg = true
                }
            }
        }
        onUpClick(e) {
            if (!this.isDownInBg) {
                if (this.bg) {
                    var t = new c(e.stageX, e.stageY);
                    var a = this.bg.globalToLocal(t);
                    if (new ce(0, 0, this.bg.width, this.bg.height).contains(a.x, a.y)) {
                        this.isDownInBg = false;
                        return
                    }
                }
                this.event("EVENT_VIEW_TIP_CLICK");
                this.isDownInBg = false
            }
        }
        onDestroy() {
            super.onDestroy();
            O.stopAllAction(this);
            be.clearAll(this);
            this.timer.clearAll(this);
            L.Instance.timer.clearAll(this)
        }
        set tipClose(e) {
            if (e) {
                b.stage.on(M.MOUSE_DOWN, this, this.onDownClick);
                b.stage.on(M.MOUSE_UP, this, this.onUpClick)
            } else {
                b.stage.off(M.MOUSE_DOWN, this, this.onDownClick);
                b.stage.off(M.MOUSE_UP, this, this.onUpClick)
            }
        }
        get tipClose() {
            return super.tipClose
        }
    }
    Common.Base.BaseView = b.BaseView = qt;
    class Jt extends F {
        constructor() {
            super();
            this._line = 0;
            this._light = false;
            this._resArr = [];
            o.on("NC_LINE_CHANGE", this, this.onLineChange);
            this._createListener(M.CLICK, this, this.onClick, null, false, false);
            this._createListener(M.MOUSE_OVER, this, this.onOver, null, false, false);
            this._createListener(M.MOUSE_OUT, this, this.onOut, null, false, false)
        }
        changeClips() {
            super.changeClips();
            this.checkLightRes();
            this.onLineChange()
        }
        checkLightRes() {
            var e = this.skin;
            if (e && e != "") {
                var t = ie.getRes(e);
                var a = t.sourceWidth;
                var i = t.sourceHeight / this._stateNum;
                this._resArr = [];
                if (this._sources && this._sources.length > 0) {
                    this._resArr.push(Re.createFromTexture(t, 0, 0, a, i));
                    var n = e.lastIndexOf("_");
                    var s = e.lastIndexOf("_line") + 5;
                    if (s > -1 && n > -1 && n > s) {
                        var r = e.substr(s, n - s);
                        this._line = parseInt(r)
                    }
                    var o = e.substr(0, e.lastIndexOf("."));
                    var l = o + "3" + e.substr(e.lastIndexOf("."));
                    var h = ie.getRes(l);
                    if (!h) {
                        h = new Re;
                        h.load(l);
                        ie.cacheRes(l, h)
                    }
                    this._resArr.push(h)
                }
            }
        }
        onLineChange() {
            var e = A.Instance.InitData.bet_line;
            if (e >= this._line) {
                this.light = true
            } else {
                this.light = false
            }
        }
        onClick() {
            if (A.Instance.NowGameStatus == 0 && A.Instance.NowGameMode == 0) {
                R.Instance.playSound("button_click");
                A.Instance.selectLine(this._line)
            }
        }
        onOver() {
            if (A.Instance.NowGameStatus == 0) {
                o.dispatch(r.NC_LIGHT_LINE, [this._line])
            }
        }
        onOut() {
            if (A.Instance.NowGameStatus == 0) {
                o.dispatch(r.NC_LIGHT_LINE, [0])
            }
        }
        get line() {
            return this._line
        }
        set line(e) {
            super.line = e
        }
        get light() {
            return this._light
        }
        set light(e) {
            if (this._sources) {
                this._light = e;
                if (e) {
                    this._sources[0] = this._resArr[1]
                } else {
                    this._sources[0] = this._resArr[0]
                }
                this.callLater(this.changeState)
            }
        }
    }
    Common.UI.LineButton = b.LineButton = Jt;
    Common.Scene = {};
    class Xt extends Vt {
        constructor() {
            super();
            this.progress = 0;
            this.allShowTipList = [];
            this.unshowTipList = [];
            this.TIP_PATH = "unjzp/Tip/";
            this.tipNameNow = ""
        }
        baseInit(e) {
            super.baseInit(e);
            this.setUIPathByName("GameLoading")
        }
        createUI() {
            super.createUI()
        }
        onOpened(e) {
            console.info(e)
        }
        onEnable() {
            super.onEnable();
            b.stage.on(M.RESIZE, this, this.onResizeHandler);
            this.onResizeHandler(null);
            this.imgWord && (this.imgWord.visible = C.onPC)
        }
        registeEvent() {
            super.registeEvent();
            o.on(r.NC_READY_GOTO_GAME, this, this.onReadyGotoGame)
        }
        onResizeHandler(e = null) {
            this.imgWord && (this.imgWord.x = b.stage.width / 2);
            this.width = b.stage.width;
            this.height = b.stage.height
        }
        onEnter() {
            this.loadingBar.setStatus(2, true);
            if (b.isZip) {
                var e = L.Instance.ModuleName + ".jzp";
                b.zipHelper.downloadZipFile(e, v.create(this, function() {
                    this.loadingBar.setStatus(1, false);
                    ft.Instance.DoLoadGameResource(v.create(this, this.onLoadedEvent), v.create(this, this.onProgressEvent, null, false), v.create(this, this.onErrorEvent))
                }), v.create(this, this.onZipDownloadProgress, null, false), v.create(this, function() {
                    this.loadingBar.setStatus(1, true);
                    b.isZip = false;
                    ft.Instance.DoLoadGameResource(v.create(this, this.onLoadedEvent), v.create(this, this.onProgressEvent, null, false), v.create(this, this.onErrorEvent))
                }))
            } else {
                this.loadingBar.setStatus(1, true);
                ft.Instance.DoLoadGameResource(v.create(this, this.onLoadedEvent), v.create(this, this.onProgressEvent, null, false), v.create(this, this.onErrorEvent))
            }
            for (var t = 0; t < L.Instance.fontArr.length; t++) {
                var a = new Se;
                a.text = "12345";
                a.font = L.Instance.fontArr[t]
            }
        }
        onZipDownloadProgress(e) {
            this.loadingBar.Progress = e * 100
        }
        onExit() {
            b.stage.offAllCaller(this);
            v.recoverCaller(this)
        }
        onLoadedEvent() {
            b.zipHelper.finish();
            this.loadingBar.Progress = 99;
            o.dispatch("GLOABLE_GAME_RES_LOAD_FINISH")
        }
        onProgressEvent(e) {
            this.loadingBar.Progress = e * 100
        }
        onErrorEvent(e) {
            Yt.Instance.showText("load failed:" + e)
        }
        onLoad() {}
        onReadyGotoGame() {
            L.Instance.GotoGameScene()
        }
    }
    Common.Scene.GameLoadingScene = b.GameLoadingScene = Xt;
    class Zt extends F {
        constructor(e = null, t = "") {
            super(e, t);
            this.playDefaultSound = false
        }
        onMouse(e) {
            if (this.toggle === false && this._selected) return;
            if (e.type === M.CLICK) {
                this.toggle && (this.selected = !this._selected);
                this._clickHandler && this._clickHandler.run();
                return
            }!this._selected && (this.state = F.stateMap[e.type])
        }
        on(e, t, a, i = null) {
            if (e == M.CLICK) {
                super.on(e, this, this.playClickSound)
            }
            var n = super.on(e, t, a, i);
            return n
        }
        playClickSound() {
            if (this.playDefaultSound) {
                R.Instance.playSound("button_click")
            } else {
                if (this.customClickSound != "") {
                    R.Instance.playSound(this.customClickSound)
                }
            }
        }
        changeState() {
            if (!this.disabledSkin || this.disabledSkin == "") {
                super.changeState()
            } else if (!this._disabled) {
                super.changeState()
            }
        }
        set disabled(e) {
            if (this.disabledAlpha != null && this.disabledAlpha > 0) {
                if (e) {
                    this.alpha = this.disabledAlpha
                } else {
                    this.alpha = 1
                }
            }
            if (this.disabledSkin && this.disabledSkin != "") {
                if (e !== this._disabled) {
                    this._disabled = e;
                    this.mouseEnabled = !e;
                    if (e) {
                        this._state = 0;
                        var t = ie.getRes(this.disabledSkin);
                        if (!t) {
                            t = new Re;
                            t.load(this.disabledSkin);
                            ie.cacheRes(this.disabledSkin, t)
                        }
                        this._bitmap.source = t
                    } else {
                        this.callLater(this.changeState)
                    }
                }
            } else {
                super.disabled = e
            }
            if (this.getChildByName("subEffect")) {
                this.getChildByName("subEffect").visible = !e
            }
        }
        get disabled() {
            return super.disabled
        }
    }
    Common.UI.DolButton = b.DolButton = Zt;
    class Qt extends te {
        constructor() {
            super();
            this._dolColor = "#FFFFFF";
            this._dolFontSize = 0
        }
        jumpTo(e, t, a, i, n = 1, s = false, r = null, o = null, l = false, h = "") {
            var _ = this.getComponent(bt);
            if (!_) {
                _ = this.addComponent(bt)
            }
            _.jumpTo(e, t, a, i, n, s, r, o, l, h)
        }
        stopJump() {
            var e = this.getComponent(bt);
            if (e) {
                e.stopJump()
            }
        }
        reCaluSize() {
            if (Se._bitmapFonts && Se._bitmapFonts[this.font]) {
                var e = Se._bitmapFonts[this.font].fontSize;
                if (this._dolFontSize == 0) {
                    this._dolFontSize = e
                }
                var t = this._dolFontSize / e;
                if (Qt._scaleConstConfig && Qt._scaleConstConfig[this.font]) {
                    t *= Qt._scaleConstConfig[this.font]
                }
                this.scaleX = t;
                this.scaleY = t
            }
        }
        get font() {
            return super.font
        }
        set font(e) {
            super.font = e;
            this.reCaluSize()
        }
        get color() {
            return this._dolColor
        }
        set color(e) {
            if (this._dolColor != e && e.charAt() == "#" && e.length >= 7) {
                if (e != "#FFFFFF") {
                    var t = e.substr(1, 2);
                    var a = e.substr(3, 2);
                    var i = e.substr(5, 2);
                    var n = parseInt(t, 16) / 255;
                    var s = parseInt(a, 16) / 255;
                    var r = parseInt(i, 16) / 255;
                    this._myFilter = new V([n, 0, 0, 0, 0, s, 0, 0, 0, 0, r, 0, 0, 0, 0, 0, 0, 0, 1, 0]);
                    this._tf.filters = [this._myFilter]
                } else {
                    this._tf.filters = []
                }
                this._dolColor = e
            }
        }
        get fontSize() {
            return this._dolFontSize
        }
        set fontSize(e) {
            this._dolFontSize = e;
            this.reCaluSize()
        }
        get italic() {
            return this._italic
        }
        set italic(e) {
            this._italic = e;
            if (e) {
                this.skewX = -10
            } else {
                this.skewX = 0
            }
        }
        static preloadFnt(e, t = null) {
            if (!e || e == "") {
                t && t.run();
                return
            }
            var a = e.lastIndexOf("/") + 1;
            a = a < 0 ? 0 : a;
            var i = e.lastIndexOf(".");
            if (a >= i) {
                t && t.run();
                return
            }
            var n = e.substr(a, i - a);
            if (Qt.bitmapFontMap[n]) {
                t && t.run();
                return
            }
            var s = new B;
            Qt.bitmapFontMap[n] = s;
            s.loadFont(e, v.create(this, function(e, t = null) {
                Se.registerBitmapFont(e, this.bitmapFontMap[e]);
                this.bitmapFontMap[e].setSpaceWidth(10);
                t && t.run()
            }, [n, t]))
        }
    }
    Common.UI.BitmapFontLabel = b.BitmapFontLabel = Qt;
    Qt.bitmapFontMap = {};
    b.static(Qt, ["_scaleConstConfig", function() {
        return this._scaleConstConfig = {
            common: 1.08,
            msyhbd: 1.39
        }
    }]);
    class $t extends ee {
        constructor() {
            super();
            this._filterArray = [];
            this._nowState = 0;
            this._filterArray[0] = [];
            this._filterArray[1] = [];
            this._filterArray[2] = [];
            this._filterArray[3] = [];
            this.on(M.MOUSE_OVER, this, this.onMouse);
            this.on(M.MOUSE_OUT, this, this.onMouse);
            this.on(M.RIGHT_MOUSE_DOWN, this, this.onMouse);
            this.on(M.RIGHT_MOUSE_UP, this, this.onMouse)
        }
        onMouse(e) {
            this._nowState = $t.stateMap[e.type];
            this.filters = [new V(this._filterArray[this._nowState])]
        }
        getArrFromStr(e) {
            if (!e || e.length < 20 * 2 - 1) {
                return []
            }
            if (e.charAt(0) == "[") {
                e = e.substr(1)
            }
            if (e.charAt(e.length - 1) == "]") {
                e = e.substr(0, e.length - 1)
            }
            var t = [];
            var a = e.split(",");
            for (var i = 0; i < a.length; i++) {
                t.push(parseFloat(a[i]))
            }
            return t
        }
        set filterNormal(e) {
            this._filterArray[0] = this.getArrFromStr(e)
        }
        get filterNormal() {
            return super.filterNormal
        }
        set filterOver(e) {
            this._filterArray[1] = this.getArrFromStr(e)
        }
        get filterOver() {
            return super.filterOver
        }
        set filterDown(e) {
            this._filterArray[2] = this.getArrFromStr(e)
        }
        get filterDown() {
            return super.filterDown
        }
        set filterDisable(e) {
            this._filterArray[3] = this.getArrFromStr(e)
        }
        get filterDisable() {
            return super.filterDisable
        }
    }
    Common.UI.FilterButton = b.FilterButton = $t;
    b.static($t, ["stateMap", function() {
        return this.stateMap = {
            mouseup: 0,
            mouseover: 1,
            mousedown: 2,
            mouseout: 0
        }
    }]);
    class ea extends U {
        constructor() {
            super();
            this.closeDelayTime = 0;
            this.on(M.COMPLETE, this, this.onPlayComplete)
        }
        onPlayComplete() {
            this.visible = false
        }
        play(e = 0, t = true, a = "") {
            this.visible = true;
            super.play(e, t, a)
        }
    }
    Common.UI.GameAnimation = b.GameAnimation = ea;
    class ta extends U {
        constructor() {
            super()
        }
        initFromPool() {
            this.interval = L.Instance.SymbolInterval;
            this.anchorX = 0;
            this.anchorY = 0;
            this.index = 0;
            this.offAll()
        }
        recoverToPool() {
            this.clear();
            this.offAll();
            this.mask = null;
            this.filters = [];
            O.stopAllAction(this)
        }
        initWithCell(e) {
            this.source = e.getAniAtlasName();
            O.setPosByOtherSp(this, e)
        }
        play(e = 0, t = true, a = "", i = null) {
            this._complete = null;
            if (!t && i) {
                this._complete = i;
                this.on(M.COMPLETE, this, this.onComplete)
            }
            super.play(e, t, a)
        }
        _resumePlay() {
            if (this._isPlaying) {
                if (this._controlNode.displayedInStage) this.play(this._index, this.loop, this._actionName, this._complete);
                else this.clearTimer(this, this._frameLoop)
            }
        }
        onComplete() {
            this._complete && this._complete.run();
            this._complete = null
        }
        get frames() {
            return super.frames
        }
        set frames(e) {
            super.frames = e
        }
    }
    Common.UI.DolAnimation = b.DolAnimation = ta;
    class aa extends Kt {
        constructor() {
            super()
        }
        playByName(e) {
            if (e !== this._defaultName && this._nowName == this._defaultName) {
                this.play(e, false)
            }
        }
        onActionEnd() {
            super.onActionEnd();
            b.timer.frameOnce(1, this, this.checkAutoPlay)
        }
    }
    Common.UI.PlayerSkeleton = b.PlayerSkeleton = aa;
    class ia extends qt {
        constructor() {
            super()
        }
        baseInit() {
            super.baseInit();
            this.setUIPathByName("RoleView")
        }
        onEnable() {
            super.onEnable();
            this.panel && (this.panel.canTouch = true);
            this.panel && (this.panel.vScrollBar.hide = true);
            this.registeAllButton()
        }
        onButtonClick(e) {
            super.onButtonClick(e);
            if (e == "btnClose") {
                o.dispatch(r.NC_SHOW_ROLE, [false]);
                this.onCloseClick()
            }
        }
        onCloseClick() {}
    }
    Common.Base.BaseRole = b.BaseRole = ia;
    class na extends K {
        constructor() {
            super();
            this.IsLoaded = false
        }
        createChildren() {
            super.createChildren();
            this.on("onViewCreateEnd", this, this.onViewLoad);
            this.createUI()
        }
        createUI() {}
        onViewLoad() {
            this.off("onViewCreateEnd", this, this.onViewLoad);
            this.IsLoaded = true;
            this.onLoad();
            this.event(r.EVENT_ON_VIEW_CREATE_END, this)
        }
        onLoad() {}
    }
    Common.Base.BaseDialog = b.BaseDialog = na;
    class sa extends qt {
        constructor() {
            super();
            this.NODE_NAME_PR = "item";
            this._paylineId = 0
        }
        createUI() {
            this.loadScene("GameUI/" + L.Instance.ModuleName + "/View/PayLineCell.json")
        }
        set paylineId(e) {
            if (!(typeof e == "number" && Math.floor(e) == e)) return;
            if (e < 1) return;
            this.lineID && (this.lineID.text = e.toString());
            if (e > Common.Base.BasePayLine.PayLine.length) return;
            var t = Common.Base.BasePayLine.PayLine[e - 1];
            for (var a = 0; a < L.Instance.CellNumber; a++) {
                for (var i = 0; i < L.Instance.ReelNumber; i++) {
                    var n = a * L.Instance.ReelNumber + i;
                    var s = this[this.NODE_NAME_PR + n];
                    s && (s.visible = t.indexOf(n) >= 0)
                }
            }
        }
        get paylineId() {
            return super.paylineId
        }
    }
    Common.UI.PayLineCell = b.PayLineCell = sa;
    class ra extends qt {
        constructor() {
            super();
            this.NODE_NAME_PR = "nodeInfo";
            this._symbolId = 0
        }
        createUI() {
            this.loadScene("GameUI/" + L.Instance.ModuleName + "/View/SymbolMoneyCell.json")
        }
        set symbolId(e) {
            if (!(typeof e == "number" && Math.floor(e) == e)) return;
            var t = L.Instance.SymbolMoneyConfig;
            if (e < 0 || e >= t.length) return;
            var a = 0;
            this._symbolId = e;
            var i = t[e];
            var n = Object.keys(i);
            var s = this.getChildren();
            for (a = 0; a < s.length; a++) {
                s[a].visible = false
            }
            for (a = 0; a < n.length; a++) {
                var r = n[a].toString();
                var o = this[this.NODE_NAME_PR + r];
                if (o) {
                    o.visible = typeof i[r] == "number";
                    if (typeof i[r] == "number") {
                        var l = o.getChildByName("money");
                        l && (l.text = i[r].toString())
                    }
                }
            }
        }
        get symbolId() {
            return super.symbolId
        }
    }
    Common.UI.SymbolMoneyCell = b.SymbolMoneyCell = ra;
    Common.View = {};
    class oa extends qt {
        constructor() {
            super();
            this._isShowAuto = false;
            this.footbar = Common.Base.BaseFootbar
        }
        baseInit() {
            super.baseInit();
            this._noSuffix = true;
            this._uiPath = "GameUI/Common/View/AutoPlay"
        }
        registeEvent() {
            super.registeEvent();
            this.btnAutoPlay && this.btnAutoPlay.on(M.MOUSE_DOWN, this, this.autoPlayClick);
            o.on("NC_WANT_SPIN", this, this.checkAutoPlay);
            o.on(r.NC_SHOW_AUTOPLAY, this, this.autoPlayClick);
            o.on(r.NC_HTTP_ERROR, this, this.onSpinError)
        }
        onSpinError() {
            A.Instance.autoPlayTimes = 0;
            this.btnStartPlay && (this.btnStartPlay.visible = true);
            this.btnAutoStop && (this.btnAutoStop.visible = false)
        }
        onEnable() {
            super.onEnable();
            this.txtAutoTimes.maxChars = 4;
            this.init()
        }
        init() {
            this.loadAutoPlayConfig();
            this.checkAutoPlay();
            if (this.nodeAutoPlay) {
                this.nodeAutoPlay.savePos();
                this.nodeAutoPlay.visible = false;
                this.btnStartPlay.visible = true;
                this.btnAutoStop.visible = false
            }
        }
        doSpecialGame(e = false) {
            this.btnAutoPlay.visible = !e;
            this.btnAutoPlay.mouseEnabled = !e;
            if (e) {
                this.closeAutoPlay()
            }
        }
        loadAutoPlayConfig() {
            if (this.nodeAutoPlay) {
                for (var e = 0; e < this.nodeAutoPlay.numChildren; e++) {
                    var t = this.nodeAutoPlay.getChildAt(e);
                    if (t instanceof laya.ui.Image) {
                        this._autoPlayHeight = t.height;
                        this._imgWidth = t.width;
                        break
                    }
                }
            }
        }
        checkAutoPlay() {
            var e = A.Instance.autoPlayTimes;
            if (e == 0) {
                this.showAutoPlay(false)
            }
            this.txtAutoTimes && (this.txtAutoTimes.text = e.toString())
        }
        autoPlayClick() {
            this.showAutoPlay(!this._isShowAuto);
            R.Instance.playSound("button_click")
        }
        showAutoPlay(e) {
            var t = this;
            if (this.nodeAutoPlay && this._isShowAuto != e) {
                if (e) {
                    this.btnAutoPlay.mouseEnabled = false;
                    this.txtAutoTimes.mouseEnabled = true;
                    this.nodeAutoPlay.visible = true;
                    this.nodeAutoPlay.loadPos();
                    this.txtAutoTimes.text = "999";
                    this.btnStartPlay.visible = true;
                    this.btnAutoStop.visible = false;
                    var a = this.nodeAutoPlay.y;
                    this.nodeAutoPlay.y += this._autoPlayHeight;
                    w.to(this.nodeAutoPlay, {
                        y: a
                    }, 200, null, v.create(this, function() {
                        t.btnStartPlay && t.btnStartPlay.on(M.MOUSE_DOWN, this, t.startAutoPlay);
                        t.btnAutoStop && t.btnAutoStop.on(M.MOUSE_DOWN, this, t.stopAutoPlay);
                        t.btnClose && t.btnClose.on(M.MOUSE_DOWN, this, t.closeAutoPlay)
                    }))
                } else {
                    this.txtAutoTimes.mouseEnabled = false;
                    this.btnAutoPlay.mouseEnabled = true;
                    this.nodeAutoPlay.visible = true;
                    this.nodeAutoPlay.loadPos();
                    var a = this.nodeAutoPlay.y + this._autoPlayHeight;
                    this.btnStartPlay.offAll(M.CLICK);
                    this.btnAutoStop.offAll(M.CLICK);
                    this.btnClose.offAll(M.CLICK);
                    w.to(this.nodeAutoPlay, {
                        y: a
                    }, 200, null, v.create(this, function() {
                        this.nodeAutoPlay.visible = false
                    }))
                }
                this._isShowAuto = e
            }
        }
        startAutoPlay() {
            var e = this.txtAutoTimes.text;
            if (e > 0) {
                A.Instance.autoPlayTimes = e - 1;
                this.checkAutoPlay();
                o.dispatch("NC_WANT_SPIN");
                A.Instance.NowGameMode = 1;
                this.btnStartPlay && (this.btnStartPlay.visible = false);
                this.btnAutoStop && (this.btnAutoStop.visible = true)
            }
            R.Instance.playSound("button_click")
        }
        stopAutoPlay() {
            A.Instance.autoPlayTimes = 0;
            this.btnStartPlay && (this.btnStartPlay.visible = true);
            this.btnAutoStop && (this.btnAutoStop.visible = false);
            A.Instance.NowGameMode = 0;
            R.Instance.playSound("button_click")
        }
        closeAutoPlay() {
            A.Instance.autoPlayTimes = 0;
            if (A.Instance.NowGameMode == 1) {
                A.Instance.NowGameMode = 0
            }
            this.showAutoPlay(false);
            o.dispatch(r.NC_CLOSE_AUTOPLAY);
            R.Instance.playSound("button_click")
        }
        set autoBtnVisiblely(e = true) {
            this.btnAutoPlay.visible = e
        }
        get autoBtnVisiblely() {
            return super.autoBtnVisiblely
        }
    }
    Common.View.AutoPlay = b.AutoPlay = oa;
    class la extends qt {
        constructor() {
            super();
            this.needTime = 0;
            this.maxWidth = C.onPC ? 72 : 42
        }
        baseInit() {
            super.baseInit();
            this._uiPath = "GameUI/Common/View/BonusAnnouncementView"
        }
        onEnable() {
            super.onEnable();
            this.panel && (this.panel.mouseThrough = true);
            this.panel && (this.panel.mouseEnabled = false)
        }
        setBonusDto(e) {
            var t = new Q;
            t.style.width = 3e3;
            t.style.height = this.height;
            t.style.fontSize = this.getFontSizeByLang();
            t.style.align = "center";
            t.style.valign = "center";
            t.style.lineHeight = 46;
            var a = "<span color='#ffffff'>" + e.msg + "</span>";
            t.innerHTML = a;
            t.x = 30;
            t.y = 22;
            this.panel.addChild(t);
            if (t._element.contextWidth > this.panel.width) {
                var i = t._element.contextWidth - this.panel.width;
                var n = this.getTimeByStr(i);
                this.needTime = n;
                w.to(t, {
                    x: -i
                }, n, null, null, 2e3)
            }
        }
        getFontSizeByLang() {
            return 30
        }
        getTimeByStr(e) {
            return Math.max(0, e * 12)
        }
    }
    Common.View.BonusAnnouncementView = b.BonusAnnouncementView = la;
    class ha extends qt {
        constructor() {
            super()
        }
        createUI() {
            if (L.Instance.IsFinishResLoading) {
                this.loadScene(L.Instance.DynamicMsgSkin)
            } else {
                this.loadScene(L.Instance.CommonDynamicMsgSkin)
            }
        }
        setContent(e, t = 0) {
            this.lblText && (this.lblText.text = e);
            if (t == 1) {
                R.Instance.playSound("sound_prompt")
            } else if (t == 2) {
                R.Instance.playSound("sound_warn_prompt")
            } else if (t == 3) {
                R.Instance.playSound("sound_error_prompt")
            }
        }
    }
    Common.View.DynamicMessageView = b.DynamicMessageView = ha;
    class _a extends qt {
        constructor() {
            super()
        }
        baseInit() {
            super.baseInit();
            this._uiPath = "GameUI/CommonPGGame/View/ExitDialogView"
        }
        onEnable() {
            super.onEnable();
            this.registeAllButton();
            this.nodeDialog.visible = true;
            this.nodeView.visible = false
        }
        onButtonClick(e) {
            super.onButtonClick(e);
            switch (e) {
                case "btnCancel":
                    o.dispatch(r.NC_SHOW_EXIT_DIALOG, [false]);
                    break;
                case "btnExit":
                    this.showExitedView();
                    break;
                case "btnRefresh":
                    o.dispatch("GLOABLE_EVENT_APP_RESTART");
                    break
            }
        }
        showExitedView() {
            this.nodeDialog.visible = false;
            this.nodeView.visible = true
        }
    }
    Common.View.ExitDialogView = b.ExitDialogView = _a;
    class ca extends qt {
        constructor() {
            super();
            this._Progress = 0;
            this.loadingCnt = 0;
            this._MaskSprite = new p;
            this._MaskSprite.pos(44, 44)
        }
        createUI() {
            this.loadScene("GameUI/Common/View/GameLoadingBar.json")
        }
        onEnter() {
            super.onEnter();
            this._MaskSprite.graphics.clear(true);
            this.imgFront && (this.imgFront.mask = this._MaskSprite);
            if (this.lblLoading) {
                b.timer.frameLoop(20, this, function() {
                    if (this.loadingCnt >= 3) {
                        this.loadingCnt = 0
                    } else {
                        this.loadingCnt++
                    }
                    var e = "";
                    for (var t = 0; t < this.loadingCnt; t++) {
                        e += "."
                    }
                    this.lblLoading.text = e
                })
            }
        }
        onEnable() {
            super.onEnable();
            this.lblPercentage.text = "0"
        }
        onDestroy() {
            b.timer.clearAll(this);
            super.onDestroy()
        }
        setStatus(e, t) {
            this._circle = e;
            if (e == 1) {
                this.imgFront && (this.imgFront.visible = true);
                this.imgBack && (this.imgBack.visible = true);
                this.imgHalf && (this.imgHalf.visible = false);
                this.imgHalf && w.clearTarget(this.imgHalf)
            } else {
                this.imgFront && (this.imgFront.visible = false);
                this.imgBack && (this.imgBack.visible = true);
                this.imgHalf && (this.imgHalf.visible = true);
                this._MaskSprite.graphics.clear(true);
                this.imgHalf && w.clearTarget(this.imgHalf);
                this.imgHalf && w.to(this.imgHalf, {
                    rotation: 360
                }, 800, null, null, null, false, 9999999)
            }
            this.imgWord.skin = I.replayString(this.imgWord.skin, "img_", ".png", t ? "loading" : "unzip");
            this.imgWord.on(M.RESIZE, this, this.initPos)
        }
        initPos() {
            if (this.imgWord.source) {
                var e = this.imgWord.source.sourceWidth - 156;
                if (e > 50) {
                    this.lblPercentage.x = this.lblPercentage.x + e / 2;
                    this.imgWord.x = this.imgWord.x + e / 2;
                    this.lblLoading.x = this.lblLoading.x + e / 2;
                    this.imgPorcentaje.x = this.imgPorcentaje.x + e / 2
                }
            }
        }
        set Progress(e) {
            e = Math.max(0, Math.min(98, e));
            this.lblPercentage.text = Math.ceil(e).toString();
            if (this._circle == 1) {
                this._MaskSprite.graphics.drawPie(0, 0, 50, -90, -90 + e / 100 * 360, 16711680, 16711680)
            }
        }
        get Progress() {
            return super.Progress
        }
    }
    Common.View.GameLoadingBar = b.GameLoadingBar = ca;
    class ua extends qt {
        constructor() {
            super()
        }
        createUI() {
            this.loadSceneByName("GameLoadingBarNew")
        }
        onEnable() {
            super.onEnable();
            this.lblPercentage && (this.lblPercentage.text = "0");
            this.progress && this.progress.init();
            this.progress && (this.progress.value = 0);
            this.skLoading && this.skLoading.play("loading", true)
        }
        onDestroy() {
            super.onDestroy()
        }
        setStatus(e, t) {}
        set Progress(e) {
            e = Math.max(0, Math.min(98, e));
            this.lblPercentage.text = Math.ceil(e).toString();
            this.progress && (this.progress.value = e)
        }
        get Progress() {
            return super.Progress
        }
    }
    Common.View.GameLoadingBarNew = b.GameLoadingBarNew = ua;
    class ma extends Jt {
        constructor() {
            super()
        }
        onClick() {
            if (A.Instance.NowGameStatus == 0) {
                o.dispatch(r.NC_LIGHT_LINE, [this._line])
            }
            if (A.Instance.NowGameStatus == 0 && A.Instance.NowGameMode == 0) {
                A.Instance.selectLine(this._line)
            }
        }
        onOver() {}
        onOut() {}
    }
    Common.UI.ClickLineButton = b.ClickLineButton = ma;
    class da extends W {
        constructor() {
            super()
        }
        onMouse(e) {
            if (this.stateNum == 2) {
                if (this.toggle === false && this._selected) return;
                if (e.type === M.CLICK) {
                    this.toggle && (this.selected = !this._selected);
                    this._clickHandler && this._clickHandler.run()
                }
            } else {
                super.onMouse(e)
            }
            if (e.type === M.CLICK) {
                R.Instance.playSound("button_click")
            }
        }
    }
    Common.UI.DolCheckBox = b.DolCheckBox = da;
    class ga extends oe {
        constructor() {
            super();
            this._btnCount = 0;
            this._index = 0;
            this._offsetY = 0
        }
        onEnable() {
            super.onEnable();
            this.init()
        }
        init(e = true) {
            this.initScrollBar(this.vScrollBar);
            if (this.numChildren < 3) return;
            var t = this.height / 2 - this.getChildAt(0).height * (e ? 3 : 1) / 2;
            this._btnCount = this.numChildren - (e ? 2 : 0);
            this._offsetY = t;
            for (var a = 0; a < this.numChildren; a++) {
                var i = this.getChildAt(a);
                i.y = t;
                t += i.height
            }
            var n = new ee("");
            n.width = this.width;
            n.height = this.height / 2 - this.getChildAt(this.numChildren - 1).height * (e ? 3 : 1) / 2;
            n.y = t;
            this.addChild(n)
        }
        initScrollBar(e) {
            if (e) {
                e.hide = true;
                e.rollRatio = 0;
                e.on(M.START, this, this.onMyScrollStart)
            }
        }
        onMyScrollStart() {
            this.vScrollBar.on(M.END, this, this.onMyScrollEnd)
        }
        onMyScrollEnd() {
            this.vScrollBar.off(M.END, this, this.onMyScrollEnd);
            var e;
            var t = this._index;
            for (var a = 0; a < this.numChildren; a++) {
                e = this.getChildAt(a);
                if (this.vScrollBar.value + this._offsetY - e.y < e.height / 2) {
                    this._index = a;
                    break
                }
            }
            w.to(this.vScrollBar, {
                value: e.y - this._offsetY
            }, 100, null, v.create(this, this.onMyTweenEnd, [t != this._index]));
            this.vScrollBar.touchScrollEnable = false
        }
        onMyTweenEnd(e = false) {
            e && this.event(M.CHANGED);
            this.vScrollBar.touchScrollEnable = true
        }
        get btnCount() {
            return this._btnCount
        }
        set btnCount(e) {
            super.btnCount = e
        }
        get index() {
            return this._index
        }
        set index(e) {
            this._index = e;
            this.vScrollBar.touchScrollEnable = false;
            var t = this.getChildAt(e);
            w.to(this.vScrollBar, {
                value: t.y - this._offsetY
            }, 250, null, v.create(this, this.onMyTweenEnd, [false]))
        }
    }
    Common.UI.DolWheelView = b.DolWheelView = ga;
    class pa extends oe {
        constructor() {
            super();
            this._pageArr = [];
            this._isMoving = false;
            this._moveTime = 250;
            this._canTouch = false;
            this._isDown = false;
            this._nextPageOffset = 50
        }
        onEnable() {
            super.onEnable();
            this.mouseThrough = false;
            this.loadConfig()
        }
        initMask(e = true) {
            this.cMask && this.cMask.destroy();
            this.mask = null;
            if (e) {
                this.cMask = new p;
                this.cMask.graphics.drawRect(0, 0, this.width, this.height, "#000000");
                this.mask = this.cMask
            }
        }
        loadConfig() {
            this._index = 0;
            if (this.width == 0) {
                console.error("tableview's width can not be zero!!!!!!!!!!!!!!!!!!")
            }
            if (this.numChildren > 0) {
                this._pageArr = [];
                this._totalPage = this.numChildren;
                for (var e = 0; e < this._totalPage; e++) {
                    var t = this.getChildAt(e);
                    this._pageArr.push(t);
                    t.visible = e == 0;
                    t.x = e * this.width
                }
            }
            this.event(M.CHANGED, [this]);
            this._pageArr[this._index].event(M.FOCUS_CHANGE, [true])
        }
        rollTo(e) {
            if (!this._isMoving) {
                e = (e + this._pageArr.length) % this._pageArr.length;
                for (var t = 0; t < this._pageArr.length; t++) {
                    var a = this._pageArr[t];
                    var i = (t - e) * this.width;
                    if (a.x != i) {
                        this._isMoving = true;
                        this.event(M.CHANGE, [this, e]);
                        a.visible = true;
                        w.to(a, {
                            x: i
                        }, this._moveTime)
                    }
                }
                if (this._index != e) {
                    o.dispatch(r.NC_PAGE_PAYTABLE, [e])
                }
                this._index = e;
                if (this._isMoving) {
                    this.timer.once(this._moveTime, this, this.pageActionEnd)
                } else {
                    this.pageActionEnd()
                }
            }
        }
        pageActionEnd() {
            this._isMoving = false;
            this.showPageByIndex(false);
            this.event(M.CHANGED, [this]);
            this._pageArr[this._index].event(M.FOCUS_CHANGE, [true]);
            if (this._radioGroup) {
                this.registeRadioGroupEvent(false);
                this._radioGroup.selectedIndex = this.index;
                this.registeRadioGroupEvent(true)
            }
        }
        showPageByIndex(e = true) {
            for (var t = 0; t < this._pageArr.length; t++) {
                var a = this._pageArr[t];
                if (e) {
                    a.visible = Math.abs(t - this._index) <= 1
                } else {
                    a.visible = t == this._index
                }
            }
        }
        checkBeginRoll(e) {
            var t = this._startMouseX - e.stageX;
            var a = this.index;
            if (t > this._nextPageOffset) {
                a++
            } else if (t < -this._nextPageOffset) {
                a--
            }
            a = Math.max(a, 0);
            a = Math.min(a, this._pageArr.length - 1);
            this.rollTo(a)
        }
        onMouseDown(e) {
            this._isDown = true;
            this.showPageByIndex();
            this._startMouseX = e.stageX;
            this._pageArr[this._index].event(M.FOCUS_CHANGE, [false])
        }
        onMouseMove(e) {
            if (this._isDown) {
                for (var t = 0; t < this._pageArr.length; t++) {
                    var a = this._pageArr[t];
                    var i = (t - this._index) * this.width;
                    a.x = i + (e.stageX - this._startMouseX)
                }
            }
        }
        onMouseUp(e) {
            if (this._isDown) {
                this._isDown = false;
                this.checkBeginRoll(e)
            }
        }
        onPreClick() {
            var e = this._index - 1;
            if (e < 0) {
                e += this._pageArr.length
            }
            this.rollTo(e)
        }
        onNextClick() {
            var e = (this._index + 1) % this._pageArr.length;
            this.rollTo(e)
        }
        registeRadioGroupEvent(e) {
            if (this._radioGroup) {
                if (e) {
                    this._radioGroup.on(M.CHANGE, this, this.onRadioGroupChange)
                } else {
                    this._radioGroup.offAllCaller(this)
                }
            }
        }
        onRadioGroupChange() {
            if (this._radioGroup) {
                this.rollTo(this._radioGroup.selectedIndex)
            }
        }
        destroy(e = true) {
            super.destroy(e)
        }
        set btnPre(e) {
            if (this._btnPre) {
                this._btnPre.offAllCaller(this);
                this._btnPre = null
            }
            if (e && !e.destroyed) {
                this._btnPre = e;
                e.on(M.CLICK, this, this.onPreClick)
            }
        }
        get btnPre() {
            return super.btnPre
        }
        get canTouch() {
            return this._canTouch
        }
        set canTouch(e) {
            if (this._canTouch != e) {
                this._canTouch = e;
                if (e) {
                    this.on(M.MOUSE_DOWN, this, this.onMouseDown);
                    b.stage.on(M.MOUSE_MOVE, this, this.onMouseMove);
                    b.stage.on(M.MOUSE_UP, this, this.onMouseUp);
                    b.stage.on(M.MOUSE_OUT, this, this.onMouseUp)
                } else {
                    this.offAllCaller(this);
                    b.stage.offAllCaller(this);
                    this._isDown = false;
                    this.rollTo(this.index)
                }
            }
        }
        get index() {
            return this._index
        }
        set index(e) {
            super.index = e
        }
        get visible() {
            return super.visible
        }
        set visible(e) {
            super.visible = e;
            if (this._pageArr.length > 0 && this._index >= 0 && this._index < this._pageArr.length) {
                this._pageArr[this._index].event(M.FOCUS_CHANGE, [e])
            }
            if (e) {
                o.dispatch(r.NC_PAGE_PAYTABLE, [this.index])
            }
        }
        set radioGroup(e) {
            if (this._radioGroup) {
                this.registeRadioGroupEvent(false);
                this._radioGroup = null
            }
            if (e && !e.destroyed) {
                this._radioGroup = e;
                e.selectedIndex = this.index;
                this.registeRadioGroupEvent(true)
            }
        }
        get radioGroup() {
            return super.radioGroup
        }
        get isMoving() {
            return this._isMoving
        }
        set isMoving(e) {
            super.isMoving = e
        }
        set btnNext(e) {
            if (this._btnNext) {
                this._btnNext.offAllCaller(this);
                this._btnNext = null
            }
            if (e && !e.destroyed) {
                this._btnNext = e;
                e.on(M.CLICK, this, this.onNextClick)
            }
        }
        get btnNext() {
            return super.btnNext
        }
    }
    Common.UI.TableView = b.TableView = pa;
    class Ea extends Z {
        constructor() {
            super();
            this._format = "%s";
            this._isExternal = false;
            this._vFloat = false;
            this._valueBgPath = "Common/m/common/img_scrollBg.png";
            this._offSetX = -80;
            this._offSetY = -80
        }
        onEnable() {
            super.onEnable();
            this.showValueText();
            this.addValueBg();
            this.label.visible = false;
            this._progress.x = 13;
            this._progress.y = 22
        }
        addValueBg() {
            if (this._valueBgPath != "") {
                this.labelBg = new ee;
                this.labelBg.skin = this._valueBgPath;
                this.addChild(this.labelBg);
                this.labelBg.visible = false;
                if (this.isVertical) {
                    this.labelBg.x = this._bar._x - 80;
                    this.labelBg.y = this._bar._y - 37
                } else {
                    this.labelBg.x = this._bar._x - 37;
                    this.labelBg.y = this._bar._y - 80
                }
            }
        }
        showValueText() {
            if (this.showLabel) {
                this.showMyText();
                if (!this._isExternal) {
                    if (this.isVertical) {
                        this.label.y = this._bar.height * .5 + this._bar._y;
                        if (this._vFloat) {
                            this.label.x = this._bar._x + this._bar.width * .5 + this._offSetX;
                            this.labelBg.x = this._bar._x - 80;
                            this.labelBg.y = this._bar._y - 37
                        } else {
                            this.label.x = this._bar._x + this._bar.width * .5
                        }
                    } else {
                        this.label.x = this._bar.width * .5 + this._bar._x;
                        if (this._vFloat) {
                            this.label.y = this._bar._y + this._bar.height * .5 + this._offSetY;
                            this.labelBg.x = this._bar._x - 37;
                            this.labelBg.y = this._bar._y - 80
                        } else {
                            this.label.y = this._bar._y + this._bar.height * .5
                        }
                    }
                }
            }
        }
        showMyText() {
            if (this._array && this._array[this._value] != null) {
                this.showTextByFormat(this._array[this._value])
            } else {
                this.showTextByFormat(this._value)
            }
        }
        showTextByFormat(e) {
            if (!this._format || this._format == "") {
                this._format = "%s"
            }
            this.createLabel();
            this.label.text = I.format(this._format, e);
            if (Number(e) == 0) {
                this._bar.skin = "Common/m/common/hslider$bar2.png"
            } else {
                this._bar.skin = "Common/m/common/hslider$bar.png"
            }
        }
        createLabel() {
            if (!this.label) {
                this.label = new xt;
                this.label.skin = "Common/m/common/num_progressBar";
                this.label.align = 2;
                this.label.offsetType = "imgWithFixed";
                this.label.offset = 5;
                this.addChild(this.label)
            }
        }
        onBarMouseDown(e) {
            super.onBarMouseDown(e);
            this.timer.clear(this, this.showLabelBg);
            this._vFloat && this.showLabelBg(true)
        }
        onBgMouseDown(e) {
            super.onBgMouseDown(e);
            this.timer.clear(this, this.showLabelBg);
            this._vFloat && this.showLabelBg(true);
            this.hideValueText()
        }
        hideValueText() {
            this._vFloat && this.timer.once(1e3, this, this.showLabelBg, [false])
        }
        showLabelBg(e) {
            this.label.visible = e;
            this.labelBg.visible = e
        }
        set array(e) {
            this._array = e;
            if (e) {
                this.min = 0;
                this.max = e.length - 1
            }
            this.showValueText()
        }
        get array() {
            return super.array
        }
        set text(e) {
            this.showValueText();
            this.showTextByFormat(e)
        }
        get text() {
            return super.text
        }
        set isExternal(e) {
            if (this._isExternal != e) {
                this._isExternal = e
            }
        }
        get isExternal() {
            return super.isExternal
        }
        get value() {
            return super.value
        }
        set value(e) {
            super.value = e;
            this.showValueText()
        }
        get format() {
            return this._format
        }
        set format(e) {
            this._format = e;
            this.showMyText()
        }
        set externalLabel(e) {
            if (e == null && this._isExternal) {
                this._isExternal = false;
                this.label = null;
                return
            }
            if (!this._isExternal && this.label) {
                this.label.destroy()
            }
            this.label = e;
            this._isExternal = true;
            this.showMyText()
        }
        get externalLabel() {
            return super.externalLabel
        }
        get valueFloat() {
            return this._vFloat
        }
        set valueFloat(e) {
            this._vFloat = e;
            this.showValueText()
        }
        get showText() {
            return this.showLabel
        }
        set showText(e) {
            this.showLabel = e;
            if (!this._isExternal && !e) {
                this.label && this.label.destroy();
                this.label = null
            }
        }
    }
    Common.UI.CommonSlider = b.CommonSlider = Ea;
    class fa extends ea {
        constructor() {
            super()
        }
    }
    Common.UI.AutoHideAnimation = b.AutoHideAnimation = fa;
    Common.Dialog = {};
    class Aa extends na {
        constructor() {
            super();
            this.codeStr = "错误码:";
            this.tempCode = -1;
            this.tempHandler = null;
            this.tempCloseOther = false;
            this.tempShowEffect = true
        }
        createUI() {
            this.loadScene(L.Instance.MessageBoxSkin)
        }
        onLoad() {
            this.btnClose && this.btnClose.on(M.CLICK, this, this.onBtnCloseClickEvent);
            this.btnYes && this.btnYes.on(M.CLICK, this, this.onBtnYesClickEvent);
            if (this.tempContent != null) {
                this.txtContent && (this.txtContent.text = this.tempContent);
                this.showErrorCode(this.tempCode);
                this.closeHandler = this.tempHandler;
                R.Instance.playSound("sound_open");
                this.popup(this.tempCloseOther, this.tempShowEffect);
                this.tempContent = null;
                this.tempHandler = null
            }
        }
        onBtnCloseClickEvent(e) {
            this.close(K.CLOSE)
        }
        onBtnYesClickEvent(e) {
            this.close(K.YES)
        }
        showMessage(e, t = -1, a = null, i = false, n = true) {
            if (this.ViewCreated) {
                this.txtContent && (this.txtContent.text = e);
                this.showErrorCode(t);
                this.closeHandler = a;
                this.popup(i, n);
                R.Instance.playSound("sound_open")
            } else {
                this.tempContent = e;
                this.tempCode = t;
                this.tempHandler = a;
                this.tempCloseOther = i;
                this.tempShowEffect = n
            }
        }
        onClosed() {
            R.Instance.playSound("sound_close")
        }
        showErrorCode(e = -1) {
            if (this.lblErrorCode) {
                if (e >= 0) {
                    this.lblErrorCode.visible = true;
                    this.lblErrorCode.text = this.codeStr + e
                } else {
                    this.lblErrorCode.visible = false
                }
            }
        }
    }
    Common.Dialog.MessageBox = b.MessageBox = Aa;
    b.static(Aa, ["Instance", function() {
        return this.Instance = new Aa
    }]);
    class Ca extends na {
        constructor() {
            super();
            this.tempHandler = null;
            this.tempCloseOther = false;
            this.tempShowEffect = true;
            this._yesType = l.YESNO_YES_LEFT
        }
        createUI() {
            this.loadScene(L.Instance.MessageYesNoBoxSkin)
        }
        onLoad() {
            this.btnClose && this.btnClose.on(M.CLICK, this, this.onBtnCloseClickEvent);
            this.btnYes && this.btnYes.on(M.CLICK, this, this.onBtnYesClickEvent);
            this.btnNo && this.btnNo.on(M.CLICK, this, this.onBtnNoClickEvent);
            this.btnYes && (this.yesX = this.btnYes.x);
            this.btnNo && (this.noX = this.btnNo.x);
            this.checkYesType();
            if (this.tempContent != null) {
                this.setTitleAndContent(this.tempTitle, this.tempContent, this.tempYes, this.tempNo);
                this.closeHandler = this.tempHandler;
                this.popup(this.tempCloseOther, this.tempShowEffect);
                R.Instance.playSound("sound_open");
                this.tempContent = null;
                this.tempTitle = null;
                this.tempHandler = null
            }
        }
        onBtnCloseClickEvent(e) {
            R.Instance.playSound("sound_close");
            this.close(K.CLOSE)
        }
        onBtnYesClickEvent(e) {
            R.Instance.playSound("sound_close");
            this.close(K.YES)
        }
        onBtnNoClickEvent(e) {
            R.Instance.playSound("sound_close");
            this.close(K.NO)
        }
        showMessage(e, t, a = null, i = l.DIALOG_OK, n = l.DIALOG_CANCEL, s = true, r = true) {
            if (this.ViewCreated) {
                this.setTitleAndContent(e, t, i, n);
                this.closeHandler = a;
                this.popup(s, r);
                R.Instance.playSound("sound_open")
            } else {
                this.tempContent = t;
                this.tempTitle = e;
                this.tempYes = i;
                this.tempNo = n;
                this.tempHandler = a;
                this.tempCloseOther = s;
                this.tempShowEffect = r
            }
            this.yesType = l.YESNO_YES_LEFT
        }
        setTitleAndContent(e, t, a, i) {
            this.imgTitle && (this.imgTitle.skin = I.replayString(this.imgTitle.skin, "/title_", ".png", e));
            this.imgContext && (this.imgContext.skin = I.replayString(this.imgContext.skin, "/context_", ".png", t));
            this.btnYes && (this.btnYes.skin = I.replayString(this.btnYes.skin, "/btn_", ".png", a));
            this.btnNo && (this.btnNo.skin = I.replayString(this.btnNo.skin, "/btn_", ".png", i))
        }
        checkYesType() {
            if (this._yesType == l.YESNO_YES_LEFT) {
                this.btnYes && (this.btnYes.x = this.yesX);
                this.btnNo && (this.btnNo.x = this.noX)
            } else {
                this.btnYes && (this.btnYes.x = this.noX);
                this.btnNo && (this.btnNo.x = this.yesX)
            }
        }
        get yesType() {
            return this._yesType
        }
        set yesType(e) {
            this._yesType = e;
            this.checkYesType()
        }
    }
    Common.Dialog.MessageYesNoBox = b.MessageYesNoBox = Ca;
    b.static(Ca, ["Instance", function() {
        return this.Instance = new Ca
    }]);
    class Ta extends na {
        constructor() {
            super();
            this.codeStr = "错误码:";
            this.tempCode = -1;
            this.tempHandler = null;
            this.tempCloseOther = false;
            this.tempShowEffect = true
        }
        MessageBox() {}
        createUI() {
            this.loadScene(L.Instance.ReconnectMessageBoxSkin)
        }
        onLoad() {
            this.btnClose && this.btnClose.on(M.CLICK, this, this.onBtnCloseClickEvent);
            this.btnYes && this.btnYes.on(M.CLICK, this, this.onBtnYesClickEvent);
            if (this.tempContent != null) {
                this.txtContent && (this.txtContent.text = this.tempContent);
                this.showErrorCode(this.tempCode);
                this.closeHandler = this.tempHandler;
                R.Instance.playSound("sound_open");
                this.popup(this.tempCloseOther, this.tempShowEffect);
                this.tempContent = null;
                this.tempHandler = null
            }
        }
        onBtnCloseClickEvent(e) {
            this.close(K.CLOSE)
        }
        onBtnYesClickEvent(e) {
            this.close(K.YES)
        }
        showMessage(e, t = -1, a = null, i = false, n = true) {
            if (this.ViewCreated) {
                this.txtContent && (this.txtContent.text = e);
                this.showErrorCode(t);
                this.closeHandler = a;
                this.popup(i, n);
                R.Instance.playSound("sound_open")
            } else {
                this.tempContent = e;
                this.tempCode = t;
                this.tempHandler = a;
                this.tempCloseOther = i;
                this.tempShowEffect = n
            }
        }
        onClosed() {
            R.Instance.playSound("sound_close")
        }
        showErrorCode(e = -1) {
            if (this.lblErrorCode) {
                if (e >= 0) {
                    this.lblErrorCode.visible = true;
                    this.lblErrorCode.text = this.codeStr + e
                } else {
                    this.lblErrorCode.visible = false
                }
            }
        }
    }
    Common.Dialog.ReconnectMessageBox = b.ReconnectMessageBox = Ta;
    b.static(Ta, ["Instance", function() {
        return this.Instance = new Ta
    }]);
    class Oa extends _e {
        constructor() {
            super()
        }
        itemClick(e) {
            super.itemClick(e);
            R.Instance.playSound("button_click")
        }
    }
    Common.UI.DolRadioGroup = b.DolRadioGroup = Oa;
    return b
})(window);