(function(t) {
    var I = t.Laya;
    var s = I.AppConfig,
        i = I.AppContext,
        e = I.ArrayUtils,
        M = I.AutoNumberCell;
    var L = I.AutoPlay,
        o = I.AutoPlaySelected,
        n = I.BaseGameScene,
        a = I.BaseMain;
    var P = I.BaseScene,
        r = I.BaseView,
        j = I.Box,
        l = I.Browser,
        x = I.Button;
    var D = I.CMDEvent,
        h = I.CheckRoundSeed,
        m = I.CommonUtils,
        S = I.Dispatcher;
    var K = I.DolAnimation,
        F = I.DolButton,
        T = I.DolSkeleton,
        H = I.DynamicMessage;
    var u = I.Event,
        W = I.FairSimpleMyBetDto,
        w = I.GameContext,
        Y = I.GameEnum;
    var z = I.GlobalButtonEnum,
        X = I.GlobalConfig,
        J = I.GlobalEnum,
        q = I.GlobalEvent;
    var Q = I.GlobalSoundEnum,
        Z = I.HBox,
        $ = I.HSlider,
        c = I.Handler,
        tt = I.HandlerSequence;
    var p = I.HeaderView,
        st = I.Image,
        et = I.ImageNumber,
        it = I.Label,
        ot = I.MsgMaster;
    var C = I.MyBetViewCell,
        nt = I.NumberCell,
        at = I.NumberInputView,
        rt = I.Panel;
    var lt = I.Radio,
        ht = I.RadioGroup,
        b = I.SceneManager,
        A = I.SoundUtils;
    var mt = I.Sprite,
        ut = I.StringUtils,
        d = I.TcpLogicManager,
        _ = I.TweenLite;
    var ct = I.TweenSequence,
        y = I.UserInfo;
    t.Cryptos = {};
    Cryptos.Config = {};
    class k {
        constructor() {}
    }
    Cryptos.Config.DataRiskConfig = I.DataRiskConfig = k;
    I.static(k, ["REWARD_RATE", function() {
        return this.REWARD_RATE = {
            25: {
                1: [0, .5, 1.5, 3.5, 4.5, 5.5, 21],
                2: [0, .1, 2.4, 3.7, 5.5, 7.7, 63],
                3: [0, 0, .4, 5, 10, 20, 241]
            },
            30: {
                1: [0, .5, 1.5, 3.5, 4.5, 5, 18],
                2: [0, .1, 2.4, 3.7, 5.4, 7.6, 50],
                3: [0, 0, .4, 5, 10, 20, 220]
            },
            35: {
                1: [0, .5, 1.5, 3.5, 4.4, 4.7, 15],
                2: [0, .1, 2.4, 3.7, 5.4, 7.1, 50],
                3: [0, 0, .4, 5, 10, 20, 200]
            }
        }
    }, "ICON_COEFFICIENT", function() {
        return this.ICON_COEFFICIENT = [
            [0, 0, 0, 0, 0],
            [1, 1, 0, 0, 0],
            [1, 1, 2, 2, 0],
            [1, 1, 1, 0, 0],
            [1, 1, 1, 2, 2],
            [1, 1, 1, 1, 0],
            [1, 1, 1, 1, 1]
        ]
    }]);
    Cryptos.Config.Res = {};
    class g {
        constructor() {}
    }
    Cryptos.Config.Res.GameResConfig = I.GameResConfig = g;
    g.RES_3D = [];
    g.RES_3D_LMAT = [];
    g.RES_FNT = [];
    I.static(g, ["RES_2D", function() {
        return this.RES_2D = ["Cryptos/common/common/ani/loading.atlas", "Cryptos/common/common/ani/roundid.atlas", "res/atlas/Common/common/common/autoPlay.atlas", "res/atlas/Common/common/common/comp.atlas", "res/atlas/Common/common/common/dialog.atlas", "res/atlas/Common/common/common/ui.atlas", "res/atlas/Common/common/common/userinfo.atlas", "res/atlas/Common/common/common/verification.atlas", "res/atlas/Common/common/en/ui.atlas", "res/atlas/Common/common/hi/ui.atlas", "res/atlas/Common/common/id/ui.atlas", "res/atlas/Common/common/ms/ui.atlas", "res/atlas/Common/common/pr/ui.atlas", "res/atlas/Common/common/th/ui.atlas", "res/atlas/Common/common/vi/ui.atlas", "res/atlas/Common/common/zh-cn/ui.atlas", "res/atlas/Common/m/common/ui.atlas", "res/atlas/Common/m/en/ui.atlas", "res/atlas/Common/m/hi/ui.atlas", "res/atlas/Common/m/id/ui.atlas", "res/atlas/Common/m/ms/ui.atlas", "res/atlas/Common/m/pr/ui.atlas", "res/atlas/Common/m/th/ui.atlas", "res/atlas/Common/m/vi/ui.atlas", "res/atlas/Common/pc/common/ui.atlas", "res/atlas/Common/pc/en/ui.atlas", "res/atlas/Common/pc/hi/ui.atlas", "res/atlas/Common/pc/id/ui.atlas", "res/atlas/Common/pc/ms/ui.atlas", "res/atlas/Common/pc/pr/ui.atlas", "res/atlas/Common/pc/th/ui.atlas", "res/atlas/Common/pc/vi/ui.atlas", "res/atlas/Cryptos/common/common/ui.atlas", "res/atlas/Cryptos/m/common/ui.atlas", "res/atlas/Cryptos/m/en/ui.atlas", "res/atlas/Cryptos/m/hi/ui.atlas", "res/atlas/Cryptos/m/id/ui.atlas", "res/atlas/Cryptos/m/ms/ui.atlas", "res/atlas/Cryptos/m/pr/ui.atlas", "res/atlas/Cryptos/m/th/ui.atlas", "res/atlas/Cryptos/m/vi/ui.atlas", "res/atlas/Cryptos/pc/common/ui.atlas", "res/atlas/Cryptos/pc/en/ui.atlas", "res/atlas/Cryptos/pc/hi/ui.atlas", "res/atlas/Cryptos/pc/id/ui.atlas", "res/atlas/Cryptos/pc/ms/ui.atlas", "res/atlas/Cryptos/pc/pr/ui.atlas", "res/atlas/Cryptos/pc/th/ui.atlas", "res/atlas/Cryptos/pc/vi/ui.atlas", "Cryptos/common/common/spine/icon_light.png", "Cryptos/common/common/spine/icon_light.sk", "Cryptos/common/common/spine/icon01.png", "Cryptos/common/common/spine/icon01.sk", "Cryptos/common/common/spine/icon02.png", "Cryptos/common/common/spine/icon02.sk", "Cryptos/common/common/spine/icon03.png", "Cryptos/common/common/spine/icon03.sk", "Cryptos/common/common/spine/icon04.png", "Cryptos/common/common/spine/icon04.sk", "Cryptos/common/common/spine/icon05.png", "Cryptos/common/common/spine/icon05.sk", "Cryptos/common/common/spine/icon06.png", "Cryptos/common/common/spine/icon06.sk", "Cryptos/common/common/spine/icon07.png", "Cryptos/common/common/spine/icon07.sk", "Cryptos/common/common/spine/icon08.png", "Cryptos/common/common/spine/icon08.sk"]
    }, "RES_SOUND", function() {
        return this.RES_SOUND = ["Assets/Cryptos/Sound/big_button.mp3", "Assets/Cryptos/Sound/button_click.mp3", "Assets/Cryptos/Sound/chip.mp3", "Assets/Cryptos/Sound/flip.mp3", "Assets/Cryptos/Sound/match.mp3", "Assets/Cryptos/Sound/soft_win.mp3", "Assets/Cryptos/Sound/sound_lose.mp3"]
    }, "RES_UI", function() {
        return this.RES_UI = ["GameUI/Common/Dialog/MessageBox.json", "GameUI/Common/Dialog/MessageYesNoBox.json", "GameUI/Common/Dialog/ReconnectMessageBox.json", "GameUI/Common/Scenes/GameLoading.json", "GameUI/Common/View/AutoNumberCell_h.json", "GameUI/Common/View/AutoNumberCell_v.json", "GameUI/Common/View/BonusAnnouncementView.json", "GameUI/Common/View/BonusAnnouncementView_h.json", "GameUI/Common/View/BonusAnnouncementView_v.json", "GameUI/Common/View/DynamicMsgView.json", "GameUI/Common/View/GameLoadingBarNew.json", "GameUI/Common/View/LangSettingView_h.json", "GameUI/Common/View/LangSettingView_v.json", "GameUI/Common/View/LoadingView_h.json", "GameUI/Common/View/LoadingView_v.json", "GameUI/Common/View/ScreenSettingView_h.json", "GameUI/Common/View/ScreenSettingView_v.json", "GameUI/Common/View/UserInfoView_h.json", "GameUI/Common/View/UserInfoView_v.json", "GameUI/Cryptos/Scenes/GameLoading_h.json", "GameUI/Cryptos/Scenes/GameLoading_v.json", "GameUI/Cryptos/Scenes/GameScene_h.json", "GameUI/Cryptos/Scenes/GameScene_v.json", "GameUI/Cryptos/View/AutoNumberCell_h.json", "GameUI/Cryptos/View/AutoNumberCell_v.json", "GameUI/Cryptos/View/AutoPlaySelected_h.json", "GameUI/Cryptos/View/AutoPlaySelected_v.json", "GameUI/Cryptos/View/BetViewCell2_h.json", "GameUI/Cryptos/View/BetViewCell2_v.json", "GameUI/Cryptos/View/BonusCell_h.json", "GameUI/Cryptos/View/BonusCell_v.json", "GameUI/Cryptos/View/CheckRoundSeedView_h.json", "GameUI/Cryptos/View/CheckRoundSeedView_v.json", "GameUI/Cryptos/View/DetailedRulesView_h.json", "GameUI/Cryptos/View/DetailedRulesView_v.json", "GameUI/Cryptos/View/GameCell.json", "GameUI/Cryptos/View/GameLimitsView_h.json", "GameUI/Cryptos/View/GameLimitsView_v.json", "GameUI/Cryptos/View/GameLoadingBarNew.json", "GameUI/Cryptos/View/GameRulesView_h.json", "GameUI/Cryptos/View/GameRulesView_v.json", "GameUI/Cryptos/View/GreenDetailed_h.json", "GameUI/Cryptos/View/GreenDetailed_v.json", "GameUI/Cryptos/View/HeaderView_h.json", "GameUI/Cryptos/View/HeaderView_v.json", "GameUI/Cryptos/View/LangSettingView_h.json", "GameUI/Cryptos/View/LangSettingView_v.json", "GameUI/Cryptos/View/LoadingView_h.json", "GameUI/Cryptos/View/LoadingView_v.json", "GameUI/Cryptos/View/MyBetViewCell_h.json", "GameUI/Cryptos/View/MyBetViewCell_v.json", "GameUI/Cryptos/View/MyHistoryView_h.json", "GameUI/Cryptos/View/MyHistoryView_v.json", "GameUI/Cryptos/View/NumberCell_h.json", "GameUI/Cryptos/View/NumberCell_v.json", "GameUI/Cryptos/View/NumberKeyboard_h.json", "GameUI/Cryptos/View/NumberKeyboard_v.json", "GameUI/Cryptos/View/ScreenSettingView_h.json", "GameUI/Cryptos/View/ScreenSettingView_v.json", "GameUI/Cryptos/View/UserInfoView_h.json", "GameUI/Cryptos/View/UserInfoView_v.json"]
    }, "RES_SK", function() {
        return this.RES_SK = ["Cryptos/common/common/spine/icon_light.sk", "Cryptos/common/common/spine/icon01.sk", "Cryptos/common/common/spine/icon02.sk", "Cryptos/common/common/spine/icon03.sk", "Cryptos/common/common/spine/icon04.sk", "Cryptos/common/common/spine/icon05.sk", "Cryptos/common/common/spine/icon06.sk", "Cryptos/common/common/spine/icon07.sk", "Cryptos/common/common/spine/icon08.sk"]
    }, "RES_ALL", function() {
        return this.RES_ALL = ["Assets/Cryptos/Sound/big_button.mp3", "Assets/Cryptos/Sound/button_click.mp3", "Assets/Cryptos/Sound/chip.mp3", "Assets/Cryptos/Sound/flip.mp3", "Assets/Cryptos/Sound/match.mp3", "Assets/Cryptos/Sound/soft_win.mp3", "Assets/Cryptos/Sound/sound_lose.mp3", "res/atlas/Cryptos/common/common/ui.atlas", "res/atlas/Cryptos/common/common/ui.png", "res/atlas/Cryptos/m/common/ui.atlas", "res/atlas/Cryptos/m/common/ui.png", "res/atlas/Cryptos/m/en/ui.atlas", "res/atlas/Cryptos/m/en/ui.png", "res/atlas/Cryptos/m/hi/ui.atlas", "res/atlas/Cryptos/m/hi/ui.png", "res/atlas/Cryptos/m/id/ui.atlas", "res/atlas/Cryptos/m/id/ui.png", "res/atlas/Cryptos/m/ms/ui.atlas", "res/atlas/Cryptos/m/ms/ui.png", "res/atlas/Cryptos/m/pr/ui.atlas", "res/atlas/Cryptos/m/pr/ui.png", "res/atlas/Cryptos/m/th/ui.atlas", "res/atlas/Cryptos/m/th/ui.png", "res/atlas/Cryptos/m/vi/ui.atlas", "res/atlas/Cryptos/m/vi/ui.png", "res/atlas/Cryptos/pc/common/ui.atlas", "res/atlas/Cryptos/pc/common/ui.png", "res/atlas/Cryptos/pc/en/ui.atlas", "res/atlas/Cryptos/pc/en/ui.png", "res/atlas/Cryptos/pc/hi/ui.atlas", "res/atlas/Cryptos/pc/hi/ui.png", "res/atlas/Cryptos/pc/id/ui.atlas", "res/atlas/Cryptos/pc/id/ui.png", "res/atlas/Cryptos/pc/ms/ui.atlas", "res/atlas/Cryptos/pc/ms/ui.png", "res/atlas/Cryptos/pc/pr/ui.atlas", "res/atlas/Cryptos/pc/pr/ui.png", "res/atlas/Cryptos/pc/th/ui.atlas", "res/atlas/Cryptos/pc/th/ui.png", "res/atlas/Cryptos/pc/vi/ui.atlas", "res/atlas/Cryptos/pc/vi/ui.png", "Cryptos/common/common/ani/loading.atlas", "Cryptos/common/common/ani/loading.png", "Cryptos/common/common/ani/roundid.atlas", "Cryptos/common/common/ani/roundid.png", "Cryptos/common/common/spine/icon01.png", "Cryptos/common/common/spine/icon01.sk", "Cryptos/common/common/spine/icon02.png", "Cryptos/common/common/spine/icon02.sk", "Cryptos/common/common/spine/icon03.png", "Cryptos/common/common/spine/icon03.sk", "Cryptos/common/common/spine/icon04.png", "Cryptos/common/common/spine/icon04.sk", "Cryptos/common/common/spine/icon05.png", "Cryptos/common/common/spine/icon05.sk", "Cryptos/common/common/spine/icon06.png", "Cryptos/common/common/spine/icon06.sk", "Cryptos/common/common/spine/icon07.png", "Cryptos/common/common/spine/icon07.sk", "Cryptos/common/common/spine/icon08.png", "Cryptos/common/common/spine/icon08.sk", "Cryptos/common/common/spine/icon_light.png", "Cryptos/common/common/spine/icon_light.sk", "GameUI/Cryptos/Scenes/GameLoading_h.json", "GameUI/Cryptos/Scenes/GameLoading_v.json", "GameUI/Cryptos/Scenes/GameScene_h.json", "GameUI/Cryptos/Scenes/GameScene_v.json", "GameUI/Cryptos/View/AutoNumberCell_h.json", "GameUI/Cryptos/View/AutoNumberCell_v.json", "GameUI/Cryptos/View/AutoPlaySelected_h.json", "GameUI/Cryptos/View/AutoPlaySelected_v.json", "GameUI/Cryptos/View/BetViewCell2_h.json", "GameUI/Cryptos/View/BetViewCell2_v.json", "GameUI/Cryptos/View/BonusCell_h.json", "GameUI/Cryptos/View/BonusCell_v.json", "GameUI/Cryptos/View/CheckRoundSeedView_h.json", "GameUI/Cryptos/View/CheckRoundSeedView_v.json", "GameUI/Cryptos/View/DetailedRulesView_h.json", "GameUI/Cryptos/View/DetailedRulesView_v.json", "GameUI/Cryptos/View/GameCell.json", "GameUI/Cryptos/View/GameLimitsView_h.json", "GameUI/Cryptos/View/GameLimitsView_v.json", "GameUI/Cryptos/View/GameLoadingBarNew.json", "GameUI/Cryptos/View/GameRulesView_h.json", "GameUI/Cryptos/View/GameRulesView_v.json", "GameUI/Cryptos/View/GreenDetailed_h.json", "GameUI/Cryptos/View/GreenDetailed_v.json", "GameUI/Cryptos/View/HeaderView_h.json", "GameUI/Cryptos/View/HeaderView_v.json", "GameUI/Cryptos/View/LangSettingView_h.json", "GameUI/Cryptos/View/LangSettingView_v.json", "GameUI/Cryptos/View/LoadingView_h.json", "GameUI/Cryptos/View/LoadingView_v.json", "GameUI/Cryptos/View/MyBetViewCell_h.json", "GameUI/Cryptos/View/MyBetViewCell_v.json", "GameUI/Cryptos/View/MyHistoryView_h.json", "GameUI/Cryptos/View/MyHistoryView_v.json", "GameUI/Cryptos/View/NumberCell_h.json", "GameUI/Cryptos/View/NumberCell_v.json", "GameUI/Cryptos/View/NumberKeyboard_h.json", "GameUI/Cryptos/View/NumberKeyboard_v.json", "GameUI/Cryptos/View/ScreenSettingView_h.json", "GameUI/Cryptos/View/ScreenSettingView_v.json", "GameUI/Cryptos/View/UserInfoView_h.json", "GameUI/Cryptos/View/UserInfoView_v.json"]
    }]);
    class f extends a {
        constructor() {
            super()
        }
        initConfig() {
            super.initConfig();
            i.Instance.supportPlatform = 1;
            l.langList = ["en", "vi", "pr", "hi", "th", "ms", "id"]
        }
        InitApp() {
            super.InitApp();
            i.Instance.AppID = 111;
            i.Instance.AppVersion = "1.0.0";
            i.Instance.ModuleName = "Cryptos";
            i.Instance.GameResConfig = g;
            i.Instance.GameScene = V;
            i.Instance.GameKind = 2;
            i.Instance.CheckRoundSeedClass = U;
            i.Instance.fontArr = ["Microsoft YaHei", "fzcsjt", "stkaiti"];
            i.Instance.skNeedChangeSkin = [];
            i.Instance.hide_win_interval = 1e3;
            i.Instance.help_pos_x = 180;
            i.Instance.fsg_next_interval = 1500;
            this.setMoblieScreenTypeByLocalStorage(1)
        }
    }
    Cryptos.Main = I.Main = f;
    Cryptos.View = {};
    class v extends r {
        constructor() {
            super();
            this._status = -1;
            this._rate = -1
        }
        baseInit(t) {
            super.baseInit(t);
            this.setUIPathByName("BonusCell")
        }
        onEnable() {
            super.onEnable();
            this.status = 0
        }
        setIconColor(t, s = false) {
            for (var e = 0; e < t.length; e++) {
                var i = "Cryptos/" + m.getPCOrMobilePath() + "/common/ui/imgIcon_";
                if (s == false) {
                    i += "n_"
                }
                i += t[e] + ".png";
                if (t[e] > 0) {
                    this.icons.getChildByName("imgIcon" + e).skin = i
                }
            }
        }
        get index() {
            return this._index
        }
        set index(t) {
            this._index = t;
            if (t < 0 || t > 6) return;
            this.setIconColor(k.ICON_COEFFICIENT[t])
        }
        get rate() {
            return this._rate
        }
        set rate(t) {
            this._rate = t;
            this.lblOdds.text = t.toFixed(2) + "x"
        }
        get status() {
            return this._status
        }
        set status(t) {
            this._status = t;
            switch (t) {
                case 0:
                    this.imgFrame.skin = "Cryptos/" + m.getPCOrMobilePath() + "/common/ui/img_bonus_1.png";
                    this.lblOdds.scale(1, 1);
                    this.lblOdds.color = "#8f8aa9";
                    break;
                case 1:
                    this.imgFrame.skin = "Cryptos/" + m.getPCOrMobilePath() + "/common/ui/img_bonus_2.png";
                    this.lblOdds.scale(1.2, 1.2);
                    this.lblOdds.color = "#97ed2b";
                    break
            }
        }
    }
    Cryptos.View.CryptosBonusCell = I.CryptosBonusCell = v;
    class B extends r {
        constructor() {
            super();
            this._status = -1;
            this._movie = true
        }
        createUI() {
            this.loadSceneByName("GameCell")
        }
        registeEvent() {
            super.registeEvent();
            this.registeAllButton();
            S.on("NC_FSG_KENO_BALL_CAN_SELECT", this, this.onCanSelectChange);
            S.on("NC_FSG_KENO_BALL_MOUSE_ENABLE", this, this.setCannotClick)
        }
        onEnable() {
            super.onEnable();
            this.status = 0;
            this._canSelect = true
        }
        onCanSelectChange(t) {
            this._canSelect = t
        }
        setCannotClick(t = false) {
            this.btn.mouseEnabled = t
        }
        onButtonClick(t) {
            super.onButtonClick(t);
            if (t == "btn") {
                S.dispatch("NC_FSG_KENO_BALL_SELECTED", [this._index, true])
            }
        }
        get status() {
            return this._status
        }
        set status(t) {
            this._status = t;
            switch (t) {
                case 0:
                    this.skIcon.visible = false;
                    this.imgX && (this.imgX.visible = true);
                    this.imgBg && (this.imgBg.skin = i.Instance.ModuleName + "/common/common/ui/img_ground_0.png");
                    break;
                case 3:
                    this.lblIcon && (this.lblIcon.visible = true);
                case 1:
                    this.skIcon.visible = true;
                    this.imgX && (this.imgX.visible = false);
                    break;
                case 4:
                    this.imgSel && (this.imgSel.visible = true);
                    this.lblIcon && (this.lblIcon.visible = true);
                    this.imgX && (this.imgX.visible = false);
                    this.imgBg && (this.imgBg.skin = i.Instance.ModuleName + "/common/common/ui/img_ground_" + this._imgId + ".png");
                    break;
                case 2:
                    this.skIcon.visible = true;
                    this.imgX && (this.imgX.visible = false);
                    this.imgBg && (this.imgBg.skin = i.Instance.ModuleName + "/common/common/ui/img_ground_" + this._imgId + ".png");
                    break;
                case 5:
                    this.imgSel && (this.imgSel.visible = true);
                    this.lblIcon && (this.lblIcon.visible = true);
                    this.imgX && (this.imgX.visible = false);
                    break
            }
        }
        set movie(t) {
            this._movie = t
        }
        get movie() {
            return super.movie
        }
        set sel(t) {
            this._sel = t;
            this.skSel && (this.skSel.visible = this._sel);
            if (this._sel) {
                this.skSel && this.skSel.play("icon0" + this._imgId, true)
            } else {
                this.skSel && this.skSel.stop()
            }
        }
        get sel() {
            return super.sel
        }
        set index(t) {
            this._index = t;
            this.lblPos.text = t + 1
        }
        get index() {
            return super.index
        }
        set imgId(t) {
            this._imgId = t;
            if (this._imgId > 0) {
                this.skIcon.skin = i.Instance.ModuleName + "/common/common/spine/icon0" + this._imgId + ".sk";
                this.skIcon.play("icon0" + this._imgId, true);
                if (!this._movie) {
                    this.skIcon.stop()
                }
                this.skIcon.visible = true
            } else {
                this.skIcon.visible = false
            }
            this.lblIcon && (this.lblIcon.text = t)
        }
        get imgId() {
            return super.imgId
        }
    }
    Cryptos.View.CryptosGameCell = I.CryptosGameCell = B;
    class N extends r {
        constructor(t = null, s = 3) {
            super();
            this._num = "0";
            this._fix_count = "2";
            this._callback = null;
            this._numCount = 3;
            this._callback = t;
            this._numCount = s
        }
        createUI() {
            super.createUI()
        }
        baseInit(t) {
            super.baseInit(t);
            this.setUIPathByName("NumberKeyboard")
        }
        registeEvent() {
            super.registeEvent();
            this.registeAllButton()
        }
        onButtonClick(t) {
            switch (t) {
                case "btnNum0":
                    this.addNum("0");
                    break;
                case "btnNum1":
                    this.addNum("1");
                    break;
                case "btnNum2":
                    this.addNum("2");
                    break;
                case "btnNum3":
                    this.addNum("3");
                    break;
                case "btnNum4":
                    this.addNum("4");
                    break;
                case "btnNum5":
                    this.addNum("5");
                    break;
                case "btnNum6":
                    this.addNum("6");
                    break;
                case "btnNum7":
                    this.addNum("7");
                    break;
                case "btnNum8":
                    this.addNum("8");
                    break;
                case "btnNum9":
                    this.addNum("9");
                    break;
                case "btnNumDot":
                    this.addNum(".");
                    break;
                case "btnClear":
                    this.clear();
                    break;
                case "btnOK":
                    if (this._callback != null) {
                        this._callback.runWith(this._num)
                    }
                    S.dispatch("NC_NUMBER_KEYBOARD_CLOSE");
                    this.visible = false;
                    break;
                case "btnClose":
                    this.close();
                    break
            }
        }
        clear() {
            this.num = "0";
            this.freshNum()
        }
        addNum(t) {
            var s = true;
            if (this._num != "0") {
                s = false
            }
            var e = -1;
            if (s == false) {
                e = this.hasDot()
            }
            var i = 1;
            if (t != ".") {
                if (s) {
                    if (t == 0) {
                        return
                    } else {
                        this.num = t
                    }
                } else {
                    if (e >= this._fix_count) {
                        return
                    }
                    if (this.getNumCount() >= this._numCount) {
                        return
                    }
                    this.num = this._num + "" + t
                }
            } else {
                if (e >= 0) {
                    return
                } else {
                    this.num = this._num + "."
                }
            }
            this.freshNum()
        }
        onEnable() {
            super.onEnable();
            this.initView()
        }
        initView() {
            this.freshNum()
        }
        freshNum() {
            this.lbNum && (this.lbNum.text = this._num)
        }
        hasDot() {
            if (this._num) {
                var t = "" + this._num;
                var s = t.indexOf(".");
                if (s > 0) {
                    return t.length - s - 1
                }
            }
            return -1
        }
        getNumCount() {
            var t = this._num.split(".");
            if (t.length == 1) {
                return t[0].length
            }
            return 0
        }
        openKeyboard() {
            this._num = "";
            this.visible = true
        }
        set num(t) {
            console.log("set num:", t);
            this._num = t;
            var s = this._num;
            if (s.length > 0 && s[0] == ".") {
                s = "0" + s
            }
            S.dispatch("NC_NUMBER_KEYBOARD_CHANGE", s)
        }
        get num() {
            return super.num
        }
    }
    Cryptos.View.NumberKeyboard = I.NumberKeyboard = N;
    Cryptos.Scene = {};
    class V extends n {
        constructor() {
            super()
        }
        onResize() {
            super.onResize();
            this.bgRight && (this.bgRight.x = I.stage.realDesignWidth)
        }
        doFSGStart(t, s) {
            if (t != null) {
                console.log("data:", t);
                m.setLocalStorageItem("COOKIE_BETMONEY", t.bet_money);
                m.setLocalStorageItem("COOKIE_BRM", t.brm);
                m.setLocalStorageItem("COOKIE_START_POS", t.bet_pos)
            }
            if (s != null) {
                w.Instance.FairSimple.pai_t = s.pai_t;
                w.Instance.FairSimple.mul = s.mul
            }
        }
    }
    Cryptos.Scene.GameScene = I.GameScene = V;
    class G extends o {
        constructor(t = null, s = 1, e = null) {
            super(t, s, e);
            this._bet_pos = 1
        }
        init() {
            super.init()
        }
        onCellSelected(t) {
            super.onCellSelected(t);
            if (t != null && t.Data != null) {
                var s = t.Data;
                if (s.key == "pos") {
                    this._bet_pos = s.bet_pos;
                    if (this.curPosCell != null) {
                        this.curPosCell.changeSelected()
                    }
                    this.curPosCell = t;
                    this.curPosCell.changeSelected(true)
                }
            }
        }
        onBtnStart() {
            if (this._callback != null) {
                this._autoData.bet_pos = this._bet_pos;
                this._autoData.leftTime = this.getLeftTime();
                this.reStorJson();
                this._callback.runWith(this._autoData)
            }
            m.setLocalStorageJson("COOKIEAUTOPLAY" + i.Instance.uid, this._autoData);
            this.close()
        }
        onNumDownClick() {
            this.imgKeyboard && (this.imgKeyboard.visible = true);
            this.imgKeyboard && (this.imgKeyboard.y = 0);
            this.popStatus = this.POPUP_DOWN;
            this._num = "";
            this.freshNum()
        }
        onNumSingleClick() {
            this.imgKeyboard && (this.imgKeyboard.visible = true);
            this.imgKeyboard && (this.imgKeyboard.y = 90);
            this.popStatus = this.POPUP_SINGLE;
            this._num = "";
            this.freshNum()
        }
        onNumUpClick() {
            this.imgKeyboard && (this.imgKeyboard.visible = true);
            if (this.isHor) {
                this.imgKeyboard && (this.imgKeyboard.y = 180)
            } else {
                this.imgKeyboard && (this.imgKeyboard.y = 200)
            }
            this.popStatus = this.POPUP_UP;
            this._num = "";
            this.freshNum()
        }
    }
    Cryptos.View.CryptosAutoPlaySelected = I.CryptosAutoPlaySelected = G;
    class U extends h {
        constructor() {
            super();
            this.gameModImgList = ["img_paytable_classic.png", "img_paytable_lastball.png"];
            this.imgRishList = ["btn_choose1_1.png", "btn_choose1_2.png", "btn_choose1_3.png"];
            this.wordRishList = ["img_low.png", "img_normal.png", "img_high.png"];
            this.wcount = 10;
            this.hcount = 4
        }
        onEnable() {
            this.ballScale = l.onPC ? .36 : .4;
            this.wcount = l.onPC ? 14 : 10;
            this.hcount = l.onPC ? 3 : 4;
            super.onEnable();
            this.onResize();
            I.stage.on(u.RESIZE, this, this.onResize)
        }
        onResize() {}
        cal(t) {
            var s = t.concat();
            var e = {};
            console.log("showBallList:", s);
            for (var i = 0; i < s.length; i++) {
                var o = s[i];
                if (e[o] != null) {
                    e[o]++
                } else {
                    e[o] = 1
                }
            }
            var n = [];
            for (var a in e) {
                var r = e[a];
                var l = false;
                for (var i = 0; i < n.length; i++) {
                    if (n[i].count < r) {
                        n.unshift({
                            key: a,
                            count: r
                        });
                        l = true;
                        break
                    }
                }
                if (l == false) {
                    n.push({
                        key: a,
                        count: r
                    })
                }
            }
            var h = [0, 0, 0, 0, 0];
            var m = [0, 0, 0, 0, 0];
            var u = 0;
            var c = 1;
            for (var i = 0; i < n.length; i++) {
                var p = n[i];
                if (p.count > 1) {
                    for (var C = 0; C < p.count; C++) {
                        h[u] = c;
                        m[u] = p.key;
                        u++
                    }
                    c++
                }
            }
            return m
        }
        initBox() {
            var t = w.Instance;
            this.pIcon.destroyChildren();
            this.labResult2.text = t.CheckRoundSeedData.gs;
            var o = JSON.parse(t.CheckRoundSeedData.bs);
            var n = t.CheckRoundSeedData.gr.split("");
            var a = this.cal(n.slice(o.bet_pos - 1, o.bet_pos + 4));
            for (var r = 0; r < n.length; r++) {
                m.createView(B, c.create(this, function(t, s, e) {
                    this.pIcon.addChild(e);
                    e.x = (l.onPC ? 7 : 9) + s % this.wcount * (e.width * this.ballScale + 5);
                    e.y = (l.onPC ? 35 : 35) + Math.floor(s / this.wcount) * ((e.height + 70) * this.ballScale + 20);
                    e.index = s;
                    e.name = "ball" + s;
                    e.movie = false;
                    e.setCannotClick();
                    e.scale(this.ballScale, this.ballScale, true);
                    e.imgId = t;
                    var i = 3;
                    if (s >= o.bet_pos - 1 && s < o.bet_pos + 4) {
                        i = 5;
                        if (a.indexOf(n[r]) >= 0) {
                            i = 4
                        }
                    } else {
                        e.sel = false
                    }
                    e.status = i
                }, [parseInt(n[r]), r]))
            }
            if (o) {
                this.imgWordRisk.skin = "Cryptos/" + m.getPCOrMobilePath() + "/" + i.Instance.lang + "/ui/" + this.wordRishList[o.brm - 1]
            }
        }
    }
    Cryptos.View.CryptosCheckRoundSeed = I.CryptosCheckRoundSeed = U;
    class R extends p {
        constructor() {
            super()
        }
        registeEvent() {
            super.registeEvent();
            S.on("NC_SHOW_WIN_MONEY", this, this.onShowWinMoney);
            S.on("GLOABLE_USER_BALANCE_TOPUP", this, this.OnUserBalanceTopup);
            this.btnAni && this.btnAni.on(u.CLICK, this, this.onBtnAni)
        }
        OnUserBalanceTopup(t) {
            if (t != null && t != undefined) {
                this.balance += t
            }
        }
        onResize() {
            super.onResize()
        }
        onBtnAni(t = true) {
            w.Instance.animation_open = !w.Instance.animation_open;
            var s = "0";
            if (w.Instance.animation_open) {
                s = "1";
                this.btnAni && (this.btnAni.disabled = true);
                this.btnAni && (this.btnAni.mouseEnabled = true)
            } else {
                this.btnAni && (this.btnAni.disabled = false)
            }
            var e = i.Instance.ModuleName + "LOCALSTOREANICONFIF" + i.Instance.uid;
            m.setLocalStorageItem(e, s);
            S.dispatch("NC_ANIMATION_SET", [w.Instance.animation_open]);
            if (t && !this.isHor) {
                this.showAniWord()
            }
        }
        showAniWord() {
            var t = this;
            if (this.imgFast == null) {
                return
            }
            this.imgF.visible = false;
            if (w.Instance.animation_open) {
                this.imgFast.skin = i.Instance.ModuleName + "/" + m.getPCOrMobilePath() + "/" + i.Instance.lang + "/ui/img_fast2.png"
            } else {
                this.imgFast.skin = i.Instance.ModuleName + "/" + m.getPCOrMobilePath() + "/" + i.Instance.lang + "/ui/img_fast1.png"
            }
            this.imgF.visible = true;
            I.timer.clearAll(this.imgF);
            I.timer.once(1e3, this.imgF, function() {
                t.imgF.visible = false
            })
        }
        onEnable() {
            super.onEnable();
            this.balance = i.Instance.balance;
            var t = i.Instance.ModuleName + "LOCALSTOREANICONFIF" + i.Instance.uid;
            var s = m.getLocalStorageItem(t, "0");
            w.Instance.animation_open = s == "0";
            this.onBtnAni(false);
            this.imgF && (this.imgF.visible = false)
        }
        onGameOver(t) {}
        onShowWinMoney() {
            var t = w.Instance.FairSimple;
            if (t != null && t.rm != null && t.rm > 0) {
                if (t.rm >= t.bm) {
                    A.Instance.playSound("soft_win")
                }
                this.balance = i.Instance.balance;
                if (this._is_movie) {
                    this.hideWin();
                    I.timer.clear(this, this.hideWin);
                    I.timer.once(this.JY_TIME + 1, this, this.makeMovie, [t])
                } else {
                    this.makeMovie(t)
                }
            } else {
                I.timer.clear(this, this.hideWin);
                this.hideWin()
            }
        }
        onGameStart(t, s) {
            if (s && s.pm) {
                this.balance -= s.pm
            }
        }
        onShowMoney() {
            this.balance = i.Instance.balance
        }
        get balance() {
            return w.Instance.MyClientBalance
        }
        set balance(t) {
            w.Instance.MyClientBalance = t;
            this.lbBalance && (this.lbBalance.text = m.getCurrencyStrBySignal(m.trimMoney(w.Instance.MyClientBalance)))
        }
    }
    Cryptos.View.CryptosHeaderView = I.CryptosHeaderView = R;
    class E extends C {
        constructor() {
            super();
            this.status = 0;
            this._isOver = false;
            this.wcount = 40;
            this.hcount = 1;
            this.wh = 140;
            this.canSelectBallCount = 3;
            this._riskLevel = 0;
            this._selectedBallList = [];
            this.isFirstSelect = true;
            this.hasResultAnimation = false;
            this._isAnimation = false;
            this._startPos = 1;
            this.POPUP_NUMBER_KEYBOARD = 3;
            this._bonusId = -1;
            this.PAYOUT_POSITION = [370, 350, 310, 260, 220, 180, 150];
            this.ARROW_POSITION = [55, 35, 25, 25, 25, 25, 10];
            this.RATE_ARRAY = [20.507, 51.269, 15.38, 10.253, 1.7089, .8544, .0244];
            this.isShow = false;
            this.payoutIn = false;
            this.resultArr = [];
            this.step = 0;
            this._selStartPos = -1;
            this._isMovie = false;
            this._overBtn = [];
            this._outBtn = []
        }
        initConfig() {
            super.initConfig();
            this.FLASH_START_X = -410;
            this.FLASH_END_X = 590;
            this.AUTO_DELAY = 200;
            this.CODE_STRING = "rs256"
        }
        onEnable() {
            this.wh = l.onPC ? 156 : 166;
            super.onEnable()
        }
        onResize() {
            super.onResize();
            if (this.isHor) {} else {
                this.imgQuickBetMoney && (this.imgQuickBetMoney.y = 794 - this.offY / 2);
                this.btnSha && (this.btnSha.y = 130 + this.offY / 2);
                this.btnCopy && (this.btnCopy.y = 120 + this.offY / 2);
                this.imgCopy && (this.imgCopy.y = 120 + this.offY / 2);
                this.btnFresh && (this.btnFresh.y = 120 + this.offY / 2);
                this.btnRisk.y = 188 + this.offY / 2;
                this.imgRisk.y = 182 + this.offY / 2
            }
        }
        registeEvent() {
            super.registeEvent();
            S.on("NC_FSG_KENO_BALL_SELECTED", this, this.onBallSelect);
            S.on("NC_NUMBER_KEYBOARD_CHANGE", this, this.onStartNumberChange);
            S.on("NC_NUMBER_KEYBOARD_CLOSE", this, this.onStartNumberClose);
            if (this.isHor) {
                for (var t = 0; t < 7; t++) {
                    var s = this.nodeBonus.getChildByName("coefficient_" + t);
                    s.on(u.MOUSE_OVER, this, this.onMouseOverBonus, [t, s]);
                    s.on(u.MOUSE_OUT, this, this.onMouseOutBonus, [t])
                }
                this.btnPayout && this.btnPayout.on(u.MOUSE_OVER, this, this.onPayoutMouseOver);
                this.btnPayout && this.btnPayout.on(u.MOUSE_OUT, this, this.onPayoutMouseOut)
            }
        }
        onBallSelect(t, s) {}
        checkEverything() {
            this.checkCanSelect();
            this.refreshOddsNode();
            this.setBonusCellRate();
            this.setBonusCellStatus();
            this.refreshStartPos();
            this.clearGameCell()
        }
        checkCanSelect() {
            if (this._selectedBallList.length >= this.canSelectBallCount) {
                S.dispatch("NC_FSG_KENO_BALL_CAN_SELECT", [false])
            }
            if (this._selectedBallList.length < this.canSelectBallCount) {
                S.dispatch("NC_FSG_KENO_BALL_CAN_SELECT", [true])
            }
        }
        showBallBySelectList() {
            for (var t = 0; t < this.wcount * this.hcount; t++) {
                var s = this.pBox.getChildByName("ball" + t);
                if (s) {
                    var e = this._selectedBallList.indexOf(t) >= 0;
                    if (e) {
                        s.status = 1
                    } else {
                        s.status = 0
                    }
                }
            }
            this.setBonusCellStatus()
        }
        refreshOddsNode() {}
        onGetReady() {
            this._isAnimation = false;
            this.freshCode(true);
            this.changeAutoMode(false);
            this.checkEverything();
            this.showPayout(0, true);
            m.stopAllAction(this)
        }
        showResult() {
            this.resultArr = [];
            var t = w.Instance.FairSimple;
            var s = t.gs;
            this.clearGameCell();
            this.resultArr = s.split("");
            if (w.Instance.isAuto) {
                this.step = 4
            } else {
                this.step = 0
            }
            this.showResultByStep()
        }
        showResultByStep() {
            if (!this.resultArr) {
                var t = w.Instance.FairSimple.gs;
                this.resultArr = t.split("")
            }
            if (this.step < this.resultArr.length) {
                var s = this.resultArr.slice(this._startPos - 1, this._startPos + this.step);
                this.showBallResult(s)
            }
        }
        showBallResult(t) {
            var s = w.Instance.FairSimple;
            if (!t) {
                return
            }
            var e = t.concat();
            var i = {};
            for (var o = 0; o < e.length; o++) {
                var n = e[o];
                if (i[n] != null) {
                    i[n]++
                } else {
                    i[n] = 1
                }
            }
            var a = [];
            for (var r in i) {
                var l = i[r];
                var h = false;
                for (var o = 0; o < a.length; o++) {
                    if (a[o].count <= l) {
                        a.unshift({
                            key: r,
                            count: l
                        });
                        h = true;
                        break
                    }
                }
                if (h == false) {
                    a.push({
                        key: r,
                        count: l
                    })
                }
            }
            var m = [0, 0, 0, 0, 0];
            var u = [0, 0, 0, 0, 0];
            var c = 0;
            var p = 1;
            for (var o = 0; o < a.length; o++) {
                var C = a[o];
                if (C.count > 1) {
                    for (var b = 0; b < C.count; b++) {
                        m[c] = p;
                        u[c] = C.key;
                        c++
                    }
                    p++
                }
            }
            var d = -1;
            for (var o = 0; o < k.ICON_COEFFICIENT.length; o++) {
                if (k.ICON_COEFFICIENT[o].toString() == m.toString()) {
                    d = o;
                    break
                }
            }
            if (d >= 0) {
                for (var o = 0; o <= d; o++) {
                    var _ = this.getChildByName("nodeBonus");
                    var y = _.getChildByName("coefficient_" + o);
                    if (d == o) {
                        y.status = 1;
                        y.setIconColor(u, true);
                        this.showPayout(d, true)
                    } else {
                        y.status = 0;
                        y.index = o
                    }
                }
            }
            this.step++;
            if (this.step == 5) {
                this.showAll()
            }
            for (var o = 0; o < t.length; o++) {
                var g = this.pBox.getChildByName("ball" + (this._startPos - 1 + o));
                if (g) {
                    if (w.Instance.isAuto || !w.Instance.isAuto && o >= this.step - 1) {
                        g.imgId = parseInt(t[o]);
                        g.sel = true;
                        if (u.indexOf(t[o]) >= 0) {
                            A.Instance.playSound("match")
                        } else {
                            A.Instance.playSound("flip")
                        }
                    }
                    var f = 1;
                    if (u.indexOf(t[o]) >= 0) {
                        f = 2
                    }
                    g.status = f
                }
            }
            if (this.step < 5) {
                I.timer.once(300, this, this.showResultByStep)
            } else {
                this.isMovie = false;
                if (s && s.rm > 0) {
                    var v = this._autoMode ? 900 : 1500;
                    A.Instance.playSound("limbo_win");
                    S.dispatch("NC_SHOW_WIN_MONEY")
                } else {
                    A.Instance.playSound("losing")
                }
            }
        }
        showAll() {
            for (var t = 0; t < this.resultArr.length; t++) {
                var s = this.pBox.getChildByName("ball" + t);
                if (s) {
                    s.imgId = parseInt(this.resultArr[t]);
                    var e = 1;
                    s.status = e
                }
            }
        }
        onGameStart(t, s) {
            super.onGameStart();
            this.isMovie = true;
            this.spAllMask && (this.spAllMask.visible = true);
            this.btnBet && (this.btnBet.disabled = true);
            this.btnAuto && (this.btnAuto.disabled = true);
            this.btnDec && (this.btnDec.disabled = true);
            this.btnAdd && (this.btnAdd.disabled = true);
            this.btnBetCoin && (this.btnBetCoin.disabled = true);
            this.selStartPos = t.bet_pos;
            this.setBonusCellStatus()
        }
        onGameOver() {
            this.isFirstSelect = true;
            this.showResult()
        }
        onNext() {
            this.freshCode(true);
            this._isAnimation = false;
            if (w.Instance.isAuto) {
                this.refreshOddsNode();
                this.timer.once(175, this, this.freshLeftCount)
            } else {
                this.changeAutoMode(false)
            }
            this.clear()
        }
        onOpeOver(t = true) {}
        clear() {
            this.onOpeOver()
        }
        playButtonSound(t) {
            if (t == "btnBet") {} else {
                super.playButtonSound(t)
            }
        }
        doBet() {
            this.refreshOddsNode();
            this.setBonusCellRate();
            this.setOptDisabled(true);
            this.doCashOut()
        }
        onButtonClick(t) {
            var s = this;
            super.onButtonClick(t);
            switch (t) {
                case "btnAuto":
                    ;
                    var e = new G(c.create(this, function(t) {
                        w.Instance.single_win_list[0] = 0;
                        w.Instance.balance_change_list[0] = 0;
                        s._data.leftTime = t.leftTime;
                        s._data.totalWin = t.totalWin;
                        s._data.totalLose = t.totalLose;
                        s._data.perWin = t.perWin;
                        s._data.auto = t.auto;
                        s._data.bet_pos = t.bet_pos;
                        if (s._data.leftTime && s._data.leftTime > 0) {
                            s.changeAutoMode(true)
                        }
                    }), 1);
                    e.zOrder = 100;
                    b.Instance.NowScene.addChild(e);
                    break;
                case "btnStop":
                    this.timer.clear(this, this.freshLeftCount);
                    this.changeAutoMode(false);
                    break;
                case "btnSha":
                    this.onBtnCopy();
                    break;
                case "btnRisk":
                    this.imgRisk.visible = !this.imgRisk.visible;
                    this.btnClose && (this.btnClose.visible = this.imgRisk.visible);
                    break;
                case "btnLow":
                    this.riskLevel = 0;
                    this.imgRisk.visible = false;
                    this.btnClose && (this.btnClose.visible = this.imgRisk.visible);
                    break;
                case "btnNormal":
                    this.riskLevel = 1;
                    this.imgRisk.visible = false;
                    this.btnClose && (this.btnClose.visible = this.imgRisk.visible);
                    break;
                case "btnHigh":
                    this.riskLevel = 2;
                    this.imgRisk.visible = false;
                    this.btnClose && (this.btnClose.visible = this.imgRisk.visible);
                    break;
                case "btnKeyBoardStart":
                    if (this.keyboardStart) {
                        this.keyboardStart.visible = !this.keyboardStart.visible;
                        this.btnClose && (this.btnClose.visible = this.keyboardStart.visible);
                        if (this.keyboardStart.visible) {
                            this.keyboardStart.openKeyboard();
                            this.lblStart.text = "";
                            this.imgStartSelect && (this.imgStartSelect.visible = true);
                            this.popStatus = this.POPUP_NUMBER_KEYBOARD
                        }
                    }
                    break;
                case "btnLeft":
                    this.startPos--;
                    break;
                case "btnLeft2":
                    this.startPos -= 5;
                    break;
                case "btnLeft3":
                    this.startPos = 1;
                    break;
                case "btnRight":
                    this.startPos++;
                    break;
                case "btnRight2":
                    this.startPos += 5;
                    break;
                case "btnRight3":
                    this.startPos = 36;
                    break
            }
        }
        changeAutoMode(t = false) {
            this._autoMode = t;
            w.Instance.isAuto = this._autoMode;
            w.Instance.isAutoGaming = this._autoMode;
            I.timer.clear(this, this.doAutoPlay);
            S.dispatch("NC_AUTOMODE_CHANGE", [this._autoMode]);
            if (this._autoMode || this._isAnimation) {
                this.spAllMask && (this.spAllMask.visible = true);
                this.btnStop && (this.btnStop.visible = true);
                this.btnAuto && (this.btnAuto.visible = false);
                this.btnAuto && (this.btnAuto.disabled = true);
                this.btnBet && (this.btnBet.disabled = true);
                this.btnDec && (this.btnDec.disabled = true);
                this.btnAdd && (this.btnAdd.disabled = true);
                this.btnBetCoin && (this.btnBetCoin.disabled = true);
                this.btnFresh && (this.btnFresh.visible = false);
                this.btnCopy && (this.btnCopy.disabled = true);
                this.btnKeyBoard && (this.btnKeyBoard.disabled = true);
                this.btnRisk && (this.btnRisk.disabled = true);
                this.isMovie = this._isMovie;
                if (this._autoMode) {
                    this.freshLeftCount()
                } else if (!this._autoMode && this._isAnimation) {
                    this.btnStop && (this.btnStop.visible = false);
                    this.btnAuto && (this.btnAuto.visible = true)
                }
                S.dispatch("NC_FSG_KENO_BALL_MOUSE_ENABLE", [false])
            } else {
                this.spAllMask && (this.spAllMask.visible = false);
                this.btnStop && (this.btnStop.visible = false);
                this.btnAuto && (this.btnAuto.visible = true);
                this.btnAuto && (this.btnAuto.disabled = false);
                this.btnBet && (this.btnBet.disabled = false);
                this.btnDec && (this.btnDec.disabled = false);
                this.btnAdd && (this.btnAdd.disabled = false);
                this.btnBetCoin && (this.btnBetCoin.disabled = false);
                this.btnFresh && (this.btnFresh.visible = true);
                this.btnCopy && (this.btnCopy.disabled = false);
                this.btnKeyBoard && (this.btnKeyBoard.disabled = false);
                this.btnRisk && (this.btnRisk.disabled = false);
                this.setOptDisabled(false);
                this.btnKeyBoardStart.disabled = false;
                S.dispatch("NC_FSG_KENO_BALL_MOUSE_ENABLE", [true])
            }
        }
        changeAutoStatus() {
            if (w.Instance.isAuto == false) {
                w.Instance.autoArray = []
            }
        }
        doCashOut() {
            var s = this;
            this._isAnimation = true;
            var t = {};
            t.bet_pos = this._startPos;
            t.bet_money = m.formatNumber(this.betMoney);
            t.brm = this._riskLevel + 1;
            if (w.Instance.isAuto) {
                i.Instance.fsg_next_interval = 500
            } else {
                i.Instance.fsg_next_interval = 1500
            }
            d.Instance.doSendFairSimpleStartByData(t, c.create(this, function(t) {
                if (m.IsNoError(t)) {} else {
                    s._isAnimation = false;
                    s.changeAutoMode(false)
                }
                return
            }), !w.Instance.isAuto)
        }
        stopAutoMode() {
            if (w.Instance.isAuto) {
                this.changeAutoMode(false)
            }
        }
        doAutoPlay() {
            super.doAutoPlay();
            this.doCashOut()
        }
        initView() {
            super.initView();
            this.hideAllButton();
            this.riskLevel = parseInt(m.getLocalStorageItem("COOKIE_BRM", "1")) - 1;
            this.selStartPos = parseInt(m.getLocalStorageItem("COOKIE_START_POS", 1));
            this.startPos = this._selStartPos;
            this.changeAutoMode(false);
            for (var t = 0; t < this.wcount; t++) {
                for (var s = 0; s < this.hcount; s++) {
                    m.createView(B, c.create(this, function(t, s, e) {
                        this.pBox.addChild(e);
                        e.x = t * this.wh;
                        e.y = s * this.wh;
                        var i = t + s * this.wcount;
                        e.index = i;
                        e.name = "ball" + i;
                        e.sel = false;
                        e.setCannotClick();
                        l.onPC && e.scale(.8, .8, true)
                    }, [t, s]))
                }
            }
            this.initBonusCell();
            this.showPayout(0, true)
        }
        clearGameCell() {
            for (var t = 0; t < this.wcount; t++) {
                for (var s = 0; s < this.hcount; s++) {
                    var e = this.pBox.getChildByName("ball" + t);
                    e.status = 0;
                    e.sel = false
                }
            }
        }
        hideAllButton() {
            this.spMask && (this.spMask.visible = false);
            this.spAllMask && (this.spAllMask.visible = false);
            this.imgAuto && (this.imgAuto.visible = false);
            this.imgBet && (this.imgBet.visible = false);
            this.btnDec && (this.btnDec.disabled = false);
            this.btnAdd && (this.btnAdd.disabled = false);
            this.btnBetCoin && (this.btnBetCoin.disabled = false)
        }
        changeBetStatus() {
            this.hideAllButton()
        }
        closeAll() {
            if (this.POPUP_NUMBER_KEYBOARD == this.popStatus) {
                this.refreshStartPos()
            }
            super.closeAll();
            this.imgRisk.visible = false;
            this.imgStartSelect && (this.imgStartSelect.visible = false);
            this.keyboardStart && (this.keyboardStart.visible = false)
        }
        closeResultBonus() {}
        initBonusCell() {
            for (var t = 0; t < 7; t++) {
                var s = this.getChildByName("nodeBonus");
                var e = s.getChildByName("coefficient_" + t);
                e && (e.index = t);
                e && (e.status = 0)
            }
        }
        setBonusCellRate() {
            var t = k.REWARD_RATE[w.Instance.FairSimple.dt][this._riskLevel + 1];
            for (var s = 0; s < t.length; s++) {
                var e = this.getChildByName("nodeBonus");
                var i = e.getChildByName("coefficient_" + s);
                i && (i.rate = t[s]);
                i && (i.status = 0);
                i && (i.index = s)
            }
        }
        setBonusCellStatus(t = -1) {
            for (var s = 0; s < 7; s++) {
                var e = this.getChildByName("nodeBonus");
                var i = e.getChildByName("coefficient_" + s);
                if (t == s) {
                    i.status = 2
                } else {
                    i.status = t >= 0 ? 1 : 0
                }
                i.index = s
            }
        }
        setOptDisabled(t) {
            this.btnRisk && (this.btnRisk.disabled = t);
            this.btnCopy && (this.btnCopy.disabled = t);
            this.btnFresh && (this.btnFresh.visible = !t);
            this.btnKeyBoardStart && (this.btnKeyBoardStart.disabled = t);
            this.isMovie = this._isMovie
        }
        onStartNumberChange(t) {
            this.lblStart.text = t
        }
        onStartNumberClose() {
            this.closeAll()
        }
        refreshStartPos() {
            if (this.lblStart.text != "") {
                this.startPos = parseInt(this.lblStart.text)
            } else {
                this.lblStart.text = this._startPos.toString()
            }
        }
        makeStartMovie(t) {
            var s = this;
            _.clearTarget(this.pBox);
            this.imgKuang && _.clearTarget(this.imgKuang);
            this.isMovie = true;
            this.imgKuang && _.to(this.imgKuang, {
                x: 5 + this.wh * (this._selStartPos - t)
            }, 200);
            _.to(this.pBox, {
                x: 5 + this.wh * (1 - t)
            }, 200, null, c.create(this, function() {
                s.isMovie = false
            }))
        }
        showPayout(t = 0, s = false) {
            if (s) {
                this._bonusId = t
            }
            this.imgPayout && (this.imgPayout.visible = true);
            if (!this.imgPayout) return;
            this.imgPayout.visible = true;
            this.freshPayout(t)
        }
        freshPayout(t) {
            this.lblMul && (this.lblMul.text = this.RATE_ARRAY[t]);
            this.imgPayout.y = this.PAYOUT_POSITION[t];
            this.imgArrow.y = this.ARROW_POSITION[t];
            var s = k.REWARD_RATE[w.Instance.FairSimple.dt][this._riskLevel + 1];
            var e = s[t];
            this.lblBonus.text = m.getCurrencyStrBySignal(m.caculateAndFixed(this.betMoney, e, 3))
        }
        onMouseOverBonus(t, s) {
            if (w.Instance.isAuto) {
                return
            }
            e.deleteItemFromArray(this._outBtn, t);
            if (this._overBtn.indexOf(t) < 0) {
                this._overBtn.push(t)
            }
            this.isShow = false;
            this.showPayout(t)
        }
        onMouseOutBonus(t) {
            if (w.Instance.isAuto) {
                return
            }
            if (this._outBtn.indexOf(t) < 0) {
                this._outBtn.push(t)
            }
            if (!this.isShow && !this.payoutIn) {
                I.timer.frameOnce(10, this, this.checkShowPayout, [t])
            }
        }
        onPayoutMouseOver() {
            if (w.Instance.isAuto) {
                return
            }
            this.payoutIn = true
        }
        onPayoutMouseOut() {
            if (w.Instance.isAuto) {
                return
            }
            this.payoutIn = false;
            if (!this.isShow && !this.payoutIn) {
                I.timer.frameOnce(10, this, this.checkShowPayout)
            }
        }
        checkShowPayout(t) {
            if (this._outBtn.length >= this._overBtn.length && !this.isShow && !this.payoutIn) {
                this.isShow = true;
                this.showPayout(this._bonusId)
            }
        }
        set riskLevel(t) {
            if (t >= 0 && t < 3) {
                this._riskLevel = t;
                this.btnLow.disabled = this._riskLevel == 0;
                this.btnNormal.disabled = this._riskLevel == 1;
                this.btnHigh.disabled = this._riskLevel == 2;
                this.btnRisk.skin = "Cryptos/" + m.getPCOrMobilePath() + "/" + i.Instance.lang + "/ui/btn_risk_" + this._riskLevel + ".png";
                this.btnRisk.disabledSkin = "Cryptos/" + m.getPCOrMobilePath() + "/" + i.Instance.lang + "/ui/btn_risk_" + this._riskLevel + "3.png";
                this.refreshOddsNode();
                this.setBonusCellRate()
            }
        }
        get riskLevel() {
            return super.riskLevel
        }
        set betMoney(t) {
            super.betMoney = t
        }
        get betMoney() {
            return super.betMoney
        }
        set selStartPos(t) {
            this._selStartPos = t;
            if (this.imgKuang) {
                _.clearTarget(this.imgKuang);
                _.to(this.imgKuang, {
                    x: 5
                }, 200)
            }
        }
        get selStartPos() {
            return super.selStartPos
        }
        set isMovie(t) {
            this._isMovie = t;
            var s = this._isMovie || w.Instance.isAuto;
            this.btnLeft && (this.btnLeft.disabled = s);
            this.btnRight && (this.btnRight.disabled = s);
            this.btnLeft2 && (this.btnLeft2.disabled = s);
            this.btnRight2 && (this.btnRight2.disabled = s);
            this.btnLeft3 && (this.btnLeft3.disabled = s);
            this.btnRight3 && (this.btnRight3.disabled = s);
            this.btnKeyBoardStart && (this.btnKeyBoardStart.disabled = s);
            if (!s) {
                if (this._startPos <= 1) {
                    this.btnLeft && (this.btnLeft.disabled = true);
                    this.btnLeft2 && (this.btnLeft2.disabled = true);
                    this.btnLeft3 && (this.btnLeft3.disabled = true)
                } else if (this._startPos >= 36) {
                    this.btnRight && (this.btnRight.disabled = true);
                    this.btnRight2 && (this.btnRight2.disabled = true);
                    this.btnRight3 && (this.btnRight3.disabled = true)
                }
            }
        }
        get isMovie() {
            return super.isMovie
        }
        get startPos() {
            return this._startPos
        }
        set startPos(t) {
            if (t < 1) {
                t = 1
            } else if (t > 36) {
                t = 36
            }
            this._startPos = t;
            this.lblStart.text = this._startPos.toString();
            this.makeStartMovie(t)
        }
    }
    Cryptos.View.CryptosMyBetViewCell = I.CryptosMyBetViewCell = E;
    E.DELAY_RESULT = 300;
    E.CELL_COUNT = 5;
    E.MOVIE_TIME = 200;
    class O extends y {
        constructor() {
            super()
        }
        init() {
            super.init();
            if (this.btnScreen && this.btnScreen.visible == false) {
                this.imgK.height = 396
            }
        }
        onResize() {
            if (this.isHor) {
                var t = 1900 - I.stage._realDesignWidth;
                var s = 900 - I.stage.realDesignHeight;
                this.imgK && (this.imgK.x = 1851 - t / 2)
            } else {
                var t = 900 - I.stage._realDesignWidth;
                var s = 1900 - I.stage.realDesignHeight;
                this.imgK && (this.imgK.y = 1280 - s / 2)
            }
        }
    }
    Cryptos.View.CryptosUserInfo = I.CryptosUserInfo = O;
    new f;
    return I
})(window);